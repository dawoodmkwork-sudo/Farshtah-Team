@echo off
setlocal
title Farshtah setup
echo Installing Farshtah...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -Launch
if errorlevel 1 (
  echo.
  echo Setup didn't finish. The message above says why.
  pause
  exit /b 1
)
echo.
echo Done. Farshtah is opening, and it's on your Desktop and in the Start menu.
timeout /t 6 >nul
