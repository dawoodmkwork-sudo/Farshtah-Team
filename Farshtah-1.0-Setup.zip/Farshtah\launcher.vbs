' Farshtah: starts the app's helper (Node.js running server.js) with no console window.
' The helper opens the app's own window; if it's already running, it just opens another window.
' install.ps1 writes Node's path in place of __NODE__.
Option Explicit
Dim sh, fso, dir, node
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
node = "__NODE__"
If Not fso.FileExists(node) Then node = sh.ExpandEnvironmentStrings("%ProgramFiles%") & "\nodejs\node.exe"
If Not fso.FileExists(node) Then
  MsgBox "Farshtah needs Node.js, which isn't on this PC anymore." & vbCrLf & "Install Node.js from nodejs.org, then open Farshtah again.", vbExclamation, "Farshtah"
  WScript.Quit 1
End If
sh.CurrentDirectory = dir
sh.Run """" & node & """ """ & dir & "\server.js""", 0, False
