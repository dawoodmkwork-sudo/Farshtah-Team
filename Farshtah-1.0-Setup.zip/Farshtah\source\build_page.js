// build_page.js - template.html + r6core.js + desktop/logo.svg -> index.html (the published page), test.html (a local copy
// with a stand-in for the page's storage, for checking it in a browser without claude.ai) and desktop/app/index.html.
//   node build_page.js
const fs = require('fs'), path = require('path');
const here = __dirname;
const tpl = fs.readFileSync(path.join(here, 'template.html'), 'utf8');
const core = fs.readFileSync(path.join(here, 'r6core.js'), 'utf8');
if (!tpl.includes('/*__CORE__*/')) throw new Error('template has no /*__CORE__*/ slot');
if (!tpl.includes('<!--__LOGO__-->')) throw new Error('template has no <!--__LOGO__--> slot');
const logo = fs.readFileSync(path.join(here, 'desktop', 'logo.svg'), 'utf8').trim()
  .replace('<svg xmlns="http://www.w3.org/2000/svg"', '<svg class="logo" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg"');
if (!tpl.includes('/*__IMPORTER__*/')) throw new Error('template has no /*__IMPORTER__*/ slot');
const importer = fs.readFileSync(path.join(here, 'importer.js'), 'utf8');
const page = tpl.replace('/*__CORE__*/', () => core).replace('/*__IMPORTER__*/', () => importer).replace('<!--__LOGO__-->', () => logo);
fs.writeFileSync(path.join(here, 'index.html'), page);

const mock = `<script>
// stand-in for claude.use("db") / ("assets"): in memory, enough of the API for this page
(function () {
  const cols = new Map(), listeners = [], blobs = new Map();
  const col = p => { if (!cols.has(p)) cols.set(p, new Map()); return cols.get(p); };
  const snapDoc = (id, data) => ({ id, exists: data !== undefined, data: () => data && JSON.parse(JSON.stringify(data)), metadata: { fromCache: false, hasPendingWrites: false } });
  const notify = p => setTimeout(() => { for (const l of listeners) if (l.p === p) l.fn(); }, 15);
  const rid = () => Math.random().toString(16).slice(2, 10) + Math.random().toString(16).slice(2, 10);
  function docRef(p, id) {
    return { id, path: p + "/" + id,
      async get() { return snapDoc(id, col(p).get(id)); },
      async set(d) { if (window.__mockFail) throw { code: window.__mockFail }; col(p).set(id, JSON.parse(JSON.stringify(d))); notify(p); },
      async update(d) { const c = col(p).get(id); if (!c) throw { code: "invalid_argument" }; col(p).set(id, Object.assign({}, c, JSON.parse(JSON.stringify(d)))); notify(p); },
      async delete() { col(p).delete(id); notify(p); } };
  }
  function query(p) {
    return { doc: id => docRef(p, id || rid()),
      async add(d) { const r = docRef(p, rid()); await r.set(d); return r; },
      orderBy() { return query(p); }, where() { return query(p); }, limit() { return query(p); },
      async get() { const docs = [...col(p).entries()].map(([i, d]) => snapDoc(i, d)); return { docs, size: docs.length, empty: !docs.length, docChanges: () => [], metadata: { fromCache: false, hasPendingWrites: false } }; },
      onSnapshot(next) { const l = { p, fn: async () => next(await query(p).get()) }; listeners.push(l); setTimeout(l.fn, 30); return () => { const i = listeners.indexOf(l); if (i >= 0) listeners.splice(i, 1); }; } };
  }
  const db = { collection: p => query(p), doc: path => { const s = path.split("/"); return docRef(s.slice(0, -1).join("/"), s[s.length - 1]); } };
  const assets = {
    async upload(blob, o) { const id = (rid() + rid()).slice(0, 32); const url = URL.createObjectURL(blob); blobs.set(id, url); return { id, url, sizeBytes: blob.size, contentType: (o && o.type) || blob.type }; },
    async list() { return { assets: [], usage: {} }; }, async delete(id) { return { deleted: blobs.delete(id) }; } };
  window.__r6BlobUrl = id => blobs.get(id);
  window.__mock = { cols, blobs };
  window.claude = { use: async n => (n === "db" ? db : n === "assets" ? assets : null) };
})();
</script>`;
const test = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">' +
  '<style>:root{color-scheme:light;padding-top:env(safe-area-inset-top);padding-bottom:env(safe-area-inset-bottom)}body{margin:0;font:14px system-ui}img{max-width:100%}[hidden]{display:none!important}</style></head><body>' +
  mock + page + '</body></html>';
fs.writeFileSync(path.join(here, 'test.html'), test);

// desktop/app/index.html: the same page for the desktop app (desktop/server.js). claude.use("db") / ("assets") become calls to
// the local server, which keeps animations and references as files. The server writes its key in place of __R6_TOKEN__.
const shim = `<script>
(function () {
  const KEY = "__R6_TOKEN__";
  const err = (code, message) => Object.assign(new Error(message || code), { code });
  async function api(method, p, body, type) {
    const o = { method, headers: { "X-R6-Token": KEY } };
    if (body !== undefined) {
      o.body = type ? body : JSON.stringify(body);
      o.headers["Content-Type"] = type || "application/json";
      if (!type && o.body.length < 60000) o.keepalive = true; // lets a save finish while the window closes
    }
    let r; try { r = await fetch("/api/" + p, o); } catch (e) { throw err("unavailable", "The Farshtah helper isn't running"); }
    let j = null; try { j = await r.json(); } catch (e) {}
    if (!r.ok) throw err(r.status === 413 ? "too_large" : r.status === 404 ? "not_found" : r.status === 400 ? "invalid_argument" : "unavailable", j && j.error);
    return j;
  }
  const rid = () => [...crypto.getRandomValues(new Uint8Array(10))].map(b => b.toString(16).padStart(2, "0")).join("");
  const enc = encodeURIComponent;
  const watch = {}; // collection -> { rev, listeners:Set, docs }
  const W = col => watch[col] || (watch[col] = { rev: null, listeners: new Set(), docs: [], fails: 0 });
  const snapOf = docs => {
    const d = docs.map(x => ({ id: x.id, exists: true, data: () => JSON.parse(JSON.stringify(x.data)), metadata: { fromCache: false, hasPendingWrites: false } }));
    return { docs: d, size: d.length, empty: !d.length, docChanges: () => [], metadata: { fromCache: false, hasPendingWrites: false } };
  };
  async function refresh(col) {
    const w = W(col), j = await api("GET", "col/" + col);
    w.rev = j.rev; w.docs = j.docs;
    for (const l of w.listeners) { try { l.next(snapOf(w.docs)); } catch (e) { console.error(e); } }
  }
  const afterWrite = col => { if (W(col).listeners.size) refresh(col).catch(() => {}); };
  async function poll() { // picks up edits from another window, or files changed on disk
    for (const col of Object.keys(watch)) {
      const w = watch[col]; if (!w.listeners.size) continue;
      try { const j = await api("GET", "rev/" + col); w.fails = 0; if (j.rev !== w.rev) await refresh(col); }
      catch (e) { if (++w.fails === 2) for (const l of w.listeners) if (l.error) { try { l.error(e); } catch (x) {} } }
    }
    setTimeout(poll, 3000);
  }
  setTimeout(poll, 3000);
  function docRef(col, id) {
    return { id, path: col + "/" + id,
      async get() { const j = await api("GET", "col/" + col); const x = j.docs.find(d => d.id === id); return { id, exists: !!x, data: () => x ? JSON.parse(JSON.stringify(x.data)) : undefined }; },
      async set(d) { await api("PUT", "col/" + col + "/" + enc(id), d); afterWrite(col); },
      async update(d) { await api("PATCH", "col/" + col + "/" + enc(id), d); afterWrite(col); },
      async delete() { await api("DELETE", "col/" + col + "/" + enc(id)); afterWrite(col); } };
  }
  function collection(col) {
    const q = {
      doc: id => docRef(col, id || rid()),
      async add(d) { const r = docRef(col, rid()); await r.set(d); return r; },
      orderBy: () => q, where: () => q, limit: () => q,
      async get() { const j = await api("GET", "col/" + col); return snapOf(j.docs); },
      onSnapshot(next, error) {
        const l = { next, error }, w = W(col); w.listeners.add(l);
        refresh(col).catch(e => { if (error) error(e); });
        return () => w.listeners.delete(l);
      } };
    return q;
  }
  const db = { collection, doc: p => { const s = p.split("/"); return docRef(s.slice(0, -1).join("/"), s[s.length - 1]); } };
  const assets = {
    async upload(blob, o) { const type = (o && o.type) || blob.type || "application/octet-stream"; return api("POST", "assets", blob, type); },
    async list() { return { assets: [], usage: {} }; },
    async delete(id) { return api("DELETE", "assets/" + enc(id)); } };
  window.__r6BlobUrl = id => "/assets/" + enc(id);
  window.__r6Host = { desktop: true, maxUpload: 1024 * 1024 * 1024, maxDoc: 8 * 1024 * 1024, acceptAll: true,
    openFolder: sub => api("POST", "open-folder" + (sub ? "/" + enc(sub) : ""), {}).catch(() => {}),
    saveClip: async (blob, name) => { // into the clips folder inside the Farshtah folder
      const r = await fetch("/api/clips", { method: "POST", headers: { "X-R6-Token": KEY, "X-Clip-Name": enc(name), "Content-Type": blob.type || "application/octet-stream" }, body: blob });
      if (!r.ok) throw err("unavailable", "clip not saved");
      return r.json();
    } };
  window.claude = { use: async n => (n === "db" ? db : n === "assets" ? assets : null) };
  // this window's "still open" line to the helper; it shuts down a little after the last window closes
  try { new EventSource("/api/alive?k=" + KEY); } catch (e) {}
})();
</script>`;
const desk = '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
  '<link rel="icon" href="/icon.png"><style>body{margin:0;font:14px system-ui}img{max-width:100%}[hidden]{display:none!important}</style></head><body>' +
  shim + page + '</body></html>';
fs.mkdirSync(path.join(here, 'desktop', 'app'), { recursive: true });
fs.writeFileSync(path.join(here, 'desktop', 'app', 'index.html'), desk);
console.log('wrote index.html', (page.length / 1024).toFixed(1) + ' KB; test.html; desktop/app/index.html');
