# make_icon.ps1 - turns logo.svg (the Farshtah logo) into icon.png (512 px: the window's icon) and icon.ico (16-256 px:
# the shortcuts). Microsoft Edge draws the SVG (headless, nothing downloaded); Windows' System.Drawing makes the sizes.
#   powershell -NoProfile -ExecutionPolicy Bypass -File make_icon.ps1 [-Out <png to also write, e.g. a preview>]
param([string]$Out = "")
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$tmp = Join-Path $env:TEMP ("farshtah-icon-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
try {
  $svg = Get-Content (Join-Path $here "logo.svg") -Raw
  $html = "<!doctype html><html><head><style>html,body{margin:0;background:transparent}svg{display:block;width:512px;height:512px}</style></head><body>$svg</body></html>"
  $page = Join-Path $tmp "logo.html"
  [IO.File]::WriteAllText($page, $html, (New-Object System.Text.UTF8Encoding $false))
  $edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
  if (-not $edge) { throw "Microsoft Edge wasn't found" }
  $shot = Join-Path $tmp "logo512.png"
  $p = Start-Process -FilePath $edge -PassThru -WindowStyle Hidden -ArgumentList @("--headless=new", "--disable-gpu", "--hide-scrollbars",
    "--user-data-dir=`"$(Join-Path $tmp 'profile')`"", "--default-background-color=00000000", "--window-size=512,512",
    "--screenshot=`"$shot`"", ("file:///" + ($page -replace '\\', '/')))
  if (-not $p.WaitForExit(60000)) { $p.Kill(); throw "Edge took too long" }
  if (-not (Test-Path $shot)) { throw "Edge didn't draw the logo" }
  $big = [System.Drawing.Bitmap]::FromFile($shot)
  $big.Save((Join-Path $here "icon.png"), [System.Drawing.Imaging.ImageFormat]::Png)
  if ($Out) { $big.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png) }

  # icon.ico: PNG-compressed entries (read by Windows Vista and later at every size)
  $sizes = 16, 24, 32, 48, 64, 128, 256
  $pngs = @()
  foreach ($n in $sizes) {
    $b = New-Object System.Drawing.Bitmap $n, $n, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($b)
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.DrawImage($big, 0, 0, $n, $n); $g.Dispose()
    $ms = New-Object System.IO.MemoryStream
    $b.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png); $b.Dispose()
    $pngs += , $ms.ToArray()
  }
  $big.Dispose()
  $ico = New-Object System.IO.MemoryStream
  $w = New-Object System.IO.BinaryWriter $ico
  $w.Write([UInt16]0); $w.Write([UInt16]1); $w.Write([UInt16]$sizes.Count)
  $offset = 6 + 16 * $sizes.Count
  for ($i = 0; $i -lt $sizes.Count; $i++) {
    $n = $sizes[$i]; $dim = if ($n -ge 256) { 0 } else { $n }
    $w.Write([Byte]$dim); $w.Write([Byte]$dim); $w.Write([Byte]0); $w.Write([Byte]0)
    $w.Write([UInt16]1); $w.Write([UInt16]32); $w.Write([UInt32]$pngs[$i].Length); $w.Write([UInt32]$offset)
    $offset += $pngs[$i].Length
  }
  foreach ($p2 in $pngs) { $w.Write($p2) }
  $w.Flush()
  [IO.File]::WriteAllBytes((Join-Path $here "icon.ico"), $ico.ToArray())
  "wrote icon.png and icon.ico"
} finally {
  Start-Sleep -Milliseconds 300
  Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
}
