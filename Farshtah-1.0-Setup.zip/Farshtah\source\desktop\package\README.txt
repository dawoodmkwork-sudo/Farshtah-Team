Farshtah - an R6 animator for Roblox
Version __VERSION__. Free and open source (MIT license, see LICENSE).

INSTALL (Windows 10 or 11)
1. Unzip this folder anywhere (right-click the zip > Extract All).
2. Double-click "Install Farshtah.cmd".
   Windows may warn that it's from an unknown publisher (it isn't signed): click
   "More info" and then "Run anyway".
3. Farshtah opens. Next time, use the Farshtah shortcut on your Desktop or in
   the Start menu. You can delete the unzipped folder afterwards.

Nothing else is needed: Node.js comes inside (the node folder), and Microsoft Edge
is part of Windows. The first start needs internet (the 3D view's library loads
from a CDN); after that it's usually cached.

YOUR FILES
Everything you make is saved in Documents\Farshtah: animations, references,
backgrounds, models, settings, and recorded clips (in its clips folder).
Open > Show files opens that folder.

INTO ROBLOX STUDIO
Clip tab > "Into Roblox Studio":
- Copy for Claude: paste it to a Claude that's connected to Roblox Studio (the
  Roblox Studio MCP server). It installs the animation as a KeyframeSequence in
  your open place, in the folder you typed under "Where".
- Copy script: paste it into Studio's Command Bar instead (View > Command Bar).
The script checks itself before it creates anything, and backs up an older
animation with the same name to ServerStorage.AnimationBackups.

TEST IT LIKE IN GAME
The Test chip (or Play tab > Start test) lets you walk the rig around with
Roblox controls: WASD, Space, right-drag to look, scroll to zoom, Esc to stop.
The Play tab's blocks say what keys do, e.g. "When E is pressed: Play animation",
"When the test starts: Set WalkSpeed to 16".

UPDATE
Unzip the new version and run "Install Farshtah.cmd" again. Your animations are
never overwritten.

UNINSTALL
Start menu > Farshtah > Uninstall Farshtah. Your Documents\Farshtah folder stays.

SOURCE
The full source is in the "source" folder (see source\README.md).
