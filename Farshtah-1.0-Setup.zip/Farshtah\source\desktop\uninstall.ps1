# uninstall.ps1 - removes Farshtah: the app, its shortcuts and its private Edge profile.
# Your animations, references, backgrounds, settings and clips stay in the data folder (Documents\Farshtah unless you
# chose another); delete that folder yourself if you want them gone too.
#   powershell -NoProfile -ExecutionPolicy Bypass -File uninstall.ps1 [-Quiet]
param([switch]$Quiet)
$ErrorActionPreference = "Continue"
$appDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$stateDir = Join-Path $env:LOCALAPPDATA "Farshtah"
$wsh = New-Object -ComObject WScript.Shell
$dataDir = $null; $profileDir = Join-Path $stateDir "browser"
try { $cfg = Get-Content (Join-Path $appDir "config.json") -Raw | ConvertFrom-Json; $dataDir = $cfg.dataDir; if ($cfg.profileDir) { $profileDir = $cfg.profileDir } } catch {}
if (-not $Quiet) {
  if ($wsh.Popup("Remove Farshtah?`n`nYour animations, backgrounds and clips stay in:`n$dataDir", 0, "Farshtah", 4 + 32) -ne 6) { exit }
}
Set-Location $env:LOCALAPPDATA

# close the app's own Edge windows (only the ones using its private profile), then stop its helper
$wins = @(Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -and $_.CommandLine.Contains($profileDir) })
foreach ($w in $wins) { $p = Get-Process -Id $w.ProcessId -ErrorAction SilentlyContinue; if ($p -and $p.MainWindowHandle -ne 0) { [void]$p.CloseMainWindow() } }
for ($i = 0; $i -lt 30 -and $wins.Count; $i++) { Start-Sleep -Milliseconds 200; if (-not @($wins | Where-Object { Get-Process -Id $_.ProcessId -ErrorAction SilentlyContinue }).Count) { break } }
$wins | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
$state = Join-Path $stateDir "server.json"
if (Test-Path $state) {
  try {
    $s = Get-Content $state -Raw | ConvertFrom-Json
    $p = Get-Process -Id $s.pid -ErrorAction SilentlyContinue
    if ($p -and $p.ProcessName -eq "node") { Stop-Process -Id $s.pid -Force }
  } catch {}
}
Start-Sleep -Milliseconds 800

Remove-Item (Join-Path ([Environment]::GetFolderPath("Desktop")) "Farshtah.lnk") -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path ([Environment]::GetFolderPath("Programs")) "Farshtah") -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item $stateDir -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item $appDir -Recurse -Force -ErrorAction SilentlyContinue

$left = @($appDir, $stateDir) | Where-Object { Test-Path $_ }
$msg = if ($left.Count) { "Farshtah is mostly removed. Close any Farshtah window and delete these folders:`n" + ($left -join "`n") } else { "Farshtah was removed." }
if ($dataDir) { $msg += "`n`nYour animations are still in:`n$dataDir" }
if ($Quiet) { $msg } else { [void]$wsh.Popup($msg, 0, "Farshtah", 64) }
