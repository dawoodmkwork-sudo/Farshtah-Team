// import_r6.js - the command-line form of the Farshtah importer (the builder itself is importer.js, shared with the app).
//
//   node import_r6.js <anim.json> [--parent ServerStorage.AnimatorImports] [--name Wave] [--swing] [--fps 60] [--check] [--out file.luau]
//
// Writes one Luau script: run it in Roblox Studio with execute_luau in Edit mode (or paste it into the Command Bar).
//   --parent  where the KeyframeSequence goes (dot path from game; missing folders are created). An existing one with
//             the same name is copied to ServerStorage.AnimationBackups first.
//   --check   only check: the script bakes and compares in Studio, then stops without creating anything.
//   --swing   One Shot Duels weapon-swing attributes: ImpactTime (the "Impact" or "Hit" marker), StartAt, EndAt,
//             TorsoWeight 1, FullBody true.
const fs = require('fs'), path = require('path');
const { buildInstaller } = require('./importer.js');
const args = process.argv.slice(2);
const opt = (k, d) => { const i = args.indexOf('--' + k); return i >= 0 ? args[i + 1] : d; };
const flag = k => args.includes('--' + k);
const src = args.find(a => !a.startsWith('--') && !['--parent', '--name', '--fps', '--out'].includes(args[args.indexOf(a) - 1]));
if (!src) { console.error('usage: node import_r6.js <anim.json> [--parent P] [--name N] [--swing] [--fps 60] [--check] [--out f.luau]'); process.exit(1); }
const doc = JSON.parse(fs.readFileSync(src, 'utf8'));
const r = buildInstaller(doc, { parent: opt('parent'), name: opt('name'), fps: opt('fps'), swing: flag('swing'), check: flag('check') });
if (r.impactMissing) console.warn('note: --swing without an "Impact" marker: ImpactTime is left at 0.21');
const out = opt('out', path.join(path.dirname(src), r.name.replace(/\s+/g, '_') + '.install.luau'));
fs.writeFileSync(out, r.lua);
console.log(`wrote ${out} (${r.lua.length} chars, ${r.frames} frames to bake, key checksum ${r.sum.toFixed(6)})`);
