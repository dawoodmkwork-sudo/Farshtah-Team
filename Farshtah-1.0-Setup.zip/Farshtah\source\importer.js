// importer.js - a Farshtah animation (the document the app stores) -> one Luau script that builds its KeyframeSequence in
// Roblox Studio. Run the script with Studio's MCP tool execute_luau in Edit mode, or paste it into Studio's Command Bar.
// Shared by import_r6.js (Node) and the app's "Copy for Claude" / "Copy script" (browser). Needs r6core.js.
//
// Only the keys travel (small even for long clips); the script bakes them in Studio with the same math as the app
// (r6core.js, ported below) into dense linear keyframes, so the game plays exactly what the app showed, whatever
// easing the keys use. It checks itself first: a checksum guards the key data, and frames baked here by r6core.js must
// match the ones it bakes there, or it refuses to install.
//   buildInstaller(doc, { parent, name, swing, fps, check }) -> { lua, name, parent, frames, impactMissing }
//   parent  where it goes (dot path from game; missing folders are made). One of the same name is copied to
//           ServerStorage.AnimationBackups first.
//   check   only check: bake and compare in Studio (about 100 frames), then stop without creating anything.
//   swing   One Shot Duels weapon-swing attributes: ImpactTime (the "Impact" or "Hit" marker), StartAt, EndAt,
//           TorsoWeight 1, FullBody true.
(function (root) {
  "use strict";
  function make(R6) {
    function buildInstaller(doc, opts) {
      opts = opts || {};
      if (doc && doc.data && doc.data.tracks) doc = doc.data; // an ArtifactData "get" result
      const anim = R6.sanitize(doc);
      const parentPath = String(opts.parent || "ServerStorage.AnimatorImports");
      if (!/^[A-Za-z_][\w ]*(\.[A-Za-z_][\w ]*)*$/.test(parentPath)) throw new Error("bad place: " + parentPath);
      const kfsName = String(opts.name || anim.name || "Animation").replace(/[^\w \-.]/g, "").trim().slice(0, 60) || "Animation";
      const bakeFps = Math.min(Math.max(+opts.fps || 60, 10), 120);
      const swing = !!opts.swing, dry = !!opts.check;
    const num = v => { if (Math.abs(v) < 5e-7) return '0'; let s = (+v.toFixed(6)).toString(); return s.replace(/^(-?)0\./, '$1.'); };
    let sum = 0; const add = v => { sum += +num(v); return num(v); };
    const trackLua = R6.JOINTS.map(j => {
      const rows = anim.tracks[j].map(k => {
        const p = k.p || [0, 0, 0];
        return '{' + [k.t, ...k.q, ...p].map(add).join(',') + ',' + R6.EASE_CODE[k.e] + '}';
      });
      return `[${JSON.stringify(j)}]={${rows.join(',')}}`;
    }).join(',\n ');
    const markersLua = anim.markers.map(m => `{${JSON.stringify(m.name)},${add(m.t)}}`).join(',');
    add(anim.length);
    const impact = (anim.markers.find(m => /^(impact|hit)$/i.test(m.name)) || {}).t;

    // five frames baked here, which Studio's bake must reproduce
    const frames = R6.bake(anim, bakeFps);
    const pickIdx = dry ? frames.map((f, i) => i).filter(i => i % Math.max(1, Math.round(frames.length / 100)) === 0 || i === frames.length - 1) // --check: about 100 frames
      : [0, Math.round((frames.length - 1) * 0.25), Math.round((frames.length - 1) * 0.5), Math.round((frames.length - 1) * 0.75), frames.length - 1];
    const checkLua = pickIdx.map(i => {
      const f = frames[i];
      return '{' + i + ',' + R6.JOINTS.map(j => [...f[j].p, ...f[j].q].map(v => (+v.toFixed(6)).toString()).join(',')).join(',') + '}';
    }).join(',');


const lua = `-- Farshtah import: ${JSON.stringify(anim.name)} -> ${parentPath}.${kfsName}
local A={name=${JSON.stringify(kfsName)},title=${JSON.stringify(anim.name)},len=${num(anim.length)},fps=${bakeFps},loop=${anim.loop},priority=${JSON.stringify(anim.priority)},plant=${anim.plantFeet},
 markers={${markersLua}},
 tracks={${trackLua}}}
local EXPECT_SUM=${sum.toFixed(6)}
local CHECK={${checkLua}}
local PARENT=${JSON.stringify(parentPath)}
local SWING=${swing}
local DRY=${dry}
local IMPACT=${impact === undefined ? 'nil' : num(impact)}
local JOINTS={"Torso","Head","Right Arm","Left Arm","Right Leg","Left Leg"}
local PIVOT={Torso={0,0,0},Head={0,1,0},["Right Arm"]={1,.5,0},["Left Arm"]={-1,.5,0},["Right Leg"]={1,-1,0},["Left Leg"]={-1,-1,0}}
local S=math.sqrt(.5)
local C0Q={Torso={0,S,S,0},Head={0,S,S,0},["Right Arm"]={0,S,0,S},["Left Arm"]={0,-S,0,S},["Right Leg"]={0,S,0,S},["Left Leg"]={0,-S,0,S}}
local out={}
-- the key data arrived whole?
local sum=0
for _,j in JOINTS do for _,k in A.tracks[j] do for i=1,8 do sum+=k[i] end end end
for _,m in A.markers do sum+=m[2] end
sum+=A.len
if math.abs(sum-EXPECT_SUM)>1e-4 then error(string.format("checksum %.6f, expected %.6f: the key data was damaged on the way",sum,EXPECT_SUM)) end
table.insert(out,string.format("checksum ok (%.4f)",sum))
-- r6core.js, ported (keep in step with it)
local function qdot(a,b) return a[1]*b[1]+a[2]*b[2]+a[3]*b[3]+a[4]*b[4] end
local function qnorm(q) local n=math.sqrt(q[1]^2+q[2]^2+q[3]^2+q[4]^2) if n==0 then n=1 end return {q[1]/n,q[2]/n,q[3]/n,q[4]/n} end
local function qconj(q) return {-q[1],-q[2],-q[3],q[4]} end
local function qmul(a,b)
 local ax,ay,az,aw,bx,by,bz,bw=a[1],a[2],a[3],a[4],b[1],b[2],b[3],b[4]
 return {aw*bx+ax*bw+ay*bz-az*by, aw*by-ax*bz+ay*bw+az*bx, aw*bz+ax*by-ay*bx+az*bw, aw*bw-ax*bx-ay*by-az*bz}
end
local function qrot(q,v) local r=qmul(qmul(q,{v[1],v[2],v[3],0}),qconj(q)) return {r[1],r[2],r[3]} end
local function slerp(a,b,t)
 local d=qdot(a,b) local c=b
 if d<0 then d=-d c={-b[1],-b[2],-b[3],-b[4]} end
 if d>0.9995 then return qnorm({a[1]+(c[1]-a[1])*t,a[2]+(c[2]-a[2])*t,a[3]+(c[3]-a[3])*t,a[4]+(c[4]-a[4])*t}) end
 local th=math.acos(d) local s=math.sin(th) local wa,wb=math.sin((1-t)*th)/s,math.sin(t*th)/s
 return {a[1]*wa+c[1]*wb,a[2]*wa+c[2]*wb,a[3]*wa+c[3]*wb,a[4]*wa+c[4]*wb}
end
local function bounceOut(s)
 local n,d=7.5625,2.75
 if s<1/d then return n*s*s elseif s<2/d then s-=1.5/d return n*s*s+0.75 elseif s<2.5/d then s-=2.25/d return n*s*s+0.9375 end
 s-=2.625/d return n*s*s+0.984375
end
local EASE_IN={
 function(s) return 1-math.cos(s*math.pi/2) end, function(s) return s*s end, function(s) return s*s*s end, function(s) return s*s*s*s end,
 function(s) return s*s*s*s*s end, function(s) if s<=0 then return 0 end return 2^(10*s-10) end, function(s) return 1-math.sqrt(math.max(0,1-s*s)) end,
 function(s) return 2.70158*s*s*s-1.70158*s*s end,
 function(s) if s<=0 then return 0 elseif s>=1 then return 1 end return -(2^(10*s-10))*math.sin((s*10-10.75)*(2*math.pi/3)) end,
 function(s) return 1-bounceOut(1-s) end}
-- codes: 0 smooth, 1 linear, 2/3/4 cubic in/out/in-out, 5 constant, 6 spline, 10+ the other families (sine, quad, quart,
-- quint, expo, circ, back, elastic, bounce), three codes each: in, out, in-out
local FAM_OF={1,2,4,5,6,7,8,9,10}
local function ease(e,s)
 if e==5 then return 0 end
 local f,d
 if e>=2 and e<=4 then f,d=3,e-2 elseif e>=10 then f,d=FAM_OF[math.floor((e-10)/3)+1],(e-10)%3 else return s end
 local g=EASE_IN[f]
 if d==0 then return g(s) elseif d==1 then return 1-g(1-s) end
 if s<0.5 then return g(2*s)/2 end
 return 1-g(2-2*s)/2
end
local function sign(x) if x>0 then return 1 elseif x<0 then return -1 end return 0 end
local function prep(keys)
 local outk={} local prev=nil
 for _,k in keys do
  local q=qnorm({k[2],k[3],k[4],k[5]})
  if prev and qdot(prev,q)<0 then q={-q[1],-q[2],-q[3],-q[4]} end
  table.insert(outk,{t=k[1],v={q[1],q[2],q[3],q[4],k[6],k[7],k[8]},e=k[9]}) prev=q
 end
 local n=#outk
 for i=1,n do
  local m={0,0,0,0,0,0,0} local mu={0,0,0,0,0,0,0}
  if i>1 and i<n then
   local ta,tb=outk[i].t-outk[i-1].t,outk[i+1].t-outk[i].t
   if ta>1e-9 and tb>1e-9 then for c=1,7 do
    local a=(outk[i].v[c]-outk[i-1].v[c])/ta local b=(outk[i+1].v[c]-outk[i].v[c])/tb
    local s=(a*tb+b*ta)/(ta+tb) mu[c]=s
    if a*b>0 then local lim=3*math.min(math.abs(a),math.abs(b)) m[c]=sign(s)*math.min(math.abs(s),lim) end
   end end
  end
  outk[i].m=m outk[i].mu=mu
 end
 return outk
end
local function sampleP(pk,t)
 local n=#pk
 if n==0 then return nil end
 if t<=pk[1].t or n==1 then return table.clone(pk[1].v) end
 if t>=pk[n].t then return table.clone(pk[n].v) end
 local i=1 while i<n-1 and t>=pk[i+1].t do i+=1 end
 local a,b=pk[i],pk[i+1] local h=b.t-a.t local s=1 if h>1e-9 then s=(t-a.t)/h end
 if a.e==0 or a.e==6 then
  local ma,mb=a.m,b.m if a.e==6 then ma,mb=a.mu,b.mu end
  local s2=s*s local s3=s2*s local h00,h10,h01,h11=2*s3-3*s2+1,s3-2*s2+s,-2*s3+3*s2,s3-s2
  local v={} for c=1,7 do v[c]=h00*a.v[c]+h10*h*ma[c]+h01*b.v[c]+h11*h*mb[c] end
  local q=qnorm({v[1],v[2],v[3],v[4]})
  return {q[1],q[2],q[3],q[4],v[5],v[6],v[7]}
 end
 local u=ease(a.e,s) local q=slerp({a.v[1],a.v[2],a.v[3],a.v[4]},{b.v[1],b.v[2],b.v[3],b.v[4]},u)
 return {q[1],q[2],q[3],q[4],a.v[5]+(b.v[5]-a.v[5])*u,a.v[6]+(b.v[6]-a.v[6])*u,a.v[7]+(b.v[7]-a.v[7])*u}
end
local PT={} for _,j in JOINTS do PT[j]=prep(A.tracks[j]) end
local function plantedLeg(leg,torso)
 local ic=qconj(torso.q) local piv=PIVOT[leg]
 local r=qrot(ic,{piv[1]-torso.p[1],piv[2]-torso.p[2],piv[3]-torso.p[3]})
 return {q=ic,p={r[1]-piv[1],r[2]-piv[2],r[3]-piv[3]}}
end
local function evaluate(t)
 local pose={}
 for _,j in JOINTS do
  local r=sampleP(PT[j],t)
  if r then pose[j]={q={r[1],r[2],r[3],r[4]},p={r[5],r[6],r[7]}} else pose[j]={q={0,0,0,1},p={0,0,0}} end
 end
 if A.plant then pose["Right Leg"]=plantedLeg("Right Leg",pose.Torso) pose["Left Leg"]=plantedLeg("Left Leg",pose.Torso) end
 return pose
end
local function transformOf(j,q,p) local c=C0Q[j] local ic=qconj(c) return qnorm(qmul(qmul(ic,q),c)),qrot(ic,p) end
-- the bake: dense frames, end included
local times={}
local nf=math.max(1,math.floor(A.len*A.fps+0.5))
for i=0,nf do table.insert(times,math.min(i/A.fps,A.len)) end
if times[#times]<A.len-1e-6 then table.insert(times,A.len) end
local baked={}
for i,t in times do
 local pose=evaluate(t) local fr={}
 for _,j in JOINTS do local q,p=transformOf(j,pose[j].q,pose[j].p) fr[j]={q=q,p=p} end
 baked[i]=fr
end
-- does it match the page's own bake?
local worst=0
for _,c in CHECK do
 local fr=baked[c[1]+1]
 for ji,j in JOINTS do
  local o=1+(ji-1)*7
  local e={c[o+1],c[o+2],c[o+3],c[o+4],c[o+5],c[o+6],c[o+7]}
  local g=fr[j]
  worst=math.max(worst,math.abs(g.p[1]-e[1]),math.abs(g.p[2]-e[2]),math.abs(g.p[3]-e[3]),1-math.abs(qdot(g.q,{e[4],e[5],e[6],e[7]})))
 end
end
if worst>1e-4 then error(string.format("Studio's bake differs from the page's by %.6f: not installed",worst)) end
table.insert(out,string.format("bake matches the page (worst %.1e)",worst))
if DRY then local msg=table.concat(out," | ").." | check only: nothing installed" print("Farshtah: "..msg) return msg end
-- build the KeyframeSequence (outside the DataModel, parented once)
local kfs=Instance.new("KeyframeSequence")
kfs.Name=A.name kfs.Loop=A.loop
pcall(function() kfs.Priority=Enum.AnimationPriority[A.priority] end)
local L=Enum.PoseEasingStyle.Linear
local KF={}
for i,t in times do
 local kf=Instance.new("Keyframe") kf.Time=t
 local root=Instance.new("Pose") root.Name="HumanoidRootPart" root.Weight=0 root.Parent=kf
 local fr=baked[i]
 local tp=Instance.new("Pose") tp.Name="Torso" tp.Weight=1 tp.EasingStyle=L
 tp.CFrame=CFrame.new(fr.Torso.p[1],fr.Torso.p[2],fr.Torso.p[3],fr.Torso.q[1],fr.Torso.q[2],fr.Torso.q[3],fr.Torso.q[4]) tp.Parent=root
 for ji=2,6 do
  local j=JOINTS[ji] local v=fr[j]
  local ps=Instance.new("Pose") ps.Name=j ps.Weight=1 ps.EasingStyle=L
  ps.CFrame=CFrame.new(v.p[1],v.p[2],v.p[3],v.q[1],v.q[2],v.q[3],v.q[4]) ps.Parent=tp
 end
 kf.Parent=kfs KF[i]=kf
 if i%200==0 then task.wait() end
end
for _,m in A.markers do
 local bi,bd=1,math.huge
 for i,t in times do if math.abs(t-m[2])<bd then bi,bd=i,math.abs(t-m[2]) end end
 local mk=Instance.new("KeyframeMarker") mk.Name=m[1] mk.Value="" KF[bi]:AddMarker(mk)
end
kfs:SetAttribute("Source","Farshtah: "..A.title.." ("..#times.." frames baked at "..A.fps.." fps from its keys)")
kfs:SetAttribute("ImportedAt",os.date("!%Y-%m-%d %H:%M UTC"))
if SWING then
 kfs:SetAttribute("ImpactTime",IMPACT or 0.21) kfs:SetAttribute("StartAt",0) kfs:SetAttribute("EndAt",A.len)
 kfs:SetAttribute("TorsoWeight",1) kfs:SetAttribute("FullBody",true)
end
-- where it goes (folders made as needed); an existing one of the same name is backed up first
local parent=game
for seg in string.gmatch(PARENT,"[^%.]+") do
 local nxt
 if parent==game then local ok,svc=pcall(function() return game:GetService(seg) end) nxt=ok and svc or game:FindFirstChild(seg)
 else nxt=parent:FindFirstChild(seg) end
 if not nxt then nxt=Instance.new("Folder") nxt.Name=seg nxt.Parent=parent table.insert(out,"made "..nxt:GetFullName()) end
 parent=nxt
end
local old=parent:FindFirstChild(A.name)
if old then
 local SS=game:GetService("ServerStorage")
 local bk=SS:FindFirstChild("AnimationBackups") or Instance.new("Folder") bk.Name="AnimationBackups" bk.Parent=SS
 local copy=old:Clone() copy.Name=A.name.."_"..os.date("!%Y%m%d_%H%M%S") copy.Parent=bk
 old:Destroy() table.insert(out,"backed up the old one to "..copy:GetFullName())
end
kfs.Parent=parent
table.insert(out,string.format("%s: %d keyframes, %.3f s%s%s",kfs:GetFullName(),#times,A.len,#A.markers>0 and (", "..#A.markers.." marker(s)") or "",SWING and ", swing attributes set" or ""))
local msg=table.concat(out," | ") print("Farshtah: "..msg) return msg
`;
      return { lua, name: kfsName, parent: parentPath, frames: frames.length, sum, impactMissing: swing && impact === undefined };
    }
    return { buildInstaller };
  }
  if (typeof module !== "undefined" && module.exports) module.exports = make(require("./r6core.js"));
  else root.FarshtahImporter = make(root.R6);
})(this);
