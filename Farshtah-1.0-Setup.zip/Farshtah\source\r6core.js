/* r6core.js - the R6 rig and the animation math of the R6 Animator. One copy of this file is inlined into the page
 * (build_page.js) and the same file is required by import_r6.js, so what the page shows is what gets baked for Studio.
 *
 * Space conventions (Roblox's own: X right, Y up, Z back; a character faces -Z):
 *   a key's q = the joint's rotation in its PARENT part's space, about the joint's pivot   [x, y, z, w]
 *   a key's p = the joint's offset from its pivot, in the parent part's space              [x, y, z]
 *   (for the Torso the parent is the HumanoidRootPart and the pivot is its centre)
 * Motor6D.Transform / Pose.CFrame = C0rot^-1 * CFrame(p, q) * C0rot  (transformOf below)
 */
(function (root) {
  "use strict";
  const JOINTS = ["Torso", "Head", "Right Arm", "Left Arm", "Right Leg", "Left Leg"];
  const PARENT = { Torso: "HumanoidRootPart", Head: "Torso", "Right Arm": "Torso", "Left Arm": "Torso", "Right Leg": "Torso", "Left Leg": "Torso" };
  const MOTOR = { Torso: "RootJoint", Head: "Neck", "Right Arm": "Right Shoulder", "Left Arm": "Left Shoulder", "Right Leg": "Right Hip", "Left Leg": "Left Hip" };
  // pivot = C0's position in the parent part; offset = the part's centre from the pivot (= -C1's position)
  const PIVOT = { Torso: [0, 0, 0], Head: [0, 1, 0], "Right Arm": [1, 0.5, 0], "Left Arm": [-1, 0.5, 0], "Right Leg": [1, -1, 0], "Left Leg": [-1, -1, 0] };
  const OFFSET = { Torso: [0, 0, 0], Head: [0, 0.5, 0], "Right Arm": [0.5, -0.5, 0], "Left Arm": [-0.5, -0.5, 0], "Right Leg": [-0.5, -1, 0], "Left Leg": [0.5, -1, 0] };
  const S = Math.SQRT1_2;
  // the rotation shared by each motor's C0 and C1 (standard R6): RootJoint/Neck (-90, 0, 180), right side +90 about Y, left -90
  const C0Q = { Torso: [0, S, S, 0], Head: [0, S, S, 0], "Right Arm": [0, S, 0, S], "Left Arm": [0, -S, 0, S], "Right Leg": [0, S, 0, S], "Left Leg": [0, -S, 0, S] };
  const MIRROR = { Torso: "Torso", Head: "Head", "Right Arm": "Left Arm", "Left Arm": "Right Arm", "Right Leg": "Left Leg", "Left Leg": "Right Leg" };
  // Easings (how a key moves into the next one). "smooth": a curve through the keys that never overshoots them;
  // "spline": a freer curve through the keys (keeps its speed through them, so arcs flow, and may overshoot a little);
  // then the classic families, each with in / out / in-out. Cubic keeps its first ids ("in", "out", "inout").
  const FAMILIES = [["sine", "Sine"], ["quad", "Quad"], ["cubic", "Cubic"], ["quart", "Quart"], ["quint", "Quint"], ["expo", "Expo"],
    ["circ", "Circ"], ["back", "Back"], ["elastic", "Elastic"], ["bounce", "Bounce"]];
  const DIRS = [["in", "in"], ["out", "out"], ["inout", "in-out"]];
  const easeId = (f, d) => (f === "cubic" ? d : f + "-" + d);
  const EASES = [["smooth", "Smooth"], ["spline", "Spline"], ["linear", "Linear"], ["constant", "Constant"]];
  const EASE_CODE = { smooth: 0, linear: 1, in: 2, out: 3, inout: 4, constant: 5, spline: 6 };
  const EASE_FAMILY = {}; // id -> [family, direction]
  { let code = 10;
    for (const [f, fl] of FAMILIES) for (const [d, dl] of DIRS) {
      const id = easeId(f, d); EASES.push([id, fl + " " + dl]); EASE_FAMILY[id] = [f, d];
      if (f !== "cubic") EASE_CODE[id] = code++;
    } }
  const PRIORITIES = ["Core", "Idle", "Movement", "Action", "Action2", "Action3", "Action4"];
  const FORMAT = "r6-animator/1";

  // ---------------------------------------------------------------- quaternions [x, y, z, w]
  const qdot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3];
  function qnorm(q) { const n = Math.hypot(q[0], q[1], q[2], q[3]) || 1; return [q[0] / n, q[1] / n, q[2] / n, q[3] / n]; }
  const qconj = q => [-q[0], -q[1], -q[2], q[3]];
  function qmul(a, b) {
    const ax = a[0], ay = a[1], az = a[2], aw = a[3], bx = b[0], by = b[1], bz = b[2], bw = b[3];
    return [aw * bx + ax * bw + ay * bz - az * by, aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw, aw * bw - ax * bx - ay * by - az * bz];
  }
  function qrot(q, v) { const r = qmul(qmul(q, [v[0], v[1], v[2], 0]), qconj(q)); return [r[0], r[1], r[2]]; }
  function slerp(a, b, t) {
    let d = qdot(a, b), c = b;
    if (d < 0) { d = -d; c = [-b[0], -b[1], -b[2], -b[3]]; }
    if (d > 0.9995) return qnorm([a[0] + (c[0] - a[0]) * t, a[1] + (c[1] - a[1]) * t, a[2] + (c[2] - a[2]) * t, a[3] + (c[3] - a[3]) * t]);
    const th = Math.acos(d), s = Math.sin(th), wa = Math.sin((1 - t) * th) / s, wb = Math.sin(t * th) / s;
    return [a[0] * wa + c[0] * wb, a[1] * wa + c[1] * wb, a[2] * wa + c[2] * wb, a[3] * wa + c[3] * wb];
  }
  // Roblox CFrame.Angles(rx, ry, rz) (= Rx * Ry * Rz), degrees <-> quaternion
  function qFromEuler(xd, yd, zd) {
    const r = Math.PI / 180, hx = xd * r / 2, hy = yd * r / 2, hz = zd * r / 2;
    const qx = [Math.sin(hx), 0, 0, Math.cos(hx)], qy = [0, Math.sin(hy), 0, Math.cos(hy)], qz = [0, 0, Math.sin(hz), Math.cos(hz)];
    return qnorm(qmul(qmul(qx, qy), qz));
  }
  function eulerFromQ(q) { // XYZ order, degrees
    const [x, y, z, w] = qnorm(q);
    const m02 = 2 * (x * z + w * y), m12 = 2 * (y * z - w * x), m22 = 1 - 2 * (x * x + y * y);
    const m01 = 2 * (x * y - w * z), m00 = 1 - 2 * (y * y + z * z), m11 = 1 - 2 * (x * x + z * z), m21 = 2 * (y * z + w * x);
    const d = 180 / Math.PI, sy = Math.max(-1, Math.min(1, m02));
    const ry = Math.asin(sy);
    let rx, rz;
    if (Math.abs(sy) < 0.99999) { rx = Math.atan2(-m12, m22); rz = Math.atan2(-m01, m00); }
    else { rx = Math.atan2(m21, m11); rz = 0; }
    return [rx * d, ry * d, rz * d];
  }

  // ---------------------------------------------------------------- easing
  function bounceOut(s) {
    const n = 7.5625, d = 2.75;
    if (s < 1 / d) return n * s * s;
    if (s < 2 / d) { s -= 1.5 / d; return n * s * s + 0.75; }
    if (s < 2.5 / d) { s -= 2.25 / d; return n * s * s + 0.9375; }
    s -= 2.625 / d; return n * s * s + 0.984375;
  }
  const EASE_IN = { // each family's "in" curve; "out" and "in-out" are made from it
    sine: s => 1 - Math.cos(s * Math.PI / 2), quad: s => s * s, cubic: s => s * s * s, quart: s => s * s * s * s, quint: s => s * s * s * s * s,
    expo: s => (s <= 0 ? 0 : Math.pow(2, 10 * s - 10)), circ: s => 1 - Math.sqrt(Math.max(0, 1 - s * s)),
    back: s => 2.70158 * s * s * s - 1.70158 * s * s,
    elastic: s => (s <= 0 ? 0 : s >= 1 ? 1 : -Math.pow(2, 10 * s - 10) * Math.sin((s * 10 - 10.75) * (2 * Math.PI / 3))),
    bounce: s => 1 - bounceOut(1 - s),
  };
  function ease(e, s) {
    if (e === "constant") return 0;
    const fd = EASE_FAMILY[e]; if (!fd) return s;
    const g = EASE_IN[fd[0]];
    if (fd[1] === "in") return g(s);
    if (fd[1] === "out") return 1 - g(1 - s);
    return s < 0.5 ? g(2 * s) / 2 : 1 - g(2 - 2 * s) / 2;
  }

  // ---------------------------------------------------------------- tracks
  // A track is a time-sorted array of keys {t, q, p, e}; e is how the segment AFTER the key moves. "smooth" runs a
  // cubic through the keys (each value's slope from its neighbours, clamped so it never overshoots a key; flat at
  // turning points and at the ends) - the default, and what makes few keys read as fluid motion.
  function prep(keys) {
    const out = []; let prev = null;
    for (const k of keys) {
      let q = qnorm(k.q || [0, 0, 0, 1]);
      if (prev && qdot(prev, q) < 0) q = [-q[0], -q[1], -q[2], -q[3]];
      const p = k.p || [0, 0, 0];
      out.push({ t: k.t, v: [q[0], q[1], q[2], q[3], p[0], p[1], p[2]], e: k.e || "smooth" });
      prev = q;
    }
    const n = out.length;
    for (let i = 0; i < n; i++) {
      const m = [0, 0, 0, 0, 0, 0, 0], mu = [0, 0, 0, 0, 0, 0, 0]; // m: smooth (clamped), mu: spline (free)
      if (i > 0 && i < n - 1) {
        const ta = out[i].t - out[i - 1].t, tb = out[i + 1].t - out[i].t;
        if (ta > 1e-9 && tb > 1e-9) for (let c = 0; c < 7; c++) {
          const a = (out[i].v[c] - out[i - 1].v[c]) / ta, b = (out[i + 1].v[c] - out[i].v[c]) / tb;
          const s = (a * tb + b * ta) / (ta + tb);
          mu[c] = s;
          if (a * b <= 0) continue;
          const lim = 3 * Math.min(Math.abs(a), Math.abs(b));
          m[c] = Math.sign(s) * Math.min(Math.abs(s), lim);
        }
      }
      out[i].m = m; out[i].mu = mu;
    }
    return out;
  }
  function sampleP(pk, t) { // a prepared track -> [q4, p3] or null when it has no keys
    const n = pk.length;
    if (!n) return null;
    if (t <= pk[0].t || n === 1) return pk[0].v.slice();
    if (t >= pk[n - 1].t) return pk[n - 1].v.slice();
    let i = 0; while (i < n - 2 && t >= pk[i + 1].t) i++;
    const a = pk[i], b = pk[i + 1], h = b.t - a.t, s = h > 1e-9 ? (t - a.t) / h : 1;
    if (a.e === "smooth" || a.e === "spline") {
      const ma = a.e === "spline" ? a.mu : a.m, mb = a.e === "spline" ? b.mu : b.m;
      const s2 = s * s, s3 = s2 * s, h00 = 2 * s3 - 3 * s2 + 1, h10 = s3 - 2 * s2 + s, h01 = -2 * s3 + 3 * s2, h11 = s3 - s2;
      const v = []; for (let c = 0; c < 7; c++) v.push(h00 * a.v[c] + h10 * h * ma[c] + h01 * b.v[c] + h11 * h * mb[c]);
      const q = qnorm(v.slice(0, 4));
      return [q[0], q[1], q[2], q[3], v[4], v[5], v[6]];
    }
    const u = ease(a.e, s), q = slerp(a.v.slice(0, 4), b.v.slice(0, 4), u);
    return [q[0], q[1], q[2], q[3], a.v[4] + (b.v[4] - a.v[4]) * u, a.v[5] + (b.v[5] - a.v[5]) * u, a.v[6] + (b.v[6] - a.v[6]) * u];
  }
  function sample(keys, t) { const r = sampleP(prep(keys), t); return r ? { q: r.slice(0, 4), p: r.slice(4) } : null; }

  // feet planted: the hips undo the torso's turn and shift, so the legs keep their rest place in the root's space
  function plantedLeg(leg, torso) {
    const ic = qconj(torso.q), piv = PIVOT[leg];
    const r = qrot(ic, [piv[0] - torso.p[0], piv[1] - torso.p[1], piv[2] - torso.p[2]]);
    return { q: ic, p: [r[0] - piv[0], r[1] - piv[1], r[2] - piv[2]] };
  }

  // the whole pose at time t: {joint: {q, p}} (rest pose for a joint with no keys)
  function evaluate(anim, t, prepared) {
    const pt = prepared || prepAnim(anim), out = {};
    for (const j of JOINTS) {
      const r = sampleP(pt[j], t);
      out[j] = r ? { q: r.slice(0, 4), p: r.slice(4) } : { q: [0, 0, 0, 1], p: [0, 0, 0] };
    }
    if (anim.plantFeet) { out["Right Leg"] = plantedLeg("Right Leg", out.Torso); out["Left Leg"] = plantedLeg("Left Leg", out.Torso); }
    return out;
  }
  function prepAnim(anim) { const pt = {}; for (const j of JOINTS) pt[j] = prep((anim.tracks && anim.tracks[j]) || []); return pt; }

  // Motor6D.Transform (= Pose.CFrame) for a pose in parent space
  function transformOf(joint, q, p) {
    const c = C0Q[joint], ic = qconj(c);
    return { q: qnorm(qmul(qmul(ic, q), c)), p: qrot(ic, p) };
  }
  function mirrorPose(pose) { // left <-> right across the body's middle (x -> -x)
    const out = {};
    for (const j of JOINTS) {
      const s = pose[MIRROR[j]];
      out[j] = { q: [s.q[0], -s.q[1], -s.q[2], s.q[3]], p: [-s.p[0], s.p[1], s.p[2]] };
    }
    return out;
  }
  // dense frames for Studio: Pose CFrames at fps, end included
  function bake(anim, fps) {
    fps = fps || 60;
    const pt = prepAnim(anim), len = Math.max(anim.length || 0, 0), n = Math.max(1, Math.round(len * fps));
    const times = []; for (let i = 0; i <= n; i++) times.push(Math.min(i / fps, len));
    if (times[times.length - 1] < len - 1e-6) times.push(len);
    return times.map(t => {
      const pose = evaluate(anim, t, pt), fr = { t };
      for (const j of JOINTS) fr[j] = transformOf(j, pose[j].q, pose[j].p);
      return fr;
    });
  }
  function keyTimes(anim) { // every time any track has a key, sorted
    const s = new Set();
    for (const j of JOINTS) for (const k of ((anim.tracks && anim.tracks[j]) || [])) s.add(Math.round(k.t * 10000) / 10000);
    return [...s].sort((a, b) => a - b);
  }
  // a stored document -> a clean animation (unknown fields dropped, numbers checked, tracks sorted)
  function sanitize(doc) {
    const num = (v, d) => (typeof v === "number" && isFinite(v) ? v : d);
    const a = {
      format: FORMAT, name: String((doc && doc.name) || "Untitled").slice(0, 80), rig: "R6",
      length: Math.min(Math.max(num(doc && doc.length, 1), 0.05), 120), fps: (doc && doc.fps === 30) ? 30 : 60,
      loop: !!(doc && doc.loop), priority: PRIORITIES.includes(doc && doc.priority) ? doc.priority : "Action",
      plantFeet: !!(doc && doc.plantFeet), markers: [], tracks: {}, props: [],
    };
    const v3 = (v, d) => (Array.isArray(v) && v.length === 3 ? v.map((x, i) => num(x, d[i])) : d.slice());
    for (const pr of ((doc && Array.isArray(doc.props)) ? doc.props : [])) {
      if (!pr || typeof pr.model !== "string" || !JOINTS.includes(pr.joint)) continue;
      a.props.push({ id: String(pr.id || Math.random().toString(36).slice(2, 10)).slice(0, 40), model: pr.model.slice(0, 200), joint: pr.joint,
        p: v3(pr.p, [0, 0, 0]), r: v3(pr.r, [0, 0, 0]), s: v3(pr.s, [1, 1, 1]).map(x => Math.min(Math.max(x, 0.02), 50)), hide: !!pr.hide });
      if (a.props.length >= 24) break;
    }
    for (const m of ((doc && doc.markers) || [])) if (m && typeof m.t === "number") a.markers.push({ name: String(m.name || "Marker").slice(0, 40), t: Math.max(0, num(m.t, 0)) });
    a.markers.sort((x, y) => x.t - y.t);
    for (const j of JOINTS) {
      const src = (doc && doc.tracks && Array.isArray(doc.tracks[j])) ? doc.tracks[j] : [];
      const ks = [];
      for (const k of src) {
        if (!k || typeof k.t !== "number" || !Array.isArray(k.q) || k.q.length !== 4) continue;
        const key = { t: Math.max(0, k.t), q: qnorm(k.q.map(v => num(v, 0))), e: EASE_CODE[k.e] !== undefined ? k.e : "smooth" };
        if (Array.isArray(k.p) && k.p.length === 3 && k.p.some(v => v !== 0)) key.p = k.p.map(v => num(v, 0));
        ks.push(key);
      }
      ks.sort((x, y) => x.t - y.t);
      const dedup = []; for (const k of ks) { if (dedup.length && Math.abs(dedup[dedup.length - 1].t - k.t) < 1e-6) dedup[dedup.length - 1] = k; else dedup.push(k); }
      a.tracks[j] = dedup;
    }
    return a;
  }
  function round(v, d) { const f = Math.pow(10, d); return Math.round(v * f) / f; }
  function serialize(anim) { // what goes into the store (rounded so documents stay small)
    const a = sanitize(anim), out = Object.assign({}, a, { tracks: {} });
    for (const j of JOINTS) out.tracks[j] = a.tracks[j].map(k => {
      const o = { t: round(k.t, 4), q: k.q.map(v => round(v, 6)), e: k.e };
      if (k.p) o.p = k.p.map(v => round(v, 5));
      return o;
    });
    out.markers = a.markers.map(m => ({ name: m.name, t: round(m.t, 4) }));
    out.props = a.props.map(p => ({ id: p.id, model: p.model, joint: p.joint, p: p.p.map(v => round(v, 4)), r: p.r.map(v => round(v, 3)), s: p.s.map(v => round(v, 4)), hide: p.hide }));
    out.length = round(a.length, 4);
    return out;
  }

  const R6 = { JOINTS, PARENT, MOTOR, PIVOT, OFFSET, C0Q, MIRROR, EASES, EASE_CODE, EASE_FAMILY, FAMILIES, DIRS, easeId, PRIORITIES, FORMAT,
    qdot, qnorm, qconj, qmul, qrot, slerp, qFromEuler, eulerFromQ, ease, prep, sampleP, sample, plantedLeg,
    evaluate, prepAnim, transformOf, mirrorPose, bake, keyTimes, sanitize, serialize, round };
  if (typeof module !== "undefined" && module.exports) module.exports = R6; else root.R6 = R6;
})(typeof window !== "undefined" ? window : globalThis);
