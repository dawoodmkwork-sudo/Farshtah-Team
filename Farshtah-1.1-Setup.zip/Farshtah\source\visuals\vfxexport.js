// ======================================================================= Visuals+: into Roblox Studio
// The effect becomes a Model in the ForgeVFX attribute format (ParticleEmitters with EmitDelay / EmitCount / EmitDuration,
// mesh emitters as Model + Start / End, Beams, and Bloom on the Model), so One Shot Duels' ForgeVFX plays it as it is, and
// anyone else plays it with FarshtahVFX, a small player the script adds to ReplicatedStorage. Textures: Claude uploads them
// with the Studio tool upload_image (the Farshtah helper serves them at http://127.0.0.1:<port>/assets/<id>) and writes the
// ids into the script's TEX table; a texture left without an id shows Roblox's default sparkle.
const VX_TEX_VER = 1; // bump when a preset's drawing changes, so it uploads again
const VX_PLAYER_VERSION = 1;
const LUA_RESERVED = new Set("and break do else elseif end false for function if in local nil not or repeat return then true until while continue export type".split(" "));
function luaStr(s) { return '"' + String(s).replace(/[\\"]/g, c => "\\" + c).replace(/[\u0000-\u001f\u007f]/g, c => "\\" + c.charCodeAt(0)) + '"'; }
function luaVal(v) {
  if (typeof v === "number") return isFinite(v) ? String(+v.toFixed(5)) : "0";
  if (typeof v === "boolean") return v ? "true" : "false";
  if (typeof v === "string") return luaStr(v);
  if (Array.isArray(v)) return "{" + v.map(luaVal).join(", ") + "}";
  if (v && typeof v === "object") return "{" + Object.entries(v).filter(([, x]) => x !== undefined && x !== null).map(([k, x]) => (/^[A-Za-z_]\w*$/.test(k) && !LUA_RESERVED.has(k) ? k : "[" + luaStr(k) + "]") + " = " + luaVal(x)).join(", ") + "}";
  return "nil";
}
const VX_PLAYER_LUA = `-- FarshtahVFX (from Farshtah Visuals+): plays an effect Model, from a LocalScript.
--   local VFX = require(game.ReplicatedStorage.FarshtahVFX)
--   local fx = VFX.play(game.ReplicatedStorage.FarshtahEffects.Impact, CFrame.new(0, 3, 0))  -- fx:stop() ends it early
--   VFX.play(effect, cframe, { speed = 0.5 })                                                -- slow motion
-- What it reads (the ForgeVFX attribute format, plus the camera's feel):
--   ParticleEmitter   EmitCount at EmitDelay, then on (at its own Rate) for EmitDuration; TimeScale_Start -> _End over _Duration
--   Model + Start/End copies of Start that grow and move into End: EmitCount at EmitDelay, then Rate per second for EmitDuration,
--                     each over EffectDuration (EasingStyle / EasingDirection), fading Mesh_StartTransparency -> Transparency
--                     over Lifetime; MinInitRot / MaxInitRot, SpreadAngle and Part_RotSpeed_Start / _End turn them
--   Beam              on from EmitDelay for EmitDuration (0: to the end)
--   the effect Model  Bloom (Intensity, Size, Threshold) while it plays; CameraShake / FovPunch / Flash (amount, seconds, at);
--                     FlashColor; HitStop (seconds, at): the effect's own clock holds that long
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local Players = game:GetService("Players")
local M = {}
M.Version = ${VX_PLAYER_VERSION}
local live = {}
local bound, conn = false, nil
local bloom, flashGui, baseFov

local function num(i, k, d) local v = i:GetAttribute(k) if typeof(v) == "number" then return v end return d end
local function enum(e, name, d) local ok, v = pcall(function() return e[name] end) if ok and v then return v end return d end
local function count(i, d) local n = num(i, "EmitCount", d) local w = math.floor(n) if math.random() < n - w then w += 1 end return w end
local function folder()
	local f = workspace:FindFirstChild("FX_FarshtahVFX")
	if not f then f = Instance.new("Folder") f.Name = "FX_FarshtahVFX" f.Parent = workspace end
	return f
end

-- a source fires EmitCount at its EmitDelay, then Rate per second until EmitDelay + EmitDuration
local function source(eff, inst, spawn, onStart, onStop, defCount)
	local s = { inst = inst, delay = num(inst, "EmitDelay", 0), dur = num(inst, "EmitDuration", 0), rate = num(inst, "Rate", 0), spawn = spawn,
		onStart = onStart, onStop = onStop, defCount = defCount or 1, acc = 0, started = false, stopped = false }
	table.insert(eff.sources, s)
	eff.until_ = math.max(eff.until_, s.delay + s.dur)
	eff.longest = math.max(eff.longest, s.delay + s.dur)
	return s
end
local function stepSource(s, t, d)
	if s.stopped then if s.scale and t < (s.aliveUntil or 0) then s.scale(t) end return end
	if not s.started then
		if t < s.delay then return end
		s.started = true
		if s.onStart then s.onStart() end
		if s.spawn then for _ = 1, count(s.inst, s.defCount) do s.spawn() end end
	end
	if s.scale then s.scale(t) end
	if t > s.delay + s.dur then s.stopped = true if s.onStop then s.onStop() end return end
	if s.spawn and s.rate > 0 then s.acc += d * s.rate while s.acc >= 1 do s.acc -= 1 s.spawn() end end
end

local function particle(eff, e)
	local ts0, ts1, tsd = e:GetAttribute("TimeScale_Start"), e:GetAttribute("TimeScale_End"), num(e, "TimeScale_Duration", 0)
	local base = e.TimeScale
	local ramp = typeof(ts0) == "number" and typeof(ts1) == "number"
	local s
	s = source(eff, e, nil, function()
		s.scale(s.delay) -- (before the burst, so a slowed effect's burst is slowed too)
		local n = count(e, 1)
		if n > 0 then e:Emit(n) end
		if s.dur > 0 then e.Enabled = true end
	end, function() e.Enabled = false end)
	s.rate = 0 -- (a ParticleEmitter streams at its own Rate while it's on)
	s.scale = function(t)
		local v = base
		if ramp then v = ts0 + (ts1 - ts0) * (tsd > 0 and math.clamp((t - s.delay) / tsd, 0, 1) or 1) end
		e.TimeScale = math.clamp(v * eff.speed, 0, 1)
	end
	local slowest = math.max(ramp and math.min(ts0, ts1) or base, 0.05)
	s.aliveUntil = s.delay + s.dur + e.Lifetime.Max / slowest
	eff.longest = math.max(eff.longest, s.aliveUntil)
end

local function meshEmitter(eff, model, a, b)
	local ring = model:GetAttribute("Lifetime") ~= nil
	local dur = math.max(num(model, "EffectDuration", 0.3), 0.02)
	local p = { dur = dur, life = ring and math.max(num(model, "Lifetime", dur), dur) or dur,
		es = enum(Enum.EasingStyle, model:GetAttribute("EasingStyle") or "Quad", Enum.EasingStyle.Quad),
		ed = enum(Enum.EasingDirection, model:GetAttribute("EasingDirection") or "Out", Enum.EasingDirection.Out),
		ts = enum(Enum.EasingStyle, model:GetAttribute("TransparencyEasingStyle") or "Quad", Enum.EasingStyle.Quad),
		td = enum(Enum.EasingDirection, model:GetAttribute("TransparencyEasingDirection") or "Out", Enum.EasingDirection.Out),
		t0 = num(model, "Mesh_StartTransparency", 0), t1 = num(model, "Transparency", 1),
		rs0 = num(model, "Part_RotSpeed_Start", 0), rs1 = num(model, "Part_RotSpeed_End", 0) }
	local r0, r1, spread = model:GetAttribute("MinInitRot"), model:GetAttribute("MaxInitRot"), model:GetAttribute("SpreadAngle")
	local function rnd(x, y) return x + (y - x) * math.random() end
	local s = source(eff, model, function()
		local m = a:Clone()
		m.Transparency = p.t0
		local turn = CFrame.identity
		if typeof(r0) == "Vector3" and typeof(r1) == "Vector3" then
			turn = CFrame.Angles(math.rad(rnd(r0.X, r1.X)), math.rad(rnd(r0.Y, r1.Y)), math.rad(rnd(r0.Z, r1.Z)))
		end
		if typeof(spread) == "Vector3" and (spread.X ~= 0 or spread.Y ~= 0) then
			local sx, sy = math.abs(spread.X), math.abs(spread.Y)
			turn = CFrame.Angles(math.rad(rnd(-sx, sx)), 0, math.rad(rnd(-sy, sy))) * turn
		end
		local about = a.CFrame * turn * a.CFrame:Inverse() -- turned about Start's centre, both ends alike
		local ac, bc = about * a.CFrame, about * b.CFrame
		m.CFrame = ac
		m.Parent = eff.folder
		table.insert(eff.meshes, { m = m, a = a, b = b, ac = ac, bc = bc, t0 = eff.t, p = p })
	end, nil, nil, ring and 0 or 1)
	eff.longest = math.max(eff.longest, s.delay + s.dur + p.life)
end
local function stepMesh(r, t)
	local p, age = r.p, t - r.t0
	if age >= p.life then r.m:Destroy() return true end
	local k = TweenService:GetValue(math.clamp(age / p.dur, 0, 1), p.es, p.ed)
	r.m.Size = r.a.Size:Lerp(r.b.Size, k)
	local spin = CFrame.identity
	if p.rs0 ~= 0 or p.rs1 ~= 0 then spin = CFrame.Angles(0, math.rad((p.rs0 + (p.rs1 - p.rs0) * math.clamp(age / p.life, 0, 1) * 0.5) * age), 0) end
	r.m.CFrame = r.ac:Lerp(r.bc, k) * spin
	r.m.Transparency = math.clamp(p.t0 + (p.t1 - p.t0) * TweenService:GetValue(math.clamp(age / p.life, 0, 1), p.ts, p.td), 0, 1)
	return false
end

local function beam(eff, bm)
	local dur = num(bm, "EmitDuration", 0)
	bm.Enabled = false
	source(eff, bm, nil, function() bm.Enabled = true end, function() if dur > 0 then bm.Enabled = false end end)
end

local function release()
	if not bound then return end
	bound = false
	if conn then conn:Disconnect() conn = nil else pcall(function() RunService:UnbindFromRenderStep("FarshtahVFX") end) end
	local cam = workspace.CurrentCamera
	if baseFov and cam then cam.FieldOfView = baseFov end
	baseFov = nil
	if bloom then bloom:Destroy() bloom = nil end
	if flashGui then flashGui:Destroy() flashGui = nil end
end
local function step(dt)
	local shake, fov, flash, flashC, best, bv = 0, 0, 0, nil, 0, nil
	for i = #live, 1, -1 do
		local eff = live[i]
		if eff.dead then table.remove(live, i) continue end
		local d = dt * eff.speed
		if eff.hold > 0 then eff.hold -= d d = 0
		elseif eff.hitAt and eff.t < eff.hitAt and eff.t + d >= eff.hitAt then d = eff.hitAt - eff.t eff.hold = eff.hitDur eff.hitAt = nil end
		eff.t += d
		local t = eff.t
		for _, s in eff.sources do stepSource(s, t, d) end
		for j = #eff.meshes, 1, -1 do if stepMesh(eff.meshes[j], t) then table.remove(eff.meshes, j) end end
		local function k(v) if v and t >= v.Z and t <= v.Z + v.Y then return 1 - (t - v.Z) / v.Y end return 0 end
		if eff.shake then local x = k(eff.shake) shake = math.max(shake, eff.shake.X * x * x) end
		if eff.fov then local x = k(eff.fov) fov += eff.fov.X * x * x end
		if eff.flash then local x = eff.flash.X * k(eff.flash) if x > flash then flash = x flashC = eff.flashColor end end
		if eff.bloom then
			local w = math.clamp(t / 0.05, 0, 1) * math.clamp((eff.until_ + 0.4 - t) / 0.4, 0, 1)
			if w * eff.bloom.X > best then best = w * eff.bloom.X bv = eff.bloom end
		end
		if t > eff.longest + 0.3 then M.stop(eff) end
	end
	local cam = workspace.CurrentCamera
	if cam and RunService:IsClient() then
		if shake > 0 then
			local tt = os.clock()
			cam.CFrame *= CFrame.new(math.noise(tt * 23, 1.7) * shake * 2, math.noise(3.1, tt * 23) * shake * 2, 0) * CFrame.Angles(0, 0, math.noise(tt * 19, 7.3) * shake * 0.04)
		end
		if fov ~= 0 then baseFov = baseFov or cam.FieldOfView cam.FieldOfView = baseFov + fov
		elseif baseFov then cam.FieldOfView = baseFov baseFov = nil end
		if best > 0 and bv then
			if not (bloom and bloom.Parent == cam) then if bloom then bloom:Destroy() end bloom = Instance.new("BloomEffect") bloom.Name = "FarshtahVFXBloom" bloom.Parent = cam end
			bloom.Intensity = best bloom.Size = bv.Y bloom.Threshold = bv.Z
		elseif bloom then bloom:Destroy() bloom = nil end
		if flash > 0 then
			if not flashGui then
				local pg = Players.LocalPlayer and Players.LocalPlayer:FindFirstChildOfClass("PlayerGui")
				if pg then
					flashGui = Instance.new("ScreenGui") flashGui.Name = "FarshtahVFXFlash" flashGui.IgnoreGuiInset = true flashGui.DisplayOrder = 100 flashGui.ResetOnSpawn = false
					local f = Instance.new("Frame") f.Size = UDim2.fromScale(1, 1) f.BorderSizePixel = 0 f.Parent = flashGui
					flashGui.Parent = pg
				end
			end
			if flashGui then local f = flashGui:FindFirstChildOfClass("Frame") f.BackgroundColor3 = flashC or Color3.new(1, 1, 1) f.BackgroundTransparency = 1 - math.clamp(flash, 0, 1) flashGui.Enabled = true end
		elseif flashGui then flashGui.Enabled = false end
	end
	if #live == 0 then release() end
end
local function ensure()
	if bound then return end
	bound = true
	if RunService:IsClient() then RunService:BindToRenderStep("FarshtahVFX", Enum.RenderPriority.Camera.Value + 1, step)
	else conn = RunService.Heartbeat:Connect(step) end
end

function M.play(template, cf, opts)
	opts = opts or {}
	assert(typeof(template) == "Instance", "FarshtahVFX.play: give it the effect's Model")
	local root = template:Clone()
	local speed = math.clamp(tonumber(opts.speed) or 1, 0.02, 4)
	for _, d in root:GetDescendants() do
		if d:IsA("BasePart") then d.Anchored = true d.CanCollide = false d.CanQuery = false d.CanTouch = false
		elseif d:IsA("ParticleEmitter") then d.Enabled = false end
	end
	if root:IsA("Model") then root:PivotTo(cf or CFrame.identity) elseif root:IsA("BasePart") then root.CFrame = cf or CFrame.identity end
	local eff = { t = 0, speed = speed, sources = {}, meshes = {}, longest = 0, until_ = 0, hold = 0, folder = Instance.new("Folder") }
	eff.folder.Name = template.Name
	root.Parent = eff.folder
	local b = template:GetAttribute("Bloom")
	if typeof(b) == "Vector3" and b.X > 0 then eff.bloom = b end
	for key, field in { CameraShake = "shake", FovPunch = "fov", Flash = "flash" } do
		local v = template:GetAttribute(key)
		if typeof(v) == "Vector3" and v.X ~= 0 and v.Y > 0 then eff[field] = v eff.longest = math.max(eff.longest, v.Z + v.Y) end
	end
	local fc = template:GetAttribute("FlashColor")
	eff.flashColor = typeof(fc) == "Color3" and fc or Color3.new(1, 1, 1)
	local hs = template:GetAttribute("HitStop")
	if typeof(hs) == "Vector3" and hs.X > 0 then eff.hitAt = hs.Y eff.hitDur = hs.X end
	local skip = {}
	for _, m in root:GetDescendants() do
		if m:IsA("Model") then
			local a, z = m:FindFirstChild("Start"), m:FindFirstChild("End")
			if a and z and a:IsA("BasePart") and z:IsA("BasePart") then
				a.Transparency = 1 z.Transparency = 1 skip[a] = true skip[z] = true
				meshEmitter(eff, m, a, z)
			end
		end
	end
	for _, e in root:GetDescendants() do
		if e:IsA("ParticleEmitter") then
			local inside, p = false, e.Parent
			while p and p ~= root do if skip[p] then inside = true break end p = p.Parent end
			if not inside then particle(eff, e) end
		elseif e:IsA("Beam") then beam(eff, e) end
	end
	eff.folder.Parent = opts.parent or folder()
	eff.stop = M.stop
	table.insert(live, eff)
	if not opts.manual then ensure() end
	return eff
end
function M.stop(eff)
	if not eff or eff.dead then return end
	eff.dead = true
	if eff.folder then eff.folder:Destroy() end
end
M._step = step -- (steps every live effect by dt seconds: for testing with opts.manual)
return M
`;

function vxSafeName(s) { return String(s || "Effect").replace(/[^\w \-.]/g, "").trim().slice(0, 60) || "Effect"; }
function vxLuaPath(parent, name) { // game.ReplicatedStorage.FarshtahEffects["Ground slam"]
  return "game" + parent.split(".").concat([name]).map(seg => (/^[A-Za-z_]\w*$/.test(seg) ? "." + seg : "[" + luaStr(seg) + "]")).join("");
}
async function vxTexUrls(eff) { // each texture the effect uses (and has no Roblox id typed in): a URL Studio's uploader can fetch
  const keys = [...new Set(eff.layers.filter(L => L.on && L.type !== "mesh" && !L.texId).map(L => L.tex))];
  const out = []; let cache = {};
  try { cache = JSON.parse(store.get("farshtah.vx.texup") || "{}"); } catch (e) {}
  for (const k of keys) {
    let id = null;
    if (k.startsWith("u:")) { const d = vxCustom.get(k.slice(2)); id = d ? d.asset : null; }
    else if (HOST.desktop && assets) {
      const c = cache[k];
      if (c && c.v === VX_TEX_VER) { try { const r = await fetch("/assets/" + encodeURIComponent(c.id), { headers: { Range: "bytes=0-0" } }); if (r.ok) id = c.id; } catch (e) {} }
      if (!id) {
        try {
          const blob = await new Promise(r => vxTexture(k).canvas.toBlob(r, "image/png"));
          const up = await assets.upload(blob, { type: "image/png" }); id = up.id; cache[k] = { id, v: VX_TEX_VER };
        } catch (e) { id = null; }
      }
    }
    out.push({ key: k, name: vxTexture(k).name, url: id && HOST.desktop ? location.origin + "/assets/" + encodeURIComponent(id) : "" });
  }
  store.set("farshtah.vx.texup", JSON.stringify(cache));
  return out;
}
function vxStudioScript(eff, o) { // -> { lua, name, parent, layers, textures }
  o = o || {};
  const name = vxSafeName(o.name || eff.name), parent = String(o.parent || "ServerStorage.FarshtahEffects");
  if (!/^[A-Za-z_][\w ]*(\.[A-Za-z_][\w ]*)*$/.test(parent)) throw new Error("bad place: " + parent);
  const layers = eff.layers.filter(L => L.on).map(L => {
    const base = { type: L.type, name: L.name, p: L.p, r: L.r };
    if (L.type === "particles") return Object.assign(base, { tex: L.tex, texId: L.texId, color: L.color, transp: L.transp, size: L.size, squash: L.squash, light: L.light, bright: L.bright,
      lightInf: L.lightInf, z: L.z, orient: L.orient, life: L.life, speed: L.speed, spread: L.spread, rot: L.rot, rotSpeed: L.rotSpeed, accel: L.accel, drag: L.drag, locked: L.locked,
      rate: L.rate, delay: L.delay, count: L.count, duration: L.duration, dir: L.dir, shape: L.shape, shapeSize: L.shapeSize, shapeStyle: L.shapeStyle, shapeInOut: L.shapeInOut,
      shapePartial: L.shapePartial, flip: L.flip, ts: L.ts });
    if (L.type === "mesh") return Object.assign(base, { shape: L.shape, meshId: L.meshId, material: L.material, color: L.color, start: L.start, end: L.end, t0: L.t0, t1: L.t1,
      morph: L.morph, life: Math.max(L.life, L.morph), ease: L.ease, tease: L.tease, delay: L.delay, count: L.count, rate: L.rate, duration: L.duration, initMin: L.initMin, initMax: L.initMax, spread: L.spread, spin: L.spin });
    return Object.assign(base, { a: L.a, b: L.b, width: L.width, curve: L.curve, segments: L.segments, tex: L.tex, texId: L.texId, texMode: L.texMode, texLen: L.texLen, texSpeed: L.texSpeed,
      color: L.color, transp: L.transp, light: L.light, bright: L.bright, faceCam: L.faceCam, z: L.z, delay: L.delay, duration: L.duration });
  });
  const c = eff.cam, E = { layers };
  if (eff.bloom.on) E.bloom = [eff.bloom.intensity, eff.bloom.size, eff.bloom.threshold];
  if (c.shake[0] && c.shake[1] > 0) E.shake = c.shake;
  if (c.fov[0] && c.fov[1] > 0) E.fov = c.fov;
  if (c.flash[0] && c.flash[1] > 0) { E.flash = c.flash; E.flashColor = c.flashColor; }
  if (c.hitstop[0] > 0) E.hitstop = c.hitstop;
  const tex = o.textures || [];
  const texLines = tex.map(t => `\t[${luaStr(t.key)}] = "", -- ${t.name}${t.url ? ": " + t.url : ""}`).join("\n");
  const lua = `-- Farshtah Visuals+ export: ${luaStr(eff.name)} -> ${parent}.${name}
-- Builds the effect as a Model in the ForgeVFX attribute format: ParticleEmitters, mesh emitters (Model + Start / End) and
-- Beams. Play it from a LocalScript: require(game.ReplicatedStorage.FarshtahVFX).play(<the Model>, someCFrame)
local DRY = ${o.dry ? "true" : "false"}
local PARENT = ${luaStr(parent)}
local NAME = ${luaStr(name)}
local ADD_PLAYER = ${o.player === false ? "false" : "true"}
-- each texture's Roblox image id ("rbxassetid://123" or 123); one left empty shows Roblox's default sparkle
local TEX = {
${texLines}
}
local E = ${luaVal(E)}
local RING = ${luaStr(RING_MESH)}
local PLAYER_VERSION = ${VX_PLAYER_VERSION}
local PLAYER = [==[
${VX_PLAYER_LUA}]==]

local AssetService = game:GetService("AssetService")
local FALLBACK = "rbxasset://textures/particles/sparkles_main.dds"
local missing, made, meshFail = {}, { p = 0, m = 0, b = 0 }, 0
local function NS(k) local t = {} for _, p in k do table.insert(t, NumberSequenceKeypoint.new(p[1], p[2], p[3] or 0)) end return NumberSequence.new(t) end
local function CS(k) local t = {} for _, p in k do table.insert(t, ColorSequenceKeypoint.new(p[1], Color3.fromHex(p[2]))) end return ColorSequence.new(t) end
local function NR(a) return NumberRange.new(math.min(a[1], a[2]), math.max(a[1], a[2])) end
local function V3(a) return Vector3.new(a[1], a[2], a[3]) end
local function SZ(a) return Vector3.new(math.max(a[1], 0.05), math.max(a[2], 0.05), math.max(a[3], 0.05)) end
local function CF(p, r) return CFrame.new(p[1], p[2], p[3]) * CFrame.fromOrientation(math.rad(r[1]), math.rad(r[2]), math.rad(r[3])) end
local function texOf(key, id)
	local v = (id ~= nil and id ~= "") and id or TEX[key]
	if v == nil or v == "" then missing[key] = true return FALLBACK end
	v = tostring(v)
	if v:match("^%d+$") then return "rbxassetid://" .. v end
	return v
end
local function hide(p) p.Anchored = true p.CanCollide = false p.CanQuery = false p.CanTouch = false p.CastShadow = false p.Transparency = 1 end
local meshCache = {}
local function meshPart(id)
	if meshCache[id] == nil then
		local ok, mp = pcall(function() return AssetService:CreateMeshPartAsync(id) end)
		if not (ok and mp) then ok, mp = pcall(function() return AssetService:CreateMeshPartAsync(Content.fromUri(id)) end) end
		meshCache[id] = (ok and mp) or false
	end
	if meshCache[id] then return meshCache[id]:Clone() end
	return nil
end

local model = Instance.new("Model")
model.Name = NAME
local root = Instance.new("Part")
root.Name = "Root" root.Size = Vector3.new(1, 1, 1) root.CFrame = CFrame.identity hide(root) root.Parent = model
model.PrimaryPart = root
for _, L in E.layers do
	local lcf = CF(L.p, L.r)
	if L.type == "particles" then
		local holder
		if L.shape == "Point" then holder = Instance.new("Attachment") holder.CFrame = lcf holder.Parent = root
		else holder = Instance.new("Part") holder.Size = SZ(L.shapeSize) holder.CFrame = lcf hide(holder) holder.Parent = model end
		holder.Name = L.name
		local e = Instance.new("ParticleEmitter")
		e.Name = L.name
		e.Texture = texOf(L.tex, L.texId)
		e.Color = CS(L.color) e.Transparency = NS(L.transp) e.Size = NS(L.size) e.Squash = NS(L.squash)
		e.LightEmission = L.light e.LightInfluence = L.lightInf e.Brightness = L.bright e.ZOffset = L.z
		e.Orientation = Enum.ParticleOrientation[L.orient]
		e.Lifetime = NR(L.life) e.Speed = NR(L.speed) e.SpreadAngle = Vector2.new(L.spread[1], L.spread[2])
		e.Rotation = NR(L.rot) e.RotSpeed = NR(L.rotSpeed) e.Acceleration = V3(L.accel) e.Drag = L.drag e.LockedToPart = L.locked
		e.Rate = L.rate e.EmissionDirection = Enum.NormalId[L.dir]
		if L.shape ~= "Point" then
			e.Shape = Enum.ParticleEmitterShape[L.shape] e.ShapeStyle = Enum.ParticleEmitterShapeStyle[L.shapeStyle]
			e.ShapeInOut = Enum.ParticleEmitterShapeInOut[L.shapeInOut] e.ShapePartial = L.shapePartial
		end
		e.FlipbookLayout = Enum.ParticleFlipbookLayout[L.flip.layout]
		if L.flip.layout ~= "None" then e.FlipbookMode = Enum.ParticleFlipbookMode[L.flip.mode] e.FlipbookFramerate = NR(L.flip.fps) e.FlipbookStartRandom = L.flip.startRandom end
		e.TimeScale = L.ts.on and L.ts.start or 1
		e.Enabled = false
		e:SetAttribute("EmitDelay", L.delay) e:SetAttribute("EmitCount", L.count) e:SetAttribute("EmitDuration", L.duration)
		if L.ts.on then e:SetAttribute("TimeScale_Start", L.ts.start) e:SetAttribute("TimeScale_End", L.ts["end"]) e:SetAttribute("TimeScale_Duration", L.ts.duration) end
		e.Parent = holder
		made.p += 1
	elseif L.type == "mesh" then
		local mm = Instance.new("Model")
		mm.Name = L.name
		local function make(partName, tr)
			local p
			if L.shape == "Ring" or L.shape == "Mesh" then
				local id = L.shape == "Ring" and RING or L.meshId
				if id ~= "" then p = meshPart(id) end
				if not p then meshFail += 1 end
			end
			if not p then
				p = Instance.new("Part")
				p.Shape = (L.shape == "Sphere" and Enum.PartType.Ball) or ((L.shape == "Cylinder" or L.shape == "Ring") and Enum.PartType.Cylinder) or Enum.PartType.Block
				if L.shape == "Wedge" then pcall(function() p.Shape = Enum.PartType.Wedge end) end
			end
			local s, cf = V3(tr.size), lcf * CF(tr.p, tr.r)
			if p:IsA("Part") and p.Shape == Enum.PartType.Cylinder then s = Vector3.new(s.Y, s.X, s.Z) cf = cf * CFrame.Angles(0, 0, math.rad(90)) end -- (a Roblox cylinder lies along X)
			p.Name = partName
			p.Size = Vector3.new(math.max(s.X, 0.001), math.max(s.Y, 0.001), math.max(s.Z, 0.001))
			p.CFrame = cf
			p.Material = Enum.Material[L.material]
			p.Color = Color3.fromHex(L.color)
			hide(p)
			p.Parent = mm
		end
		make("Start", L.start) make("End", L["end"])
		mm:SetAttribute("Lifetime", L.life) mm:SetAttribute("EffectDuration", L.morph)
		mm:SetAttribute("EmitDelay", L.delay) mm:SetAttribute("EmitCount", L.count) mm:SetAttribute("Rate", L.rate) mm:SetAttribute("EmitDuration", L.duration)
		mm:SetAttribute("EasingStyle", L.ease[1]) mm:SetAttribute("EasingDirection", L.ease[2])
		mm:SetAttribute("TransparencyEasingStyle", L.tease[1]) mm:SetAttribute("TransparencyEasingDirection", L.tease[2])
		mm:SetAttribute("Mesh_StartTransparency", L.t0) mm:SetAttribute("Transparency", L.t1)
		if V3(L.initMin).Magnitude > 0 or V3(L.initMax).Magnitude > 0 then mm:SetAttribute("MinInitRot", V3(L.initMin)) mm:SetAttribute("MaxInitRot", V3(L.initMax)) end
		if L.spread[1] ~= 0 or L.spread[2] ~= 0 then mm:SetAttribute("SpreadAngle", Vector3.new(L.spread[1], L.spread[2], 0)) end
		if L.spin[1] ~= 0 or L.spin[2] ~= 0 then mm:SetAttribute("Part_RotSpeed_Start", L.spin[1]) mm:SetAttribute("Part_RotSpeed_End", L.spin[2]) end
		mm.Parent = model
		made.m += 1
	elseif L.type == "beam" then
		local a0 = Instance.new("Attachment") a0.Name = L.name .. " A" a0.CFrame = lcf * CFrame.new(V3(L.a)) a0.Parent = root
		local a1 = Instance.new("Attachment") a1.Name = L.name .. " B" a1.CFrame = lcf * CFrame.new(V3(L.b)) a1.Parent = root
		local b = Instance.new("Beam")
		b.Name = L.name b.Attachment0 = a0 b.Attachment1 = a1
		b.Width0 = L.width[1] b.Width1 = L.width[2] b.CurveSize0 = L.curve[1] b.CurveSize1 = L.curve[2] b.Segments = L.segments
		b.Texture = texOf(L.tex, L.texId) b.TextureMode = Enum.TextureMode[L.texMode] b.TextureLength = L.texLen b.TextureSpeed = L.texSpeed
		b.Color = CS(L.color) b.Transparency = NS(L.transp) b.LightEmission = L.light b.LightInfluence = 0 b.Brightness = L.bright
		b.FaceCamera = L.faceCam b.ZOffset = L.z
		b:SetAttribute("EmitDelay", L.delay) b:SetAttribute("EmitDuration", L.duration)
		b.Parent = root
		made.b += 1
	end
end
if E.bloom then model:SetAttribute("Bloom", V3(E.bloom)) end
if E.shake then model:SetAttribute("CameraShake", V3(E.shake)) end
if E.fov then model:SetAttribute("FovPunch", V3(E.fov)) end
if E.flash then model:SetAttribute("Flash", V3(E.flash)) model:SetAttribute("FlashColor", Color3.fromHex(E.flashColor)) end
if E.hitstop then model:SetAttribute("HitStop", Vector3.new(E.hitstop[1], E.hitstop[2], 0)) end
model:SetAttribute("Source", "Farshtah Visuals+: " .. ${luaStr(eff.name)})
if made.p + made.m + made.b ~= #E.layers then error(string.format("Farshtah Visuals+: built %d layers of %d", made.p + made.m + made.b, #E.layers)) end
local nmiss = 0 for _ in missing do nmiss += 1 end
local summary = string.format("%d emitter%s, %d mesh emitter%s, %d beam%s", made.p, made.p == 1 and "" or "s", made.m, made.m == 1 and "" or "s", made.b, made.b == 1 and "" or "s")
if nmiss > 0 then summary ..= string.format(" | %d texture%s without an id (Roblox's sparkle for now)", nmiss, nmiss == 1 and "" or "s") end
if meshFail > 0 then summary ..= string.format(" | %d mesh%s didn't load (a cylinder stands in)", meshFail, meshFail == 1 and "" or "es") end
if DRY then model:Destroy() local msg = "Farshtah Visuals+: " .. summary .. " | check only: nothing added" print(msg) return msg end
-- where it goes (folders made as needed); an older one with this name is moved to ServerStorage.EffectBackups first
local out = {}
local parent = game
for seg in string.gmatch(PARENT, "[^%.]+") do
	local nxt
	if parent == game then local ok, svc = pcall(function() return game:GetService(seg) end) nxt = ok and svc or game:FindFirstChild(seg)
	else nxt = parent:FindFirstChild(seg) end
	if not nxt then nxt = Instance.new("Folder") nxt.Name = seg nxt.Parent = parent table.insert(out, "made " .. nxt:GetFullName()) end
	parent = nxt
end
local old = parent:FindFirstChild(NAME)
if old then
	local SS = game:GetService("ServerStorage")
	local bk = SS:FindFirstChild("EffectBackups") or Instance.new("Folder") bk.Name = "EffectBackups" bk.Parent = SS
	local copy = old:Clone() copy.Name = NAME .. "_" .. os.date("!%Y%m%d_%H%M%S") copy.Parent = bk
	old:Destroy() table.insert(out, "backed up the old one to " .. copy:GetFullName())
end
model.Parent = parent
table.insert(out, 1, model:GetFullName() .. ": " .. summary)
if ADD_PLAYER then
	local RS = game:GetService("ReplicatedStorage")
	local pm = RS:FindFirstChild("FarshtahVFX")
	if not (pm and pm:IsA("ModuleScript") and (pm:GetAttribute("Version") or 0) >= PLAYER_VERSION) then
		local ok = pcall(function()
			if not (pm and pm:IsA("ModuleScript")) then if pm then pm.Name = "FarshtahVFX_old" end pm = Instance.new("ModuleScript") pm.Name = "FarshtahVFX" end
			pm.Source = PLAYER pm:SetAttribute("Version", PLAYER_VERSION) pm.Parent = RS
		end)
		table.insert(out, ok and "player added: ReplicatedStorage.FarshtahVFX" or "couldn't add the player (paste the script into the Command Bar instead)")
	end
end
local msg = "Farshtah Visuals+: " .. table.concat(out, " | ")
print(msg)
return msg
`;
  return { lua, name, parent, layers: layers.length, textures: tex };
}
function vxHandoff(r) { // what you paste to your Claude (any Claude with the Roblox Studio connector)
  const fence = "```", up = r.textures.filter(t => t.url);
  const steps = [];
  if (up.length) steps.push(`1. Upload these images with the Roblox Studio tool upload_image, in one call: ${up.map(t => t.url).join(" ")}`,
    `2. In the script below, put each returned rbxassetid into the TEX table, next to the key whose comment has that URL. Change nothing else.`,
    `3. Run the script with the Roblox Studio tool execute_luau (datamodel_type "Edit"), in one call. If more than one Studio window is open, ask me which one first.`);
  else steps.push(`Run the script below with the Roblox Studio tool execute_luau (datamodel_type "Edit"), exactly as it is, in one call. If more than one Studio window is open, ask me which one first.`);
  return [`Please add this effect to my Roblox Studio place.`, ``,
    `It's "${VX.eff.name}", a VFX made in Farshtah Visuals+.`, ...steps, ``,
    `The script builds the effect as ${r.parent}.${r.name} (missing folders are made; an older one with that name is moved to ServerStorage.EffectBackups) and adds ReplicatedStorage.FarshtahVFX, the module that plays it. It returns one line; tell me what it says, and how to play it: ${vxLuaPath(r.parent, r.name).replace(/^game/, "require(game.ReplicatedStorage.FarshtahVFX).play(game")}, CFrame.new(0, 3, 0)) from a LocalScript.`.replace("play(game.", "play(game."),
    ``, fence + "lua", r.lua.replace(/\n+$/, ""), fence, ``].join("\n");
}
function vxExportOpts() { return { parent: $("vxExpParent").value.trim() || "ReplicatedStorage.FarshtahEffects", name: $("vxExpName").value.trim() || VX.eff.name, player: $("vxExpPlayer").checked }; }
function vxOpenExport() {
  if (!VX.eff.layers.some(L => L.on)) return toast("Add a layer first");
  vxClosePop(); closeMenu(); $("vxExpBack").hidden = false;
  $("vxExpParent").value = store.get("farshtah.vx.parent") || $("vxExpParent").value;
  $("vxExpName").value = vxSafeName(VX.eff.name);
  vxRenderExportInfo(); $("vxCopyClaude").focus();
}
function vxRenderExportInfo() {
  const o = vxExportOpts(), n = new Set(VX.eff.layers.filter(L => L.on && L.type !== "mesh" && !L.texId).map(L => L.tex)).size;
  let path = ""; try { path = vxLuaPath(o.parent, vxSafeName(o.name)); } catch (e) { path = "game." + o.parent; }
  $("vxExpUse").textContent = `require(game.ReplicatedStorage.FarshtahVFX).play(${path}, CFrame.new(0, 3, 0))`;
  $("vxExpTex").textContent = n ? (HOST.desktop ? `${n} texture${n === 1 ? "" : "s"}: Claude uploads ${n === 1 ? "it" : "them"} to Roblox for you.` : `${n} texture${n === 1 ? "" : "s"}: open Farshtah's app to upload ${n === 1 ? "it" : "them"} with Claude.`) : "";
}
function vxCloseExport() { $("vxExpBack").hidden = true; }
async function vxExport(forClaude) {
  const o = vxExportOpts();
  if (!/^[A-Za-z_][\w ]*(\.[A-Za-z_][\w ]*)*$/.test(o.parent)) { toast("Where: a path like ReplicatedStorage.FarshtahEffects"); $("vxExpParent").focus(); return; }
  store.set("farshtah.vx.parent", o.parent);
  const btn = forClaude ? $("vxCopyClaude") : $("vxCopyScript"); btn.disabled = true;
  try {
    const textures = await vxTexUrls(VX.eff);
    const r = vxStudioScript(VX.eff, Object.assign({}, o, { textures }));
    if (forClaude) await copyText(vxHandoff(r), "Copied: paste it to Claude");
    else await copyText(r.lua, textures.length ? "Copied. Put your texture ids in TEX first" : "Copied: paste it into Studio's Command Bar");
  } catch (e) { toast("Couldn't make the script: " + (e.message || e)); }
  btn.disabled = false;
}
$("vxExpClose").onclick = vxCloseExport;
$("vxExpBack").addEventListener("pointerdown", e => { if (e.target === $("vxExpBack")) vxCloseExport(); });
$("vxCopyClaude").onclick = () => vxExport(true);
$("vxCopyScript").onclick = () => vxExport(false);
for (const id of ["vxExpParent", "vxExpName"]) $(id).addEventListener("input", vxRenderExportInfo);

// ======================================================================= which app opens first
{
  const want = LINK.get("app"), motionLink = ["anim", "tab", "test", "settings"].some(k => LINK.has(k));
  if (want === "visuals") setApp("visuals");
  else if (want === "motion" || (motionLink && want !== "hub")) setApp("motion");
  else openHub();
}
window.__vx = { VX, SIM, vxSeek, vxSamples, vxLoadSample, vxStudioScript, vxHandoff, vxTexUrls, VX_PLAYER_LUA, vxClean, setApp, openHub, enterApp, greetLine,
  vxAddLayer, vxUndo, vxRedo, vxImportFile, vxCustom, vxExport, vxOpenExport, vxSetLib, vxUseTexture, openCurve, openGrad, renderVxInsp, renderVxTimeline, vxFitCurve, vxStats: () => vxStats, vxChange };
