// ======================================================================= the start screen (hub)
// Opening Farshtah shows its two apps. The first time, it asks your name; picking an app plays a short greeting that
// depends on the time of day, then opens it. #app=motion|visuals|hub in the link goes straight there (and skips the greeting).
const APP_TITLE = { motion: "Farshtah Motion", visuals: "Farshtah Visuals+" };
const GREET = {
  morning: ["Good morning, {n}. Ready to create peak?", "Morning, {n}. Let's make something unreal today.", "Rise and grind, {n}. The rig's waiting.",
    "Good morning, {n}. Fresh mind, fresh frames.", "Early start, {n}? Let's make it count."],
  afternoon: ["Good afternoon, {n}. Ready to create peak?", "Afternoon session, {n}. Let's cook.", "Hey {n}, perfect time to build something crazy.",
    "Good afternoon, {n}. Let's make it look effortless.", "Welcome back, {n}. What are we making today?"],
  evening: ["Good evening, {n}. Time to create peak.", "Evening, {n}. Let's end the day with something insane.", "Welcome back, {n}. The good stuff happens now.",
    "Evening grind, {n}. Let's go.", "Good evening, {n}. One more masterpiece?"],
  night: ["Late night, {n}? That's when the best ideas show up.", "Night shift, {n}. Let's cook something crazy.", "Still going, {n}? Respect. Let's create peak.",
    "The world's winding down, {n}. You're just getting started."],
  late: ["Up while everyone's sleeping, {n}. Must have a goal in mind.", "It's {time}, {n}. Legends are made at this hour.",
    "Everyone's asleep, {n}. Perfect time to create peak.", "No one's awake but you, {n}. Make it worth it."],
};
function greetLine(name, now) {
  const h = now.getHours(), pool = GREET[h < 5 ? "late" : h < 12 ? "morning" : h < 17 ? "afternoon" : h < 21 ? "evening" : "night"];
  let i = Math.floor(Math.random() * pool.length); const last = store.get("farshtah.greet");
  if (pool.length > 1 && String(i) === last) i = (i + 1) % pool.length;
  store.set("farshtah.greet", String(i));
  return pool[i].replace("{time}", now.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })).replace("{n}", "\u0001" + name + "\u0001");
}
const hubEl = $("hub");
let hubBusy = false, vxStarted = false;
function setApp(id) { // which app shows: "hub", "motion" or "visuals"
  APP = id;
  document.body.classList.remove("app-hub", "app-motion", "app-visuals"); document.body.classList.add("app-" + id);
  if (id === "motion") { resize(); attachGizmo(); renderTimeline(); last = performance.now(); }
  if (id === "visuals") { if (!vxStarted) vxStart(); vxResize(); vxLast = performance.now(); renderVxTimeline(); }
  if (id !== "motion" && state.test) exitTest();
  if (id !== "motion" && state.playing) setPlaying(false);
}
function hubShow(part) { for (const p of ["hubHome", "hubName", "hubIntro"]) $(p).hidden = p !== part; }
function hubRenderMe() {
  const n = S.profile.name; $("hubMeName").textContent = n || "Your name"; $("hubAv").textContent = (n || "?").trim().charAt(0).toUpperCase() || "?";
}
async function openHub() {
  setApp("hub"); hubEl.hidden = false; hubEl.classList.remove("leaving"); hubBusy = false;
  if (!S.profile.name) { // the desktop app keeps the name in its settings file: give it a moment to arrive
    for (let i = 0; i < 20 && !S.profile.name; i++) await new Promise(r => setTimeout(r, 100));
  }
  if (!S.profile.name) askName(); else { hubRenderMe(); hubShow("hubHome"); $("hubMotion").focus({ preventScroll: true }); }
}
function askName() { hubShow("hubName"); const inp = $("hubNameIn"); inp.value = S.profile.name || ""; hubEl.scrollTop = 0; setTimeout(() => inp.focus({ preventScroll: true }), 60); }
$("hubName").addEventListener("submit", e => {
  e.preventDefault();
  const v = $("hubNameIn").value.replace(/[\u0000-\u001f<>]/g, "").trim().slice(0, 24);
  if (!v) { $("hubNameIn").focus(); return; }
  S.profile.name = v; saveSettings(); hubRenderMe(); hubShow("hubHome"); $("hubMotion").focus({ preventScroll: true });
});
$("hubMe").onclick = askName;
$("hubSettings").onclick = () => openSettings();
function enterApp(id, intro) {
  if (hubBusy) return; hubBusy = true;
  const go = () => {
    hubEl.classList.add("leaving");
    setApp(id);
    const appEl = id === "visuals" ? $("vx") : $("app"); appEl.classList.remove("arrive"); void appEl.offsetWidth; appEl.classList.add("arrive");
    setTimeout(() => { hubEl.hidden = true; hubEl.classList.remove("leaving"); hubBusy = false; }, 480);
  };
  if (!intro || reduceMotion) return go();
  const line = $("hiLine"); line.innerHTML = "";
  const parts = greetLine(S.profile.name || "friend", new Date()).split("\u0001");
  let k = 0;
  parts.forEach((txt, pi) => {
    const isName = pi % 2 === 1;
    const words = isName ? [txt] : txt.split(/\s+/).filter(Boolean);
    words.forEach((w, wi) => {
      const glue = /^[.,!?']/.test(w) || (line.childNodes.length && wi === 0 && !isName && /^[.,!?']/.test(w));
      if (line.childNodes.length && !glue) line.append(" ");
      const sp = make("span", { class: "w" + (isName ? " nm" : ""), text: w }); sp.style.animationDelay = (0.08 * k++) + "s"; line.append(sp);
    });
  });
  const sub = $("hiSub"); sub.textContent = APP_TITLE[id]; sub.style.animationDelay = (0.08 * k + 0.15) + "s";
  hubShow("hubIntro");
  let done = false; const finish = () => { if (done) return; done = true; clearTimeout(timer); hubEl.removeEventListener("pointerdown", finish); removeEventListener("keydown", finish, true); go(); };
  const timer = setTimeout(finish, 1500 + k * 80);
  setTimeout(() => { hubEl.addEventListener("pointerdown", finish); addEventListener("keydown", finish, true); }, 250);
}
$("hubMotion").onclick = () => enterApp("motion", true);
$("hubVisuals").onclick = () => enterApp("visuals", true);
{ // the logo, three more times: each copy gets its own ids (a copy pointing at the header's gradients goes blank while Motion is hidden)
  const src = document.querySelector(".brand .logo");
  if (src) ["hubLogo", "hubLogo2", "vxLogo"].forEach((id, k) => {
    let h = src.outerHTML; const ids = [...h.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]);
    for (const x of ids) h = h.split('id="' + x + '"').join('id="' + x + "-c" + k + '"').split("#" + x + ")").join("#" + x + "-c" + k + ")").split('"#' + x + '"').join('"#' + x + "-c" + k + '"');
    $(id).innerHTML = h;
  });
}
// the Motion logo goes home too
{ const brand = document.querySelector(".app .brand"); if (brand) { brand.classList.add("home-btn"); brand.setAttribute("role", "button"); brand.tabIndex = 0; brand.title = "Home";
  brand.addEventListener("click", () => openHub()); brand.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openHub(); } }); } }
$("vxHome").onclick = () => openHub();
document.addEventListener("keydown", e => {
  if (APP !== "hub" || hubEl.hidden) return;
  if (e.key === "Escape" && !$("settings").hidden) { closeSettings(); return; }
  if (!$("hubHome").hidden && (e.key === "1" || e.key === "2") && document.activeElement.tagName !== "INPUT") enterApp(e.key === "1" ? "motion" : "visuals", true);
});

// ======================================================================= Farshtah Visuals+: the effect
// An effect is a list of layers, each a Roblox ParticleEmitter, a mesh emitter (copies of a part that grow and fade, as
// the ForgeVFX format plays them) or a Beam, plus the camera feel (shake, FOV punch, flash, hit-stop) and its bloom.
// Times are seconds from the effect's start; sizes are studs. See vfxexport.js for how it becomes Roblox instances.
const VX_FORMAT = "farshtah-vfx/1";
const VXN = (v, d, lo, hi) => (typeof v === "number" && isFinite(v) ? clamp(v, lo, hi) : d);
const VXV = (v, d, lo, hi) => (Array.isArray(v) && v.length === d.length ? v.map((x, i) => VXN(x, d[i], lo, hi)) : d.slice());
const VXP = (v, list, d) => (list.includes(v) ? v : d);
const vxHex = (v, d) => (typeof v === "string" && /^#[0-9a-f]{6}$/i.test(v) ? v.toLowerCase() : d);
const vxId = () => Math.random().toString(36).slice(2, 10);
const ORIENTS = ["FacingCamera", "FacingCameraWorldUp", "VelocityParallel", "VelocityPerpendicular"];
const DIRS6 = ["Top", "Bottom", "Front", "Back", "Right", "Left"];
const SHAPES_P = ["Point", "Box", "Sphere", "Cylinder", "Disc"];
const STYLES = ["Linear", "Sine", "Quad", "Cubic", "Quart", "Quint", "Exponential", "Circular", "Back", "Elastic", "Bounce"];
const EDIRS = ["In", "Out", "InOut"];
const MSHAPES = ["Ring", "Sphere", "Cylinder", "Block", "Wedge", "Mesh"];
const MATS = ["Neon", "ForceField", "Glass", "SmoothPlastic"];
const RING_MESH = "rbxassetid://750305703";
function vxSeqN(v, d, lo, hi) { // a NumberSequence: [[time 0..1, value, envelope]], first at 0, last at 1, at most 20
  let pts = Array.isArray(v) ? v.filter(p => Array.isArray(p) && p.length >= 2).map(p => [VXN(p[0], 0, 0, 1), VXN(p[1], 0, lo, hi), VXN(p[2], 0, 0, hi - lo)]) : [];
  if (pts.length < 2) return d.map(p => p.slice());
  pts.sort((a, b) => a[0] - b[0]); pts = pts.slice(0, 20);
  pts[0][0] = 0; pts[pts.length - 1][0] = 1;
  for (let i = 1; i < pts.length; i++) if (pts[i][0] <= pts[i - 1][0]) pts[i][0] = Math.min(1, pts[i - 1][0] + 1e-4);
  for (const p of pts) p[2] = Math.min(p[2], p[1] - lo, hi - p[1]);
  return pts;
}
function vxSeqC(v, d) { // a ColorSequence: [[time 0..1, "#rrggbb"]]
  let pts = Array.isArray(v) ? v.filter(p => Array.isArray(p) && p.length >= 2).map(p => [VXN(p[0], 0, 0, 1), vxHex(p[1], "#ffffff")]) : [];
  if (pts.length < 2) { if (pts.length === 1) return [[0, pts[0][1]], [1, pts[0][1]]]; return d.map(p => p.slice()); }
  pts.sort((a, b) => a[0] - b[0]); pts = pts.slice(0, 20);
  pts[0][0] = 0; pts[pts.length - 1][0] = 1;
  for (let i = 1; i < pts.length; i++) if (pts[i][0] <= pts[i - 1][0]) pts[i][0] = Math.min(1, pts[i - 1][0] + 1e-4);
  return pts;
}
const WHITE = [[0, "#ffffff"], [1, "#ffffff"]];
const VX_DEF = {
  particles: () => ({ type: "particles", name: "Particles", on: true, p: [0, 0, 0], r: [0, 0, 0], tex: "glow", texId: "",
    color: WHITE, transp: [[0, 0, 0], [1, 1, 0]], size: [[0, 1, 0], [1, 0, 0]], squash: [[0, 0, 0], [1, 0, 0]],
    light: 1, bright: 1, lightInf: 0, z: 0, orient: "FacingCamera", life: [0.5, 0.8], speed: [5, 8], spread: [25, 25], rot: [0, 0], rotSpeed: [0, 0],
    accel: [0, 0, 0], drag: 0, locked: false, rate: 20, delay: 0, count: 10, duration: 0, dir: "Top",
    shape: "Point", shapeSize: [2, 2, 2], shapeStyle: "Volume", shapeInOut: "Outward", shapePartial: 1,
    flip: { layout: "None", mode: "Loop", fps: [30, 30], startRandom: false }, ts: { on: false, start: 1, end: 0.2, duration: 0.5 } }),
  mesh: () => ({ type: "mesh", name: "Ring", on: true, p: [0, 0, 0], r: [0, 0, 0], shape: "Ring", meshId: "", material: "Neon", color: "#7fd8ff",
    start: { size: [2, 0.2, 2], p: [0, 0, 0], r: [0, 0, 0] }, end: { size: [12, 0.1, 12], p: [0, 0, 0], r: [0, 0, 0] },
    t0: 0, t1: 1, morph: 0.4, life: 0.4, ease: ["Quart", "Out"], tease: ["Quad", "In"], delay: 0, count: 1, rate: 0, duration: 0,
    initMin: [0, 0, 0], initMax: [0, 0, 0], spread: [0, 0], spin: [0, 0] }),
  beam: () => ({ type: "beam", name: "Beam", on: true, p: [0, 0, 0], r: [0, 0, 0], a: [0, 0, 0], b: [0, 8, 0], width: [1, 1], curve: [0, 0], segments: 12,
    tex: "beam", texId: "", texMode: "Stretch", texLen: 1, texSpeed: 1, color: WHITE, transp: [[0, 0, 0], [1, 0, 0]], light: 1, bright: 1, faceCam: true, z: 0, delay: 0, duration: 0 }),
};
function vxCleanLayer(raw) {
  const type = raw && VX_DEF[raw.type] ? raw.type : "particles", d = VX_DEF[type](), r = raw || {};
  const L = { type, id: typeof r.id === "string" && /^[a-z0-9]{1,16}$/.test(r.id) ? r.id : vxId(), name: String(r.name || d.name).replace(/[\u0000-\u001f]/g, "").slice(0, 40) || d.name,
    on: r.on !== false, p: VXV(r.p, d.p, -500, 500), r: VXV(r.r, d.r, -360, 360) };
  if (type === "particles") Object.assign(L, {
    tex: typeof r.tex === "string" && r.tex.length < 60 ? r.tex : d.tex, texId: typeof r.texId === "string" ? r.texId.trim().slice(0, 80) : "",
    color: vxSeqC(r.color, d.color), transp: vxSeqN(r.transp, d.transp, 0, 1), size: vxSeqN(r.size, d.size, 0, 200), squash: vxSeqN(r.squash, d.squash, -3, 3),
    light: VXN(r.light, d.light, 0, 1), bright: VXN(r.bright, d.bright, 0, 50), lightInf: VXN(r.lightInf, d.lightInf, 0, 1), z: VXN(r.z, d.z, -50, 50),
    orient: VXP(r.orient, ORIENTS, d.orient), life: VXV(r.life, d.life, 0.01, 30), speed: VXV(r.speed, d.speed, -500, 500), spread: VXV(r.spread, d.spread, 0, 360),
    rot: VXV(r.rot, d.rot, -360, 360), rotSpeed: VXV(r.rotSpeed, d.rotSpeed, -3600, 3600), accel: VXV(r.accel, d.accel, -1000, 1000), drag: VXN(r.drag, d.drag, 0, 100),
    locked: !!r.locked, rate: VXN(r.rate, d.rate, 0, 1000), delay: VXN(r.delay, d.delay, 0, 60), count: VXN(r.count, d.count, 0, 1000), duration: VXN(r.duration, d.duration, 0, 60),
    dir: VXP(r.dir, DIRS6, d.dir), shape: VXP(r.shape, SHAPES_P, d.shape), shapeSize: VXV(r.shapeSize, d.shapeSize, 0, 500),
    shapeStyle: VXP(r.shapeStyle, ["Volume", "Surface"], d.shapeStyle), shapeInOut: VXP(r.shapeInOut, ["Outward", "Inward", "InAndOut"], d.shapeInOut), shapePartial: VXN(r.shapePartial, 1, 0, 1),
    flip: { layout: VXP(r.flip && r.flip.layout, ["None", "Grid2x2", "Grid4x4", "Grid8x8"], "None"), mode: VXP(r.flip && r.flip.mode, ["Loop", "OneShot", "PingPong", "Random"], "Loop"),
      fps: VXV(r.flip && r.flip.fps, [30, 30], 0, 120), startRandom: !!(r.flip && r.flip.startRandom) },
    ts: { on: !!(r.ts && r.ts.on), start: VXN(r.ts && r.ts.start, 1, 0, 1), end: VXN(r.ts && r.ts.end, 0.2, 0, 1), duration: VXN(r.ts && r.ts.duration, 0.5, 0, 30) } });
  else if (type === "mesh") {
    const tr = (v, dd) => ({ size: VXV(v && v.size, dd.size, 0, 2048), p: VXV(v && v.p, dd.p, -500, 500), r: VXV(v && v.r, dd.r, -360, 360) });
    Object.assign(L, { shape: VXP(r.shape, MSHAPES, d.shape), meshId: typeof r.meshId === "string" ? r.meshId.trim().slice(0, 80) : "", material: VXP(r.material, MATS, d.material),
      color: vxHex(r.color, d.color), start: tr(r.start, d.start), end: tr(r.end, d.end), t0: VXN(r.t0, d.t0, 0, 1), t1: VXN(r.t1, d.t1, 0, 1),
      morph: VXN(r.morph, d.morph, 0.02, 30), life: VXN(r.life, VXN(r.morph, d.life, 0.02, 30), 0.02, 30),
      ease: [VXP(r.ease && r.ease[0], STYLES, d.ease[0]), VXP(r.ease && r.ease[1], EDIRS, d.ease[1])], tease: [VXP(r.tease && r.tease[0], STYLES, d.tease[0]), VXP(r.tease && r.tease[1], EDIRS, d.tease[1])],
      delay: VXN(r.delay, d.delay, 0, 60), count: VXN(r.count, d.count, 0, 200), rate: VXN(r.rate, d.rate, 0, 120), duration: VXN(r.duration, d.duration, 0, 60),
      initMin: VXV(r.initMin, d.initMin, -360, 360), initMax: VXV(r.initMax, d.initMax, -360, 360), spread: VXV(r.spread, d.spread, 0, 180), spin: VXV(r.spin, d.spin, -3600, 3600) });
    if (L.shape === "Sphere") { L.start.size = [L.start.size[0], L.start.size[0], L.start.size[0]]; L.end.size = [L.end.size[0], L.end.size[0], L.end.size[0]]; }
  } else Object.assign(L, {
    a: VXV(r.a, d.a, -500, 500), b: VXV(r.b, d.b, -500, 500), width: VXV(r.width, d.width, 0, 200), curve: VXV(r.curve, d.curve, -200, 200), segments: Math.round(VXN(r.segments, d.segments, 1, 1000)),
    tex: typeof r.tex === "string" && r.tex.length < 60 ? r.tex : d.tex, texId: typeof r.texId === "string" ? r.texId.trim().slice(0, 80) : "",
    texMode: VXP(r.texMode, ["Stretch", "Wrap", "Static"], d.texMode), texLen: VXN(r.texLen, d.texLen, 0.01, 1000), texSpeed: VXN(r.texSpeed, d.texSpeed, -100, 100),
    color: vxSeqC(r.color, d.color), transp: vxSeqN(r.transp, d.transp, 0, 1), light: VXN(r.light, d.light, 0, 1), bright: VXN(r.bright, d.bright, 0, 50),
    faceCam: r.faceCam !== false, z: VXN(r.z, d.z, -50, 50), delay: VXN(r.delay, d.delay, 0, 60), duration: VXN(r.duration, d.duration, 0, 60) });
  return L;
}
function vxLayer(type, over) { return vxCleanLayer(Object.assign(VX_DEF[type](), over || {}, { type })); }
const WHERE = [["ground", "Ground"], ["front", "In front"], ["chest", "Chest, in front"], ["torso", "Torso"], ["rhand", "Right hand"], ["lhand", "Left hand"]];
function vxClean(raw) {
  const r = raw || {}, c = r.cam || {}, b = r.bloom || {}, pv = r.preview || {};
  const v3 = (v, d) => VXV(v, d, -100, 100).map((x, i) => (i === 1 ? Math.max(0, x) : i === 2 ? Math.max(0, x) : x));
  return { format: VX_FORMAT, name: String(r.name || "Untitled effect").replace(/[\u0000-\u001f]/g, "").slice(0, 60) || "Untitled effect",
    bloom: { on: b.on !== false, intensity: VXN(b.intensity, 1, 0, 5), size: VXN(b.size, 24, 0, 56), threshold: VXN(b.threshold, 2, 0.8, 4) },
    cam: { shake: v3(c.shake, [0, 0.3, 0]), fov: v3(c.fov, [0, 0.3, 0]), flash: v3(c.flash, [0, 0.15, 0]), flashColor: vxHex(c.flashColor, "#ffffff"),
      hitstop: VXV(c.hitstop, [0, 0], 0, 10) },
    preview: { where: VXP(pv.where, WHERE.map(w => w[0]), "ground"), anim: typeof pv.anim === "string" ? pv.anim.slice(0, 120) : "",
      at: typeof pv.at === "string" ? pv.at.slice(0, 60) : typeof pv.at === "number" && isFinite(pv.at) ? clamp(pv.at, 0, 60) : "start" },
    layers: (Array.isArray(r.layers) ? r.layers : []).slice(0, 64).map(vxCleanLayer),
    updatedAt: typeof r.updatedAt === "string" ? r.updatedAt : undefined };
}
function vxLongest(eff) { // when the last thing in it ends
  let e = 0.3;
  for (const L of eff.layers) {
    if (!L.on) continue;
    if (L.type === "particles") e = Math.max(e, L.delay + L.duration + L.life[1] / Math.max(L.ts.on ? Math.min(L.ts.start, L.ts.end) || 0.05 : 1, 0.05));
    else if (L.type === "mesh") e = Math.max(e, L.delay + L.duration + Math.max(L.life, L.morph));
    else e = Math.max(e, L.delay + (L.duration || 0.6));
  }
  const c = eff.cam;
  for (const k of ["shake", "fov", "flash"]) if (c[k][0]) e = Math.max(e, c[k][2] + c[k][1]);
  return Math.min(e, 60);
}

// ======================================================================= Visuals+: textures in use
const vxTexCache = new Map(); // key -> { key, name, grid, canvas, tex, texWrap, custom }
const vxCustom = new Map(); // a texture doc id -> its doc (imported PNG / JPG / GIF)
let vxTexCol = null;
function vxGridN(layout) { return layout === "Grid2x2" ? 2 : layout === "Grid4x4" ? 4 : layout === "Grid8x8" ? 8 : 1; }
function vxTexture(key) {
  let t = vxTexCache.get(key); if (t) return t;
  const p = VX_TEX_MAP.get(key);
  if (p) {
    const cv = document.createElement("canvas"); cv.width = cv.height = p.size; p.draw(cv.getContext("2d"), p.size);
    t = { key, name: p.name, grid: p.grid, canvas: cv, tex: null, texWrap: null }; vxTexCache.set(key, t); return t;
  }
  if (key.startsWith("u:")) {
    const d = vxCustom.get(key.slice(2));
    const cv = document.createElement("canvas"); cv.width = cv.height = 64;
    t = { key, name: d ? d.name : "Texture", grid: d ? d.grid : "None", canvas: cv, tex: null, texWrap: null, custom: true, loading: true, asset: d ? d.asset : null }; vxTexCache.set(key, t);
    if (d && d.asset) {
      const img = new Image(); img.crossOrigin = "anonymous";
      img.onload = () => { cv.width = img.naturalWidth; cv.height = img.naturalHeight; cv.getContext("2d").drawImage(img, 0, 0); t.loading = false;
        for (const x of [t.tex, t.texWrap]) if (x) { x.image = cv; x.needsUpdate = true; } vxRefreshThumbs(); };
      img.onerror = () => { t.loading = false; };
      img.src = (window.__r6BlobUrl && window.__r6BlobUrl(d.asset)) || "";
    }
    return t;
  }
  return vxTexture("glow");
}
function vxThreeTex(t, wrap) {
  const k = wrap ? "texWrap" : "tex";
  if (!t[k]) { const x = new THREE.CanvasTexture(t.canvas); x.anisotropy = 4; if (wrap) { x.wrapS = THREE.RepeatWrapping; } t[k] = x; }
  return t[k];
}
function vxThumb(key, color, w, h, cv) { // a texture on a dark tile, tinted
  cv = cv || document.createElement("canvas"); cv.width = w; cv.height = h;
  const c = cv.getContext("2d"), t = vxTexture(key), n = vxGridN(t.grid);
  c.fillStyle = "#0b0d14"; c.fillRect(0, 0, w, h);
  const s = Math.min(w, h) * 0.9, sw = t.canvas.width / n, sh = t.canvas.height / n;
  const tmp = document.createElement("canvas"); tmp.width = tmp.height = Math.round(s); const tc = tmp.getContext("2d");
  tc.drawImage(t.canvas, 0, 0, sw, sh, 0, 0, s, s);
  if (color) { tc.globalCompositeOperation = "source-in"; tc.fillStyle = color; tc.fillRect(0, 0, s, s); }
  c.globalCompositeOperation = "lighter"; c.drawImage(tmp, (w - s) / 2, (h - s) / 2); c.globalCompositeOperation = "source-over";
  return cv;
}
let vxThumbTimer = null;
function vxRefreshThumbs() { clearTimeout(vxThumbTimer); vxThumbTimer = setTimeout(() => { if (VX.lib === "tex") renderVxLib(); renderVxInsp(); }, 120); }

// ======================================================================= Visuals+: state, undo, saving
const VX = { eff: vxClean({ name: "Untitled effect", layers: [] }), docId: null, sel: -1, mode: store.get("farshtah.vx.mode") === "adv" ? "adv" : "simple",
  t: 0, playing: true, speed: 1, loop: true, freeze: 0, rev: 0, lib: ["add", "samples", "tex"].includes(store.get("farshtah.vx.lib")) ? store.get("farshtah.vx.lib") : "add",
  light: store.get("farshtah.vx.light") === "game" ? "game" : "studio", backdrop: ["night", "baseplate", "theme"].includes(store.get("farshtah.vx.bd")) ? store.get("farshtah.vx.bd") : "night",
  showRig: store.get("farshtah.vx.rig") !== "0", zoom: 1, undo: [], redo: [], docs: new Map(), col: null, local: false, saveTimer: null, saving: false, again: false, lastSaved: null };
const VX_LOCAL = "farshtah.vx.local.v1";
const vxL = () => VX.eff.layers[VX.sel] || null;
let vxGestureTimer = null;
function vxPush() { VX.undo.push(JSON.stringify(VX.eff)); if (VX.undo.length > 120) VX.undo.shift(); VX.redo.length = 0; }
function vxChange(fn, o) { // every edit: one undo step per burst of changes
  o = o || {};
  if (!vxGestureTimer) vxPush(); clearTimeout(vxGestureTimer); vxGestureTimer = setTimeout(() => { vxGestureTimer = null; }, 650);
  fn(); vxDirty(o);
}
function vxDirty(o) {
  o = o || {}; VX.rev++;
  vxScheduleSave();
  if (o.struct !== false) vxSyncObjects();
  if (o.tl !== false) renderVxTimeline();
  if (o.insp) renderVxInsp();
  if (!VX.playing) vxSeek(VX.t);
}
function vxUndo() { if (!VX.undo.length) return toast("Nothing to undo"); VX.redo.push(JSON.stringify(VX.eff)); vxRestore(VX.undo.pop()); }
function vxRedo() { if (!VX.redo.length) return toast("Nothing to redo"); VX.undo.push(JSON.stringify(VX.eff)); vxRestore(VX.redo.pop()); }
function vxRestore(json) { VX.eff = vxClean(JSON.parse(json)); if (VX.sel >= VX.eff.layers.length) VX.sel = VX.eff.layers.length - 1; vxAfterOpen(true); vxScheduleSave(); }
function vxSetSave(s, text) { const el = $("vxSave"); el.dataset.s = s; el.textContent = text; }
function vxScheduleSave() { vxSetSave("pending", "Unsaved"); clearTimeout(VX.saveTimer); VX.saveTimer = setTimeout(vxSaveNow, 900); }
function vxLocalAll() { try { return JSON.parse(store.get(VX_LOCAL) || "{}"); } catch (e) { return {}; } }
async function vxSaveNow() {
  clearTimeout(VX.saveTimer);
  if (VX.saving) { VX.again = true; return; }
  if (!VX.local && !VX.col) { vxSetSave("pending", "Unsaved"); return; }
  VX.saving = true; vxSetSave("saving", "Saving…");
  const body = JSON.parse(JSON.stringify(VX.eff)); body.updatedAt = new Date().toISOString();
  try {
    if (JSON.stringify(body).length > MAX_DOC) throw { code: "too_big" };
    if (VX.local) {
      if (!VX.docId) VX.docId = "local-" + Date.now().toString(36);
      const all = vxLocalAll(); all[VX.docId] = body; store.set(VX_LOCAL, JSON.stringify(all)); VX.docs.set(VX.docId, body); vxSetSave("local", "Saved in this browser");
    } else { if (!VX.docId) VX.docId = VX.col.doc().id; await VX.col.doc(VX.docId).set(body); vxSetSave("saved", "Saved"); }
    VX.lastSaved = body.updatedAt; store.set("farshtah.vx.last", VX.docId);
  } catch (err) {
    const c = err && err.code; vxSetSave(c === "quota_exceeded" ? "full" : "error", c === "too_big" ? "Too big to save" : "Not saved");
    if (c !== "too_big" && c !== "quota_exceeded") toast("Couldn't save the effect. It tries again on your next change.");
  }
  VX.saving = false; if (VX.again) { VX.again = false; vxSaveNow(); }
}
function vxOpen(id) {
  const d = VX.docs.get(id); if (!d) return;
  clearTimeout(VX.saveTimer);
  VX.eff = vxClean(d); VX.docId = id; VX.lastSaved = d.updatedAt || null; VX.undo.length = 0; VX.redo.length = 0; VX.sel = VX.eff.layers.length ? 0 : -1;
  store.set("farshtah.vx.last", id);
  vxSetSave(VX.local ? "local" : "saved", VX.local ? "Saved in this browser" : "Saved");
  vxAfterOpen();
}
function vxNewEffect(base) {
  clearTimeout(VX.saveTimer);
  const names = new Set([...VX.docs.values()].map(d => d.name)); let nm = base ? base.name : "Untitled effect", i = 2; const b0 = nm; while (names.has(nm)) nm = `${b0} ${i++}`;
  VX.eff = vxClean(Object.assign({}, base || { layers: [] }, { name: nm })); VX.docId = null; VX.undo.length = 0; VX.redo.length = 0; VX.sel = VX.eff.layers.length ? 0 : -1;
  vxAfterOpen(); vxSaveNow();
}
function vxAfterOpen(keepTime) {
  $("vxName").value = VX.eff.name;
  vxSyncObjects(); vxPreviewChanged(); if (!keepTime) { VX.t = -vxLead(); VX.playing = true; } vxSeek(VX.t);
  renderVxTimeline(); renderVxInsp(); renderVxTransport();
}
$("vxName").addEventListener("input", () => { const v = $("vxName").value.trim(); if (!v) return; vxChange(() => { VX.eff.name = v.slice(0, 60); }, { struct: false }); });
$("vxName").addEventListener("blur", () => { $("vxName").value = VX.eff.name; });
async function vxInitStore() {
  for (let i = 0; i < 160 && !db && !local; i++) await new Promise(r => setTimeout(r, 50)); // Motion opens the storage first
  if (!db) {
    VX.local = true; for (const [id, d] of Object.entries(vxLocalAll())) VX.docs.set(id, d);
    vxFirstOpen(); return;
  }
  VX.col = db.collection("effects"); let first = true;
  VX.col.onSnapshot(snap => {
    VX.docs.clear(); for (const d of snap.docs) VX.docs.set(d.id, d.data());
    if (first) { first = false; vxFirstOpen(); }
    else if (VX.docId && VX.docs.has(VX.docId) && !VX.saving && $("vxSave").dataset.s === "saved") {
      const d = VX.docs.get(VX.docId); if (d.updatedAt && VX.lastSaved && d.updatedAt > VX.lastSaved) { const t = VX.t, sel = VX.sel; vxOpen(VX.docId); VX.sel = Math.min(sel, VX.eff.layers.length - 1); VX.t = t; renderVxInsp(); toast("Updated from another window"); }
    }
    vxRenderList();
  }, () => vxSetSave("error", "Storage unavailable"));
  vxTexCol = db.collection("textures");
  vxTexCol.onSnapshot(snap => {
    vxCustom.clear(); for (const d of snap.docs) { const x = d.data(); if (x && typeof x.asset === "string") vxCustom.set(d.id, { id: d.id, name: String(x.name || "Texture").slice(0, 40), asset: x.asset, grid: VXP(x.grid, ["None", "Grid2x2", "Grid4x4", "Grid8x8"], "None") }); }
    for (const [k, t] of [...vxTexCache]) if (k.startsWith("u:")) { // a stand-in made before the list arrived (or a changed one) is made again
      const d = vxCustom.get(k.slice(2));
      if (!d || t.asset !== d.asset) { for (const x of [t.tex, t.texWrap]) if (x) x.dispose(); vxTexCache.delete(k); }
    }
    vxSyncObjects(); vxRefreshThumbs();
  }, () => {});
}
function vxFirstOpen() {
  const linkFx = LINK.get("fx");
  if (linkFx && linkFx.startsWith("sample:")) { const s = vxSamples().find(x => x.key === linkFx.slice(7)); if (s) { vxLoadSample(s, true); return vxApplyLink(); } }
  if (linkFx && VX.docs.has(linkFx)) { vxOpen(linkFx); return vxApplyLink(); }
  const last = store.get("farshtah.vx.last");
  if (last && VX.docs.has(last)) vxOpen(last);
  else { const recent = [...VX.docs.entries()].sort((a, b) => String(b[1].updatedAt || "").localeCompare(String(a[1].updatedAt || "")))[0];
    if (recent) vxOpen(recent[0]); else vxLoadSample(vxSamples()[0]); } // the first time: a sample to play with
  vxApplyLink();
}
function vxApplyLink() {
  const t = parseFloat(LINK.get("vt")); if (isFinite(t)) { VX.playing = false; vxSeek(t); renderVxTransport(); }
  const s = parseInt(LINK.get("vsel"), 10); if (isFinite(s)) { VX.sel = clamp(s, -1, VX.eff.layers.length - 1); renderVxInsp(); renderVxTimeline(); }
  const lib = LINK.get("vlib"); if (["add", "samples", "tex"].includes(lib)) vxSetLib(lib);
  if (LINK.get("vmode") === "adv") { VX.mode = "adv"; renderVxInsp(); }
  if (LINK.has("vexport")) vxOpenExport();
}
function vxLoadSample(s, noSave) {
  const eff = JSON.parse(JSON.stringify(s.effect)); eff.preview = Object.assign({ where: s.where || "ground", anim: "", at: "start" }, eff.preview || {});
  if (noSave) { VX.eff = vxClean(eff); VX.docId = null; VX.sel = VX.eff.layers.length ? 0 : -1; vxAfterOpen(); vxSetSave("idle", "Not saved"); return; }
  vxNewEffect(eff);
}
// ---- the Effects list
function vxRenderList() {
  const el = $("vxList"); if (!el || $("vxOpenBack").hidden) return; el.innerHTML = "";
  const list = [...VX.docs.entries()].sort((a, b) => String(b[1].updatedAt || "").localeCompare(String(a[1].updatedAt || "")));
  if (!list.length) { el.append(make("p", { class: "muted", text: "No saved effects yet." })); return; }
  for (const [id, d] of list) {
    const cur = id === VX.docId, n = Array.isArray(d.layers) ? d.layers.length : 0;
    const o = make("button", { type: "button", class: "btn" + (cur ? "" : " primary"), text: cur ? "Open now" : "Open", onclick: () => { vxOpen(id); vxCloseList(); } });
    const du = make("button", { type: "button", class: "btn", text: "Duplicate", onclick: () => { vxNewEffect(vxClean(d)); vxCloseList(); } });
    const de = make("button", { type: "button", class: "btn danger", text: "Delete", onclick: () => vxAsk(`Delete “${d.name}” for good?`, () => vxDelete(id)) });
    el.append(make("div", { class: "aitem" + (cur ? " cur" : "") }, make("div", { class: "nm", text: d.name || "Untitled effect" }), make("div", { class: "acts" }, o, du, de),
      make("div", { class: "meta", text: `${n} layer${n === 1 ? "" : "s"} · ${fmtAgo(d.updatedAt)}` })));
  }
}
let vxYes = null;
function vxAsk(text, yes) { $("vxDlgConfirmText").textContent = text; $("vxDlgConfirm").hidden = false; vxYes = yes; $("vxDlgNo").focus(); }
$("vxDlgYes").onclick = () => { $("vxDlgConfirm").hidden = true; if (vxYes) vxYes(); vxYes = null; };
$("vxDlgNo").onclick = () => { $("vxDlgConfirm").hidden = true; vxYes = null; };
async function vxDelete(id) {
  try {
    if (VX.local) { const all = vxLocalAll(); delete all[id]; store.set(VX_LOCAL, JSON.stringify(all)); VX.docs.delete(id); } else await VX.col.doc(id).delete();
    VX.docs.delete(id);
    if (id === VX.docId) { const next = [...VX.docs.keys()][0]; if (next) vxOpen(next); else { VX.docId = null; vxNewEffect(); } }
    toast("Deleted"); vxRenderList();
  } catch (e) { toast("Couldn't delete it. Try again."); }
}
function vxOpenList() { vxClosePop(); closeMenu(); $("vxOpenBack").hidden = false; vxRenderList(); $("vxDlgClose").focus(); }
function vxCloseList() { $("vxOpenBack").hidden = true; $("vxDlgConfirm").hidden = true; }
$("vxOpen").onclick = vxOpenList; $("vxDlgClose").onclick = vxCloseList;
$("vxOpenBack").addEventListener("pointerdown", e => { if (e.target === $("vxOpenBack")) vxCloseList(); });
$("vxNew").onclick = () => vxNewEffect(); $("vxDlgNew").onclick = () => { vxNewEffect(); vxCloseList(); };
$("vxSettings").onclick = () => openSettings();
addEventListener("pagehide", () => { if ($("vxSave").dataset.s === "pending") vxSaveNow(); });

// ======================================================================= Visuals+: the 3D view
let vxR = null, vxScene = null, vxCam = null, vxOrbit = null, vxComposer = null, vxBloom = null, vxBloomComp = null, vxRig = null, vxFloor = null, vxGrid = null, vxLast = 0;
const vxFx = new THREE.Group(); // every layer's drawing
const vxObjs = new Map(); // layer id -> { kind, mesh, geo, mat, cap, ... }
function vxStart() {
  vxStarted = true;
  const cv = $("vxView");
  try { vxR = new THREE.WebGLRenderer({ canvas: cv, antialias: true, powerPreference: "high-performance" }); }
  catch (e) { $("vxStage").insertAdjacentHTML("beforeend", '<div class="nogl">The preview needs WebGL, which this browser has turned off.</div>'); }
  vxScene = new THREE.Scene();
  vxCam = new THREE.PerspectiveCamera(55, 1, 0.1, 1000); vxCam.position.set(10, 7, -12);
  vxScene.add(new THREE.HemisphereLight(0xffffff, 0x4a5060, 0.85));
  const sunL = new THREE.DirectionalLight(0xffffff, 0.75); sunL.position.set(8, 14, -6); vxScene.add(sunL);
  vxFloor = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), new THREE.MeshLambertMaterial({ color: 0x2a2f3a })); vxFloor.rotation.x = -Math.PI / 2; vxScene.add(vxFloor);
  vxRig = buildRig("solid"); dressRig(vxRig); vxScene.add(vxRig.root);
  vxScene.add(vxFx);
  if (vxR) {
    vxOrbit = new THREE.OrbitControls(vxCam, cv); vxOrbit.target.set(0, 3, -2); vxOrbit.enableDamping = !reduceMotion; vxOrbit.dampingFactor = 0.12; vxOrbit.minDistance = 2; vxOrbit.maxDistance = 200; vxOrbit.update();
    try { // selective bloom: a pass with only the effect's glowing layers (the rest drawn black), blurred and added on top,
          // so neon and bright particles glow in their own colour while the rig and the floor don't
      if (THREE.EffectComposer && THREE.UnrealBloomPass && THREE.ShaderPass) {
        vxBloomComp = new THREE.EffectComposer(vxR); vxBloomComp.renderToScreen = false;
        vxBloomComp.addPass(new THREE.RenderPass(vxScene, vxCam));
        vxBloom = new THREE.UnrealBloomPass(new THREE.Vector2(256, 256), 1, 0.4, 0); vxBloomComp.addPass(vxBloom);
        vxComposer = new THREE.EffectComposer(vxR);
        vxComposer.addPass(new THREE.RenderPass(vxScene, vxCam));
        const mix = new THREE.ShaderPass(new THREE.ShaderMaterial({ uniforms: { baseTexture: { value: null }, bloomTexture: { value: vxBloomComp.renderTarget2.texture } },
          vertexShader: "varying vec2 vUv; void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",
          fragmentShader: "uniform sampler2D baseTexture; uniform sampler2D bloomTexture; varying vec2 vUv; void main() { gl_FragColor = texture2D(baseTexture, vUv) + vec4(texture2D(bloomTexture, vUv).rgb, 0.0); }" }), "baseTexture");
        mix.needsSwap = true; vxComposer.addPass(mix);
      }
    } catch (e) { vxComposer = null; vxBloom = null; vxBloomComp = null; }
  }
  vxApplyBackdrop(); vxApplyRigLook();
  new ResizeObserver(vxResize).observe($("vxStage"));
  new ResizeObserver(() => renderVxTimeline()).observe($("vxTlMain"));
  vxBindUi(); renderVxSpeeds(); renderVxTransport(); renderVxLib(); renderVxInsp(); renderVxTimeline();
  vxInitStore().catch(() => vxFirstOpen());
}
function vxResize() {
  if (!vxR) return;
  const st = $("vxStage"), w = st.clientWidth, h = st.clientHeight; if (w < 2 || h < 2) return;
  const pr = Math.min(devicePixelRatio || 1, 2);
  vxR.setPixelRatio(pr); vxR.setSize(w, h, false);
  if (vxComposer) { for (const c of [vxComposer, vxBloomComp]) { c.setPixelRatio(pr); c.setSize(w, h); } }
  vxCam.aspect = w / h; vxCam.updateProjectionMatrix(); VX.fovBase = vxCam.fov;
}
const BACKDROPS = { night: ["#0b0d14", "#161b26", "#2a3142", "#1c2230"], baseplate: ["#8fb8e6", "#cfe4f7", "#a3a2a5", "#8d8c8f"] };
function vxApplyBackdrop() {
  if (!vxScene) return;
  let top, bot, floor, grid;
  if (VX.backdrop === "theme") { top = css("--stage") || "#0b0d14"; bot = css("--bg") || top; floor = css("--floor") || "#212733"; grid = css("--grid") || "#303747"; }
  else [top, bot, floor, grid] = BACKDROPS[VX.backdrop];
  const g = document.createElement("canvas"); g.width = 4; g.height = 256; const c = g.getContext("2d"), lg = c.createLinearGradient(0, 0, 0, 256);
  lg.addColorStop(0, VX.backdrop === "baseplate" ? top : bot); lg.addColorStop(1, VX.backdrop === "baseplate" ? bot : top); c.fillStyle = lg; c.fillRect(0, 0, 4, 256);
  if (vxScene.background && vxScene.background.dispose) vxScene.background.dispose();
  vxScene.background = new THREE.CanvasTexture(g);
  vxFloor.material.color.set(floor);
  vxScene.fog = new THREE.Fog(new THREE.Color(VX.backdrop === "baseplate" ? bot : top), 45, 170); // (the floor fades out instead of shimmering at the horizon)
  if (vxGrid) { vxScene.remove(vxGrid); vxGrid.geometry.dispose(); }
  vxGrid = new THREE.GridHelper(400, 200, new THREE.Color(grid), new THREE.Color(grid)); vxGrid.position.y = 0.003; vxGrid.material.transparent = true; vxGrid.material.opacity = VX.backdrop === "baseplate" ? 0.35 : 0.6; vxScene.add(vxGrid);
  $("vxBackdrop").textContent = { night: "Night", baseplate: "Baseplate", theme: "Theme" }[VX.backdrop];
}
appHooks.theme = () => { if (vxStarted && VX.backdrop === "theme") vxApplyBackdrop(); };
function vxApplyRigLook() { if (!vxRig) return; dressRig(vxRig); vxRig.root.visible = VX.showRig; vxRigProps(); }
let vxPropObjs = [];
function vxRigProps() { // the preview animation's held models
  for (const o of vxPropObjs) { if (o.parent) o.parent.remove(o); disposeTree(o); } vxPropObjs = [];
  const a = vxAnim(); let held = false;
  for (const pr of ((a && a.props) || [])) {
    const m = models.get(pr.model); if (!m || !vxRig.holds[pr.joint] || pr.hide) continue;
    const h = new THREE.Group(); h.position.set(pr.p[0], pr.p[1], pr.p[2]); h.rotation.set(pr.r[0] * DEG, pr.r[1] * DEG, pr.r[2] * DEG); h.scale.set(pr.s[0], pr.s[1], pr.s[2]);
    h.add(buildModelGroup(m)); vxRig.holds[pr.joint].add(h); vxPropObjs.push(h); if (pr.joint === "Right Arm") held = true;
  }
  vxRig.sword.visible = state.show.sword && !held;
}
// ---- the preview animation (from Motion) and where the effect starts
let vxAnimCache = { id: null, rev: null, anim: null, prep: null };
function vxAnim() {
  const id = VX.eff.preview.anim; if (!id || !docs.has(id)) return null;
  const d = docs.get(id);
  if (vxAnimCache.id !== id || vxAnimCache.rev !== d.updatedAt) { const a = R.sanitize(d); vxAnimCache = { id, rev: d.updatedAt, anim: a, prep: R.prepAnim(a) }; }
  return vxAnimCache.anim;
}
function vxLead() { // how far into the animation the effect starts
  const a = vxAnim(); if (!a) return 0;
  const at = VX.eff.preview.at;
  if (typeof at === "number") return clamp(at, 0, a.length);
  if (typeof at === "string" && at.startsWith("marker:")) { const m = a.markers.find(x => x.name === at.slice(7)); if (m) return m.t; }
  return 0;
}
const vxOrigin = new THREE.Vector3(), vxOriginQ = new THREE.Quaternion();
function vxPoseRig(animT) {
  const a = vxAnim();
  if (a) applyPose(vxRig, R.evaluate(a, clamp(animT, 0, a.length), vxAnimCache.prep));
  else { const rest = {}; for (const j of J) rest[j] = { q: [0, 0, 0, 1], p: [0, 0, 0] }; applyPose(vxRig, rest); }
  vxRig.root.updateMatrixWorld(true);
}
function vxComputeOrigin() { // where the effect is placed when it starts (it stays there, as the game plays it: anchored)
  const w = VX.eff.preview.where; vxOriginQ.identity();
  if (w === "ground") vxOrigin.set(0, 0, 0); else if (w === "front") vxOrigin.set(0, 0, -6); else if (w === "chest") vxOrigin.set(0, 3, -3); else if (w === "torso") vxOrigin.set(0, 3, 0);
  else { vxPoseRig(vxLead()); const hold = vxRig.holds[w === "lhand" ? "Left Arm" : "Right Arm"]; vxOrigin.set(0, -1, 0); hold.localToWorld(vxOrigin); }
}
function vxPreviewChanged() { vxRigProps(); vxComputeOrigin(); }

// ======================================================================= Visuals+: the simulation (Roblox's rules, ForgeVFX's timing)
// Every layer is a "source": EmitCount at EmitDelay, then on for EmitDuration (particles at their own Rate; mesh copies
// at Rate per second). It's deterministic for a given start, so scrubbing re-runs it from 0 in 1/60 s steps.
const SIM = { t: 0, srcs: [], copies: [], seed: 1 };
const DIRV = { Top: [0, 1, 0], Bottom: [0, -1, 0], Front: [0, 0, -1], Back: [0, 0, 1], Right: [1, 0, 0], Left: [-1, 0, 0] };
const RBX_IN = { Linear: s => s, Sine: s => 1 - Math.cos(s * Math.PI / 2), Quad: s => s * s, Cubic: s => s * s * s, Quart: s => s ** 4, Quint: s => s ** 5,
  Exponential: s => (s <= 0 ? 0 : Math.pow(2, 10 * s - 10)), Circular: s => 1 - Math.sqrt(Math.max(0, 1 - s * s)), Back: s => 2.70158 * s * s * s - 1.70158 * s * s,
  Elastic: s => (s <= 0 ? 0 : s >= 1 ? 1 : -Math.pow(2, 10 * s - 10) * Math.sin((s * 10 - 10.75) * (2 * Math.PI / 3))),
  Bounce: s => { const b = x => { const n = 7.5625, d = 2.75; if (x < 1 / d) return n * x * x; if (x < 2 / d) { x -= 1.5 / d; return n * x * x + 0.75; } if (x < 2.5 / d) { x -= 2.25 / d; return n * x * x + 0.9375; } x -= 2.625 / d; return n * x * x + 0.984375; }; return 1 - b(1 - s); } };
function rbxEase(style, dir, s) { const g = RBX_IN[style] || RBX_IN.Quad; s = clamp(s, 0, 1); if (dir === "In") return g(s); if (dir === "Out") return 1 - g(1 - s); return s < 0.5 ? g(2 * s) / 2 : 1 - g(2 - 2 * s) / 2; }
function seqN(seq, x, e) { // a NumberSequence at x, with this particle's envelope pick e (-1..1)
  if (x <= seq[0][0]) return seq[0][1] + e * seq[0][2];
  for (let i = 1; i < seq.length; i++) if (x <= seq[i][0]) { const a = seq[i - 1], b = seq[i], k = (x - a[0]) / Math.max(b[0] - a[0], 1e-6); return a[1] + (b[1] - a[1]) * k + e * (a[2] + (b[2] - a[2]) * k); }
  const l = seq[seq.length - 1]; return l[1] + e * l[2];
}
const vxRgb = new Map(); function rgbOf(h) { let v = vxRgb.get(h); if (!v) { const n = parseInt(h.slice(1), 16); v = [(n >> 16 & 255) / 255, (n >> 8 & 255) / 255, (n & 255) / 255]; vxRgb.set(h, v); } return v; }
function seqC(seq, x, out) {
  let a = seq[0], b = seq[seq.length - 1], k = 0;
  if (x <= a[0]) b = a; else if (x >= b[0]) a = b; else for (let i = 1; i < seq.length; i++) if (x <= seq[i][0]) { a = seq[i - 1]; b = seq[i]; k = (x - a[0]) / Math.max(b[0] - a[0], 1e-6); break; }
  const ca = rgbOf(a[1]), cb = rgbOf(b[1]); out[0] = ca[0] + (cb[0] - ca[0]) * k; out[1] = ca[1] + (cb[1] - ca[1]) * k; out[2] = ca[2] + (cb[2] - ca[2]) * k; return out;
}
function hashStr(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
const _m4 = new THREE.Matrix4(), _q = new THREE.Quaternion(), _q2 = new THREE.Quaternion(), _v = new THREE.Vector3(), _v2 = new THREE.Vector3(), _e = new THREE.Euler();
function eulerQ(r, out) { return (out || new THREE.Quaternion()).setFromEuler(_e.set(r[0] * DEG, r[1] * DEG, r[2] * DEG, "YXZ")); } // Roblox's Orientation order
function layerFrame(L) { // the layer's world position and turn (the effect's place, then the layer's own offset)
  const q = eulerQ(L.r, new THREE.Quaternion()).premultiply(vxOriginQ);
  const p = new THREE.Vector3(L.p[0], L.p[1], L.p[2]).applyQuaternion(vxOriginQ).add(vxOrigin);
  return { p, q };
}
function simReset() {
  SIM.t = 0; SIM.copies.forEach(c => vxDropCopy(c)); SIM.copies = [];
  SIM.srcs = VX.eff.layers.map(L => ({ L, rng: vxRand(hashStr(L.id) ^ (SIM.seed * 2654435761)), started: false, stopped: false, acc: 0, parts: [] }));
}
function srcCount(s, n) { const w = Math.floor(n); return w + (s.rng() < n - w ? 1 : 0); }
function simStep(dt) {
  const t = (SIM.t += dt);
  for (const s of SIM.srcs) {
    const L = s.L; if (!L.on) { s.parts.length = 0; continue; }
    if (L.type === "particles") stepParticles(s, t, dt);
    else if (L.type === "mesh") stepMeshSrc(s, t, dt);
  }
  for (let i = SIM.copies.length - 1; i >= 0; i--) { const c = SIM.copies[i]; if (t - c.t0 >= c.life) { vxDropCopy(c); SIM.copies.splice(i, 1); } }
}
function tsOf(L, t) { if (!L.ts.on) return 1; const k = L.ts.duration > 0 ? clamp((t - L.delay) / L.ts.duration, 0, 1) : 1; return L.ts.start + (L.ts.end - L.ts.start) * k; }
function stepParticles(s, t, dt) {
  const L = s.L, ts = tsOf(L, Math.max(t, L.delay)), dp = dt * ts;
  // the ones alive
  const ax = L.accel[0], ay = L.accel[1], az = L.accel[2], dr = L.drag > 0 ? Math.pow(0.5, L.drag * dp) : 1;
  const P = s.parts;
  for (let i = P.length - 1; i >= 0; i--) {
    const p = P[i]; p.age += dp;
    if (p.age >= p.life) { P[i] = P[P.length - 1]; P.pop(); continue; }
    p.vx = (p.vx + ax * dp) * dr; p.vy = (p.vy + ay * dp) * dr; p.vz = (p.vz + az * dp) * dr;
    p.x += p.vx * dp; p.y += p.vy * dp; p.z += p.vz * dp; p.rot += p.rs * dp;
  }
  // new ones
  if (!s.started) { if (t < L.delay) return; s.started = true; const fr = layerFrame(L), n = srcCount(s, L.count); for (let i = 0; i < n; i++) spawnParticle(s, fr); }
  if (s.stopped) return;
  if (t > L.delay + L.duration) { s.stopped = true; return; }
  if (L.duration > 0 && L.rate > 0) { s.acc += dt * L.rate * ts; if (s.acc >= 1) { const fr = layerFrame(L); while (s.acc >= 1) { s.acc -= 1; spawnParticle(s, fr); } } }
}
function spawnParticle(s, fr) {
  const L = s.L, r = s.rng; if (s.parts.length >= 4000) return;
  const sx = L.shapeSize[0] / 2, sy = L.shapeSize[1] / 2, sz = L.shapeSize[2] / 2, base = DIRV[L.dir];
  let px = 0, py = 0, pz = 0, dx = base[0], dy = base[1], dz = base[2];
  const surf = L.shapeStyle === "Surface";
  if (L.shape === "Box") {
    if (surf) { const ax = Math.floor(r() * 3), sgn = r() < 0.5 ? -1 : 1; px = (r() * 2 - 1) * sx; py = (r() * 2 - 1) * sy; pz = (r() * 2 - 1) * sz; if (ax === 0) px = sgn * sx; else if (ax === 1) py = sgn * sy; else pz = sgn * sz; }
    else { px = (r() * 2 - 1) * sx; py = (r() * 2 - 1) * sy; pz = (r() * 2 - 1) * sz; }
  } else if (L.shape === "Sphere") { // straight out from the middle
    let ux, uy, uz, l; do { ux = r() * 2 - 1; uy = r() * 2 - 1; uz = r() * 2 - 1; l = ux * ux + uy * uy + uz * uz; } while (l > 1 || l < 1e-6);
    l = Math.sqrt(l); ux /= l; uy /= l; uz /= l; const k = surf ? 1 : Math.cbrt(r());
    px = ux * sx * k; py = uy * sy * k; pz = uz * sz * k; dx = ux; dy = uy; dz = uz;
  } else if (L.shape === "Cylinder" || L.shape === "Disc") { // round the emission direction's axis, outward from it
    const a = r() * Math.PI * 2, k = surf ? 1 : Math.sqrt(r()), h = L.shape === "Disc" ? 0 : (r() * 2 - 1);
    const axis = new THREE.Vector3(base[0], base[1], base[2]), u = Math.abs(axis.y) < 0.9 ? new THREE.Vector3(0, 1, 0) : new THREE.Vector3(1, 0, 0);
    const e1 = u.clone().cross(axis).normalize(), e2 = axis.clone().cross(e1).normalize(), cr = Math.cos(a), sr = Math.sin(a);
    const rx = Math.abs(e1.x) * sx + Math.abs(e1.y) * sy + Math.abs(e1.z) * sz, ry = Math.abs(e2.x) * sx + Math.abs(e2.y) * sy + Math.abs(e2.z) * sz, rh = Math.abs(axis.x) * sx + Math.abs(axis.y) * sy + Math.abs(axis.z) * sz;
    px = (e1.x * cr * rx + e2.x * sr * ry) * k + axis.x * h * rh; py = (e1.y * cr * rx + e2.y * sr * ry) * k + axis.y * h * rh; pz = (e1.z * cr * rx + e2.z * sr * ry) * k + axis.z * h * rh;
    dx = e1.x * cr + e2.x * sr; dy = e1.y * cr + e2.y * sr; dz = e1.z * cr + e2.z * sr;
  }
  if (L.shape !== "Point" && L.shape !== "Box") { const io = L.shapeInOut === "Inward" ? -1 : L.shapeInOut === "InAndOut" ? (r() < 0.5 ? -1 : 1) : 1; dx *= io; dy *= io; dz *= io; }
  else if (L.shape === "Box" && L.shapeInOut === "Inward") { dx = -dx; dy = -dy; dz = -dz; }
  // spread: a random turn within SpreadAngle about the two axes across the direction
  const ax = L.spread[0] * DEG, ay = L.spread[1] * DEG;
  if (ax > 0 || ay > 0) {
    _v.set(dx, dy, dz); const up = Math.abs(dy) < 0.95 ? _v2.set(0, 1, 0) : _v2.set(1, 0, 0); const a1 = up.clone().cross(_v).normalize(), a2 = _v.clone().cross(a1).normalize();
    _v.applyAxisAngle(a1, (r() * 2 - 1) * ax).applyAxisAngle(a2, (r() * 2 - 1) * ay); dx = _v.x; dy = _v.y; dz = _v.z;
  }
  const sp = L.speed[0] + (L.speed[1] - L.speed[0]) * r();
  _v.set(px, py, pz).applyQuaternion(fr.q).add(fr.p); _v2.set(dx, dy, dz).applyQuaternion(fr.q).multiplyScalar(sp);
  const n = vxGridN(L.flip.layout), frames = n * n;
  s.parts.push({ x: _v.x, y: _v.y, z: _v.z, vx: _v2.x, vy: _v2.y, vz: _v2.z, age: 0, life: L.life[0] + (L.life[1] - L.life[0]) * r(),
    rot: (L.rot[0] + (L.rot[1] - L.rot[0]) * r()) * DEG, rs: (L.rotSpeed[0] + (L.rotSpeed[1] - L.rotSpeed[0]) * r()) * DEG,
    e1: r() * 2 - 1, e2: r() * 2 - 1, f0: L.flip.startRandom ? Math.floor(r() * frames) : 0, fps: L.flip.fps[0] + (L.flip.fps[1] - L.flip.fps[0]) * r(), seed: (r() * 1e9) | 0 });
}
function stepMeshSrc(s, t, dt) {
  const L = s.L;
  if (!s.started) { if (t < L.delay) return; s.started = true; const n = srcCount(s, L.count); for (let i = 0; i < n; i++) spawnCopy(s, t); }
  if (s.stopped) return;
  if (t > L.delay + L.duration) { s.stopped = true; return; }
  if (L.rate > 0) { s.acc += dt * L.rate; while (s.acc >= 1) { s.acc -= 1; spawnCopy(s, t); } }
}
function spawnCopy(s, t) {
  const L = s.L, r = s.rng, fr = layerFrame(L);
  const rnd = (x, y) => x + (y - x) * r();
  const A = new THREE.Matrix4().compose(new THREE.Vector3(...L.start.p).applyQuaternion(fr.q).add(fr.p), eulerQ(L.start.r).premultiply(fr.q), new THREE.Vector3(1, 1, 1));
  const B = new THREE.Matrix4().compose(new THREE.Vector3(...L.end.p).applyQuaternion(fr.q).add(fr.p), eulerQ(L.end.r).premultiply(fr.q), new THREE.Vector3(1, 1, 1));
  let turn = new THREE.Quaternion();
  if (L.initMin.some(v => v) || L.initMax.some(v => v)) turn = new THREE.Quaternion().setFromEuler(new THREE.Euler(rnd(L.initMin[0], L.initMax[0]) * DEG, rnd(L.initMin[1], L.initMax[1]) * DEG, rnd(L.initMin[2], L.initMax[2]) * DEG, "XYZ"));
  if (L.spread[0] || L.spread[1]) turn.premultiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(rnd(-L.spread[0], L.spread[0]) * DEG, 0, rnd(-L.spread[1], L.spread[1]) * DEG, "XYZ")));
  const about = A.clone().multiply(new THREE.Matrix4().makeRotationFromQuaternion(turn)).multiply(A.clone().invert()); // turned about Start's centre, both ends alike
  const ac = about.clone().multiply(A), bc = about.clone().multiply(B);
  const pa = new THREE.Vector3(), qa = new THREE.Quaternion(), pb = new THREE.Vector3(), qb = new THREE.Quaternion(), sc = new THREE.Vector3();
  ac.decompose(pa, qa, sc); bc.decompose(pb, qb, sc);
  const c = { L, t0: t, dur: Math.max(L.morph, 0.02), life: Math.max(L.life, L.morph, 0.02), pa, qa, pb, qb, obj: null };
  c.obj = vxMakeCopyObj(L); vxFx.add(c.obj); SIM.copies.push(c);
}
function vxSeek(t) { // the state at effect time t (negative: before it starts, while the animation leads in)
  VX.t = t; vxComputeOrigin(); simReset();
  const target = Math.max(0, t); let n = Math.min(3600, Math.floor(target * 60));
  for (let i = 0; i < n; i++) simStep(1 / 60);
  const rest = target - n / 60; if (rest > 1e-6) simStep(rest);
}

// ======================================================================= Visuals+: drawing the layers
const P_VERT = `attribute vec3 iPos; attribute vec4 iCol; attribute vec4 iSz; attribute vec3 iVel;
uniform int orient; uniform vec2 grid; uniform float zoff;
varying vec2 vUv; varying vec4 vCol;
void main() {
  vec2 c = position.xy;
  float cs = cos(iSz.z), sn = sin(iSz.z);
  vec2 q = vec2(c.x * iSz.x, c.y * iSz.y); q = vec2(q.x * cs - q.y * sn, q.x * sn + q.y * cs);
  vec3 toCam = normalize(cameraPosition - iPos), right, up;
  if (orient == 0) { right = vec3(viewMatrix[0][0], viewMatrix[1][0], viewMatrix[2][0]); up = vec3(viewMatrix[0][1], viewMatrix[1][1], viewMatrix[2][1]); }
  else if (orient == 1) { up = vec3(0.0, 1.0, 0.0); right = normalize(cross(up, toCam) + vec3(1e-5, 0.0, 0.0)); }
  else { vec3 v = length(iVel) > 1e-4 ? normalize(iVel) : vec3(0.0, 1.0, 0.0);
    if (orient == 2) { up = v; right = normalize(cross(v, toCam) + vec3(0.0, 1e-5, 0.0)); }
    else { vec3 a = abs(v.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0); right = normalize(cross(a, v)); up = cross(v, right); } }
  vec3 wp = iPos + right * q.x + up * q.y + toCam * zoff;
  gl_Position = projectionMatrix * viewMatrix * vec4(wp, 1.0);
  float f = floor(iSz.w + 0.5), cx = mod(f, grid.x), cy = floor(f / grid.x);
  vUv = vec2((cx + c.x + 0.5) / grid.x, 1.0 - (cy + 0.5 - c.y) / grid.y);
  vCol = iCol;
}`;
const P_FRAG = `uniform sampler2D map; uniform float le; uniform float bright; uniform float gp;
varying vec2 vUv; varying vec4 vCol;
void main() { vec4 t = texture2D(map, vUv); float a = t.a * vCol.a; if (a < 0.003) discard;
  gl_FragColor = vec4(t.rgb * vCol.rgb * bright * a * mix(1.0, le, gp), a * (1.0 - le)); }`;
const B_VERT = `attribute vec4 aCol; varying vec2 vUv; varying vec4 vCol; void main() { vUv = uv; vCol = aCol; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`;
const B_FRAG = `uniform sampler2D map; uniform float le; uniform float bright; uniform float gp; varying vec2 vUv; varying vec4 vCol;
void main() { vec4 t = texture2D(map, vUv); float a = t.a * vCol.a; if (a < 0.003) discard; gl_FragColor = vec4(t.rgb * vCol.rgb * bright * a * mix(1.0, le, gp), a * (1.0 - le)); }`;
const FF_VERT = `varying vec3 vN; varying vec3 vV; varying vec3 vP; void main() { vN = normalize(normalMatrix * normal); vec4 mv = modelViewMatrix * vec4(position, 1.0); vV = normalize(-mv.xyz); vP = position; gl_Position = projectionMatrix * mv; }`;
const FF_FRAG = `uniform vec3 color; uniform float opacity; uniform float time; varying vec3 vN; varying vec3 vV; varying vec3 vP;
void main() { float f = pow(1.0 - abs(dot(normalize(vN), normalize(vV))), 2.0);
  float w = 0.55 + 0.45 * sin(vP.y * 14.0 + time * 4.0) * sin(vP.x * 9.0 - time * 2.5 + vP.z * 7.0);
  float a = clamp((0.12 + 0.9 * f) * (0.55 + 0.45 * w), 0.0, 1.0) * opacity;
  gl_FragColor = vec4(color * 2.2 * a, a * 0.25); }`;
const premul = m => { m.transparent = true; m.depthWrite = false; m.blending = THREE.CustomBlending; m.blendEquation = THREE.AddEquation; m.blendSrc = THREE.OneFactor; m.blendDst = THREE.OneMinusSrcAlphaFactor; return m; };
const ORIENT_I = { FacingCamera: 0, FacingCameraWorldUp: 1, VelocityParallel: 2, VelocityPerpendicular: 3 };
function vxParticleObj(L, cap) {
  const g = new THREE.InstancedBufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute([-0.5, -0.5, 0, 0.5, -0.5, 0, 0.5, 0.5, 0, -0.5, 0.5, 0], 3)); g.setIndex([0, 1, 2, 0, 2, 3]);
  const A = (n, k) => { const a = new THREE.InstancedBufferAttribute(new Float32Array(cap * k), k); a.setUsage(THREE.DynamicDrawUsage); g.setAttribute(n, a); return a; };
  const o = { kind: "particles", cap, geo: g, iPos: A("iPos", 3), iCol: A("iCol", 4), iSz: A("iSz", 4), iVel: A("iVel", 3) };
  o.mat = premul(new THREE.ShaderMaterial({ vertexShader: P_VERT, fragmentShader: P_FRAG,
    uniforms: { map: { value: null }, orient: { value: 0 }, grid: { value: new THREE.Vector2(1, 1) }, zoff: { value: 0 }, le: { value: 1 }, bright: { value: 1 }, gp: { value: 0 } } }));
  o.mesh = new THREE.Mesh(g, o.mat); o.mesh.frustumCulled = false; g.instanceCount = 0;
  return o;
}
function vxBeamObj(L) {
  const n = clamp(L.segments, 1, 200) + 1, g = new THREE.BufferGeometry();
  const pos = new THREE.BufferAttribute(new Float32Array(n * 2 * 3), 3), uv = new THREE.BufferAttribute(new Float32Array(n * 2 * 2), 2), col = new THREE.BufferAttribute(new Float32Array(n * 2 * 4), 4);
  for (const a of [pos, uv, col]) a.setUsage(THREE.DynamicDrawUsage);
  g.setAttribute("position", pos); g.setAttribute("uv", uv); g.setAttribute("aCol", col);
  const idx = []; for (let i = 0; i < n - 1; i++) { const a = i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); } g.setIndex(idx);
  const mat = premul(new THREE.ShaderMaterial({ vertexShader: B_VERT, fragmentShader: B_FRAG, uniforms: { map: { value: null }, le: { value: 1 }, bright: { value: 1 }, gp: { value: 0 } }, side: THREE.DoubleSide }));
  const mesh = new THREE.Mesh(g, mat); mesh.frustumCulled = false;
  return { kind: "beam", n, geo: g, pos, uv, col, mat, mesh };
}
const vxGeos = {};
function vxShapeGeo(shape) {
  if (vxGeos[shape]) return vxGeos[shape];
  let g;
  if (shape === "Ring") { const pr = [new THREE.Vector2(0.42, -0.5), new THREE.Vector2(0.5, -0.5), new THREE.Vector2(0.5, 0.5), new THREE.Vector2(0.42, 0.5), new THREE.Vector2(0.42, -0.5)]; g = new THREE.LatheGeometry(pr, 64); }
  else if (shape === "Sphere") g = new THREE.SphereGeometry(0.5, 40, 24);
  else if (shape === "Cylinder") g = new THREE.CylinderGeometry(0.5, 0.5, 1, 40);
  else if (shape === "Wedge") g = wedgeGeo();
  else if (shape === "Mesh") g = new THREE.IcosahedronGeometry(0.5, 1);
  else g = new THREE.BoxGeometry(1, 1, 1);
  g.userData.shared = true; vxGeos[shape] = g; return g;
}
const NEON = 1; // (its glow comes from the bloom pass, so it keeps its true colour)
function vxMakeCopyObj(L) {
  let mat; const col = new THREE.Color(L.color);
  if (L.material === "Neon") { mat = new THREE.MeshBasicMaterial({ color: col.clone().multiplyScalar(NEON), transparent: true, depthWrite: false }); }
  else if (L.material === "ForceField") { mat = premul(new THREE.ShaderMaterial({ vertexShader: FF_VERT, fragmentShader: FF_FRAG, uniforms: { color: { value: col }, opacity: { value: 1 }, time: { value: 0 } }, side: THREE.DoubleSide })); }
  else if (L.material === "Glass") mat = new THREE.MeshStandardMaterial({ color: col, roughness: 0.08, metalness: 0.2, transparent: true, depthWrite: false });
  else mat = new THREE.MeshStandardMaterial({ color: col, roughness: 0.5, metalness: 0, transparent: true });
  const m = new THREE.Mesh(vxShapeGeo(L.shape), mat); m.userData.vxMat = L.material; return m;
}
function vxDropCopy(c) { if (c.obj) { vxFx.remove(c.obj); c.obj.material.dispose(); c.obj = null; } }
function vxSyncObjects() { // one drawing per layer (rebuilt when its kind, texture or size changes)
  if (!vxScene) return;
  const keep = new Set();
  VX.eff.layers.forEach((L, i) => {
    keep.add(L.id);
    let o = vxObjs.get(L.id);
    if (L.type === "particles") {
      if (!o || o.kind !== "particles") { if (o) vxDropObj(o); o = vxParticleObj(L, 256); vxObjs.set(L.id, o); vxFx.add(o.mesh); }
      const t = vxTexture(L.tex), n = vxGridN(L.flip.layout);
      o.mat.uniforms.map.value = vxThreeTex(t, false); o.mat.uniforms.grid.value.set(n, n); o.mat.uniforms.orient.value = ORIENT_I[L.orient];
      o.mat.uniforms.zoff.value = L.z; o.mat.uniforms.le.value = L.light; o.mat.uniforms.bright.value = L.bright;
    } else if (L.type === "beam") {
      if (!o || o.kind !== "beam" || o.n !== clamp(L.segments, 1, 200) + 1) { if (o) vxDropObj(o); o = vxBeamObj(L); vxObjs.set(L.id, o); vxFx.add(o.mesh); }
      o.mat.uniforms.map.value = vxThreeTex(vxTexture(L.tex), true); o.mat.uniforms.le.value = L.light; o.mat.uniforms.bright.value = L.bright;
    } else if (o) { vxDropObj(o); vxObjs.delete(L.id); }
    if (o && o.mesh) o.mesh.renderOrder = 10 + i;
  });
  for (const [id, o] of vxObjs) if (!keep.has(id)) { vxDropObj(o); vxObjs.delete(id); }
  // a source whose layer was replaced (undo / open) gets the new one
  const byId = new Map(VX.eff.layers.map(L => [L.id, L]));
  for (const s of SIM.srcs) { const L = byId.get(s.L.id); if (L) s.L = L; }
  const ids = new Set(SIM.srcs.map(s => s.L.id));
  for (const L of VX.eff.layers) if (!ids.has(L.id)) SIM.srcs.push({ L, rng: vxRand(hashStr(L.id)), started: false, stopped: false, acc: 0, parts: [] });
  SIM.srcs = SIM.srcs.filter(s => byId.has(s.L.id));
  for (let i = SIM.copies.length - 1; i >= 0; i--) { const c = SIM.copies[i], L = byId.get(c.L.id); if (!L || L.type !== "mesh" || c.obj.userData.vxMat !== L.material || c.obj.geometry !== vxShapeGeo(L.shape)) { vxDropCopy(c); SIM.copies.splice(i, 1); } else c.L = L; }
  $("vxEmpty").hidden = VX.eff.layers.length > 0;
}
function vxDropObj(o) { vxFx.remove(o.mesh); o.geo.dispose(); o.mat.dispose(); }
const _col = [0, 0, 0], _cv = new THREE.Vector3();
let vxStats = { parts: 0, fill: 0 };
function vxDraw(now) { // fill each layer's drawing from the simulation
  const camPos = vxCam.position, H = $("vxStage").clientHeight || 1, W = $("vxStage").clientWidth || 1, focal = H / (2 * Math.tan(vxCam.fov * DEG / 2));
  let parts = 0, fill = 0;
  const srcById = new Map(SIM.srcs.map(s => [s.L.id, s]));
  for (const L of VX.eff.layers) {
    const o = vxObjs.get(L.id); if (!o) continue;
    const s = srcById.get(L.id);
    if (o.kind === "particles") {
      const P = (s && L.on && VX.t >= 0) ? s.parts : [];
      if (P.length > o.cap) { vxDropObj(o); const n = vxParticleObj(L, Math.min(8192, Math.max(P.length, o.cap * 2))); vxObjs.set(L.id, n); vxFx.add(n.mesh); vxSyncObjects(); return vxDraw(now); }
      let list = P;
      if (L.light < 0.999 && P.length > 1) { for (const p of P) p.d = (p.x - camPos.x) ** 2 + (p.y - camPos.y) ** 2 + (p.z - camPos.z) ** 2; list = P.slice().sort((a, b) => b.d - a.d); }
      const frames = vxGridN(L.flip.layout) ** 2;
      for (let i = 0; i < list.length; i++) {
        const p = list[i], x = p.age / p.life;
        const size = Math.max(0, seqN(L.size, x, p.e1)), sq = seqN(L.squash, x, 0);
        const w = sq >= 0 ? size / (1 + sq) : size * (1 - sq), h = sq >= 0 ? size * (1 + sq) : size / (1 - sq);
        const a = 1 - clamp(seqN(L.transp, x, p.e2), 0, 1);
        seqC(L.color, x, _col);
        let f = 0;
        if (frames > 1) {
          const fm = L.flip.mode;
          if (fm === "OneShot") f = Math.min(frames - 1, Math.floor(x * frames));
          else if (fm === "PingPong") { const k = Math.floor(p.f0 + p.age * p.fps) % Math.max(1, 2 * frames - 2); f = k < frames ? k : 2 * frames - 2 - k; }
          else if (fm === "Random") f = (hashStr(String(Math.floor(p.age * p.fps) + p.seed)) % frames);
          else f = Math.floor(p.f0 + p.age * p.fps) % frames;
        }
        o.iPos.array.set([p.x, p.y, p.z], i * 3); o.iVel.array.set([p.vx, p.vy, p.vz], i * 3);
        o.iCol.array.set([_col[0], _col[1], _col[2], a], i * 4); o.iSz.array.set([w, h, p.rot, f], i * 4);
        const dist = Math.max(0.5, Math.sqrt(p.d || ((p.x - camPos.x) ** 2 + (p.y - camPos.y) ** 2 + (p.z - camPos.z) ** 2))), px = size * focal / dist;
        fill += a * px * px / (W * H);
      }
      parts += list.length;
      o.geo.instanceCount = list.length;
      for (const k of ["iPos", "iVel", "iCol", "iSz"]) o[k].needsUpdate = true;
      o.mesh.visible = list.length > 0;
    } else if (o.kind === "beam") {
      const on = L.on && VX.t >= L.delay && (L.duration <= 0 ? VX.t <= vxLongest(VX.eff) : VX.t <= L.delay + L.duration);
      o.mesh.visible = on; if (!on) continue;
      const fr = layerFrame(L), A = new THREE.Vector3(...L.a).applyQuaternion(fr.q).add(fr.p), B = new THREE.Vector3(...L.b).applyQuaternion(fr.q).add(fr.p);
      const xA = new THREE.Vector3(1, 0, 0).applyQuaternion(fr.q), zA = new THREE.Vector3(0, 0, 1).applyQuaternion(fr.q);
      const P1 = A.clone().addScaledVector(xA, L.curve[0]), P2 = B.clone().addScaledVector(xA, -L.curve[1]);
      const bez = (u, out) => { const v = 1 - u; return out.set(0, 0, 0).addScaledVector(A, v * v * v).addScaledVector(P1, 3 * v * v * u).addScaledVector(P2, 3 * v * u * u).addScaledVector(B, u * u * u); };
      const n = o.n, pts = []; let len = 0;
      for (let i = 0; i < n; i++) { const pt = bez(i / (n - 1), new THREE.Vector3()); if (i) len += pt.distanceTo(pts[i - 1]); pts.push(pt); }
      let dist = 0; const scroll = (VX.t - L.delay) * L.texSpeed;
      for (let i = 0; i < n; i++) {
        const u = i / (n - 1), pt = pts[i]; if (i) dist += pt.distanceTo(pts[i - 1]);
        const tan = (i < n - 1 ? pts[i + 1].clone().sub(pt) : pt.clone().sub(pts[i - 1])).normalize();
        let side = L.faceCam ? tan.clone().cross(_cv.copy(camPos).sub(pt)).normalize() : zA.clone().addScaledVector(tan, -zA.dot(tan)).normalize();
        if (!isFinite(side.x) || side.lengthSq() < 1e-6) side = xA.clone();
        const w = (L.width[0] + (L.width[1] - L.width[0]) * u) / 2;
        o.pos.array.set([pt.x + side.x * w, pt.y + side.y * w, pt.z + side.z * w, pt.x - side.x * w, pt.y - side.y * w, pt.z - side.z * w], i * 6);
        const U = (L.texMode === "Stretch" ? u * L.texLen : dist / L.texLen) - scroll;
        o.uv.array.set([U, 1, U, 0], i * 4);
        const a = 1 - clamp(seqN(L.transp, u, 0), 0, 1); seqC(L.color, u, _col);
        o.col.array.set([_col[0], _col[1], _col[2], a, _col[0], _col[1], _col[2], a], i * 8);
      }
      o.pos.needsUpdate = o.uv.needsUpdate = o.col.needsUpdate = true; o.geo.computeBoundingSphere();
    }
  }
  // mesh copies
  for (const c of SIM.copies) {
    const L = c.L, age = SIM.t - c.t0, k = clamp(age / c.dur, 0, 1), ks = rbxEase(L.ease[0], L.ease[1], k);
    const m = c.obj; m.visible = L.on && VX.t >= 0;
    m.position.lerpVectors(c.pa, c.pb, ks); m.quaternion.copy(c.qa).slerp(c.qb, ks);
    if (L.spin[0] || L.spin[1]) { const ang = (L.spin[0] + (L.spin[1] - L.spin[0]) * clamp(age / c.life, 0, 1) * 0.5) * age * DEG; m.quaternion.multiply(_q.setFromAxisAngle(_v.set(0, 1, 0), ang)); }
    const s0 = L.start.size, s1 = L.end.size; m.scale.set(s0[0] + (s1[0] - s0[0]) * ks, s0[1] + (s1[1] - s0[1]) * ks, s0[2] + (s1[2] - s0[2]) * ks);
    const tr = clamp(L.t0 + (L.t1 - L.t0) * rbxEase(L.tease[0], L.tease[1], clamp(age / c.life, 0, 1)), 0, 1), op = 1 - tr;
    if (m.material.uniforms) { m.material.uniforms.opacity.value = op; m.material.uniforms.time.value = now / 1000; }
    else { m.material.opacity = L.material === "Glass" ? op * 0.35 : op; m.material.depthWrite = L.material === "SmoothPlastic" && op > 0.99; }
    if (m.visible) { parts++; const d = Math.max(0.5, m.position.distanceTo(camPos)), px = Math.max(m.scale.x, m.scale.z) * focal / d; fill += op * 0.5 * px * px / (W * H); }
  }
  vxStats = { parts, fill };
}

// ======================================================================= Visuals+: the camera feel, bloom, and the frame loop
const VX_LIGHT = { studio: [1, 24, 2], game: [0.15, 24, 2.5] }; // a baseplate's bloom; One Shot Duels' own
function vxCamFx(t) { // shake (studs), FOV punch (degrees) and flash (0..1) at effect time t
  const c = VX.eff.cam, k = (v, tt) => (v[0] && v[1] > 0 && tt >= v[2] && tt <= v[2] + v[1]) ? 1 - (tt - v[2]) / v[1] : 0;
  const ks = k(c.shake, t), kf = k(c.fov, t), kl = k(c.flash, t);
  return { shake: c.shake[0] * ks * ks, fov: c.fov[0] * kf * kf, flash: c.flash[0] * kl, flashColor: c.flashColor };
}
function vxRender(now) {
  if (!vxR) return;
  vxDraw(now);
  // the camera's feel, on top of where you put it
  const fx = VX.t >= 0 ? vxCamFx(VX.t) : { shake: 0, fov: 0, flash: 0 };
  const saved = vxCam.position.clone(), base = VX.fovBase || 55;
  if (fx.shake > 0) { const tt = now / 1000; vxCam.position.add(_v.set(Math.sin(tt * 71.3) + Math.sin(tt * 37.1) * 0.6, Math.sin(tt * 63.7 + 1.3) + Math.sin(tt * 29.3) * 0.6, Math.sin(tt * 53.9 + 2.1)).multiplyScalar(fx.shake * 0.35)); }
  if (fx.fov) { vxCam.fov = base + fx.fov; vxCam.updateProjectionMatrix(); }
  $("vxFlash").style.opacity = fx.flash ? String(clamp(fx.flash, 0, 1)) : "0"; if (fx.flash) $("vxFlash").style.background = fx.flashColor;
  // bloom: the lighting you picked, plus the effect's own while it plays (as ForgeVFX adds it in game)
  if (vxBloom) {
    const env = VX_LIGHT[VX.light], b = VX.eff.bloom, on = b.on && VX.t >= 0 && VX.t <= vxLongest(VX.eff) + 0.4;
    const inten = env[0] + (on ? b.intensity : 0), size = on ? Math.max(env[1], b.size) : env[1], thr = on ? Math.min(env[2], b.threshold) : env[2];
    vxBloom.strength = inten * 0.45; vxBloom.radius = clamp(size / 56, 0.05, 1); vxBloom.threshold = clamp((thr - 0.8) * 0.2, 0, 0.6);
    vxGlowPass(); vxComposer.render();
  } else vxR.render(vxScene, vxCam);
  vxCam.position.copy(saved); if (fx.fov) { vxCam.fov = base; vxCam.updateProjectionMatrix(); }
  // the meter: how much is on screen
  const el = $("vxPerf"), lv = vxStats.parts > 2500 || vxStats.fill > 6 ? "high" : vxStats.parts > 1000 || vxStats.fill > 2.5 ? "mid" : "low";
  el.dataset.l = lv; $("vxPerfTxt").textContent = `${vxStats.parts.toLocaleString()} particles` + (vxStats.fill >= 0.5 ? ` · ${vxStats.fill.toFixed(1)}× fill` : "");
  el.title = lv === "high" ? "Heavy: slower phones will drop frames. Fewer or smaller particles help." : lv === "mid" ? "Getting heavy for phones." : "Light enough for phones.";
}
const vxBlack = new THREE.MeshBasicMaterial({ color: 0x000000 }), vxBlackBg = new THREE.Color(0x000000);
function vxGlowPass() { // what glows: neon / force-field copies and light-emitting particles and beams; everything else black
  const swapped = [], bg = vxScene.background;
  const dark = o => o.traverse(n => { if (n.isMesh && n.material !== vxBlack) { swapped.push([n, n.material]); n.material = vxBlack; } });
  dark(vxRig.root); dark(vxFloor);
  for (const c of SIM.copies) if (c.obj && c.obj.userData.vxMat !== "Neon" && c.obj.userData.vxMat !== "ForceField") dark(c.obj);
  for (const o of vxObjs.values()) o.mat.uniforms.gp.value = 1;
  vxScene.background = vxBlackBg; const gv = vxGrid ? vxGrid.visible : false; if (vxGrid) vxGrid.visible = false;
  vxBloomComp.render();
  for (const [n, m] of swapped) n.material = m;
  for (const o of vxObjs.values()) o.mat.uniforms.gp.value = 0;
  vxScene.background = bg; if (vxGrid) vxGrid.visible = gv;
}
function vxEnd() { return vxLongest(VX.eff) + 0.35; }
function vxAdvance(d) {
  let t = VX.t + d; const end = vxEnd();
  if (t > end) { if (VX.loop) { SIM.seed++; vxSeek(-vxLead()); return; } t = end; VX.playing = false; renderVxTransport(); }
  if (t > 0) { // run the effect up to t in steps no longer than 1/30 s
    if (VX.t < 0) { vxComputeOrigin(); simReset(); }
    let rem = t - Math.max(VX.t, 0); while (rem > 1e-6) { const h = Math.min(rem, 1 / 30); simStep(h); rem -= h; }
  }
  VX.t = t;
}
appHooks.visualsStep = now => {
  const dt = Math.min(0.05, (now - vxLast) / 1000); vxLast = now;
  if (VX.playing) {
    let d = dt * VX.speed; const hs = VX.eff.cam.hitstop;
    if (VX.freeze > 0) { VX.freeze -= d; d = 0; }
    else if (hs[0] > 0 && VX.t < hs[1] && VX.t + d >= hs[1]) { d = hs[1] - VX.t; VX.freeze = hs[0]; } // hit-stop: everything holds a moment
    if (d > 0) vxAdvance(d);
  }
  if (vxRig) { const a = vxAnim(); vxPoseRig(vxLead() + VX.t); vxRig.root.visible = VX.showRig; if (!a && !VX.showRig) vxRig.root.visible = false; }
  if (vxOrbit) vxOrbit.update();
  vxRender(now);
  $("vxTime").textContent = (VX.t < 0 ? "−" : "") + Math.abs(VX.t).toFixed(2) + " s";
  vxPlacePlayhead();
};

// ======================================================================= Visuals+: transport and view buttons
const VX_SPEEDS = [[0.1, "⅒"], [0.25, "¼"], [0.5, "½"], [1, "1×"]];
function renderVxSpeeds() {
  const el = $("vxSpeeds"); el.innerHTML = "";
  for (const [v, t] of VX_SPEEDS) el.append(make("button", { type: "button", class: "chip", "aria-pressed": String(VX.speed === v), text: t, title: `Speed ${v}×`, onclick: () => { VX.speed = v; renderVxSpeeds(); } }));
}
const PLAY_SVG = '<svg viewBox="0 0 16 16"><path d="M4 2v12l10-6z"/></svg>', PAUSE_SVG = '<svg viewBox="0 0 16 16"><path d="M3 2h4v12H3zM9 2h4v12H9z"/></svg>';
function renderVxTransport() {
  $("vxPlay").innerHTML = VX.playing ? PAUSE_SVG : PLAY_SVG; $("vxPlay").setAttribute("aria-label", VX.playing ? "Pause" : "Play");
  $("vxLoop").setAttribute("aria-pressed", String(VX.loop));
  $("vxLight").textContent = VX.light === "game" ? "Game light" : "Studio light"; $("vxLight").setAttribute("aria-pressed", String(VX.light === "game"));
  $("vxRig").setAttribute("aria-pressed", String(VX.showRig));
}
function vxSetPlaying(p) { VX.playing = p; if (p && VX.t >= vxEnd() - 1e-3) { SIM.seed++; vxSeek(-vxLead()); } vxLast = performance.now(); renderVxTransport(); }
function vxStepFrame(dir) { VX.playing = false; renderVxTransport(); const t = clamp(VX.t + dir / 60, -vxLead(), vxEnd()); if (dir > 0 && VX.t >= 0) vxAdvance(1 / 60); else vxSeek(t); }
function vxRestart() { SIM.seed++; vxSeek(-vxLead()); VX.freeze = 0; if (!VX.playing) vxSetPlaying(true); }
function vxBindUi() {
  $("vxPlay").onclick = () => vxSetPlaying(!VX.playing);
  $("vxRestart").onclick = vxRestart;
  $("vxBack").onclick = () => vxStepFrame(-1); $("vxFwd").onclick = () => vxStepFrame(1);
  $("vxLoop").onclick = () => { VX.loop = !VX.loop; renderVxTransport(); };
  $("vxLight").onclick = () => { VX.light = VX.light === "game" ? "studio" : "game"; store.set("farshtah.vx.light", VX.light); renderVxTransport(); };
  $("vxRig").onclick = () => { VX.showRig = !VX.showRig; store.set("farshtah.vx.rig", VX.showRig ? "1" : "0"); renderVxTransport(); };
  $("vxBackdrop").onclick = () => { VX.backdrop = VX.backdrop === "night" ? "baseplate" : VX.backdrop === "baseplate" ? "theme" : "night"; store.set("farshtah.vx.bd", VX.backdrop); vxApplyBackdrop(); };
  $("vxCam").onclick = () => { if (!vxOrbit) return; vxCam.position.set(10, 7, -12); vxOrbit.target.set(vxOrigin.x * 0.5, 3, vxOrigin.z * 0.5 - 1); vxOrbit.update(); };
  $("vxExport").onclick = () => vxOpenExport();
  for (const id of ["add", "samples", "tex"]) $("vxr-" + id).onclick = () => vxSetLib(id);
  $("vxr-fx").onclick = () => { VX.sel = -1; renderVxInsp(); renderVxTimeline(); };
  $("vxTlZoomIn").onclick = () => { VX.zoom = Math.min(8, VX.zoom * 1.5); renderVxTimeline(); };
  $("vxTlZoomOut").onclick = () => { VX.zoom = Math.max(0.5, VX.zoom / 1.5); renderVxTimeline(); };
  $("vxTlMain").addEventListener("scroll", () => { $("vxNames").scrollTop = $("vxTlMain").scrollTop; });
  $("vxNames").addEventListener("wheel", e => { $("vxTlMain").scrollTop += e.deltaY; e.preventDefault(); }, { passive: false });
}
function vxSetLib(id) { VX.lib = id; store.set("farshtah.vx.lib", id); for (const x of ["add", "samples", "tex"]) $("vxr-" + x).setAttribute("aria-selected", String(x === id)); renderVxLib(); }

// ======================================================================= Visuals+: the library (add, samples, textures)
const LT_COLOR = { particles: "var(--accent)", mesh: "var(--key)", beam: "var(--ok)" };
const LT_ICON = {
  particles: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="2.5"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/></svg>',
  mesh: '<svg viewBox="0 0 24 24"><ellipse cx="12" cy="12" rx="9" ry="3.5"/><ellipse cx="12" cy="12" rx="5" ry="1.8"/></svg>',
  beam: '<svg viewBox="0 0 24 24"><path d="M4 18C9 18 9 6 14 6s5 6 6 6"/><circle cx="4" cy="18" r="1.5"/><circle cx="20" cy="12" r="1.5"/></svg>',
  fx: '<svg viewBox="0 0 24 24"><path d="M4 7h10M4 17h6M18 7h2M14 17h6"/><circle cx="16" cy="7" r="2"/><circle cx="12" cy="17" r="2"/></svg>' };
function vxQuickAdds() { // ready-made layers
  const C = (...cs) => cs.map((c, i) => [cs.length > 1 ? i / (cs.length - 1) : 0, c]).concat(cs.length === 1 ? [[1, cs[0]]] : []);
  return [
    ["Particles", "particles", "glow", "#ffffff", {}],
    ["Ring", "mesh", null, "#7fd8ff", { name: "Ring" }],
    ["Sphere", "mesh", null, "#ffd27a", { name: "Sphere", shape: "Sphere", start: { size: [1, 1, 1], p: [0, 0, 0], r: [0, 0, 0] }, end: { size: [6, 6, 6], p: [0, 0, 0], r: [0, 0, 0] }, morph: 0.3, life: 0.3 }],
    ["Beam", "beam", "beam", "#ff5ad1", { color: C("#ffffff", "#ff5ad1"), light: 1, bright: 2, texMode: "Wrap", texLen: 6, texSpeed: 3, duration: 0.8 }],
    ["Sparks", "particles", "spark", "#ffb347", { name: "Sparks", count: 24, rate: 0, speed: [30, 55], spread: [180, 180], drag: 6, orient: "VelocityParallel", size: [[0, 0.5, 0], [1, 0, 0]], squash: [[0, 1.6, 0], [1, 1.6, 0]], color: C("#ffffff", "#ffb347", "#ff5a1f"), bright: 2, life: [0.25, 0.45], accel: [0, -30, 0] }],
    ["Glow", "particles", "glow", "#7fd8ff", { name: "Glow", count: 1, rate: 0, speed: [0, 0], life: [0.3, 0.3], size: [[0, 2, 0], [0.4, 6, 0], [1, 7, 0]], color: C("#ffffff", "#7fd8ff"), bright: 2 }],
    ["Smoke", "particles", "smoke", "#8a8f99", { name: "Smoke", count: 8, rate: 0, speed: [2, 5], spread: [180, 180], drag: 1.5, accel: [0, 3, 0], life: [0.9, 1.4], size: [[0, 2, 0.4], [1, 5, 0.6]], transp: [[0, 0.4, 0], [1, 1, 0]], color: C("#c5c9d2", "#4a4f59"), light: 0, rot: [0, 360], rotSpeed: [-40, 40] }],
    ["Fire", "particles", "fire", "#ff7a2f", { name: "Fire", flip: { layout: "Grid4x4", mode: "OneShot", fps: [30, 30], startRandom: false }, shape: "Box", shapeSize: [2, 0.3, 2], count: 0, rate: 30, duration: 1, speed: [3, 6], spread: [8, 8], life: [0.5, 0.8], size: [[0, 1.5, 0.3], [1, 2.2, 0.3]], transp: [[0, 1, 0], [0.15, 0.1, 0], [1, 1, 0]], color: C("#ffffff", "#ffb23d", "#ff3d1f"), bright: 1.5 }],
    ["Lightning", "particles", "lightning", "#9fd8ff", { name: "Lightning", flip: { layout: "Grid2x2", mode: "Random", fps: [24, 24], startRandom: true }, orient: "FacingCameraWorldUp", count: 1, rate: 0, speed: [0, 0], life: [0.3, 0.3], p: [0, 6, 0], size: [[0, 12, 0], [1, 12, 0]], transp: [[0, 0, 0], [0.7, 0, 0], [1, 1, 0]], color: C("#ffffff", "#9fd8ff"), bright: 3 }],
    ["Shockwave", "mesh", null, "#ffffff", { name: "Shockwave", start: { size: [2, 0.3, 2], p: [0, 0.1, 0], r: [0, 0, 0] }, end: { size: [24, 0.1, 24], p: [0, 0.1, 0], r: [0, 0, 0] }, morph: 0.45, life: 0.45, color: "#dff3ff" }],
    ["Dust", "particles", "dust", "#c9b79a", { name: "Dust", shape: "Disc", shapeSize: [4, 0.2, 4], count: 18, rate: 0, speed: [8, 14], spread: [0, 0], drag: 3, life: [0.5, 0.9], size: [[0, 1.2, 0.3], [1, 3.5, 0.5]], transp: [[0, 0.45, 0], [1, 1, 0]], color: C("#d9c7a8", "#8a7a66"), light: 0, rot: [0, 360] }],
    ["Stars", "particles", "star", "#ffe28a", { name: "Stars", count: 12, rate: 0, speed: [6, 12], spread: [180, 180], drag: 2, life: [0.5, 0.9], size: [[0, 0, 0], [0.25, 0.9, 0], [1, 0, 0]], color: C("#ffffff", "#ffe28a"), bright: 2, rotSpeed: [-180, 180] }],
  ];
}
function renderVxLib() {
  const el = $("vxLib"); if (!el) return; const top = el.querySelector(".lbody") ? el.querySelector(".lbody").scrollTop : 0; el.innerHTML = "";
  const body = make("div", { class: "lbody" });
  if (VX.lib === "add") {
    el.append(make("div", { class: "lhead" }, make("h3", { text: "Add a layer" })));
    const tiles = make("div", { class: "tiles" });
    for (const [name, type, tex, col, over] of vxQuickAdds()) {
      const art = type === "mesh" ? vxMeshThumb(over.shape || "Ring", col) : vxThumb(tex, col, 160, 100);
      art.className = "ti";
      tiles.append(make("button", { type: "button", class: "tile", title: `Add ${name}`, onclick: () => vxAddLayer(type, Object.assign({ name, tex: tex || undefined }, over)) }, art, make("span", { text: name }), make("span", { class: "ty", text: type === "particles" ? "Particles" : type === "mesh" ? "Mesh" : "Beam" })));
    }
    body.append(tiles);
  } else if (VX.lib === "samples") {
    el.append(make("div", { class: "lhead" }, make("h3", { text: "Samples" })));
    const tiles = make("div", { class: "tiles" });
    for (const s of vxSamples()) {
      const main = s.effect.layers.find(l => l.type === "particles"), art = vxThumb(main ? main.tex : "glow", s.tint, 160, 100); art.className = "ti";
      tiles.append(make("button", { type: "button", class: "tile", id: "vxs-" + s.key, title: `Open ${s.name} as a new effect`, onclick: () => vxLoadSample(s) }, art, make("span", { text: s.name }), make("span", { class: "ty", text: `${s.effect.layers.length} layers` })));
    }
    body.append(tiles);
  } else {
    el.append(make("div", { class: "lhead" }, make("h3", { text: "Textures" }), make("button", { type: "button", class: "btn", id: "vxTexImport", text: "Import", onclick: () => vxImportTex() })));
    const L = vxL(), cur = L && L.tex;
    const grid = make("div", { class: "texgrid" });
    for (const [key, name] of VX_TEX) grid.append(vxTexButton(key, name, cur));
    body.append(make("h4", { text: "Ready to use" }), grid);
    const mine = make("div", { class: "texgrid" });
    for (const d of vxCustom.values()) mine.append(vxTexButton("u:" + d.id, d.name, cur, d));
    mine.append(make("button", { type: "button", class: "texbtn imp", text: "+ PNG, JPG or GIF", onclick: () => vxImportTex() }));
    body.append(make("h4", { text: "Yours" }), mine);
  }
  el.append(body); body.scrollTop = top;
}
function vxTexButton(key, name, cur, doc) {
  const b = make("button", { type: "button", class: "texbtn", "aria-pressed": String(cur === key), title: name, onclick: () => vxUseTexture(key) }, vxThumb(key, null, 96, 96), make("span", { class: "k", text: name }));
  if (doc) b.append(make("button", { type: "button", class: "x", "aria-label": "Delete " + name, text: "×", onclick: e => { e.stopPropagation(); vxDeleteTex(doc); } }));
  return b;
}
function vxMeshThumb(shape, color) {
  const cv = document.createElement("canvas"); cv.width = 160; cv.height = 100; const c = cv.getContext("2d");
  c.fillStyle = "#0b0d14"; c.fillRect(0, 0, 160, 100); c.shadowColor = color; c.shadowBlur = 14; c.strokeStyle = color; c.fillStyle = color; c.lineWidth = 5;
  if (shape === "Sphere") { const g = c.createRadialGradient(80, 50, 4, 80, 50, 34); g.addColorStop(0, "#ffffff"); g.addColorStop(0.5, color); g.addColorStop(1, color + "00"); c.fillStyle = g; c.beginPath(); c.arc(80, 50, 34, 0, 6.29); c.fill(); }
  else { c.beginPath(); c.ellipse(80, 52, 52, 18, 0, 0, 6.29); c.stroke(); c.lineWidth = 2; c.strokeStyle = "#ffffff"; c.beginPath(); c.ellipse(80, 52, 52, 18, 0, 0, 6.29); c.stroke(); }
  return cv;
}
function vxAddLayer(type, over) {
  const L = vxLayer(type, over);
  vxChange(() => { VX.eff.layers.push(L); VX.sel = VX.eff.layers.length - 1; }, { insp: true });
  if (!VX.playing) vxSeek(Math.max(VX.t, 0)); else if (VX.t > L.delay) vxRestart();
}
function vxUseTexture(key) {
  const L = vxL();
  if (L && (L.type === "particles" || L.type === "beam")) {
    const t = vxTexture(key);
    vxChange(() => { L.tex = key; if (L.type === "particles") { const g = t.grid || "None"; if (g !== "None" || L.flip.layout !== "None") L.flip.layout = g; } }, { insp: true });
    renderVxLib();
  } else vxAddLayer("particles", { name: vxTexture(key).name, tex: key, flip: { layout: vxTexture(key).grid || "None", mode: "Loop", fps: [30, 30], startRandom: false } });
}
async function vxImportTex() {
  if (!assets || !vxTexCol) return toast("Importing textures needs the Farshtah app's storage");
  const inp = make("input", { type: "file", accept: "image/png,image/jpeg,image/webp,image/gif" });
  inp.onchange = () => { const f = inp.files && inp.files[0]; if (f) vxImportFile(f); };
  inp.click();
}
async function vxImportFile(f) { // an image -> a square PNG; a GIF -> its frames on a flipbook grid (2x2, 4x4 or 8x8)
  try {
    let blob, grid = "None";
    if (f.type === "image/gif" || /\.gif$/i.test(f.name || "")) {
      const g = decodeGif(await f.arrayBuffer()), frames = g.frames, n = frames.length <= 4 ? 2 : frames.length <= 16 ? 4 : 8, cell = n === 8 ? 128 : 256;
      const one = document.createElement("canvas"); one.width = g.width; one.height = g.height; const oc = one.getContext("2d");
      const cv = document.createElement("canvas"); cv.width = cv.height = n * cell; const c = cv.getContext("2d");
      for (let i = 0; i < n * n; i++) { oc.putImageData(frames[Math.min(frames.length - 1, Math.floor(i * frames.length / (n * n)))].img, 0, 0); c.drawImage(one, (i % n) * cell, Math.floor(i / n) * cell, cell, cell); }
      blob = await new Promise(r => cv.toBlob(r, "image/png")); grid = n === 2 ? "Grid2x2" : n === 4 ? "Grid4x4" : "Grid8x8";
    } else {
      const url = URL.createObjectURL(f);
      const img = await new Promise((ok, bad) => { const im = new Image(); im.onload = () => ok(im); im.onerror = bad; im.src = url; });
      const s = Math.min(1024, Math.max(img.naturalWidth, img.naturalHeight)), cv = document.createElement("canvas"); cv.width = cv.height = s;
      cv.getContext("2d").drawImage(img, 0, 0, s, s); URL.revokeObjectURL(url); blob = await new Promise(r => cv.toBlob(r, "image/png"));
    }
    const up = await assets.upload(blob, { type: "image/png" });
    const ref = vxTexCol.doc(); await ref.set({ name: String(f.name || "Texture").replace(/\.[a-z0-9]+$/i, "").slice(0, 40) || "Texture", asset: up.id, grid, updatedAt: new Date().toISOString() });
    toast("Texture added"); vxSetLib("tex"); return ref.id;
  } catch (e) { toast("Couldn't import that image"); return null; }
}
async function vxDeleteTex(d) {
  if (VX.eff.layers.some(L => L.tex === "u:" + d.id)) return toast("A layer in this effect uses it");
  try { await vxTexCol.doc(d.id).delete(); if (assets && assets.delete) assets.delete(d.asset).catch(() => {}); toast("Texture deleted"); } catch (e) { toast("Couldn't delete it"); }
}

// ======================================================================= Visuals+: the inspector
const FIELD = { // small field builders; each change goes through vxChange
  num(get, set, o) {
    o = o || {}; const inp = make("input", { class: "num", type: "number", step: o.step || 0.1, min: o.min, max: o.max, "aria-label": o.label || "" }); inp.value = +(+get()).toFixed(o.dp == null ? 3 : o.dp);
    inp.oninput = () => { const v = parseFloat(inp.value); if (isFinite(v)) vxChange(() => set(clamp(v, o.min != null ? o.min : -1e9, o.max != null ? o.max : 1e9)), { struct: !!o.struct }); };
    inp.onchange = () => { inp.value = +(+get()).toFixed(o.dp == null ? 3 : o.dp); if (o.after) o.after(); };
    inp._drag = { get, set, o, inp };
    return inp;
  },
  row(label, ...kids) { const fl = make("span", { class: "fl", text: label }); const r = make("div", { class: "frow" }, fl, make("div", { class: "fv" }, ...kids));
    const first = kids.find(k => k && k._drag); if (first) vxDragLabel(fl, first._drag); else fl.classList.add("plain"); return r; },
  pair(label, arr, o) { return FIELD.row(label, FIELD.num(() => arr()[0], v => { arr()[0] = v; }, Object.assign({ label: label + " min" }, o)), make("span", { class: "dash", text: "–" }), FIELD.num(() => arr()[1], v => { arr()[1] = v; }, Object.assign({ label: label + " max" }, o))); },
  vec(label, arr, o) { return FIELD.row(label, ...[0, 1, 2].map(i => FIELD.num(() => arr()[i], v => { arr()[i] = v; }, Object.assign({ label: label + " " + "XYZ"[i] }, o)))); },
  segs(label, opts, get, set, o) {
    const box = make("div", { class: "segs" });
    for (const [v, t] of opts) box.append(make("button", { type: "button", class: "chip", "aria-pressed": String(get() === v), text: t, onclick: () => { vxChange(() => set(v), Object.assign({ insp: true }, o || {})); } }));
    return FIELD.row(label, box);
  },
  select(label, opts, get, set, o) {
    const s = make("select", { "aria-label": label }); for (const [v, t] of opts) { const op = make("option", { value: v, text: t }); if (get() === v) op.selected = true; s.append(op); }
    s.onchange = () => vxChange(() => set(s.value), Object.assign({ insp: true }, o || {})); return FIELD.row(label, s);
  },
  check(label, get, set, o) { const inp = make("input", { type: "checkbox" }); inp.checked = !!get(); inp.onchange = () => vxChange(() => set(inp.checked), Object.assign({ insp: true }, o || {}));
    return make("label", { class: "check" }, inp, label); },
  slider(label, get, set, min, max, step, fmt) {
    const inp = make("input", { type: "range", min, max, step, "aria-label": label }); inp.value = get(); const out = make("span", { class: "unit", text: fmt(get()) });
    inp.oninput = () => { vxChange(() => set(+inp.value), { struct: true }); out.textContent = fmt(+inp.value); }; return FIELD.row(label, inp, out);
  },
  sec(title, ...kids) { return make("div", { class: "isec" }, make("h5", { text: title }), ...kids); },
};
function vxDragLabel(fl, d) { // drag a field's label sideways to change its value
  fl.addEventListener("pointerdown", e => {
    if (e.button !== 0) return; e.preventDefault(); fl.setPointerCapture(e.pointerId);
    const x0 = e.clientX, v0 = +d.get(), st = +(d.o.step || 0.1);
    const move = ev => { const k = (ev.shiftKey ? 10 : ev.altKey ? 0.1 : 1) * st, v = clamp(Math.round((v0 + (ev.clientX - x0) * k) / (st / 10)) * (st / 10), d.o.min != null ? d.o.min : -1e9, d.o.max != null ? d.o.max : 1e9);
      vxChange(() => d.set(+v.toFixed(4)), { struct: !!d.o.struct }); d.inp.value = +(+d.get()).toFixed(d.o.dp == null ? 3 : d.o.dp); };
    const up = () => { fl.removeEventListener("pointermove", move); fl.removeEventListener("pointerup", up); fl.removeEventListener("pointercancel", up); };
    fl.addEventListener("pointermove", move); fl.addEventListener("pointerup", up); fl.addEventListener("pointercancel", up);
  });
}
function gradCss(seq, alphaSeq) { // a colour ramp (with the fade, if given) as a CSS gradient
  const stops = new Set(seq.map(p => p[0])); if (alphaSeq) for (const p of alphaSeq) stops.add(p[0]);
  return "linear-gradient(90deg," + [...stops].sort((a, b) => a - b).map(t => { seqC(seq, t, _col); const a = alphaSeq ? 1 - clamp(seqN(alphaSeq, t, 0), 0, 1) : 1;
    return `rgba(${Math.round(_col[0] * 255)},${Math.round(_col[1] * 255)},${Math.round(_col[2] * 255)},${a.toFixed(3)}) ${(t * 100).toFixed(1)}%`; }).join(",") + ")";
}
function vxCurveSvg(seq, lo, hi) {
  const W = 100, H = 30, x = t => t * W, y = v => H - 3 - (clamp(v, lo, hi) - lo) / Math.max(hi - lo, 1e-6) * (H - 6);
  let d = ""; for (let i = 0; i <= 40; i++) { const t = i / 40; d += (i ? "L" : "M") + x(t).toFixed(1) + " " + y(seqN(seq, t, 0)).toFixed(1); }
  return `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none"><path class="fill" d="${d}L${W} ${H}L0 ${H}Z"/><path d="${d}"/></svg>`;
}
function seqMax(seq) { return Math.max(...seq.map(p => p[1] + p[2])); }
function vxCurveRow(label, getSeq, setSeq, kind) {
  const b = make("button", { type: "button", class: "curvebtn", "aria-label": "Edit " + label });
  const draw = () => { const s = getSeq(), hi = kind === "transp" ? 1 : kind === "squash" ? 3 : Math.max(1, seqMax(s) * 1.15), lo = kind === "squash" ? -3 : 0; b.innerHTML = vxCurveSvg(kind === "transp" ? s.map(p => [p[0], 1 - p[1], p[2]]) : s, lo, hi); };
  draw(); b.onclick = () => openCurve(b, label, getSeq, setSeq, kind, draw);
  const pre = make("div", { class: "presets" });
  for (const [nm, fn] of CURVE_PRESETS[kind]) pre.append(make("button", { type: "button", text: nm, onclick: () => { vxChange(() => setSeq(fn(getSeq())), {}); draw(); } }));
  return [FIELD.row(label, b), pre];
}
const CURVE_PRESETS = {
  size: [["Shrink", s => { const v = Math.max(0.1, seqMax(s)); return [[0, v, 0], [1, 0, 0]]; }], ["Grow", s => { const v = Math.max(0.1, seqMax(s)); return [[0, v * 0.2, 0], [1, v, 0]]; }],
    ["Pop", s => { const v = Math.max(0.1, seqMax(s)); return [[0, 0, 0], [0.2, v, 0], [1, v * 0.4, 0]]; }], ["Steady", s => { const v = Math.max(0.1, seqMax(s)); return [[0, v, 0], [1, v, 0]]; }],
    ["Pulse", s => { const v = Math.max(0.1, seqMax(s)); return [[0, v * 0.5, 0], [0.25, v, 0], [0.5, v * 0.5, 0], [0.75, v, 0], [1, v * 0.5, 0]]; }]],
  transp: [["Fade out", () => [[0, 0, 0], [1, 1, 0]]], ["In and out", () => [[0, 1, 0], [0.2, 0, 0], [0.7, 0, 0], [1, 1, 0]]], ["Late fade", () => [[0, 0, 0], [0.7, 0, 0], [1, 1, 0]]],
    ["Flash", () => [[0, 0, 0], [0.15, 0.6, 0], [1, 1, 0]]], ["Solid", () => [[0, 0, 0], [1, 0, 0]]]],
  squash: [["None", () => [[0, 0, 0], [1, 0, 0]]], ["Tall", () => [[0, 1.5, 0], [1, 1.5, 0]]], ["Wide", () => [[0, -1.5, 0], [1, -1.5, 0]]], ["Stretch", () => [[0, 2, 0], [1, 0, 0]]]],
};
const GRAD_PRESETS = [["White", ["#ffffff"]], ["Fire", ["#ffffff", "#ffd23d", "#ff6a1f", "#7a1a0a"]], ["Ice", ["#ffffff", "#9fe3ff", "#2f7bff"]], ["Toxic", ["#f4ffd6", "#8dff3a", "#1f7a2a"]],
  ["Void", ["#ffffff", "#c58bff", "#5a1fb8", "#12052b"]], ["Gold", ["#fff6d6", "#ffd36a", "#c98a1a"]], ["Blood", ["#ffd6d6", "#ff3b3b", "#5a0606"]], ["Rainbow", ["#ff4d4d", "#ffd34d", "#4dff88", "#4dc3ff", "#b84dff"]]];
const SWATCHES = ["#ffffff", "#ff4d4d", "#ff9a3d", "#ffd23d", "#5dff8a", "#3cf2d0", "#4dc3ff", "#2f7bff", "#9b5cff", "#ff5ad1", "#8a8f99", "#1a1a1a"];
function vxGradRow(label, getSeq, setSeq, getAlpha) {
  const bar = make("button", { type: "button", class: "gradbar", "aria-label": "Edit " + label }, make("span"));
  const draw = () => { bar.firstChild.style.background = gradCss(getSeq(), getAlpha ? getAlpha() : null); };
  draw(); bar.onclick = () => openGrad(bar, label, getSeq, setSeq, draw);
  const sw = make("div", { class: "swrow" });
  for (const c of SWATCHES) sw.append(make("button", { type: "button", title: c, style: `background:${c}`, onclick: () => { vxChange(() => setSeq([[0, "#ffffff"], [1, c]].map((p, i) => i === 0 ? [0, c === "#ffffff" ? "#ffffff" : vxMix(c, "#ffffff", 0.55)] : p)), {}); draw(); } }));
  return [FIELD.row(label, bar), sw];
}
function vxMix(a, b, k) { const x = rgbOf(a), y = rgbOf(b), h = v => Math.round(clamp(v, 0, 1) * 255).toString(16).padStart(2, "0"); return "#" + [0, 1, 2].map(i => h(x[i] + (y[i] - x[i]) * k)).join(""); }
function vxTexRow(label, L) {
  const t = vxTexture(L.tex), b = make("button", { type: "button", class: "texpick", id: "vxTexPick" }, vxThumb(L.tex, null, 60, 60), make("span", { text: t.name }));
  b.onclick = () => openTexPick(b, L);
  return FIELD.row(label, b);
}
function renderVxInsp() {
  const el = $("vxInsp"); if (!el) return;
  const old = el.querySelector(".ibody"), top = old ? old.scrollTop : 0; el.innerHTML = "";
  const L = vxL();
  const head = make("div", { class: "ihead" });
  const ic = make("span", { class: "ic" }); ic.innerHTML = LT_ICON[L ? L.type : "fx"]; ic.style.background = L ? LT_COLOR[L.type] : "var(--ink-3)";
  const nm = make("input", { type: "text", maxlength: 40, "aria-label": "Layer name", spellcheck: "false" }); nm.value = L ? L.name : VX.eff.name;
  nm.oninput = () => { const v = nm.value.trim(); if (!v) return; vxChange(() => { if (L) L.name = v.slice(0, 40); else { VX.eff.name = v.slice(0, 60); $("vxName").value = VX.eff.name; } }, { struct: false }); };
  head.append(ic, nm);
  if (L) head.append(make("button", { type: "button", class: "btn icon", title: "Layer menu", "aria-label": "Layer menu", text: "⋯", onclick: e => vxLayerMenu(VX.sel, e.currentTarget) }));
  el.append(head);
  if (L) {
    const mode = make("div", { class: "imode", role: "group", "aria-label": "Detail" });
    for (const [v, t] of [["simple", "Simple"], ["adv", "Advanced"]]) mode.append(make("button", { type: "button", "aria-pressed": String(VX.mode === v), text: t, onclick: () => { VX.mode = v; store.set("farshtah.vx.mode", v); renderVxInsp(); } }));
    el.append(mode);
  }
  const body = make("div", { class: "ibody" });
  if (!L) body.append(...vxEffectFields());
  else if (L.type === "particles") body.append(...vxParticleFields(L));
  else if (L.type === "mesh") body.append(...vxMeshFields(L));
  else body.append(...vxBeamFields(L));
  el.append(body); body.scrollTop = top;
}
const adv = () => VX.mode === "adv";
function vxParticleFields(L) {
  const out = [];
  out.push(FIELD.sec("Look", vxTexRow("Texture", L), ...vxGradRow("Color", () => L.color, v => { L.color = vxSeqC(v, WHITE); }, () => L.transp),
    ...vxCurveRow("Size", () => L.size, v => { L.size = vxSeqN(v, L.size, 0, 200); }, "size"),
    ...vxCurveRow("Fade", () => L.transp, v => { L.transp = vxSeqN(v, L.transp, 0, 1); }, "transp"),
    FIELD.slider("Glow", () => L.light, v => { L.light = v; }, 0, 1, 0.05, v => Math.round(v * 100) + "%"),
    FIELD.row("Brightness", FIELD.num(() => L.bright, v => { L.bright = v; }, { min: 0, max: 50, step: 0.1, struct: true }))));
  out.push(FIELD.sec("Timing",
    FIELD.row("Start at", FIELD.num(() => L.delay, v => { L.delay = v; }, { min: 0, max: 60, step: 0.01, dp: 2 }), make("span", { class: "unit", text: "s" })),
    FIELD.row("Burst", FIELD.num(() => L.count, v => { L.count = v; }, { min: 0, max: 1000, step: 1, dp: 0 }), make("span", { class: "unit", text: "at once" })),
    FIELD.row("Stream", FIELD.num(() => L.rate, v => { L.rate = v; }, { min: 0, max: 1000, step: 1, dp: 1 }), make("span", { class: "unit", text: "/s for" }), FIELD.num(() => L.duration, v => { L.duration = v; }, { min: 0, max: 60, step: 0.05, dp: 2 }), make("span", { class: "unit", text: "s" })),
    FIELD.pair("Lifetime", () => L.life, { min: 0.01, max: 30, step: 0.05, dp: 2 })));
  out.push(FIELD.sec("Motion", FIELD.select("Direction", DIRS6.map(d => [d, { Top: "Up", Bottom: "Down", Front: "Forward", Back: "Back", Right: "Right", Left: "Left" }[d]]), () => L.dir, v => { L.dir = v; }),
    FIELD.pair("Speed", () => L.speed, { min: -500, max: 500, step: 0.5, dp: 1 }), FIELD.pair("Spread", () => L.spread, { min: 0, max: 360, step: 1, dp: 0 }),
    ...(adv() ? [FIELD.vec("Gravity", () => L.accel, { min: -1000, max: 1000, step: 0.5, dp: 1 }), FIELD.row("Drag", FIELD.num(() => L.drag, v => { L.drag = v; }, { min: 0, max: 100, step: 0.1, dp: 2 })),
      FIELD.pair("Rotation", () => L.rot, { min: -360, max: 360, step: 1, dp: 0 }), FIELD.pair("Spin", () => L.rotSpeed, { min: -3600, max: 3600, step: 5, dp: 0 }),
      FIELD.select("Facing", ORIENTS.map(o => [o, { FacingCamera: "Camera", FacingCameraWorldUp: "Camera, upright", VelocityParallel: "Along its motion", VelocityPerpendicular: "Across its motion" }[o]]), () => L.orient, v => { L.orient = v; }),
      FIELD.check("Locked to the effect", () => L.locked, v => { L.locked = v; })] : [])));
  if (adv()) {
    out.push(FIELD.sec("Shape", FIELD.segs("Emit from", SHAPES_P.map(s => [s, s]), () => L.shape, v => { L.shape = v; }),
      ...(L.shape !== "Point" ? [FIELD.vec("Size", () => L.shapeSize, { min: 0, max: 500, step: 0.1, dp: 2 }), FIELD.segs("Style", [["Volume", "Inside"], ["Surface", "Surface"]], () => L.shapeStyle, v => { L.shapeStyle = v; }),
        FIELD.segs("Direction", [["Outward", "Out"], ["Inward", "In"], ["InAndOut", "Both"]], () => L.shapeInOut, v => { L.shapeInOut = v; })] : [])));
    const fb = L.flip;
    out.push(FIELD.sec("Flipbook", FIELD.segs("Grid", [["None", "Off"], ["Grid2x2", "2×2"], ["Grid4x4", "4×4"], ["Grid8x8", "8×8"]], () => fb.layout, v => { fb.layout = v; }),
      ...(fb.layout !== "None" ? [FIELD.segs("Mode", [["Loop", "Loop"], ["OneShot", "Once"], ["PingPong", "Ping-pong"], ["Random", "Random"]], () => fb.mode, v => { fb.mode = v; }),
        FIELD.pair("Frames/s", () => fb.fps, { min: 0, max: 120, step: 1, dp: 0 }), FIELD.check("Random first frame", () => fb.startRandom, v => { fb.startRandom = v; })] : [])));
    out.push(FIELD.sec("More", ...vxCurveRow("Squash", () => L.squash, v => { L.squash = vxSeqN(v, L.squash, -3, 3); }, "squash"),
      FIELD.row("Toward camera", FIELD.num(() => L.z, v => { L.z = v; }, { min: -50, max: 50, step: 0.1, dp: 2, struct: true }), make("span", { class: "unit", text: "studs" })),
      FIELD.slider("Light influence", () => L.lightInf, v => { L.lightInf = v; }, 0, 1, 0.05, v => Math.round(v * 100) + "%"),
      FIELD.check("Slow-motion ramp", () => L.ts.on, v => { L.ts.on = v; }),
      ...(L.ts.on ? [FIELD.row("Speed", FIELD.num(() => L.ts.start, v => { L.ts.start = v; }, { min: 0, max: 1, step: 0.05, dp: 2 }), make("span", { class: "dash", text: "→" }), FIELD.num(() => L.ts.end, v => { L.ts.end = v; }, { min: 0, max: 1, step: 0.05, dp: 2 })),
        FIELD.row("Over", FIELD.num(() => L.ts.duration, v => { L.ts.duration = v; }, { min: 0, max: 30, step: 0.05, dp: 2 }), make("span", { class: "unit", text: "s" }))] : [])));
  }
  out.push(vxPlaceSec(L));
  return out;
}
function vxPlaceSec(L) {
  const kids = [FIELD.vec("Offset", () => L.p, { min: -500, max: 500, step: 0.1, dp: 2 })];
  if (adv()) kids.push(FIELD.vec("Turn °", () => L.r, { min: -360, max: 360, step: 1, dp: 0 }));
  if (adv() && L.type !== "mesh") { const inp = make("input", { class: "txt", type: "text", placeholder: "Uploaded by Claude on export", spellcheck: "false", "aria-label": "Roblox texture ID" }); inp.value = L.texId;
    inp.onchange = () => vxChange(() => { L.texId = inp.value.trim().slice(0, 80); }, { struct: false }); kids.push(FIELD.row("Roblox ID", inp)); }
  return FIELD.sec("Place", ...kids);
}
function vxMeshFields(L) {
  const out = [], sph = L.shape === "Sphere";
  const sizeRow = (label, tr) => sph ? FIELD.row(label, FIELD.num(() => tr().size[0], v => { tr().size = [v, v, v]; }, { min: 0, max: 2048, step: 0.1, dp: 2 }), make("span", { class: "unit", text: "studs" }))
    : FIELD.vec(label, () => tr().size, { min: 0, max: 2048, step: 0.1, dp: 2 });
  out.push(FIELD.sec("Look", FIELD.segs("Shape", MSHAPES.map(s => [s, s]), () => L.shape, v => { L.shape = v; if (v === "Sphere") { L.start.size = [L.start.size[0], L.start.size[0], L.start.size[0]]; L.end.size = [L.end.size[0], L.end.size[0], L.end.size[0]]; } }),
    FIELD.segs("Material", [["Neon", "Neon"], ["ForceField", "Force field"], ["Glass", "Glass"], ["SmoothPlastic", "Plastic"]], () => L.material, v => { L.material = v; }),
    (() => { const c = make("input", { type: "color", "aria-label": "Colour" }); c.value = L.color; c.oninput = () => vxChange(() => { L.color = c.value; SIM.copies.forEach(x => { if (x.L.id === L.id && x.obj) { const col = new THREE.Color(c.value); if (x.obj.material.uniforms) x.obj.material.uniforms.color.value = col; else x.obj.material.color.copy(L.material === "Neon" ? col.multiplyScalar(NEON) : col); } }); }, { struct: false }); return FIELD.row("Color", c); })(),
    (() => { const sw = make("div", { class: "swrow" }); for (const c of SWATCHES) sw.append(make("button", { type: "button", title: c, style: `background:${c}`, onclick: () => vxChange(() => { L.color = c; SIM.copies.forEach(x => { if (x.L.id === L.id) vxDropCopy(x); }); SIM.copies = SIM.copies.filter(x => x.obj); }, { insp: true }) })); return sw; })(),
    ...(L.shape === "Mesh" ? [(() => { const inp = make("input", { class: "txt", type: "text", placeholder: "rbxassetid://…", spellcheck: "false", "aria-label": "Mesh ID" }); inp.value = L.meshId; inp.onchange = () => vxChange(() => { L.meshId = inp.value.trim().slice(0, 80); }, { struct: false }); return FIELD.row("Mesh ID", inp); })()] : [])));
  out.push(FIELD.sec("Grow", sizeRow("Start size", () => L.start), sizeRow("End size", () => L.end),
    FIELD.row("Fade", FIELD.num(() => L.t0, v => { L.t0 = v; }, { min: 0, max: 1, step: 0.05, dp: 2 }), make("span", { class: "dash", text: "→" }), FIELD.num(() => L.t1, v => { L.t1 = v; }, { min: 0, max: 1, step: 0.05, dp: 2 })),
    adv() ? FIELD.row("Grow time", FIELD.num(() => L.morph, v => { L.morph = v; }, { min: 0.02, max: 30, step: 0.05, dp: 2 }), make("span", { class: "unit", text: "s" }))
      : FIELD.row("Duration", FIELD.num(() => L.life, v => { L.life = v; L.morph = v; }, { min: 0.02, max: 30, step: 0.05, dp: 2 }), make("span", { class: "unit", text: "s" })),
    ...(adv() ? [FIELD.row("Lifetime", FIELD.num(() => L.life, v => { L.life = v; }, { min: 0.02, max: 30, step: 0.05, dp: 2 }), make("span", { class: "unit", text: "s" }))] : []),
    FIELD.select("Easing", STYLES.map(s => [s, s]), () => L.ease[0], v => { L.ease[0] = v; }), FIELD.segs("", EDIRS.map(d => [d, d === "InOut" ? "In-out" : d]), () => L.ease[1], v => { L.ease[1] = v; }),
    ...(adv() ? [FIELD.select("Fade easing", STYLES.map(s => [s, s]), () => L.tease[0], v => { L.tease[0] = v; }), FIELD.segs("", EDIRS.map(d => [d, d === "InOut" ? "In-out" : d]), () => L.tease[1], v => { L.tease[1] = v; })] : [])));
  out.push(FIELD.sec("Timing", FIELD.row("Start at", FIELD.num(() => L.delay, v => { L.delay = v; }, { min: 0, max: 60, step: 0.01, dp: 2 }), make("span", { class: "unit", text: "s" })),
    FIELD.row("Copies", FIELD.num(() => L.count, v => { L.count = v; }, { min: 0, max: 200, step: 1, dp: 0 }), make("span", { class: "unit", text: "at once" })),
    FIELD.row("Then", FIELD.num(() => L.rate, v => { L.rate = v; }, { min: 0, max: 120, step: 0.5, dp: 1 }), make("span", { class: "unit", text: "/s for" }), FIELD.num(() => L.duration, v => { L.duration = v; }, { min: 0, max: 60, step: 0.05, dp: 2 }), make("span", { class: "unit", text: "s" }))));
  if (adv()) out.push(FIELD.sec("Movement", FIELD.vec("Start at", () => L.start.p, { min: -500, max: 500, step: 0.1, dp: 2 }), FIELD.vec("Start turn", () => L.start.r, { min: -360, max: 360, step: 1, dp: 0 }),
    FIELD.vec("End at", () => L.end.p, { min: -500, max: 500, step: 0.1, dp: 2 }), FIELD.vec("End turn", () => L.end.r, { min: -360, max: 360, step: 1, dp: 0 }),
    FIELD.vec("Random turn from", () => L.initMin, { min: -360, max: 360, step: 1, dp: 0 }), FIELD.vec("to", () => L.initMax, { min: -360, max: 360, step: 1, dp: 0 }),
    FIELD.row("Tilt", FIELD.num(() => L.spread[0], v => { L.spread[0] = v; }, { min: 0, max: 180, step: 1, dp: 0 }), FIELD.num(() => L.spread[1], v => { L.spread[1] = v; }, { min: 0, max: 180, step: 1, dp: 0 }), make("span", { class: "unit", text: "°" })),
    FIELD.pair("Spin °/s", () => L.spin, { min: -3600, max: 3600, step: 5, dp: 0 })));
  out.push(vxPlaceSec(L));
  return out;
}
function vxBeamFields(L) {
  const out = [];
  out.push(FIELD.sec("Look", vxTexRow("Texture", L), ...vxGradRow("Color", () => L.color, v => { L.color = vxSeqC(v, WHITE); }, () => L.transp),
    ...vxCurveRow("Fade", () => L.transp, v => { L.transp = vxSeqN(v, L.transp, 0, 1); }, "transp"),
    FIELD.row("Width", FIELD.num(() => L.width[0], v => { L.width[0] = v; }, { min: 0, max: 200, step: 0.1, dp: 2 }), make("span", { class: "dash", text: "→" }), FIELD.num(() => L.width[1], v => { L.width[1] = v; }, { min: 0, max: 200, step: 0.1, dp: 2 })),
    FIELD.slider("Glow", () => L.light, v => { L.light = v; }, 0, 1, 0.05, v => Math.round(v * 100) + "%"),
    FIELD.row("Brightness", FIELD.num(() => L.bright, v => { L.bright = v; }, { min: 0, max: 50, step: 0.1, struct: true })),
    FIELD.row("Scroll", FIELD.num(() => L.texSpeed, v => { L.texSpeed = v; }, { min: -100, max: 100, step: 0.1, dp: 2 }), make("span", { class: "unit", text: "/s" }))));
  out.push(FIELD.sec("Path", FIELD.vec("From", () => L.a, { min: -500, max: 500, step: 0.1, dp: 2 }), FIELD.vec("To", () => L.b, { min: -500, max: 500, step: 0.1, dp: 2 }),
    FIELD.row("Curve", FIELD.num(() => L.curve[0], v => { L.curve[0] = v; }, { min: -200, max: 200, step: 0.1, dp: 2 }), FIELD.num(() => L.curve[1], v => { L.curve[1] = v; }, { min: -200, max: 200, step: 0.1, dp: 2 }))));
  out.push(FIELD.sec("Timing", FIELD.row("Start at", FIELD.num(() => L.delay, v => { L.delay = v; }, { min: 0, max: 60, step: 0.01, dp: 2 }), make("span", { class: "unit", text: "s" })),
    FIELD.row("Show for", FIELD.num(() => L.duration, v => { L.duration = v; }, { min: 0, max: 60, step: 0.05, dp: 2 }), make("span", { class: "unit", text: L.duration ? "s" : "s · to the end" }))));
  if (adv()) out.push(FIELD.sec("More", FIELD.segs("Texture", [["Stretch", "Stretch"], ["Wrap", "Repeat"], ["Static", "Static"]], () => L.texMode, v => { L.texMode = v; }),
    FIELD.row("Length", FIELD.num(() => L.texLen, v => { L.texLen = v; }, { min: 0.01, max: 1000, step: 0.1, dp: 2 })),
    FIELD.row("Segments", FIELD.num(() => L.segments, v => { L.segments = Math.round(v); }, { min: 1, max: 200, step: 1, dp: 0, struct: true })),
    FIELD.check("Faces the camera", () => L.faceCam, v => { L.faceCam = v; }), FIELD.row("Toward camera", FIELD.num(() => L.z, v => { L.z = v; }, { min: -50, max: 50, step: 0.1, dp: 2 }))));
  out.push(vxPlaceSec(L));
  return out;
}
function vxEffectFields() {
  const E = VX.eff, c = E.cam, b = E.bloom, out = [];
  const a = vxAnim();
  const animOpts = [["", "None"]].concat([...docs.entries()].sort((x, y) => String(x[1].name).localeCompare(String(y[1].name))).map(([id, d]) => [id, d.name || "Untitled"]));
  const atOpts = [["start", "Its start"]].concat(a ? a.markers.map(m => ["marker:" + m.name, `${m.name} (${m.t.toFixed(2)} s)`]) : []);
  out.push(FIELD.sec("Preview", FIELD.select("Plays at", WHERE, () => E.preview.where, v => { E.preview.where = v; vxPreviewChanged(); }),
    FIELD.select("Animation", animOpts, () => E.preview.anim, v => { E.preview.anim = v; const an = vxAnim(); const imp = an && an.markers.find(m => /^(impact|hit)$/i.test(m.name)); E.preview.at = imp ? "marker:" + imp.name : "start"; vxPreviewChanged(); }),
    ...(a ? [FIELD.select("When", atOpts, () => (typeof E.preview.at === "string" ? E.preview.at : "start"), v => { E.preview.at = v; vxPreviewChanged(); })] : [])));
  out.push(FIELD.sec("Bloom", FIELD.check("Glow while it plays", () => b.on, v => { b.on = v; }),
    ...(b.on ? [FIELD.row("Intensity", FIELD.num(() => b.intensity, v => { b.intensity = v; }, { min: 0, max: 5, step: 0.05, dp: 2 })),
      FIELD.row("Size", FIELD.num(() => b.size, v => { b.size = v; }, { min: 0, max: 56, step: 1, dp: 0 })), FIELD.row("Threshold", FIELD.num(() => b.threshold, v => { b.threshold = v; }, { min: 0.8, max: 4, step: 0.05, dp: 2 }))] : [])));
  const trip = (label, arr, unit, o) => [FIELD.row(label, FIELD.num(() => arr()[0], v => { arr()[0] = v; }, Object.assign({ step: 0.05, dp: 2 }, o)), make("span", { class: "unit", text: unit })),
    FIELD.row("For", FIELD.num(() => arr()[1], v => { arr()[1] = v; }, { min: 0, max: 10, step: 0.05, dp: 2 }), make("span", { class: "unit", text: "s at" }), FIELD.num(() => arr()[2], v => { arr()[2] = v; }, { min: 0, max: 60, step: 0.01, dp: 2 }), make("span", { class: "unit", text: "s" }))];
  out.push(FIELD.sec("Camera shake", ...trip("Strength", () => c.shake, "studs", { min: 0, max: 10 })));
  out.push(FIELD.sec("FOV punch", ...trip("Amount", () => c.fov, "°", { min: -60, max: 60, step: 0.5, dp: 1 })));
  out.push(FIELD.sec("Screen flash", ...trip("Strength", () => c.flash, "", { min: 0, max: 1 }),
    (() => { const ci = make("input", { type: "color", "aria-label": "Flash colour" }); ci.value = c.flashColor; ci.oninput = () => vxChange(() => { c.flashColor = ci.value; }, { struct: false }); return FIELD.row("Color", ci); })()));
  out.push(FIELD.sec("Hit-stop", FIELD.row("Hold", FIELD.num(() => c.hitstop[0], v => { c.hitstop[0] = v; }, { min: 0, max: 2, step: 0.01, dp: 2 }), make("span", { class: "unit", text: "s at" }),
    FIELD.num(() => c.hitstop[1], v => { c.hitstop[1] = v; }, { min: 0, max: 60, step: 0.01, dp: 2 }), make("span", { class: "unit", text: "s" }))));
  return out;
}
function vxLayerMenu(i, anchor) {
  closeMenu(); vxClosePop();
  const r = anchor.getBoundingClientRect(), L = VX.eff.layers[i]; if (!L) return;
  const m = make("div", { class: "menu", role: "menu" });
  const item = (t, fn, dis) => { const b = make("button", { type: "button", role: "menuitem", text: t, onclick: () => { closeMenu(); fn(); } }); if (dis) b.disabled = true; m.append(b); };
  item("Duplicate", () => vxDuplicate(i));
  item(L.on ? "Hide" : "Show", () => vxChange(() => { L.on = !L.on; }, { insp: true }));
  item("Move up", () => vxMove(i, -1), i === 0); item("Move down", () => vxMove(i, 1), i === VX.eff.layers.length - 1);
  m.append(make("hr")); item("Delete", () => vxDeleteLayer(i));
  document.body.append(m); menuEl = m;
  const mw = m.offsetWidth, mh = m.offsetHeight; m.style.left = Math.max(8, Math.min(innerWidth - mw - 8, r.left)) + "px"; m.style.top = (r.bottom + mh + 8 > innerHeight ? r.top - mh - 4 : r.bottom + 4) + "px";
  m.querySelector("button:not([disabled])").focus();
}
function vxDuplicate(i) { const L = VX.eff.layers[i]; if (!L) return; const c = vxCleanLayer(Object.assign(JSON.parse(JSON.stringify(L)), { id: vxId(), name: L.name + " copy" })); vxChange(() => { VX.eff.layers.splice(i + 1, 0, c); VX.sel = i + 1; }, { insp: true }); }
function vxMove(i, d) { const j = i + d; if (j < 0 || j >= VX.eff.layers.length) return; vxChange(() => { const L = VX.eff.layers.splice(i, 1)[0]; VX.eff.layers.splice(j, 0, L); VX.sel = j; }, { insp: true }); }
function vxDeleteLayer(i) { if (!VX.eff.layers[i]) return; vxChange(() => { VX.eff.layers.splice(i, 1); VX.sel = Math.min(i, VX.eff.layers.length - 1); }, { insp: true }); toast("Layer deleted (Ctrl Z brings it back)"); }

// ======================================================================= Visuals+: popovers (curve, colour ramp, texture)
let vxPopClose = null;
function vxOpenPop(anchor, build) {
  vxClosePop(); closeMenu();
  const pop = $("vxPop"); pop.innerHTML = ""; pop.hidden = false; build(pop);
  const r = anchor.getBoundingClientRect(), w = pop.offsetWidth, h = pop.offsetHeight;
  let x = r.left - w - 12; if (x < 8) x = Math.min(innerWidth - w - 8, r.right + 12);
  pop.style.left = Math.max(8, x) + "px"; pop.style.top = clamp(r.top - 40, 8, innerHeight - h - 8) + "px";
  const away = e => { if (!pop.contains(e.target) && e.target !== anchor && !anchor.contains(e.target)) vxClosePop(); };
  setTimeout(() => document.addEventListener("pointerdown", away, true), 0);
  vxPopClose = () => document.removeEventListener("pointerdown", away, true);
}
function vxClosePop() { const pop = $("vxPop"); if (pop.hidden) return; pop.hidden = true; pop.innerHTML = ""; if (vxPopClose) vxPopClose(); vxPopClose = null; }
function openCurve(anchor, title, getSeq, setSeq, kind, redraw) {
  vxOpenPop(anchor, pop => {
    const lo = kind === "squash" ? -3 : 0, fixedHi = kind === "transp" ? 1 : kind === "squash" ? 3 : null;
    let sel = 1, drawMode = false;
    const graph = make("div", { class: "cgraph", tabindex: "0", "aria-label": title + " curve" }), svgNS = "http://www.w3.org/2000/svg", svg = document.createElementNS(svgNS, "svg"); graph.append(svg);
    const tIn = FIELD.num(() => getSeq()[sel] ? getSeq()[sel][0] : 0, v => { const s = getSeq().map(p => p.slice()); if (sel > 0 && sel < s.length - 1) { s[sel][0] = clamp(v, s[sel - 1][0] + 1e-3, s[sel + 1][0] - 1e-3); setSeq(s); } }, { min: 0, max: 1, step: 0.01, dp: 3, label: "Time" });
    const vIn = FIELD.num(() => getSeq()[sel] ? getSeq()[sel][1] : 0, v => { const s = getSeq().map(p => p.slice()); if (s[sel]) { s[sel][1] = v; setSeq(s); } }, { min: lo, max: fixedHi != null ? fixedHi : 200, step: kind === "transp" ? 0.05 : 0.1, dp: 3, label: "Value" });
    const eIn = FIELD.num(() => getSeq()[sel] ? getSeq()[sel][2] : 0, v => { const s = getSeq().map(p => p.slice()); if (s[sel]) { s[sel][2] = Math.max(0, v); setSeq(s); } }, { min: 0, max: 100, step: 0.05, dp: 3, label: "Random" });
    const hiOf = s => fixedHi != null ? fixedHi : Math.max(1, Math.ceil(seqMax(s) * 1.25 * 2) / 2);
    let hi = hiOf(getSeq());
    const X = t => 8 + t * (graph.clientWidth - 16), Y = v => graph.clientHeight - 14 - (v - lo) / (hi - lo) * (graph.clientHeight - 26);
    const fromX = x => clamp((x - 8) / (graph.clientWidth - 16), 0, 1), fromY = y => clamp(lo + (graph.clientHeight - 14 - y) / (graph.clientHeight - 26) * (hi - lo), lo, kind === "size" ? 200 : hi);
    const draw = () => {
      const s = getSeq(), W = graph.clientWidth, H = graph.clientHeight; let h = "";
      for (const g of [0, 0.25, 0.5, 0.75, 1]) h += `<line class="gl" x1="${X(g)}" y1="6" x2="${X(g)}" y2="${H - 14}"/>`;
      for (const v of [lo, (lo + hi) / 2, hi]) h += `<line class="gl" x1="8" y1="${Y(v)}" x2="${W - 8}" y2="${Y(v)}"/><text class="ax" x="10" y="${Y(v) - 3}">${kind === "transp" ? Math.round((1 - v) * 100) + "%" : +v.toFixed(2)}</text>`;
      let env = "", top = "", bot = ""; for (let i = 0; i <= 60; i++) { const t = i / 60; top += `${X(t)},${Y(seqN(s, t, 1))} `; bot = `${X(t)},${Y(seqN(s, t, -1))} ` + bot; }
      if (s.some(p => p[2] > 0)) env = `<polygon class="env" points="${top}${bot}"/>`;
      let d = ""; for (let i = 0; i <= 80; i++) { const t = i / 80; d += (i ? "L" : "M") + X(t).toFixed(1) + " " + Y(seqN(s, t, 0)).toFixed(1); }
      h += env + `<path class="cv" d="${d}"/>`;
      s.forEach((p, i) => { h += `<circle class="pt${i === sel ? " sel" : ""}" data-i="${i}" cx="${X(p[0])}" cy="${Y(p[1])}" r="6"/>`; });
      svg.innerHTML = h; tIn.value = s[sel] ? +s[sel][0].toFixed(3) : 0; vIn.value = s[sel] ? +s[sel][1].toFixed(3) : 0; eIn.value = s[sel] ? +s[sel][2].toFixed(3) : 0;
      tIn.disabled = sel === 0 || sel === s.length - 1; if (redraw) redraw();
    };
    const commit = s => { vxChange(() => setSeq(s), {}); };
    graph.addEventListener("pointerdown", e => {
      const r = graph.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top, s = getSeq().map(p => p.slice());
      let hit = -1; s.forEach((p, i) => { if (Math.hypot(X(p[0]) - x, Y(p[1]) - y) < 10) hit = i; });
      if (e.button === 2) { e.preventDefault(); if (hit > 0 && hit < s.length - 1) { s.splice(hit, 1); sel = Math.min(sel, s.length - 1); commit(s); draw(); } return; }
      graph.setPointerCapture(e.pointerId);
      if (hit < 0 && (e.shiftKey || drawMode)) { // freehand: drawn, then fitted to Roblox's 20 points
        const pts = [[fromX(x), fromY(y)]];
        const mv = ev => { pts.push([fromX(ev.clientX - r.left), fromY(ev.clientY - r.top)]); let dd = ""; pts.forEach((p, i) => { dd += (i ? "L" : "M") + X(p[0]) + " " + Y(p[1]); }); svg.querySelector(".cv").setAttribute("d", dd); };
        const upd = () => { graph.removeEventListener("pointermove", mv); graph.removeEventListener("pointerup", upd); const fit = vxFitCurve(pts, s); sel = 0; commit(fit); draw(); };
        graph.addEventListener("pointermove", mv); graph.addEventListener("pointerup", upd); return;
      }
      if (hit < 0) { if (s.length >= 20) { toast("Roblox allows 20 points"); return; } const t = fromX(x); let i = s.findIndex(p => p[0] > t); if (i <= 0) i = s.length - 1; s.splice(i, 0, [t, fromY(y), 0]); hit = i; commit(s); }
      sel = hit; draw();
      const mv = ev => { const s2 = getSeq().map(p => p.slice()), i = sel, t = fromX(ev.clientX - r.left);
        if (i > 0 && i < s2.length - 1) s2[i][0] = clamp(t, s2[i - 1][0] + 1e-3, s2[i + 1][0] - 1e-3); s2[i][1] = fromY(ev.clientY - r.top); commit(s2); draw(); };
      const upd = () => { graph.removeEventListener("pointermove", mv); graph.removeEventListener("pointerup", upd); hi = hiOf(getSeq()); draw(); };
      graph.addEventListener("pointermove", mv); graph.addEventListener("pointerup", upd);
    });
    graph.addEventListener("contextmenu", e => e.preventDefault());
    graph.addEventListener("keydown", e => { if ((e.key === "Delete" || e.key === "Backspace") && sel > 0 && sel < getSeq().length - 1) { const s = getSeq().map(p => p.slice()); s.splice(sel, 1); sel--; commit(s); draw(); e.preventDefault(); } });
    const drawBtn = make("button", { type: "button", class: "chip", "aria-pressed": "false", text: "Draw", title: "Draw the curve freehand (or hold Shift)", onclick: () => { drawMode = !drawMode; drawBtn.setAttribute("aria-pressed", String(drawMode)); } });
    const pre = make("div", { class: "presets" }); for (const [nm, fn] of CURVE_PRESETS[kind]) pre.append(make("button", { type: "button", text: nm, onclick: () => { commit(fn(getSeq())); sel = 1; hi = hiOf(getSeq()); draw(); } }));
    for (const inp of [tIn, vIn, eIn]) inp.addEventListener("input", () => { hi = hiOf(getSeq()); draw(); });
    pop.append(make("header", {}, make("h4", { text: title }), make("div", { class: "segs" }, drawBtn, make("button", { type: "button", class: "btn", text: "Done", onclick: vxClosePop }))), graph, pre,
      make("div", { class: "prow3" }, make("label", { class: "lbl", text: "Time" }), make("label", { class: "lbl", text: kind === "transp" ? "Transparency" : "Value" }), make("label", { class: "lbl", text: "Random ±" })),
      make("div", { class: "prow3" }, tIn, vIn, eIn));
    requestAnimationFrame(draw);
  });
}
function vxFitCurve(pts, old) { // a drawn line -> at most 20 points (Ramer-Douglas-Peucker, loosened until it fits)
  pts = pts.slice().sort((a, b) => a[0] - b[0]); if (pts.length < 2) return old;
  pts[0][0] = 0; pts[pts.length - 1][0] = 1;
  const rdp = (p, eps) => { if (p.length < 3) return p; const a = p[0], b = p[p.length - 1]; let idx = -1, dm = 0;
    for (let i = 1; i < p.length - 1; i++) { const d = Math.abs((b[1] - a[1]) * p[i][0] - (b[0] - a[0]) * p[i][1] + b[0] * a[1] - b[1] * a[0]) / Math.hypot(b[1] - a[1], b[0] - a[0]); if (d > dm) { dm = d; idx = i; } }
    return dm > eps ? rdp(p.slice(0, idx + 1), eps).slice(0, -1).concat(rdp(p.slice(idx), eps)) : [a, b]; };
  let eps = 0.002, out = rdp(pts, eps); while (out.length > 20) { eps *= 1.5; out = rdp(pts, eps); }
  return out.map(p => [p[0], p[1], 0]);
}
function openGrad(anchor, title, getSeq, setSeq, redraw) {
  vxOpenPop(anchor, pop => {
    let sel = 0;
    const ramp = make("div", { class: "gramp", title: "Click to add a color" }, make("div", { class: "bar" })), stops = make("div", { class: "gstops" });
    const ci = make("input", { type: "color", "aria-label": "Stop color" }), del = make("button", { type: "button", class: "btn danger", text: "Delete stop" });
    const posIn = FIELD.num(() => (getSeq()[sel] || [0])[0], v => { const s = getSeq().map(p => p.slice()); if (sel > 0 && sel < s.length - 1) { s[sel][0] = clamp(v, s[sel - 1][0] + 1e-3, s[sel + 1][0] - 1e-3); setSeq(s); } }, { min: 0, max: 1, step: 0.01, dp: 3, label: "Position" });
    const commit = s => vxChange(() => setSeq(s), {});
    const draw = () => {
      const s = getSeq(); ramp.firstChild.style.background = gradCss(s); stops.innerHTML = "";
      s.forEach((p, i) => { const b = make("button", { type: "button", class: "gstop" + (i === sel ? " sel" : ""), "aria-label": `Colour stop ${i + 1}`, style: `left:${p[0] * 100}%;background:${p[1]}` });
        b.addEventListener("pointerdown", e => { e.preventDefault(); sel = i; draw(); if (i === 0 || i === s.length - 1) return; const r = stops.getBoundingClientRect(); b.setPointerCapture(e.pointerId);
          const mv = ev => { const s2 = getSeq().map(q => q.slice()); s2[sel][0] = clamp((ev.clientX - r.left) / r.width, s2[sel - 1][0] + 1e-3, s2[sel + 1][0] - 1e-3); commit(s2); draw(); };
          const up = () => { b.removeEventListener("pointermove", mv); b.removeEventListener("pointerup", up); }; b.addEventListener("pointermove", mv); b.addEventListener("pointerup", up); });
        stops.append(b); });
      ci.value = (s[sel] || s[0])[1]; posIn.value = +((s[sel] || s[0])[0]).toFixed(3); posIn.disabled = sel === 0 || sel === s.length - 1; del.disabled = s.length <= 2;
      if (redraw) redraw();
    };
    ramp.addEventListener("pointerdown", e => { const s = getSeq().map(p => p.slice()); if (s.length >= 20) return toast("Roblox allows 20 colours"); const r = ramp.getBoundingClientRect(), t = clamp((e.clientX - r.left) / r.width, 0.001, 0.999);
      seqC(s, t, _col); const hex = "#" + _col.map(v => Math.round(v * 255).toString(16).padStart(2, "0")).join(""); let i = s.findIndex(p => p[0] > t); if (i < 1) i = s.length - 1; s.splice(i, 0, [t, hex]); sel = i; commit(s); draw(); });
    ci.oninput = () => { const s = getSeq().map(p => p.slice()); if (s[sel]) { s[sel][1] = ci.value; commit(s); draw(); } };
    del.onclick = () => { const s = getSeq().map(p => p.slice()); if (s.length <= 2) return; s.splice(sel, 1); if (s[0][0] !== 0) s[0][0] = 0; s[s.length - 1][0] = 1; sel = Math.max(0, sel - 1); commit(s); draw(); };
    posIn.addEventListener("input", draw);
    const pre = make("div", { class: "presets" }); for (const [nm, cs] of GRAD_PRESETS) pre.append(make("button", { type: "button", text: nm, onclick: () => { commit(cs.map((c, i) => [cs.length > 1 ? i / (cs.length - 1) : 0, c]).concat(cs.length === 1 ? [[1, cs[0]]] : [])); sel = 0; draw(); } }));
    pop.append(make("header", {}, make("h4", { text: title }), make("button", { type: "button", class: "btn", text: "Done", onclick: vxClosePop })), ramp, stops,
      make("div", { class: "frow" }, make("span", { class: "fl plain", text: "Color" }), make("div", { class: "fv" }, ci)),
      make("div", { class: "frow" }, make("span", { class: "fl plain", text: "Position" }), make("div", { class: "fv" }, posIn, del)), pre);
    draw();
  });
}
function openTexPick(anchor, L) {
  vxOpenPop(anchor, pop => {
    const g = make("div", { class: "texgrid" });
    const keys = L.type === "beam" ? VX_BEAM_TEX.concat(VX_TEX.map(t => t[0]).filter(k => !VX_BEAM_TEX.includes(k))) : VX_TEX.map(t => t[0]);
    for (const k of keys) g.append(vxTexButton(k, vxTexture(k).name, L.tex));
    for (const d of vxCustom.values()) g.append(vxTexButton("u:" + d.id, d.name, L.tex));
    g.addEventListener("click", () => setTimeout(vxClosePop, 0));
    pop.append(make("header", {}, make("h4", { text: "Texture" }), make("button", { type: "button", class: "btn", text: "Import", onclick: () => { vxClosePop(); vxImportTex(); } })), g);
  });
}

// ======================================================================= Visuals+: the timeline
let vxPps = 100, vxT0 = 0; // pixels per second, and the time at the left edge (negative: the animation's lead-in)
function renderVxTimeline() {
  const main = $("vxTlMain"), wrap = $("vxTlWrap"), names = $("vxNames"); if (!main || !vxStarted) return;
  const lead = vxLead(), end = vxEnd(); vxT0 = -lead;
  const span = Math.max(0.5, end - vxT0), W = Math.max(120, main.clientWidth - 24);
  vxPps = W / span * VX.zoom; wrap.style.width = Math.max(main.clientWidth, span * vxPps + 24) + "px";
  const X = t => (t - vxT0) * vxPps + 4;
  wrap.innerHTML = ""; names.innerHTML = "";
  // the ruler
  const ruler = make("div", { class: "tl-ruler", id: "vxRuler" }), stepS = [0.05, 0.1, 0.25, 0.5, 1, 2, 5].find(s => s * vxPps >= 56) || 5;
  for (let t = Math.ceil(vxT0 / stepS) * stepS; t <= end + 1e-6; t += stepS) { const sp = make("span", { text: (Math.abs(t) < 1e-9 ? "0" : t.toFixed(stepS < 0.1 ? 2 : stepS < 1 ? 2 : 0)) + "s" }); sp.style.left = X(t) + "px"; ruler.append(sp); }
  wrap.append(ruler);
  if (lead > 0) { const lz = make("div", { class: "tl-trig", title: "The effect starts here" }); lz.style.left = X(0) + "px"; wrap.append(lz); }
  // a row per layer
  VX.eff.layers.forEach((L, i) => {
    const col = LT_COLOR[L.type];
    const eye = make("button", { type: "button", class: "eye", "aria-label": L.on ? "Hide" : "Show", title: L.on ? "Hide" : "Show",
      onclick: e => { e.stopPropagation(); vxChange(() => { L.on = !L.on; }, { insp: VX.sel === i }); } });
    eye.innerHTML = L.on ? '<svg viewBox="0 0 24 24"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>' : '<svg viewBox="0 0 24 24"><path d="M3 3l18 18M10.6 5.1A11 11 0 0 1 12 5c6.4 0 10 7 10 7a17 17 0 0 1-3.2 4.1M6.1 6.1A17 17 0 0 0 2 12s3.6 7 10 7a10.6 10.6 0 0 0 5.9-1.9"/></svg>';
    const row = make("div", { class: "lrow" + (i === VX.sel ? " sel" : "") + (L.on ? "" : " off"), onclick: () => { VX.sel = i; renderVxInsp(); renderVxTimeline(); if (VX.lib === "tex") renderVxLib(); } },
      make("span", { class: "tdot", style: `background:${col}` }), make("span", { class: "nm", text: L.name }), eye);
    row.addEventListener("contextmenu", e => { e.preventDefault(); VX.sel = i; renderVxInsp(); renderVxTimeline(); vxLayerMenu(i, e.currentTarget); });
    names.append(row);
    const tr = make("div", { class: "ltrack" + (i === VX.sel ? " sel" : "") });
    tr.addEventListener("pointerdown", e => { if (e.target === tr) { VX.sel = i; renderVxInsp(); vxScrubAt(e); } });
    const t0 = L.delay, dur = L.type === "beam" ? (L.duration > 0 ? L.duration : Math.max(0.05, vxLongest(VX.eff) - L.delay)) : L.duration;
    const tail = L.type === "particles" ? L.life[1] : L.type === "mesh" ? Math.max(L.life, L.morph) : 0;
    if (tail > 0) { const tl = make("div", { class: "ltail", style: `background:${col}` }); tl.style.left = X(t0 + dur) + "px"; tl.style.width = Math.max(0, tail * vxPps) + "px"; tr.append(tl); }
    if (dur > 0 || L.type === "beam") {
      const bar = make("div", { class: "lbar", style: `background:${col};opacity:${L.on ? 1 : 0.4}`, title: `${L.name}: ${t0.toFixed(2)}–${(t0 + dur).toFixed(2)} s` }, make("span", { class: "grip" }));
      bar.style.left = X(t0) + "px"; bar.style.width = Math.max(6, dur * vxPps) + "px"; tr.append(bar);
      vxTlDrag(bar, L, i);
    }
    if ((L.type !== "beam") && L.count > 0) { const d = make("div", { class: "lburst", style: `background:${col};opacity:${L.on ? 1 : 0.4}`, title: `${L.count} at ${t0.toFixed(2)} s` }); d.style.left = X(t0) + "px"; tr.append(d); vxTlDrag(d, L, i); }
    wrap.append(tr);
  });
  // the camera row
  const c = VX.eff.cam, fxRow = make("div", { class: "lrow fx" + (VX.sel === -1 ? " sel" : ""), onclick: () => { VX.sel = -1; renderVxInsp(); renderVxTimeline(); } }, make("span", { class: "tdot", style: "background:var(--ink-3)" }), make("span", { class: "nm", text: "Camera & bloom" }));
  names.append(fxRow);
  const ftr = make("div", { class: "ltrack" + (VX.sel === -1 ? " sel" : "") });
  ftr.addEventListener("pointerdown", e => { if (e.target === ftr) { VX.sel = -1; renderVxInsp(); vxScrubAt(e); } });
  [["shake", "Camera shake", "#ffd166"], ["fov", "FOV punch", "#7aa0ff"], ["flash", "Screen flash", "#c9d2e3"], ["hitstop", "Hit-stop", "#ff6b8a"]].forEach(([k, label, colr], lane) => {
    const v = c[k], on = k === "hitstop" ? v[0] > 0 : v[0] && v[1] > 0; if (!on) return;
    const at = k === "hitstop" ? v[1] : v[2], len = k === "hitstop" ? v[0] : v[1];
    const m = make("div", { class: "lcam", title: label + ": " + at.toFixed(2) + " s, for " + len.toFixed(2) + " s", style: "background:" + colr + ";top:" + (4 + lane * 7) + "px" });
    m.style.left = X(at) + "px"; m.style.width = Math.max(6, len * vxPps) + "px"; ftr.append(m);
  });
  wrap.append(ftr);
  const ph = make("div", { class: "tl-ph", id: "vxPh" }); wrap.append(ph); vxPlacePlayhead();
  ruler.addEventListener("pointerdown", e => vxScrubAt(e, true));
}
function vxPlacePlayhead() { const ph = $("vxPh"); if (ph) ph.style.left = ((VX.t - vxT0) * vxPps + 4) + "px"; }
function vxScrubAt(e, drag) {
  const wrap = $("vxTlWrap"), r = wrap.getBoundingClientRect(), at = ev => clamp((ev.clientX - r.left - 4) / vxPps + vxT0, vxT0, vxEnd());
  VX.playing = false; renderVxTransport(); vxSeek(at(e));
  if (!drag && e.target.classList && !e.target.classList.contains("ltrack")) return;
  const el = e.currentTarget; el.setPointerCapture(e.pointerId);
  const mv = ev => vxSeek(at(ev)); const up = () => { el.removeEventListener("pointermove", mv); el.removeEventListener("pointerup", up); el.removeEventListener("pointercancel", up); };
  el.addEventListener("pointermove", mv); el.addEventListener("pointerup", up); el.addEventListener("pointercancel", up);
}
function vxTlDrag(el, L, i) { // drag a bar to move it, its right edge to change how long it runs
  el.addEventListener("pointerdown", e => {
    if (e.button !== 0) return; e.stopPropagation(); e.preventDefault();
    if (VX.sel !== i) { VX.sel = i; renderVxInsp(); }
    const grip = e.target.classList.contains("grip"), x0 = e.clientX, d0 = L.delay, u0 = L.duration;
    el.setPointerCapture(e.pointerId);
    const left0 = parseFloat(el.style.left) || 0, w0 = parseFloat(el.style.width) || 0;
    const mv = ev => { const dt = (ev.clientX - x0) / vxPps; // (the timeline redraws when you let go, so the bar keeps the pointer)
      vxChange(() => { if (grip) L.duration = Math.max(0, Math.round((u0 + dt) * 100) / 100); else L.delay = clamp(Math.round((d0 + dt) * 100) / 100, 0, 60); }, { struct: false, tl: false });
      if (grip) el.style.width = Math.max(6, w0 + (L.duration - u0) * vxPps) + "px"; else el.style.left = (left0 + (L.delay - d0) * vxPps) + "px";
      el.title = grip ? L.duration.toFixed(2) + " s" : L.delay.toFixed(2) + " s"; };
    const up = () => { el.removeEventListener("pointermove", mv); el.removeEventListener("pointerup", up); el.removeEventListener("pointercancel", up); renderVxTimeline(); renderVxInsp(); };
    el.addEventListener("pointermove", mv); el.addEventListener("pointerup", up); el.addEventListener("pointercancel", up);
  });
}

// ======================================================================= Visuals+: keys
document.addEventListener("keydown", e => {
  if (APP !== "visuals") return;
  const tag = (e.target && e.target.tagName) || "";
  if (e.key === "Escape") { if (!$("vxPop").hidden) return vxClosePop(); if (menuEl) return closeMenu(); if (!$("vxExpBack").hidden) return vxCloseExport(); if (!$("vxOpenBack").hidden) return vxCloseList(); if (!$("settings").hidden) return closeSettings(); }
  if (tag === "INPUT" || tag === "SELECT" || tag === "TEXTAREA") { if (e.key === "Escape") e.target.blur(); return; }
  if (!$("vxOpenBack").hidden || !$("vxExpBack").hidden) return;
  const ctrl = e.ctrlKey || e.metaKey, k = e.key;
  if (ctrl && (k === "z" || k === "Z")) { e.preventDefault(); if (e.shiftKey) vxRedo(); else vxUndo(); return; }
  if (ctrl && (k === "y" || k === "Y")) { e.preventDefault(); vxRedo(); return; }
  if (ctrl && (k === "d" || k === "D")) { e.preventDefault(); if (VX.sel >= 0) vxDuplicate(VX.sel); return; }
  if (ctrl && (k === "s" || k === "S")) { e.preventDefault(); vxSaveNow(); return; }
  if (ctrl) return;
  if (k === " " && tag !== "BUTTON") { e.preventDefault(); vxSetPlaying(!VX.playing); return; }
  if (k === "Home") { vxRestart(); return; }
  if (k === "," || k === "ArrowLeft") { e.preventDefault(); vxStepFrame(-1); return; }
  if (k === "." || k === "ArrowRight") { e.preventDefault(); vxStepFrame(1); return; }
  if ((k === "Delete" || k === "Backspace") && VX.sel >= 0) { e.preventDefault(); vxDeleteLayer(VX.sel); return; }
  if (k === "ArrowUp" || k === "ArrowDown") { e.preventDefault(); const n = VX.eff.layers.length; if (!n) return; VX.sel = clamp((VX.sel < 0 ? (k === "ArrowDown" ? -1 : n) : VX.sel) + (k === "ArrowDown" ? 1 : -1), 0, n - 1); renderVxInsp(); renderVxTimeline(); return; }
});
