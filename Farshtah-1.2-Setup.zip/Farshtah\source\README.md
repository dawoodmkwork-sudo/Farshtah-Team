# Farshtah: source

Farshtah is an R6 keyframe animator for Roblox. It's one web page, run by a small local Node.js helper that keeps everything as plain files, and shown in its own Microsoft Edge window. MIT licensed (see `../LICENSE`).

## Files
- `template.html`: the whole app (HTML, CSS and JavaScript).
- `r6core.js`: the rig and all the animation math (quaternions, easing, smooth/spline curves, planted feet, baking). It's shared by the app and the importer.
- `importer.js`: turns an animation into one self-checking Luau script that builds its KeyframeSequence in Roblox Studio. The Luau inside is a port of `r6core.js`, so the two must stay in step.
- `import_r6.js`: the same importer from the command line:
  ```bash
  node import_r6.js anim.json [--parent ServerStorage.AnimatorImports] [--name N] [--fps 60] [--check] [--out f.luau]
  ```
- `build_page.js`: inlines `r6core.js`, `importer.js` and `desktop/logo.svg` into the template. It writes:
  - `desktop/app/index.html`: the app;
  - `index.html`: a page for hosts that provide `window.claude` storage;
  - `test.html`: storage stubbed in memory, for trying it in any browser.
- `desktop/server.js`: the helper.
  - It serves the app on 127.0.0.1 with a per-run key, and stores animations, references, backgrounds, models, settings and clips under `Documents\Farshtah`.
  - It opens Edge with `--app`, and exits about 30 s after its last window closes.
  - To run it by hand:
    ```bash
    node desktop/server.js [--port 51735] [--data dir] [--no-window]
    ```
- `desktop/install.ps1`, `desktop/uninstall.ps1`, `desktop/launcher.vbs`: per-user install, with no admin rights. The installer uses `node\node.exe` from the package when it's there, otherwise the PC's own Node.js.
- `desktop/make_icon.ps1`: renders `desktop/logo.svg` into `icon.png` and `icon.ico`, using headless Edge.
- `desktop/make_package.ps1`: builds the shareable zip.
- `visuals/`: the start screen and Farshtah Visuals+ (the VFX maker). `build_page.js` puts its CSS, markup and code into the template's slots.
- `graphics/`: Farshtah Graphics (thumbnails and icons), in the same slots, after Visuals+:
  - `gfxrig.js`: the R6 character (Roblox's 585 × 559 clothing template layout, faces, accessories, held items, poses);
  - `gfxscene.js`: the 3D scene and the picture (HDR render, bloom, the camera and colour pass, outlines and glows);
  - `gfx2d.js`: the design layers (text, images, stickers, overlays);
  - `gfxui.js`, `gfxpanel.js`: the project, its presets and templates, saving, and the editor;
  - `gfxhub.js`: the start screen's live 3D cards, then which app opens first.

## Building
```bash
node build_page.js
```
Then try `desktop/app/index.html` through the helper, or open `test.html` from any local web server.

## The animation format (`animations/<id>.json`)
- `format: "r6-animator/1"`, plus `name`, `length` (s), `fps` (60 or 30), `loop`, `priority`, `plantFeet` and `markers: [{name, t}]`.
- `tracks` is keyed by joint: Torso, Head, Right Arm, Left Arm, Right Leg, Left Leg.
- Each key is `{t, q: [x, y, z, w], p?: [x, y, z], e}`:
  - `q` is the joint's rotation in its parent part's space, about its pivot, in Roblox axes. `p` is the offset from the pivot.
  - `e` is the easing into the next key: smooth, spline, linear, constant, cubic `in` / `out` / `inout`, or `<family>-<in|out|inout>` for sine, quad, quart, quint, expo, circ, back, elastic and bounce.
- `props: [{model, joint, p, r, s}]` are models held by the rig. They're for viewing only, and the import ignores them.
- Roblox's Pose.CFrame = C0rot⁻¹ · CFrame(p, q) · C0rot.

## The Graphics format (`graphics/<id>.json`)
- `format: "farshtah-gfx/1"`, `name`, `size` (thumb 1920 × 1080, yt 1280 × 720, icon 512 × 512, square 1080 × 1080, tall 1080 × 1920).
- `world`: the ground (`kind`, `color`, `color2`), the sky (`top`, `horizon`, `bottom`, `cloud`, `clouds`, `stars`, `sunSize`) and `fog`.
- `light`: the sun (`sunAz`, `sunEl`, `sunColor`, `sun`), `sky` light, `fill`, `shadows` and a `rim` light.
- `cam`: `p`, `t` (where it looks), `fov`, `roll`. `post`: tone, grade, bloom, lens, depth of field.
- `objs`: the 3D scene. A character is `{type: "char", look, pose: {joint: [x, y, z] degrees, XYZ order}, tp, p, yaw, s, fx}`. Its `look` holds body colours, `shirt` / `pants` (a built-in style, or `img`: a Roblox clothing template), `face` or `faceImg`, `tshirt`, `acc` (accessories) and `items` (held things).
- `layers`: the design layers over the picture, bottom first. Positions are fractions of the frame and sizes fractions of its height.
- `thumb` is a small JPEG of the picture, for the project list.
