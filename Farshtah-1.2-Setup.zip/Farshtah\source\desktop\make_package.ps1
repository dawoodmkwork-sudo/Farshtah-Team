# make_package.ps1 - builds the shareable Farshtah zip: the app and its installer, a copy of Node.js (so friends need
# nothing else), the full source, and the MIT license.
#   powershell -NoProfile -ExecutionPolicy Bypass -File make_package.ps1 [-Version 1.0] [-Out <folder>]
# Run "node build_page.js" first so desktop\app\index.html is current.
param([string]$Version = "1.0", [string]$Out = "")
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path          # ...\R6Animator\desktop
$root = Split-Path -Parent $here                                    # ...\R6Animator
if (-not $Out) { $Out = Join-Path $root "dist" }
$pkg = Join-Path $here "package"
$node = (Get-Command node.exe -ErrorAction Stop).Source
$nodeVersion = (& $node --version).Trim()
$stage = Join-Path $Out "Farshtah"
if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
foreach ($d in "app", "seed\animations", "node", "source\desktop\package") { New-Item -ItemType Directory -Force -Path (Join-Path $stage $d) | Out-Null }
$utf8 = New-Object System.Text.UTF8Encoding $false
function Put-Text([string]$from, [string]$to, [switch]$Crlf) { # copies a text file, filling in the version numbers
  $t = (Get-Content $from -Raw -Encoding UTF8).Replace("__VERSION__", $Version).Replace("__NODE_VERSION__", $nodeVersion)
  if ($Crlf) { $t = $t -replace "`r?`n", "`r`n" }
  [IO.File]::WriteAllText($to, $t, $utf8)
}

# the app, as install.ps1 expects it
foreach ($f in "server.js", "launcher.vbs", "install.ps1", "uninstall.ps1", "icon.png", "icon.ico") { Copy-Item (Join-Path $here $f) $stage }
Copy-Item (Join-Path $here "app\index.html") (Join-Path $stage "app")
foreach ($f in "katana-cut-sample.json", "slash-test.json", "example-wave.json") { Copy-Item (Join-Path $here "seed\animations\$f") (Join-Path $stage "seed\animations") } # the starting animations, and only these
Copy-Item $node (Join-Path $stage "node\node.exe")
Put-Text (Join-Path $pkg "NODE-LICENSE.txt") (Join-Path $stage "node\LICENSE.txt") -Crlf
# the friendly bits
Put-Text (Join-Path $pkg "Install Farshtah.cmd") (Join-Path $stage "Install Farshtah.cmd") -Crlf
Put-Text (Join-Path $pkg "README.txt") (Join-Path $stage "README.txt") -Crlf
Put-Text (Join-Path $pkg "LICENSE") (Join-Path $stage "LICENSE") -Crlf
Put-Text (Join-Path $pkg "THIRD-PARTY.txt") (Join-Path $stage "THIRD-PARTY.txt") -Crlf
# the source
foreach ($f in "template.html", "r6core.js", "importer.js", "import_r6.js", "build_page.js") { Copy-Item (Join-Path $root $f) (Join-Path $stage "source") }
New-Item -ItemType Directory -Force -Path (Join-Path $stage "source\visuals") | Out-Null # the start screen and Visuals+
foreach ($f in "visuals.css", "visuals.html", "vfxtex.js", "visuals.js", "vfxexport.js") { Copy-Item (Join-Path $root "visuals\$f") (Join-Path $stage "source\visuals") }
New-Item -ItemType Directory -Force -Path (Join-Path $stage "source\graphics") | Out-Null # Farshtah Graphics (thumbnails)
foreach ($f in "gfx.css", "gfx.html", "gfxrig.js", "gfxscene.js", "gfx2d.js", "gfxui.js", "gfxpanel.js", "gfxhub.js") { Copy-Item (Join-Path $root "graphics\$f") (Join-Path $stage "source\graphics") }
foreach ($f in "server.js", "launcher.vbs", "install.ps1", "uninstall.ps1", "make_icon.ps1", "make_package.ps1", "logo.svg", "icon.png", "icon.ico") { Copy-Item (Join-Path $here $f) (Join-Path $stage "source\desktop") }
Get-ChildItem $pkg -File | ForEach-Object { Copy-Item $_.FullName (Join-Path $stage "source\desktop\package") }
Copy-Item (Join-Path $pkg "SOURCE-README.md") (Join-Path $stage "source\README.md")
Put-Text (Join-Path $pkg "LICENSE") (Join-Path $stage "source\LICENSE")

$zip = Join-Path $Out "Farshtah-$Version-Setup.zip"
if (Test-Path $zip) { Remove-Item $zip -Force }
Compress-Archive -Path $stage -DestinationPath $zip -CompressionLevel Optimal
"built $zip ($([math]::Round((Get-Item $zip).Length / 1MB, 1)) MB; Node.js $nodeVersion inside)"
