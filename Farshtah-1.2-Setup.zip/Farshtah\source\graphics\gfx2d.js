// ======================================================================= Farshtah Graphics: the design layers
// Text, images, stickers and overlays sit over the 3D picture, bottom to top. Positions are fractions of the frame
// (x across, y down) and sizes fractions of its height, so a layer looks the same at any export size.
const GX_FONTS = [["Luckiest Guy", 400], ["Lilita One", 400], ["Fredoka", 700], ["Titan One", 400], ["Bangers", 400], ["Bungee", 400], ["Anton", 400], ["Bebas Neue", 400],
  ["Russo One", 400], ["Black Ops One", 400], ["Bowlby One SC", 400], ["Archivo Black", 400], ["Passion One", 700], ["Chewy", 400], ["Permanent Marker", 400], ["Creepster", 400],
  ["Press Start 2P", 400], ["Rubik", 900], ["Space Grotesk", 700], ["Inter", 600]];
const GX_FONT_W = new Map(GX_FONTS);
const GX_FONT_CSS = "https://fonts.googleapis.com/css2?family=Luckiest+Guy&family=Lilita+One&family=Fredoka:wght@700&family=Titan+One&family=Bangers&family=Bungee&family=Anton&family=Bebas+Neue" +
  "&family=Russo+One&family=Black+Ops+One&family=Bowlby+One+SC&family=Archivo+Black&family=Passion+One:wght@700&family=Chewy&family=Permanent+Marker&family=Creepster&family=Press+Start+2P&family=Rubik:wght@900&display=block";
let gxFontsLinked = false; const gxFontReady = new Set(), gxFontWait = new Set();
function gxLinkFonts() { if (gxFontsLinked) return; gxFontsLinked = true; const l = document.createElement("link"); l.rel = "stylesheet"; l.href = GX_FONT_CSS; document.head.appendChild(l); }
function gxFontSpec(L, px) { const w = GX_FONT_W.get(L.font) || 400; return `${w} ${Math.max(1, px).toFixed(2)}px "${L.font}", "Arial Black", sans-serif`; }
function gxEnsureFont(font) { // a font's first use loads it, then everything redraws
  if (gxFontReady.has(font) || gxFontWait.has(font) || !document.fonts) return; gxLinkFonts(); gxFontWait.add(font);
  const w = GX_FONT_W.get(font) || 400;
  document.fonts.load(`${w} 64px "${font}"`, "AaBb19!?").then(() => { gxFontReady.add(font); gxFontWait.delete(font); gx2dCache.clear(); gxDirty = true; if (typeof gxRefreshTextTiles === "function") gxRefreshTextTiles(); }, () => { gxFontWait.delete(font); gxFontReady.add(font); });
}
const gx2dCache = new Map(); // a layer's drawing at a frame height -> { cv, ox, oy } (redrawn when it changes)
const gxBoxes = new Map(); // layer id -> { cx, cy, w, h, rot } in frame pixels, for clicking and handles
function gxCacheGet(key, make) { let v = gx2dCache.get(key); if (v) { gx2dCache.delete(key); gx2dCache.set(key, v); return v; } v = make(); gx2dCache.set(key, v); while (gx2dCache.size > 60) gx2dCache.delete(gx2dCache.keys().next().value); return v; }
// ---- text
function gxTextGlyphs(c, L, size) { // the lines, measured: [{ text, w, chars: [[ch, x]] }] and the box
  c.font = gxFontSpec(L, size); try { c.letterSpacing = (L.spacing * size).toFixed(2) + "px"; } catch (e) {}
  const lines = String(L.upper ? L.text.toUpperCase() : L.text).split("\n").map(t => t || " ");
  const out = lines.map(t => { const w = c.measureText(t).width; return { text: t, w }; });
  const lh = size * L.line, w = Math.max(1, ...out.map(o => o.w)), h = lh * out.length;
  return { lines: out, w, h, lh };
}
function gxTextPaths(c, L, m, size, act) { // act(text, x, y) for every line (or every letter, on an arc)
  const n = m.lines.length;
  m.lines.forEach((ln, i) => {
    const y = (i - (n - 1) / 2) * m.lh, x0 = L.align === "left" ? -m.w / 2 : L.align === "right" ? m.w / 2 - ln.w : -ln.w / 2;
    if (Math.abs(L.arc) < 0.01) { act(ln.text, x0 + ln.w / 2, y, 0); return; }
    const R = size * 9 / L.arc; // the arc's radius (negative: it bends down)
    let x = x0; c.save();
    for (const ch of ln.text) { const cw = c.measureText(ch).width + L.spacing * size, mid = x + cw / 2, a = mid / R; // (an arch: the ends bend down, or up when the arc is negative)
      act(ch, Math.sin(a) * R, y + R - Math.cos(a) * R, a); x += cw; }
    c.restore();
  });
}
function gxDrawTextLayer(L, H) { // -> { cv, ox, oy, w, h }: the text with its strokes, depth and fill, before shadow and glow
  const size = L.size * H, pad = Math.ceil(size * (L.stroke1[0] + L.stroke2[0] + 0.25) + L.extrude[0] * size + size * Math.abs(L.arc) * 0.6);
  const meas = document.createElement("canvas").getContext("2d"), m = gxTextGlyphs(meas, L, size);
  const cw = Math.ceil(m.w + pad * 2 + size * 0.5), ch = Math.ceil(m.h + pad * 2 + size * Math.abs(L.arc) * 1.2);
  const cv = document.createElement("canvas"); cv.width = Math.min(8192, cw); cv.height = Math.min(8192, ch); const c = cv.getContext("2d");
  c.translate(cv.width / 2, cv.height / 2); c.textAlign = "center"; c.textBaseline = "middle"; c.lineJoin = "round"; c.lineCap = "round"; c.miterLimit = 2;
  c.font = gxFontSpec(L, size); try { c.letterSpacing = (Math.abs(L.arc) < 0.01 ? L.spacing * size : 0).toFixed(2) + "px"; } catch (e) {}
  if (L.italic) c.transform(1, 0, -0.18, 1, 0, 0);
  const each = fn => gxTextPaths(c, L, m, size, (t, x, y, a) => { c.save(); c.translate(x, y); if (a) c.rotate(a); fn(t); c.restore(); });
  const s1 = L.stroke1[0] * size, s2 = L.stroke2[0] * size, outer = s1 + s2;
  // depth: the outline's shape, stepped away from the text
  if (L.extrude[0] > 0.001) {
    const d = L.extrude[0] * size, a = L.extrude[2] * DEG, steps = Math.max(2, Math.ceil(d / 1.4)), far = gxShade(L.extrude[1], -0.25);
    for (let k = steps; k >= 1; k--) { const t = k / steps; c.save(); c.translate(Math.cos(a) * d * t, Math.sin(a) * d * t); const col = k === steps ? far : L.extrude[1];
      c.fillStyle = col; c.strokeStyle = col; c.lineWidth = outer * 2 || 1; each(tx => { if (outer > 0) c.strokeText(tx, 0, 0); c.fillText(tx, 0, 0); }); c.restore(); }
  }
  if (s2 > 0.01) { c.strokeStyle = L.stroke2[1]; c.lineWidth = outer * 2; each(tx => c.strokeText(tx, 0, 0)); }
  if (s1 > 0.01) { c.strokeStyle = L.stroke1[1]; c.lineWidth = s1 * 2; each(tx => c.strokeText(tx, 0, 0)); }
  // the fill: one colour or a gradient across the text, with an optional shine on its top half
  let fill = L.fill.a;
  if (L.fill.kind === "grad") { const a = (L.fill.angle + 90) * DEG, rx = Math.cos(a) * m.w / 2, ry = Math.sin(a) * m.h / 2; const g = c.createLinearGradient(-rx, -ry, rx, ry);
    g.addColorStop(0, L.fill.a); if (L.fill.mid) g.addColorStop(0.5, L.fill.mid); g.addColorStop(1, L.fill.b); fill = g; }
  c.fillStyle = fill; each(tx => c.fillText(tx, 0, 0));
  if (L.fill.shine > 0.001) { // a glossy band over the top of the letters only
    const sh = document.createElement("canvas"); sh.width = cv.width; sh.height = cv.height; const s = sh.getContext("2d");
    s.setTransform(c.getTransform()); s.textAlign = "center"; s.textBaseline = "middle"; s.font = c.font; try { s.letterSpacing = c.letterSpacing; } catch (e) {}
    s.fillStyle = "#fff"; gxTextPaths(s, L, m, size, (t, x, y, a) => { s.save(); s.translate(x, y); if (a) s.rotate(a); s.fillText(t, 0, 0); s.restore(); });
    s.setTransform(1, 0, 0, 1, 0, 0); s.globalCompositeOperation = "source-in";
    const g = s.createLinearGradient(0, cv.height / 2 - m.h / 2, 0, cv.height / 2 + m.h * 0.1); g.addColorStop(0, `rgba(255,255,255,${0.75 * L.fill.shine})`); g.addColorStop(0.55, `rgba(255,255,255,${0.35 * L.fill.shine})`); g.addColorStop(0.56, "rgba(255,255,255,0)");
    s.fillStyle = g; s.fillRect(0, 0, sh.width, sh.height); c.save(); c.setTransform(1, 0, 0, 1, 0, 0); c.drawImage(sh, 0, 0); c.restore();
  }
  return { cv, ox: cv.width / 2, oy: cv.height / 2, w: m.w + outer * 2, h: m.h + outer * 2 + size * Math.abs(L.arc) * 0.5 };
}
// ---- stickers: simple shapes drawn in a 200 x 200 box
const GX_STICKERS = [["arrow", "Arrow"], ["curve", "Curved arrow"], ["circle", "Circle"], ["burst", "Burst"], ["badge", "Badge"], ["bolt", "Bolt"], ["star", "Star"], ["sparkle", "Sparkle"],
  ["crown", "Crown"], ["heart", "Heart"], ["check", "Check"], ["cross", "Cross"], ["speech", "Speech"], ["banner", "Banner"], ["exclaim", "!"], ["question", "?"], ["skull", "Skull"], ["fireball", "Fireball"]];
const GX_STICKER_TEXT = { badge: "VS", banner: "NEW", speech: "" };
function gxStickerPath(c, kind) { // the shape's outline, in the 200 box centred on 0
  c.beginPath();
  const star = (n, r0, r1, rot) => { for (let i = 0; i < n * 2; i++) { const a = rot + i * Math.PI / n, r = i % 2 ? r1 : r0; c.lineTo(Math.cos(a) * r, Math.sin(a) * r); } c.closePath(); };
  switch (kind) {
    case "arrow": c.moveTo(-90, -22); c.lineTo(20, -22); c.lineTo(20, -60); c.lineTo(95, 0); c.lineTo(20, 60); c.lineTo(20, 22); c.lineTo(-90, 22); c.closePath(); break;
    case "curve": c.moveTo(-85, 70); c.quadraticCurveTo(-80, -40, 20, -45); c.lineTo(20, -80); c.lineTo(92, -25); c.lineTo(20, 30); c.lineTo(20, -5); c.quadraticCurveTo(-45, 0, -45, 70); c.closePath(); break;
    case "circle": c.arc(0, 0, 88, 0, Math.PI * 2); c.moveTo(66, 0); c.arc(0, 0, 66, 0, Math.PI * 2, true); break;
    case "burst": case "badge": { const r = vxRand(7); for (let i = 0; i < 28; i++) { const a = i * Math.PI / 14 - Math.PI / 2, rr = i % 2 ? 62 + r() * 6 : 92 + r() * 8; c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); } c.closePath(); break; }
    case "bolt": c.moveTo(25, -95); c.lineTo(-60, 15); c.lineTo(-5, 15); c.lineTo(-30, 95); c.lineTo(62, -20); c.lineTo(8, -20); c.closePath(); break;
    case "star": star(5, 92, 40, -Math.PI / 2); break;
    case "sparkle": for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4 - Math.PI / 2, r = i % 2 ? 18 : 92; if (i === 0) c.moveTo(Math.cos(a) * r, Math.sin(a) * r); else c.quadraticCurveTo(0, 0, Math.cos(a) * r, Math.sin(a) * r); } c.quadraticCurveTo(0, 0, 0, -92); c.closePath(); break;
    case "crown": c.moveTo(-85, 60); c.lineTo(-90, -45); c.lineTo(-45, 5); c.lineTo(0, -70); c.lineTo(45, 5); c.lineTo(90, -45); c.lineTo(85, 60); c.closePath(); break;
    case "heart": c.moveTo(0, 85); c.bezierCurveTo(-130, 0, -70, -100, 0, -40); c.bezierCurveTo(70, -100, 130, 0, 0, 85); c.closePath(); break;
    case "check": c.moveTo(-85, 5); c.lineTo(-50, -30); c.lineTo(-20, 0); c.lineTo(55, -75); c.lineTo(90, -40); c.lineTo(-20, 70); c.closePath(); break;
    case "cross": for (const [x, y] of [[-35, -80], [0, -45], [35, -80], [80, -35], [45, 0], [80, 35], [35, 80], [0, 45], [-35, 80], [-80, 35], [-45, 0], [-80, -35]]) c.lineTo(x, y); c.closePath(); break;
    case "speech": c.moveTo(-90, -50); c.quadraticCurveTo(-90, -80, -60, -80); c.lineTo(60, -80); c.quadraticCurveTo(90, -80, 90, -50); c.lineTo(90, 20); c.quadraticCurveTo(90, 50, 60, 50);
      c.lineTo(-10, 50); c.lineTo(-50, 90); c.lineTo(-40, 50); c.lineTo(-60, 50); c.quadraticCurveTo(-90, 50, -90, 20); c.closePath(); break;
    case "banner": c.moveTo(-95, -30); c.lineTo(95, -30); c.lineTo(80, 0); c.lineTo(95, 30); c.lineTo(-95, 30); c.lineTo(-80, 0); c.closePath(); break;
    case "exclaim": case "question": c.arc(0, 0, 88, 0, Math.PI * 2); break;
    case "skull": c.moveTo(-70, 10); c.bezierCurveTo(-90, -100, 90, -100, 70, 10); c.lineTo(50, 30); c.lineTo(45, 70); c.lineTo(-45, 70); c.lineTo(-50, 30); c.closePath(); break;
    case "fireball": c.moveTo(-60, 55); c.bezierCurveTo(-100, 0, -70, -40, -40, -60); c.bezierCurveTo(-45, -30, -20, -30, -15, -45); c.bezierCurveTo(-10, -80, 20, -90, 30, -95);
      c.bezierCurveTo(25, -60, 60, -50, 55, -20); c.bezierCurveTo(70, -35, 75, -45, 75, -55); c.bezierCurveTo(110, 0, 90, 60, 40, 80); c.bezierCurveTo(10, 92, -35, 85, -60, 55); c.closePath(); break;
  }
}
function gxDrawSticker(L, H) {
  const size = L.h * H, k = size / 200, sw = L.stroke[0] * 200, pad = Math.ceil((sw + 12) * k), S = Math.ceil(size + pad * 2);
  const cv = document.createElement("canvas"); cv.width = cv.height = Math.min(8192, S); const c = cv.getContext("2d");
  c.translate(cv.width / 2, cv.height / 2); c.scale(k, k); if (L.flip) c.scale(-1, 1); c.lineJoin = "round"; c.lineCap = "round";
  const ring = L.kind === "circle";
  gxStickerPath(c, L.kind);
  if (sw > 0.01 && !ring) { c.strokeStyle = L.stroke[1]; c.lineWidth = sw * 2; c.stroke(); }
  if (ring) { if (sw > 0.01) { c.strokeStyle = L.stroke[1]; c.lineWidth = sw * 2; c.stroke(); } }
  const g = c.createLinearGradient(0, -95, 0, 95); g.addColorStop(0, L.c1); g.addColorStop(1, L.c2); c.fillStyle = g; c.fill("evenodd");
  // details on top
  c.fillStyle = L.c2; c.strokeStyle = L.stroke[1];
  if (L.kind === "badge" || L.kind === "burst") { c.save(); c.scale(0.7, 0.7); gxStickerPath(c, "burst"); c.fillStyle = L.c2; c.fill(); c.restore(); }
  if (L.kind === "skull") { c.fillStyle = L.stroke[1]; for (const x of [-30, 30]) { c.beginPath(); c.ellipse(x, -10, 20, 24, 0, 0, 7); c.fill(); } c.beginPath(); c.moveTo(0, 15); c.lineTo(-10, 35); c.lineTo(10, 35); c.fill();
    for (const x of [-25, 0, 25]) c.fillRect(x - 3, 50, 6, 20); }
  if (L.kind === "fireball") { c.save(); c.scale(0.55, 0.55); c.translate(0, 40); gxStickerPath(c, "fireball"); c.fillStyle = L.c2; c.fill(); c.restore(); }
  const txt = L.kind === "exclaim" ? "!" : L.kind === "question" ? "?" : (L.kind in GX_STICKER_TEXT ? L.text : "");
  if (txt) {
    const font = L.font || "Luckiest Guy"; gxEnsureFont(font); const fs = L.kind === "banner" ? 44 : L.kind === "speech" ? 46 : txt.length > 2 ? 64 : 92;
    c.font = gxFontSpec({ font }, fs); c.textAlign = "center"; c.textBaseline = "middle"; const y = L.kind === "speech" ? -15 : L.kind === "banner" ? 2 : 6;
    c.lineWidth = 12; c.strokeStyle = L.stroke[1]; c.fillStyle = L.textColor || "#ffffff";
    c.save(); let w = c.measureText(txt).width, lim = L.kind === "banner" ? 150 : 140; if (w > lim) c.scale(lim / w, lim / w); c.strokeText(txt, 0, y); c.fillText(txt, 0, y); c.restore();
  }
  return { cv, ox: cv.width / 2, oy: cv.height / 2, w: size, h: size };
}
// ---- images (imported PNG / JPEG), with an optional sticker outline
function gxDrawImageLayer(L, H) {
  const e = gxImage(L.asset); if (!e || !e.ok) return null;
  const img = e.img, h = L.h * H, w = h * img.naturalWidth / Math.max(1, img.naturalHeight), sw = L.outline[0] * h, pad = Math.ceil(sw + 2);
  const cv = document.createElement("canvas"); cv.width = Math.min(8192, Math.ceil(w + pad * 2)); cv.height = Math.min(8192, Math.ceil(h + pad * 2)); const c = cv.getContext("2d");
  const draw = (ctx, dx, dy) => { ctx.save(); ctx.translate(cv.width / 2 + dx, cv.height / 2 + dy); if (L.flip) ctx.scale(-1, 1); ctx.drawImage(img, -w / 2, -h / 2, w, h); ctx.restore(); };
  if (sw > 0.5) { const n = sw > 8 ? 28 : 16; for (const k of [1, 0.6, 0.3]) for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; draw(c, Math.cos(a) * sw * k, Math.sin(a) * sw * k); }
    c.globalCompositeOperation = "source-in"; c.fillStyle = L.outline[1]; c.fillRect(0, 0, cv.width, cv.height); c.globalCompositeOperation = "source-over"; }
  draw(c, 0, 0);
  return { cv, ox: cv.width / 2, oy: cv.height / 2, w: w + sw * 2, h: h + sw * 2 };
}
// ---- overlays: whole-frame effects
const GX_OVERLAYS = [["speed", "Speed lines"], ["rays", "Light rays"], ["flare", "Lens flare"], ["sparkle", "Sparkles"], ["embers", "Embers"], ["confetti", "Confetti"],
  ["gradient", "Gradient"], ["vignette", "Colour edges"], ["smoke", "Low smoke"], ["border", "Glow border"], ["halftone", "Halftone"]];
function gxDrawOverlay(c, L, W, H) {
  const cx = L.x * W, cy = L.y * H, P = L.power, rnd = vxRand(L.seed * 7919 + 1), D = Math.hypot(W, H);
  switch (L.kind) {
    case "speed": { const n = Math.round(60 + 200 * P), clear = D * (0.12 + 0.25 * (1 - P)); c.fillStyle = L.c1;
      for (let i = 0; i < n; i++) { const a = rnd() * Math.PI * 2, wa = (0.002 + rnd() * 0.01) * (0.6 + P), r0 = clear * (0.8 + rnd() * 0.7);
        c.beginPath(); c.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0); c.lineTo(cx + Math.cos(a - wa) * D, cy + Math.sin(a - wa) * D); c.lineTo(cx + Math.cos(a + wa) * D, cy + Math.sin(a + wa) * D); c.closePath(); c.fill(); } break; }
    case "rays": { const n = 14 + Math.round(10 * P); c.save(); c.globalCompositeOperation = "lighter";
      for (let i = 0; i < n; i++) { const a = rnd() * Math.PI * 2, wa = 0.03 + rnd() * 0.08, g = c.createRadialGradient(cx, cy, 0, cx, cy, D * 0.8);
        g.addColorStop(0, hexA(L.c1, 0.55 * P)); g.addColorStop(0.5, hexA(L.c1, 0.18 * P)); g.addColorStop(1, hexA(L.c1, 0)); c.fillStyle = g;
        c.beginPath(); c.moveTo(cx, cy); c.arc(cx, cy, D, a - wa, a + wa); c.closePath(); c.fill(); }
      const core = c.createRadialGradient(cx, cy, 0, cx, cy, H * 0.25); core.addColorStop(0, hexA(L.c2, 0.7 * P)); core.addColorStop(1, hexA(L.c2, 0)); c.fillStyle = core; c.fillRect(0, 0, W, H); c.restore(); break; }
    case "flare": { c.save(); c.globalCompositeOperation = "lighter"; const s = H * (0.1 + 0.2 * P);
      const glow = c.createRadialGradient(cx, cy, 0, cx, cy, s * 2.2); glow.addColorStop(0, hexA("#ffffff", 0.95)); glow.addColorStop(0.15, hexA(L.c1, 0.6)); glow.addColorStop(1, hexA(L.c1, 0)); c.fillStyle = glow; c.fillRect(0, 0, W, H);
      const st = c.createLinearGradient(cx - W * 0.6, 0, cx + W * 0.6, 0); st.addColorStop(0, hexA(L.c1, 0)); st.addColorStop(0.5, hexA(L.c2, 0.8 * P)); st.addColorStop(1, hexA(L.c1, 0)); c.fillStyle = st; c.fillRect(0, cy - s * 0.03, W, s * 0.06);
      const dx = W / 2 - cx, dy = H / 2 - cy; for (const [t, r, a] of [[0.5, 0.22, 0.12], [0.8, 0.12, 0.18], [1.2, 0.35, 0.08], [1.5, 0.08, 0.22], [1.8, 0.18, 0.1]]) {
        const g = c.createRadialGradient(cx + dx * t * 2, cy + dy * t * 2, 0, cx + dx * t * 2, cy + dy * t * 2, s * r * 2); g.addColorStop(0, hexA(L.c2, a * P)); g.addColorStop(0.7, hexA(L.c1, a * 0.6 * P)); g.addColorStop(1, hexA(L.c1, 0));
        c.fillStyle = g; c.beginPath(); c.arc(cx + dx * t * 2, cy + dy * t * 2, s * r * 2, 0, 7); c.fill(); }
      c.restore(); break; }
    case "sparkle": { c.save(); c.globalCompositeOperation = "lighter"; const n = Math.round(10 + 50 * P);
      for (let i = 0; i < n; i++) { const x = rnd() * W, y = rnd() * H, s = H * (0.004 + Math.pow(rnd(), 4) * 0.026), col = rnd() < 0.5 ? L.c1 : L.c2;
        const g = c.createRadialGradient(x, y, 0, x, y, s * 3); g.addColorStop(0, hexA(col, 0.9)); g.addColorStop(1, hexA(col, 0)); c.fillStyle = g; c.fillRect(x - s * 3, y - s * 3, s * 6, s * 6);
        c.fillStyle = hexA("#ffffff", 0.95); c.beginPath(); for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4, r = k % 2 ? s * 0.25 : s * 2.2; c.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r); } c.closePath(); c.fill(); }
      c.restore(); break; }
    case "embers": { c.save(); c.globalCompositeOperation = "lighter"; const n = Math.round(40 + 160 * P);
      for (let i = 0; i < n; i++) { const x = rnd() * W, y = H * (0.25 + rnd() * 0.75), s = H * (0.002 + rnd() * 0.006), col = rnd() < 0.6 ? L.c1 : L.c2;
        const g = c.createRadialGradient(x, y, 0, x, y, s * 4); g.addColorStop(0, hexA("#ffffff", 0.9)); g.addColorStop(0.3, hexA(col, 0.8)); g.addColorStop(1, hexA(col, 0)); c.fillStyle = g; c.fillRect(x - s * 4, y - s * 4, s * 8, s * 8); }
      c.restore(); break; }
    case "confetti": { const cols = [L.c1, L.c2, "#ffd23f", "#3bceac", "#ee4266", "#540d6e", "#ffffff"], n = Math.round(40 + 160 * P);
      for (let i = 0; i < n; i++) { c.save(); c.translate(rnd() * W, rnd() * H); c.rotate(rnd() * 6.28); c.fillStyle = cols[i % cols.length]; const s = H * (0.006 + rnd() * 0.012); c.fillRect(-s, -s * 0.45, s * 2, s * 0.9); c.restore(); } break; }
    case "gradient": { const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, hexA(L.c1, 0.85 * P)); g.addColorStop(0.5, hexA(L.c1, 0)); g.addColorStop(0.5, hexA(L.c2, 0)); g.addColorStop(1, hexA(L.c2, 0.85 * P)); c.fillStyle = g; c.fillRect(0, 0, W, H); break; }
    case "vignette": { const g = c.createRadialGradient(W / 2, H / 2, Math.min(W, H) * (0.35 + 0.25 * (1 - P)), W / 2, H / 2, D * 0.6); g.addColorStop(0, hexA(L.c1, 0)); g.addColorStop(1, hexA(L.c1, 0.95)); c.fillStyle = g; c.fillRect(0, 0, W, H); break; }
    case "smoke": { const cv = gxCacheGet("smoke" + L.seed + "|" + W + "x" + H, () => { const s = document.createElement("canvas"); s.width = 480; s.height = Math.round(480 * H / W); const x = s.getContext("2d"), img = x.createImageData(s.width, s.height), d = img.data, f = vxFbm(L.seed * 13 + 5);
        for (let y = 0; y < s.height; y++) for (let i = 0; i < s.width; i++) { const v = y / s.height, n = f(i / s.width * 2, v * 1.2), a = clamp(sstep(0.35, 1, v) * (n * 1.4 - 0.25), 0, 1), k = (y * s.width + i) * 4; d[k] = d[k + 1] = d[k + 2] = 255; d[k + 3] = a * 255; }
        x.putImageData(img, 0, 0); return { cv: s }; }).cv;
      const tinted = document.createElement("canvas"); tinted.width = cv.width; tinted.height = cv.height; const t = tinted.getContext("2d"); t.drawImage(cv, 0, 0); t.globalCompositeOperation = "source-in"; t.fillStyle = L.c1; t.fillRect(0, 0, cv.width, cv.height);
      c.save(); c.globalAlpha *= clamp(P * 1.2, 0, 1); c.drawImage(tinted, 0, 0, W, H); c.restore(); break; }
    case "border": { const w = H * (0.01 + 0.03 * P); c.save(); c.strokeStyle = L.c1; c.lineWidth = w; c.shadowColor = L.c2; c.shadowBlur = w * 3; c.strokeRect(w / 2, w / 2, W - w, H - w); c.strokeRect(w / 2, w / 2, W - w, H - w); c.restore(); break; }
    case "halftone": { const step = H * (0.012 + 0.02 * (1 - P)); c.fillStyle = L.c1;
      for (let y = 0; y < H + step; y += step) for (let x = 0; x < W + step; x += step) { const d = Math.hypot(x - cx, y - cy) / D, r = step * 0.5 * clamp(d * 1.6 - 0.15, 0, 1); if (r > 0.3) { c.beginPath(); c.arc(x + ((y / step) % 2) * step / 2, y, r, 0, 7); c.fill(); } } break; }
  }
}
function hexA(hex, a) { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16 & 255},${n >> 8 & 255},${n & 255},${clamp(a, 0, 1)})`; }
// ---- all the layers onto the picture
function gxLayerKey(L, H) { return L.id + "|" + H + "|" + JSON.stringify(L) + (L.type === "image" ? ((gxImgCache.get(L.asset) || {}).ok ? 1 : 0) : "") + (L.font ? (gxFontReady.has(L.font) ? 1 : 0) : ""); }
function gxDrawLayers(ctx, p, W, H, o) {
  o = o || {}; gxBoxes.clear();
  for (const L of p.layers) {
    if (L.hide) continue;
    if (o.noText && L.type !== "overlay") continue;
    ctx.save(); ctx.globalAlpha = clamp(L.opacity, 0, 1); ctx.globalCompositeOperation = L.blend || "source-over";
    if (L.type === "overlay") { gxDrawOverlay(ctx, L, W, H); ctx.restore(); gxBoxes.set(L.id, { cx: L.x * W, cy: L.y * H, w: H * 0.06, h: H * 0.06, rot: 0, overlay: true }); continue; }
    if (L.type === "text" || L.type === "sticker") gxEnsureFont(L.font || "Luckiest Guy");
    const d = gxCacheGet(gxLayerKey(L, H), () => L.type === "text" ? gxDrawTextLayer(L, H) : L.type === "sticker" ? gxDrawSticker(L, H) : gxDrawImageLayer(L, H));
    if (!d) { ctx.restore(); continue; }
    const cx = L.x * W, cy = L.y * H, rot = (L.rot || 0) * DEG, base = ctx.getTransform();
    const shadowOnly = (color, blur, ox, oy, times) => { // only the shadow lands in the frame: the drawing itself is moved far off, its shadow moved back
      ctx.save(); ctx.setTransform(base); ctx.translate(-30000, 0); ctx.translate(cx, cy); ctx.rotate(rot);
      ctx.shadowColor = color; ctx.shadowBlur = blur; ctx.shadowOffsetX = 30000 * base.a + ox; ctx.shadowOffsetY = oy;
      for (let k = 0; k < times; k++) ctx.drawImage(d.cv, -d.ox, -d.oy); ctx.restore(); };
    if (L.shadow && L.shadow[0] + L.shadow[2] > 0.001) { const dist = L.shadow[2] * H * 0.03, a = (L.shadow[3] == null ? 60 : L.shadow[3]) * DEG;
      shadowOnly(hexA(L.shadow[1], L.shadow[4] == null ? 0.7 : L.shadow[4]), L.shadow[0] * H * 0.04, Math.cos(a) * dist, Math.sin(a) * dist, 1); }
    if (L.glow && L.glow[0] > 0.001) shadowOnly(L.glow[1], L.glow[0] * H * 0.08, 0, 0, 2); // a glow around the whole thing (twice, for strength)
    ctx.translate(cx, cy); ctx.rotate(rot); ctx.drawImage(d.cv, -d.ox, -d.oy);
    ctx.restore();
    gxBoxes.set(L.id, { cx, cy, w: d.w, h: d.h, rot });
  }
}
// ---- clicking and handles
function gxLocal(b, x, y) { const dx = x - b.cx, dy = y - b.cy, c = Math.cos(-b.rot), s = Math.sin(-b.rot); return [dx * c - dy * s, dx * s + dy * c]; }
function gxHitLayer(p, x, y) { // the top layer under a frame point (overlays only by their handle)
  for (let i = p.layers.length - 1; i >= 0; i--) { const L = p.layers[i], b = gxBoxes.get(L.id); if (!b || L.hide || L.lock) continue;
    const [lx, ly] = gxLocal(b, x, y); const pad = 6; if (Math.abs(lx) <= b.w / 2 + pad && Math.abs(ly) <= b.h / 2 + pad) return L; }
  return null;
}
function gxHandleAt(b, x, y, scale) { // "rot" | "scale" | null for the selected layer's box (screen-sized handles)
  if (!b || b.overlay) return null; const [lx, ly] = gxLocal(b, x, y), r = 9 * scale;
  if (Math.hypot(lx, ly + b.h / 2 + 28 * scale) < r * 1.4) return "rot";
  for (const [sx, sy] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) if (Math.hypot(lx - sx * b.w / 2, ly - sy * b.h / 2) < r * 1.3) return "scale";
  return null;
}
function gxDrawHandles(ctx, b, scale, accent) {
  if (!b) return; ctx.save(); ctx.translate(b.cx, b.cy); ctx.rotate(b.rot); ctx.lineWidth = 1.5 * scale; ctx.strokeStyle = accent; ctx.setLineDash([6 * scale, 4 * scale]);
  if (b.overlay) { ctx.beginPath(); ctx.arc(0, 0, 14 * scale, 0, 7); ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle = accent; ctx.beginPath(); ctx.arc(0, 0, 5 * scale, 0, 7); ctx.fill(); ctx.restore(); return; }
  ctx.strokeRect(-b.w / 2, -b.h / 2, b.w, b.h); ctx.setLineDash([]);
  ctx.beginPath(); ctx.moveTo(0, -b.h / 2); ctx.lineTo(0, -b.h / 2 - 22 * scale); ctx.stroke();
  ctx.fillStyle = "#ffffff"; ctx.lineWidth = 2 * scale;
  for (const [sx, sy] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) { ctx.beginPath(); ctx.rect(sx * b.w / 2 - 6 * scale, sy * b.h / 2 - 6 * scale, 12 * scale, 12 * scale); ctx.fill(); ctx.stroke(); }
  ctx.beginPath(); ctx.arc(0, -b.h / 2 - 28 * scale, 8 * scale, 0, 7); ctx.fill(); ctx.stroke();
  ctx.restore();
}
