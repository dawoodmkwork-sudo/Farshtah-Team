// ======================================================================= Farshtah Graphics: the 3D scene and the picture
// The scene renders in HDR into its own target (multisampled), bloom adds the glow of anything brighter than white, and
// a last pass does the camera (depth of field, zoom blur, lens, colour split), the tone curve and the colour grade. The
// result is copied into a 2D canvas, where the outlines, glows and the design layers (text, images, stickers) go on top.
// The preview and the exported PNG are made by the same code, so the export is exactly what the frame shows.
const GX_SIZES = { thumb: [1920, 1080, "Thumbnail"], yt: [1280, 720, "YouTube"], icon: [512, 512, "Icon"], square: [1080, 1080, "Square"], tall: [1080, 1920, "Story"] };
let gxR = null, gxGL = null, gxScene = null, gxCam = null, gxWorld = null, gxSky = null, gxGround = null, gxCyc = null, gxSun = null, gxRim = null, gxHemi = null;
let gxRT = null, gxDepthRT = null, gxBloom = null, gxFinal = null, gxQuad = null, gxQuadCam = null, gxHelpers = null, gxEnvRT = null, gxPM = null, gxEnvScene = null;
let gxMaskMat = null, gxHideMat = null, gxDepthMat = null, gxW = 0, gxH = 0;
const gxLive = new Map(); // object id -> its drawing { sig, root, ch, kind, lights }
// ---- the sky: a gradient, a sun, clouds and stars, in HDR
const GX_SKY_VS = "varying vec3 vDir; void main() { vDir = position; vec4 p = projectionMatrix * modelViewMatrix * vec4(position, 1.0); gl_Position = p.xyww; }";
const GX_SKY_FS = `
uniform vec3 top, horizon, bottom, sunDir, sunColor, cloudColor; uniform float sunSize, sunGlow, clouds, stars, gain, sunBoost, seed;
varying vec3 vDir;
float h21(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float vn(vec2 p) { vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(h21(i), h21(i + vec2(1, 0)), f.x), mix(h21(i + vec2(0, 1)), h21(i + vec2(1, 1)), f.x), f.y); }
float fbm(vec2 p) { float a = 0.5, s = 0.0; for (int i = 0; i < 5; i++) { s += a * vn(p); p = p * 2.03 + 17.1; a *= 0.5; } return s; }
void main() {
  vec3 d = normalize(vDir); float h = d.y;
  vec3 col = h > 0.0 ? mix(horizon, top, pow(clamp(h, 0.0, 1.0), 0.5)) : mix(horizon, bottom, pow(clamp(-h, 0.0, 1.0), 0.35));
  float sd = max(dot(d, normalize(sunDir)), 0.0);
  float sz = max(sunSize, 0.01);
  col += sunColor * (smoothstep(1.0 - 0.00045 * sz, 1.0 - 0.0003 * sz, sd) * 26.0 * sunBoost + pow(sd, 10.0) * 0.32 * sunGlow + pow(sd, 90.0) * 0.8 * sunGlow);
  if (clouds > 0.001 && h > 0.0) {
    vec2 uv = d.xz / (h + 0.18) * 0.55 + seed;
    float n = fbm(uv * 1.3), m = fbm(uv * 3.1 + 3.0);
    float c = smoothstep(1.02 - clouds * 0.75, 1.32 - clouds * 0.6, n + m * 0.35) * smoothstep(0.0, 0.18, h);
    vec3 cc = cloudColor * (0.78 + 0.32 * m) + sunColor * 0.18 * pow(sd, 3.0);
    col = mix(col, cc, clamp(c, 0.0, 1.0) * 0.92);
  }
  if (stars > 0.001 && h > 0.0) { vec3 q = floor(d * 260.0); float s = fract(sin(dot(q, vec3(12.9898, 78.233, 37.719))) * 43758.5453);
    col += vec3(pow(max(s - 0.9965, 0.0) / 0.0035, 3.0)) * stars * 2.5 * smoothstep(0.02, 0.3, h); }
  gl_FragColor = vec4(col * gain, 1.0);
  #include <tonemapping_fragment>
  #include <encodings_fragment>
}`; // (encoded for wherever it draws: linear here, RGBE in the light map, sRGB on the start screen)
// ---- the last pass
const GX_FINAL_FS = `
#include <packing>
uniform sampler2D tScene, tDepth; uniform vec2 res; uniform float exposure, contrast, saturation, vibrance, warmth, tint, vig, grain, seed, chroma, zoom, distort, sharpen, tone, alphaOut, lift, fade;
uniform vec2 zoomC; uniform float dofOn, focus, dofRange, dofMax, cnear, cfar; uniform vec3 grade;
varying vec2 vUv;
float viewZ(vec2 uv) { return -perspectiveDepthToViewZ(unpackRGBAToDepth(texture2D(tDepth, uv)), cnear, cfar); }
float coc(vec2 uv) { float z = viewZ(uv); return dofMax * clamp((abs(z - focus) - focus * 0.04) / max(focus * dofRange, 0.01), 0.0, 1.0); }
vec4 tap(vec2 uv) { uv = clamp(uv, vec2(0.0005), vec2(0.9995));
  if (chroma > 0.0) { vec2 o = (uv - 0.5) * chroma * 0.012; vec4 c = texture2D(tScene, uv); c.r = texture2D(tScene, uv + o).r; c.b = texture2D(tScene, uv - o).b; return c; }
  return texture2D(tScene, uv); }
vec3 aces(vec3 c) {
  const mat3 I = mat3(vec3(0.59719, 0.07600, 0.02840), vec3(0.35458, 0.90834, 0.13383), vec3(0.04823, 0.01566, 0.83777));
  const mat3 O = mat3(vec3(1.60475, -0.10208, -0.00327), vec3(-0.53108, 1.10813, -0.07276), vec3(-0.07367, -0.00605, 1.07602));
  c = I * (c / 0.6); vec3 a = c * (c + 0.0245786) - 0.000090537, b = c * (0.983729 * c + 0.4329510) + 0.238081; return clamp(O * (a / b), 0.0, 1.0); }
vec3 srgb(vec3 c) { c = clamp(c, 0.0, 1.0); return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c)); }
float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233)) + seed) * 43758.5453); }
void main() {
  vec2 uv = vUv;
  if (abs(distort) > 0.001) { vec2 q = uv - 0.5; q.x *= res.x / res.y; float r2 = dot(q, q); q *= 1.0 + distort * r2 * 0.9; q.x /= res.x / res.y; uv = q / (1.0 + max(distort, 0.0) * 0.18) + 0.5; }
  vec4 c;
  if (dofOn > 0.5) {
    float c0 = coc(uv);
    if (c0 < 0.6) c = tap(uv);
    else { vec4 acc = vec4(0.0); float ws = 0.0;
      for (int i = 0; i < 48; i++) { float t = (float(i) + 0.5) / 48.0, r = sqrt(t) * c0, a = float(i) * 2.39996323;
        vec2 suv = uv + vec2(cos(a), sin(a)) * r / res; float cs = coc(suv), w = mix(0.08, 1.0, smoothstep(r * 0.6, r + 1.0, cs));
        acc += tap(suv) * w; ws += w; }
      c = acc / max(ws, 1e-4); }
  } else if (zoom > 0.001) {
    vec2 dir = (uv - zoomC); vec4 acc = vec4(0.0); float ws = 0.0;
    for (int i = 0; i < 24; i++) { float t = float(i) / 23.0, w = 1.0 - t * 0.6; acc += tap(uv - dir * t * zoom * 0.14) * w; ws += w; }
    c = acc / ws;
  } else {
    c = tap(uv);
    if (sharpen > 0.001) { vec2 px = 1.0 / res; vec4 n = (tap(uv + vec2(px.x, 0.0)) + tap(uv - vec2(px.x, 0.0)) + tap(uv + vec2(0.0, px.y)) + tap(uv - vec2(0.0, px.y))) * 0.25; c.rgb += (c.rgb - n.rgb) * sharpen * 1.6; }
  }
  float a = clamp(max(c.a, max(c.r, max(c.g, c.b))), 0.0, 1.0);
  vec3 col = alphaOut > 0.5 ? c.rgb / max(a, 1e-4) : c.rgb;
  col = max(col, 0.0) * grade;
  col *= vec3(1.0 + warmth * 0.12, 1.0 + tint * 0.08, 1.0 - warmth * 0.12);
  if (tone > 0.5 && tone < 1.5) { float lm = dot(col, vec3(0.2126, 0.7152, 0.0722)); col = max(mix(vec3(lm), col, 1.3), 0.0); }
  col = tone > 1.5 ? clamp(col * exposure, 0.0, 1.0) : aces(col * exposure);
  vec3 s = srgb(col);
  s = (s - 0.5) * contrast + 0.5;
  float l = dot(s, vec3(0.2126, 0.7152, 0.0722)), mx = max(s.r, max(s.g, s.b)), mn = min(s.r, min(s.g, s.b));
  s = mix(vec3(l), s, saturation + vibrance * (1.0 - (mx - mn)));
  s = s * (1.0 - lift * 0.5) + lift * 0.5 * 0.12 + fade * 0.1 * (1.0 - s);
  vec2 v = vUv - 0.5; v.x *= mix(1.0, res.x / res.y, 0.5); s *= mix(1.0, smoothstep(0.85, 0.2, length(v) * 1.15), vig);
  s += (hash(vUv * res) - 0.5) * grain * 0.14;
  gl_FragColor = alphaOut > 0.5 ? vec4(clamp(s, 0.0, 1.0) * a, a) : vec4(clamp(s, 0.0, 1.0), 1.0);
}`;
// ---- textures drawn here: ground, materials, effects
const gxTexCache = new Map();
function gxCanvasTex(key, size, draw, o) {
  let t = gxTexCache.get(key); if (t) return t;
  const cv = document.createElement("canvas"); cv.width = cv.height = size; draw(cv.getContext("2d"), size);
  t = new THREE.CanvasTexture(cv); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = 8; if (!(o && o.linear)) t.encoding = THREE.sRGBEncoding;
  t.gxShared = true; gxTexCache.set(key, t); return t;
}
function gxNoiseFill(c, S, seed, lo, hi, cell) { // grey speckle (multiplies the material's colour)
  const img = c.getImageData(0, 0, S, S), d = img.data, f = vxFbm(seed);
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) { const i = (y * S + x) * 4, n = lo + (hi - lo) * f(x / S * (cell || 1), y / S * (cell || 1)); d[i] = d[i] * n; d[i + 1] = d[i + 1] * n; d[i + 2] = d[i + 2] * n; }
  c.putImageData(img, 0, 0);
}
const GX_SURF = { // key -> [name, studs per repeat, draw(c, S)]
  grid: ["Baseplate", 8, (c, S) => { c.fillStyle = "#f4f4f4"; c.fillRect(0, 0, S, S); gxNoiseFill(c, S, 3, 0.93, 1.0, 4); c.fillStyle = "rgba(0,0,0,.16)";
    for (let k = 0; k <= 2; k++) { c.fillRect(k * S / 2 - 1.5, 0, 3, S); c.fillRect(0, k * S / 2 - 1.5, S, 3); } }],
  studs: ["Studs", 4, (c, S) => { c.fillStyle = "#e9e9e9"; c.fillRect(0, 0, S, S); const n = 4, w = S / n;
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) { const x = (i + 0.5) * w, y = (j + 0.5) * w, r = w * 0.3;
      const g = c.createRadialGradient(x - r * 0.3, y - r * 0.35, r * 0.1, x, y, r); g.addColorStop(0, "#ffffff"); g.addColorStop(1, "#cfcfcf");
      c.fillStyle = "rgba(0,0,0,.18)"; c.beginPath(); c.arc(x + r * 0.12, y + r * 0.16, r, 0, 7); c.fill(); c.fillStyle = g; c.beginPath(); c.arc(x, y, r, 0, 7); c.fill(); } }],
  grass: ["Grass", 10, (c, S) => { c.fillStyle = "#ffffff"; c.fillRect(0, 0, S, S); gxNoiseFill(c, S, 11, 0.72, 1.05, 6); const r = vxRand(4);
    for (let i = 0; i < 2600; i++) { const x = r() * S, y = r() * S, l = 3 + r() * 7; c.strokeStyle = `rgba(${r() < 0.5 ? "255,255,230" : "40,60,20"},${0.08 + r() * 0.12})`; c.lineWidth = 1.2; c.beginPath(); c.moveTo(x, y); c.lineTo(x + (r() - 0.5) * 3, y - l); c.stroke(); } }],
  sand: ["Sand", 12, (c, S) => { c.fillStyle = "#ffffff"; c.fillRect(0, 0, S, S); gxNoiseFill(c, S, 21, 0.84, 1.03, 5); const r = vxRand(9);
    for (let i = 0; i < 5000; i++) { c.fillStyle = `rgba(${r() < 0.5 ? "0,0,0" : "255,255,255"},${0.05 + r() * 0.08})`; c.fillRect(r() * S, r() * S, 1.5, 1.5); }
    c.strokeStyle = "rgba(0,0,0,.05)"; c.lineWidth = 6; for (let k = 0; k < 6; k++) { c.beginPath(); for (let x = 0; x <= S; x += 8) c.lineTo(x, k * S / 6 + Math.sin(x / S * Math.PI * 4 + k) * 10); c.stroke(); } }],
  tiles: ["Tiles", 8, (c, S) => { const n = 2, w = S / n; for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) { c.fillStyle = (i + j) % 2 ? "#c9c9c9" : "#ffffff"; c.fillRect(i * w, j * w, w, w); }
    gxNoiseFill(c, S, 31, 0.9, 1.02, 3); c.strokeStyle = "rgba(0,0,0,.28)"; c.lineWidth = 4; for (let k = 0; k <= n; k++) { c.beginPath(); c.moveTo(k * w, 0); c.lineTo(k * w, S); c.moveTo(0, k * w); c.lineTo(S, k * w); c.stroke(); }
    c.strokeStyle = "rgba(255,255,255,.3)"; c.lineWidth = 2; for (let k = 0; k < n; k++) { c.beginPath(); c.moveTo(k * w + 4, 4); c.lineTo(k * w + 4, S); c.stroke(); } }],
  stone: ["Stone floor", 10, (c, S) => { c.fillStyle = "#ffffff"; c.fillRect(0, 0, S, S); const r = vxRand(17), rows = 4, h = S / rows;
    for (let j = 0; j < rows; j++) { let x = -(j % 2) * S / 6; while (x < S) { const w = S / 4 + r() * S / 6, g = 0.78 + r() * 0.22; c.fillStyle = `rgb(${g * 255},${g * 255},${g * 255})`; c.fillRect(x + 3, j * h + 3, w - 6, h - 6); x += w; } }
    gxNoiseFill(c, S, 41, 0.82, 1.04, 8); }],
  planks: ["Wood planks", 8, (c, S) => { const r = vxRand(23), n = 6, h = S / n;
    for (let j = 0; j < n; j++) { const g = 0.75 + r() * 0.25; c.fillStyle = `rgb(${g * 255},${g * 238},${g * 220})`; c.fillRect(0, j * h, S, h);
      c.strokeStyle = "rgba(60,30,10,.13)"; c.lineWidth = 1.5; for (let k = 0; k < 7; k++) { const y = j * h + r() * h; c.beginPath(); c.moveTo(0, y); for (let x = 0; x <= S; x += 16) c.lineTo(x, y + Math.sin(x / 40 + k) * 2); c.stroke(); }
      c.fillStyle = "rgba(0,0,0,.35)"; c.fillRect(0, j * h, S, 3); const cut = r() * S; c.fillRect(cut, j * h, 3, h); } }],
  bricks: ["Bricks", 6, (c, S) => { c.fillStyle = "#bdbdbd"; c.fillRect(0, 0, S, S); const r = vxRand(29), rows = 8, h = S / rows, w = S / 4;
    for (let j = 0; j < rows; j++) for (let i = -1; i < 5; i++) { const g = 0.8 + r() * 0.2; c.fillStyle = `rgb(${g * 255},${g * 255},${g * 255})`; c.fillRect(i * w + (j % 2) * w / 2 + 3, j * h + 3, w - 6, h - 6); }
    gxNoiseFill(c, S, 51, 0.86, 1.03, 8); }],
  snow: ["Snow", 14, (c, S) => { c.fillStyle = "#ffffff"; c.fillRect(0, 0, S, S); gxNoiseFill(c, S, 61, 0.9, 1.02, 4); }],
  asphalt: ["Asphalt", 10, (c, S) => { c.fillStyle = "#ffffff"; c.fillRect(0, 0, S, S); gxNoiseFill(c, S, 71, 0.7, 1.0, 10); const r = vxRand(3);
    for (let i = 0; i < 7000; i++) { c.fillStyle = `rgba(255,255,255,${r() * 0.12})`; c.fillRect(r() * S, r() * S, 1.4, 1.4); } }],
  neon: ["Neon grid", 8, (c, S) => { c.fillStyle = "#ffffff"; c.fillRect(0, 0, S, S); }],
  marble: ["Marble", 10, (c, S) => { c.fillStyle = "#ffffff"; c.fillRect(0, 0, S, S); const f = vxFbm(81), img = c.getImageData(0, 0, S, S), d = img.data;
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) { const v = Math.abs(Math.sin((x / S + f(x / S, y / S) * 2.2) * Math.PI * 3)), g = 0.82 + 0.18 * Math.pow(v, 0.35), i = (y * S + x) * 4; d[i] = d[i + 1] = d[i + 2] = g * 255; }
    c.putImageData(img, 0, 0); }],
  plain: ["Plain", 8, (c, S) => { c.fillStyle = "#ffffff"; c.fillRect(0, 0, S, S); }],
};
function gxSurfTex(key) { const s = GX_SURF[key] || GX_SURF.plain; return gxCanvasTex("surf:" + key, 512, s[2]); }
function gxNeonLines() { return gxCanvasTex("surf:neonglow", 512, (c, S) => { c.fillStyle = "#000"; c.fillRect(0, 0, S, S); c.fillStyle = "#fff";
  for (let k = 0; k <= 4; k++) { c.fillRect(k * S / 4 - 2, 0, 4, S); c.fillRect(0, k * S / 4 - 2, S, 4); } }); }
function gxFxTex(key) { const t = vxTexture(key); return gxCanvasTex("vx:" + key, t.canvas.width, c => c.drawImage(t.canvas, 0, 0)); }
// ---- materials for parts
const GX_MATS = [["plastic", "Plastic"], ["smooth", "Smooth"], ["neon", "Neon"], ["metal", "Metal"], ["glass", "Glass"], ["wood", "Wood"], ["bricks", "Bricks"], ["grass", "Grass"],
  ["stone", "Stone"], ["sand", "Sand"], ["marble", "Marble"], ["snow", "Snow"], ["force", "Force field"]];
const GX_MAT_SURF = { wood: "planks", bricks: "bricks", grass: "grass", stone: "stone", sand: "sand", marble: "marble", snow: "snow" };
function gxPartMat(mat, hex, rep) {
  const col = linCol(hex);
  if (mat === "neon") { const m = new THREE.MeshBasicMaterial({ color: col.clone().multiplyScalar(5) }); m.userData.glow = true; return m; }
  if (mat === "force") { const m = new THREE.MeshBasicMaterial({ color: col.clone().multiplyScalar(1.6), transparent: true, opacity: 0.45, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }); m.userData.glow = true; m.userData.fx = true; return m; }
  if (mat === "glass") return new THREE.MeshStandardMaterial({ color: col, roughness: 0.05, metalness: 0.1, transparent: true, opacity: 0.38 });
  if (mat === "metal") return new THREE.MeshStandardMaterial({ color: col, roughness: 0.28, metalness: 0.92 });
  const surf = GX_MAT_SURF[mat];
  if (surf) { const base = gxSurfTex(surf), t = base.clone(); t.gxOwn = true; t.needsUpdate = true; t.repeat.set(rep[0], rep[1]); return new THREE.MeshStandardMaterial({ color: col, map: t, roughness: mat === "marble" ? 0.3 : 0.88 }); }
  return new THREE.MeshStandardMaterial({ color: col, roughness: mat === "smooth" ? 0.32 : 0.62, metalness: 0 });
}
function gxShapeGeo(shape) { return shape === "wedge" ? wedgeGeo() : shape === "ball" ? new THREE.SphereGeometry(0.5, 40, 24) : shape === "cylinder" ? new THREE.CylinderGeometry(0.5, 0.5, 1, 40)
  : shape === "cone" ? new THREE.ConeGeometry(0.5, 1, 40) : shape === "ring" ? new THREE.TorusGeometry(0.4, 0.1, 18, 56) : roundedBox(1, 1, 1, 0.02); }
// ---- props for building a place (each a group of simple shapes, standing on the ground at its origin)
const GX_PROPS = [["barrel", "Barrel"], ["crate", "Crate"], ["tree", "Tree"], ["pine", "Pine"], ["bush", "Bush"], ["rock", "Rock"], ["pillar", "Pillar"], ["wall", "Wall"],
  ["torch", "Torch"], ["lamp", "Street lamp"], ["chest", "Chest"], ["fence", "Fence"], ["building", "Building"], ["cloud", "Cloud"], ["coin", "Coin"], ["cactus", "Cactus"], ["platform", "Platform"], ["stairs", "Stairs"]];
const GX_PROP_COLOR = { barrel: "#8a5a32", crate: "#b98a52", tree: "#4caf3e", pine: "#2f7d46", bush: "#3f9a3a", rock: "#8b8f96", pillar: "#d8d3c8", wall: "#a8a29a", torch: "#7a4a2a",
  lamp: "#2b2e36", chest: "#8a5a32", fence: "#9a6a3a", building: "#5b6170", cloud: "#ffffff", coin: "#f2c230", cactus: "#4c9a3e", platform: "#4aa3ff", stairs: "#a3a2a5" };
function gxProp(kind, hex, glowList) {
  const g = new THREE.Group(), M = (h, o) => gxMat(h, o), dark = gxMat("#2b2b30", { rough: 0.5, metal: 0.6 });
  const add = (geo, mat, p, r, s) => { const m = gxMesh(geo, mat, p, r, s); g.add(m); return m; };
  const rnd = vxRand(kind.length * 977);
  switch (kind) {
    case "barrel": { const pts = []; for (let i = 0; i <= 12; i++) { const t = i / 12; pts.push(new THREE.Vector2(1 + Math.sin(t * Math.PI) * 0.14, t * 2.6)); }
      const wood = gxPartMat("wood", hex, [3, 1]); add(new THREE.LatheGeometry(pts, 40), wood); add(new THREE.CircleGeometry(1, 40), M(gxShade(hex, -0.25), { rough: 0.8 }), [0, 2.6, 0], [-Math.PI / 2, 0, 0]);
      for (const y of [0.45, 2.15]) add(new THREE.TorusGeometry(1.1, 0.06, 8, 40), dark, [0, y, 0], [Math.PI / 2, 0, 0]); break; }
    case "crate": { const t = gxCanvasTex("crate", 256, (c, S) => { c.fillStyle = "#ffffff"; c.fillRect(0, 0, S, S); gxNoiseFill(c, S, 91, 0.8, 1.02, 6); c.strokeStyle = "rgba(60,30,10,.55)"; c.lineWidth = 22; c.strokeRect(11, 11, S - 22, S - 22);
        c.beginPath(); c.moveTo(20, 20); c.lineTo(S - 20, S - 20); c.stroke(); c.strokeStyle = "rgba(0,0,0,.25)"; c.lineWidth = 3; for (let k = 1; k < 4; k++) { c.beginPath(); c.moveTo(0, k * S / 4); c.lineTo(S, k * S / 4); c.stroke(); } });
      add(roundedBox(2.4, 2.4, 2.4, 0.06), new THREE.MeshStandardMaterial({ color: linCol(hex), map: t, roughness: 0.85 }), [0, 1.2, 0]); break; }
    case "tree": add(new THREE.CylinderGeometry(0.42, 0.6, 5, 16), M("#6b4426", { rough: 0.9 }), [0, 2.5, 0]);
      for (const [x, y, z, r] of [[0, 6, 0, 2.6], [1.5, 5.2, 0.6, 1.8], [-1.4, 5.4, -0.5, 1.9], [0.3, 7.4, -0.4, 1.8]]) add(new THREE.IcosahedronGeometry(r, 1), M(gxShade(hex, (rnd() - 0.5) * 0.2), { rough: 0.85 }), [x, y, z]); break;
    case "pine": add(new THREE.CylinderGeometry(0.3, 0.45, 2.4, 12), M("#5a3a22", { rough: 0.9 }), [0, 1.2, 0]);
      for (let i = 0; i < 4; i++) add(new THREE.ConeGeometry(2.4 - i * 0.5, 2.6, 16), M(gxShade(hex, i * 0.04), { rough: 0.85 }), [0, 2.4 + i * 1.5, 0]); break;
    case "bush": for (const [x, y, z, r] of [[0, 0.9, 0, 1.2], [1, 0.7, 0.3, 0.9], [-0.9, 0.7, -0.2, 0.95], [0.2, 0.6, -0.9, 0.8]]) add(new THREE.IcosahedronGeometry(r, 1), M(gxShade(hex, (rnd() - 0.5) * 0.2), { rough: 0.85 }), [x, y, z]); break;
    case "rock": { const geo = new THREE.IcosahedronGeometry(1.4, 1), p = geo.attributes.position;
      for (let i = 0; i < p.count; i++) { const v = new THREE.Vector3().fromBufferAttribute(p, i), k = 0.78 + 0.4 * (Math.sin(v.x * 3.1) * Math.cos(v.z * 2.7) * 0.5 + 0.5); v.multiplyScalar(k); v.y *= 0.72; p.setXYZ(i, v.x, v.y, v.z); }
      geo.computeVertexNormals(); add(geo, new THREE.MeshStandardMaterial({ color: linCol(hex), roughness: 0.9, flatShading: true }), [0, 0.7, 0]); break; }
    case "pillar": { const st = gxPartMat("marble", hex, [1, 2]); add(new THREE.CylinderGeometry(0.75, 0.75, 7, 24), st, [0, 4, 0]); add(roundedBox(2, 0.6, 2, 0.05), st, [0, 0.3, 0]); add(roundedBox(2, 0.6, 2, 0.05), st, [0, 7.7, 0]); break; }
    case "wall": add(roundedBox(12, 6, 1.2, 0.04), gxPartMat("bricks", hex, [3, 1.5]), [0, 3, 0]); break;
    case "torch": { add(new THREE.CylinderGeometry(0.12, 0.16, 3.4, 10), M(hex, { rough: 0.9 }), [0, 1.7, 0]); add(new THREE.CylinderGeometry(0.3, 0.2, 0.4, 12), dark, [0, 3.5, 0]);
      const f = gxFxMesh("fire", "#ff8a2a", "#ffe08a", 1); f.position.y = 4.1; f.scale.setScalar(0.55); g.add(f); const l = new THREE.PointLight(0xff8a3a, 1.6, 16, 2); l.position.y = 4.2; g.add(l); if (glowList) glowList.push(l); break; }
    case "lamp": { add(new THREE.CylinderGeometry(0.16, 0.22, 8, 12), M(hex, { rough: 0.35, metal: 0.8 }), [0, 4, 0]); add(new THREE.BoxGeometry(1.6, 0.14, 0.2), M(hex, { rough: 0.35, metal: 0.8 }), [0.7, 8, 0]);
      const bulb = add(new THREE.SphereGeometry(0.32, 16, 10), new THREE.MeshBasicMaterial({ color: linCol("#fff2c4").multiplyScalar(4) }), [1.3, 7.75, 0]); bulb.userData.glow = true;
      const l = new THREE.PointLight(0xffe2a8, 2.2, 22, 2); l.position.set(1.3, 7.5, 0); g.add(l); if (glowList) glowList.push(l); break; }
    case "chest": { const wood = gxPartMat("wood", hex, [1, 1]), gold = gxMat("#e0b33a", { rough: 0.3, metal: 0.9 }); add(roundedBox(2.4, 1.4, 1.6, 0.05), wood, [0, 0.7, 0]);
      add(new THREE.CylinderGeometry(0.8, 0.8, 2.4, 24, 1, false, 0, Math.PI), wood, [0, 1.4, 0], [0, 0, Math.PI / 2]);
      for (const x of [-1.05, 1.05]) add(new THREE.BoxGeometry(0.16, 1.5, 1.66), gold, [x, 0.75, 0]); add(new THREE.BoxGeometry(0.4, 0.5, 0.12), gold, [0, 1.3, -0.82]); break; }
    case "fence": { const wood = M(hex, { rough: 0.85 }); for (const x of [-3, -1, 1, 3]) add(new THREE.BoxGeometry(0.35, 2.4, 0.35), wood, [x, 1.2, 0]); for (const y of [0.8, 1.8]) add(new THREE.BoxGeometry(7, 0.3, 0.2), wood, [0, y, 0]); break; }
    case "building": { const h = 18 + Math.floor(rnd() * 3) * 6, win = gxCanvasTex("windows", 256, (c, S) => { c.fillStyle = "#000"; c.fillRect(0, 0, S, S); const r = vxRand(5);
        for (let j = 0; j < 8; j++) for (let i = 0; i < 4; i++) { const on = r() < 0.55; c.fillStyle = on ? `rgba(255,${200 + r() * 40},${120 + r() * 60},${0.7 + r() * 0.3})` : "rgba(40,60,90,.5)"; c.fillRect(i * 64 + 12, j * 32 + 8, 40, 18); } });
      const t = win.clone(); t.gxOwn = true; t.needsUpdate = true; t.repeat.set(2, h / 8);
      add(new THREE.BoxGeometry(8, h, 8), new THREE.MeshStandardMaterial({ color: linCol(hex), roughness: 0.7, emissive: 0xffffff, emissiveIntensity: 1.6, emissiveMap: t }), [0, h / 2, 0]);
      add(new THREE.BoxGeometry(8.4, 0.5, 8.4), M(gxShade(hex, -0.3)), [0, h + 0.25, 0]); break; }
    case "cloud": for (const [x, y, z, r] of [[0, 0, 0, 2], [2, -0.3, 0.3, 1.5], [-2, -0.4, 0, 1.6], [0.8, 0.9, -0.2, 1.4], [-0.9, 0.7, 0.4, 1.3]]) add(new THREE.SphereGeometry(r, 24, 14), gxMat(hex, { rough: 1 }), [x, y + 2, z]); break;
    case "coin": { const gold = gxMat(hex, { rough: 0.25, metal: 0.95 }); add(new THREE.CylinderGeometry(0.9, 0.9, 0.18, 40), gold, [0, 1.2, 0], [Math.PI / 2, 0, 0]); add(new THREE.TorusGeometry(0.9, 0.08, 10, 40), gold, [0, 1.2, 0]); break; }
    case "cactus": { const C = M(hex, { rough: 0.7 }); add(new THREE.CylinderGeometry(0.5, 0.55, 5, 16), C, [0, 2.5, 0]); add(new THREE.SphereGeometry(0.5, 16, 10), C, [0, 5, 0]);
      for (const s of [-1, 1]) { add(new THREE.CylinderGeometry(0.3, 0.3, 1.2, 12), C, [s * 0.9, 2.2 + s * 0.4, 0], [0, 0, Math.PI / 2]); add(new THREE.CylinderGeometry(0.3, 0.3, 1.6, 12), C, [s * 1.4, 2.9 + s * 0.4, 0]); add(new THREE.SphereGeometry(0.3, 12, 8), C, [s * 1.4, 3.7 + s * 0.4, 0]); } break; }
    case "platform": add(roundedBox(8, 1.2, 8, 0.08), gxMat(hex, { rough: 0.5 }), [0, 0.6, 0]); break;
    case "stairs": { const st = gxMat(hex, { rough: 0.6 }); for (let i = 0; i < 6; i++) add(roundedBox(6, 0.8, 1.6, 0.03), st, [0, 0.4 + i * 0.8, i * 1.6]); break; }
  }
  return g;
}
// ---- effects placed in the scene: glowing shapes and sprites (they bloom: their colour is brighter than white)
const GX_FX = [["slash", "Slash"], ["slash2", "Double slash"], ["burst", "Impact"], ["ring", "Shockwave"], ["aura", "Aura"], ["orb", "Energy orb"], ["sparkles", "Sparkles"],
  ["lightning", "Lightning"], ["fire", "Fire"], ["smoke", "Smoke"], ["beam", "Beam"], ["wind", "Speed lines"], ["light", "Light"]];
function gxArcGeo(r0, r1, a0, a1, seg) { // a flat ribbon arc in the XZ plane, u along the arc (0 tail .. 1 tip), v across (0 inner .. 1 outer)
  const pos = [], uv = [], idx = [];
  for (let i = 0; i <= seg; i++) { const t = i / seg, a = a0 + (a1 - a0) * t, w = Math.sin(Math.pow(t, 0.8) * Math.PI) * 0.75 + 0.25, rr0 = r1 - (r1 - r0) * w;
    pos.push(Math.cos(a) * rr0, 0, Math.sin(a) * rr0, Math.cos(a) * r1, 0, Math.sin(a) * r1); uv.push(t, 0, t, 1); if (i < seg) { const k = i * 2; idx.push(k, k + 1, k + 2, k + 1, k + 3, k + 2); } }
  const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2)); g.setIndex(idx); g.computeVertexNormals(); return g;
}
function gxArcTex() { return gxCanvasTex("fx:arc", 512, (c, S) => { const img = c.createImageData(S, S), d = img.data, f = vxFbm(13);
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) { const u = x / S, v = 1 - y / S, edge = Math.pow(v, 2.6), along = Math.pow(u, 0.7) * (1 - Math.pow(Math.max(0, u - 0.86) / 0.14, 2)),
    streak = 0.75 + 0.5 * f(u * 3, v * 0.6 + u * 0.2), a = clamp(edge * along * streak * 1.25 + Math.pow(v, 14) * along, 0, 1), i = (y * S + x) * 4;
    d[i] = d[i + 1] = d[i + 2] = 255; d[i + 3] = a * 255; }
  c.putImageData(img, 0, 0); }, { linear: true }); }
function gxAdd(map, hex, power, o) { // an additive glowing material
  o = o || {}; const m = new THREE.MeshBasicMaterial({ map, color: linCol(hex).multiplyScalar(power * GX_FXK), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false });
  m.userData.fx = true; m.userData.glow = true; return m;
}
const GX_FXK = 1.8; // (effects shine this much brighter than their colour, so they bloom)
function gxSprite(key, hex, power, size, p, rot) { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: gxFxTex(key), color: linCol(hex).multiplyScalar(power * GX_FXK), blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, fog: false, rotation: rot || 0 }));
  s.material.userData.fx = true; s.scale.set(size, size, 1); if (p) s.position.set(...p); return s; }
function gxFxMesh(kind, c1, c2, power, lights) {
  const g = new THREE.Group(), P = power == null ? 1 : power, rnd = vxRand(kind.length * 131 + 7);
  switch (kind) {
    case "slash": case "slash2": {
      const arcs = kind === "slash2" ? [[0, 1], [0.55, 0.8]] : [[0, 1]];
      for (const [off, k] of arcs) { const m = new THREE.Mesh(gxArcGeo(3.2 * k, 4.6 * k, -0.4 + off, 2.5 + off, 64), gxAdd(gxArcTex(), c1, 2.4 * P)); m.position.y = off * 0.6; g.add(m);
        const core = new THREE.Mesh(gxArcGeo(4.35 * k, 4.6 * k, 0.1 + off, 2.45 + off, 64), gxAdd(gxArcTex(), c2, 3 * P)); core.position.y = off * 0.6 + 0.01; g.add(core); }
      g.add(gxSprite("star", c2, 2.2 * P, 2.4, [Math.cos(2.4) * 4.5, 0.05, Math.sin(2.4) * 4.5])); break; }
    case "burst": g.add(gxSprite("flare", c1, 2.2 * P, 7)); g.add(gxSprite("glow", c2, 2.5 * P, 3.2)); g.add(gxSprite("star", c2, 2 * P, 5.5, null, 0.4));
      for (let i = 0; i < 14; i++) { const a = rnd() * Math.PI * 2, r = 1.6 + rnd() * 2.4; g.add(gxSprite("spark", c1, 2.4 * P, 0.9 + rnd() * 1.2, [Math.cos(a) * r, Math.sin(a) * r, (rnd() - 0.5) * 2], -a + Math.PI / 2)); } break;
    case "ring": { const m = new THREE.Mesh(new THREE.RingGeometry(0.1, 4, 64, 1), gxAdd(gxFxTex("shock"), c1, 2 * P)); m.rotation.x = -Math.PI / 2; g.add(m);
      const m2 = new THREE.Mesh(new THREE.RingGeometry(0.1, 2.6, 64, 1), gxAdd(gxFxTex("ring"), c2, 1.6 * P)); m2.rotation.x = -Math.PI / 2; m2.position.y = 0.02; g.add(m2); break; }
    case "aura": { const t = gxCanvasTex("fx:aura", 256, (c, S) => { const img = c.createImageData(S, S), d = img.data, f = vxFbm(19);
        for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) { const u = x / S, v = 1 - y / S, n = f(u * 4, v * 1.2), streak = Math.pow(Math.max(0, Math.sin(u * Math.PI * 14 + n * 6)), 3),
          a = clamp((streak * 0.7 + n * 0.5) * Math.pow(1 - v, 1.4) * sstep(0, 0.12, v + 0.05), 0, 1), i = (y * S + x) * 4; d[i] = d[i + 1] = d[i + 2] = 255; d[i + 3] = a * 255; }
        c.putImageData(img, 0, 0); }, { linear: true });
      for (const [r, h, k] of [[2.1, 6.5, 1], [1.7, 5.4, 0.7]]) { const m = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.75, r, h, 40, 1, true), gxAdd(t, k === 1 ? c1 : c2, 1.6 * P * k)); m.position.y = h / 2 - 0.2; g.add(m); }
      g.add(gxSprite("glow", c1, 0.9 * P, 7, [0, 3, 0])); break; }
    case "orb": { const core = new THREE.Mesh(new THREE.SphereGeometry(0.7, 32, 20), new THREE.MeshBasicMaterial({ color: linCol(c2).multiplyScalar(4 * P) })); core.material.userData.glow = true; g.add(core);
      g.add(gxSprite("glow", c1, 2 * P, 5)); g.add(gxSprite("ring", c1, 1.2 * P, 3.4)); for (let i = 0; i < 8; i++) { const a = rnd() * 6.28, r = 1.4 + rnd(); g.add(gxSprite("dot", c1, 2 * P, 0.3 + rnd() * 0.3, [Math.cos(a) * r, Math.sin(a) * r, (rnd() - 0.5)])); }
      const l = new THREE.PointLight(linCol(c1).getHex(), 2.5 * P, 18, 2); g.add(l); if (lights) lights.push(l); break; }
    case "sparkles": for (let i = 0; i < 26; i++) g.add(gxSprite(rnd() < 0.75 ? "star" : "dot", rnd() < 0.5 ? c1 : c2, 2 * P, rnd() < 0.75 ? 0.4 + rnd() * 1.1 : 0.15 + rnd() * 0.2, [(rnd() - 0.5) * 8, rnd() * 6, (rnd() - 0.5) * 4], rnd() * 1.5)); break;
    case "lightning": { const mk = (seed, width, hex, k) => { const r = vxRand(seed), pts = []; let x = 0, z = 0;
        for (let i = 0; i <= 14; i++) { pts.push(new THREE.Vector3(x, 8 - i * 8 / 14, z)); x += (r() - 0.5) * 1.6; z += (r() - 0.5) * 1.2; }
        const m = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts, false, "catmullrom", 0.1), 80, width, 6), new THREE.MeshBasicMaterial({ color: linCol(hex).multiplyScalar(k * P) }));
        m.material.userData.glow = true; return m; };
      g.add(mk(5, 0.07, c2, 5)); g.add(mk(5, 0.2, c1, 1.6)); const b = mk(9, 0.05, c2, 4); b.scale.setScalar(0.55); b.position.set(0.6, 3, 0); g.add(b);
      g.add(gxSprite("glow", c1, 1.4 * P, 5, [0, 0.2, 0])); const l = new THREE.PointLight(linCol(c1).getHex(), 2 * P, 20, 2); l.position.y = 3; g.add(l); if (lights) lights.push(l); break; }
    case "fire": { const t = vxTexture("fire"), base = gxCanvasTex("vx:fire", t.canvas.width, c => c.drawImage(t.canvas, 0, 0));
      for (let i = 0; i < 6; i++) { const tx = base.clone(); tx.gxOwn = true; tx.needsUpdate = true; tx.repeat.set(0.25, 0.25); const k = (i * 5) % 16; tx.offset.set((k % 4) * 0.25, 0.75 - Math.floor(k / 4) * 0.25);
        const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tx, color: linCol(i < 2 ? c2 : c1).multiplyScalar(2.2 * P), blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, fog: false }));
        s.material.userData.fx = true; const sz = 2.2 + rnd() * 1.6; s.scale.set(sz, sz * 1.25, 1); s.position.set((rnd() - 0.5) * 0.9, sz * 0.45, (rnd() - 0.5) * 0.6); g.add(s); }
      g.add(gxSprite("glow", c1, 0.8 * P, 4, [0, 1, 0])); const l = new THREE.PointLight(linCol(c1).getHex(), 1.8 * P, 16, 2); l.position.y = 1.5; g.add(l); if (lights) lights.push(l); break; }
    case "smoke": for (let i = 0; i < 9; i++) { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: gxFxTex("smoke"), color: linCol(rnd() < 0.5 ? c1 : c2), transparent: true, depthWrite: false, opacity: 0.55 + rnd() * 0.3, rotation: rnd() * 6, fog: false }));
      s.material.userData.fx = true; const sz = 2.5 + rnd() * 3; s.scale.set(sz, sz, 1); s.position.set((rnd() - 0.5) * 5, 0.8 + rnd() * 2, (rnd() - 0.5) * 3); g.add(s); } break;
    case "beam": { const a = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 20, 24, 1, true), new THREE.MeshBasicMaterial({ color: linCol(c2).multiplyScalar(4 * P) })); a.material.userData.glow = true;
      const b = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 20, 32, 1, true), gxAdd(gxFxTex("beam"), c1, 1.4 * P)); for (const m of [a, b]) { m.rotation.z = Math.PI / 2; m.position.x = 10; g.add(m); }
      g.add(gxSprite("flare", c1, 2 * P, 5)); break; }
    case "wind": for (let i = 0; i < 14; i++) { // streaks along X (the way something rushes), in a loose bundle
      const m = new THREE.Mesh(new THREE.PlaneGeometry(6 + rnd() * 7, 0.18 + rnd() * 0.3), gxAdd(gxFxTex("wind"), rnd() < 0.5 ? c1 : c2, 1.6 * P));
      m.position.set((rnd() - 0.5) * 4, rnd() * 6, (rnd() - 0.5) * 3); m.rotation.x = (rnd() - 0.5) * 0.6; g.add(m); } break;
    case "light": { const l = new THREE.PointLight(linCol(c1).getHex(), 3 * P, 30, 2); g.add(l); if (lights) lights.push(l); const s = gxSprite("glow", c1, 0.6 * P, 1.6); s.userData.helperOnly = true; g.add(s); break; }
  }
  g.traverse(n => { if (n.isMesh || n.isSprite) { n.castShadow = false; n.receiveShadow = false; } });
  return g;
}
// ---- the scene
function gxStartScene() {
  gxGL = document.createElement("canvas");
  try { gxR = new THREE.WebGLRenderer({ canvas: gxGL, antialias: true, alpha: true, premultipliedAlpha: true, preserveDrawingBuffer: false, powerPreference: "high-performance" }); }
  catch (e) { gxR = null; return false; }
  gxR.outputEncoding = THREE.LinearEncoding; gxR.toneMapping = THREE.NoToneMapping; gxR.physicallyCorrectLights = false;
  gxR.shadowMap.enabled = true; gxR.shadowMap.type = THREE.PCFSoftShadowMap; gxR.setPixelRatio(1);
  gxScene = new THREE.Scene(); gxWorld = new THREE.Group(); gxScene.add(gxWorld);
  gxCam = new THREE.PerspectiveCamera(40, 16 / 9, 0.1, 3000);
  const skyMat = new THREE.ShaderMaterial({ vertexShader: GX_SKY_VS, fragmentShader: GX_SKY_FS, side: THREE.BackSide, depthWrite: false, fog: false,
    uniforms: { top: { value: new THREE.Color() }, horizon: { value: new THREE.Color() }, bottom: { value: new THREE.Color() }, sunDir: { value: new THREE.Vector3(0, 1, 0) }, sunColor: { value: new THREE.Color() },
      cloudColor: { value: new THREE.Color(1, 1, 1) }, sunSize: { value: 1 }, sunGlow: { value: 1 }, clouds: { value: 0.4 }, stars: { value: 0 }, gain: { value: 1 }, sunBoost: { value: 1 }, seed: { value: 0 } } });
  gxSky = new THREE.Mesh(new THREE.SphereGeometry(1500, 48, 24), skyMat); gxSky.renderOrder = -10; gxSky.frustumCulled = false; gxScene.add(gxSky);
  gxGround = new THREE.Mesh(new THREE.PlaneGeometry(2400, 2400), new THREE.MeshStandardMaterial({ color: 0x888888, roughness: 0.9 })); gxGround.rotation.x = -Math.PI / 2; gxGround.receiveShadow = true; gxScene.add(gxGround);
  { // the studio backdrop: a floor that curves up into a wall
    const sh = new THREE.Shape(); sh.moveTo(-60, 0); sh.lineTo(60, 0); sh.lineTo(60, 1); sh.lineTo(-60, 1);
    const prof = []; for (let i = 0; i <= 24; i++) { const a = i / 24 * Math.PI / 2; prof.push([Math.sin(a) * 14, 14 - Math.cos(a) * 14]); }
    const pos = [], idx = [], N = prof.length + 2, pts = [[-40, 0]].concat(prof.map(([z, y]) => [z, y])).concat([[14, 60]]);
    for (let i = 0; i < pts.length; i++) for (const x of [-70, 70]) pos.push(x, pts[i][1], pts[i][0] + 12);
    for (let i = 0; i < pts.length - 1; i++) { const k = i * 2; idx.push(k, k + 2, k + 1, k + 1, k + 2, k + 3); }
    const geo = new THREE.BufferGeometry(); geo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3)); geo.setIndex(idx); geo.computeVertexNormals();
    gxCyc = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color: 0x888888, roughness: 0.8, side: THREE.DoubleSide })); gxCyc.receiveShadow = true; gxCyc.visible = false; gxScene.add(gxCyc); void N;
  }
  gxSun = new THREE.DirectionalLight(0xffffff, 2); gxSun.castShadow = true; gxSun.shadow.mapSize.set(2048, 2048); gxSun.shadow.bias = -0.0004; gxSun.shadow.normalBias = 0.03; gxSun.shadow.radius = 3;
  gxScene.add(gxSun); gxScene.add(gxSun.target);
  gxRim = new THREE.DirectionalLight(0xffffff, 0); gxScene.add(gxRim); gxScene.add(gxRim.target);
  gxHemi = new THREE.HemisphereLight(0xffffff, 0x444444, 0); gxScene.add(gxHemi);
  gxHelpers = new THREE.Scene();
  gxMaskMat = new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide, fog: false });
  gxHideMat = new THREE.MeshBasicMaterial({ colorWrite: false, side: THREE.DoubleSide });
  gxDepthMat = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking });
  gxPM = new THREE.PMREMGenerator(gxR);
  gxEnvScene = new THREE.Scene(); { const s = new THREE.Mesh(gxSky.geometry, skyMat.clone()); s.material.uniforms = THREE.UniformsUtils.clone(skyMat.uniforms); gxEnvScene.add(s); gxEnvScene.userData.sky = s;
    const disc = new THREE.Mesh(new THREE.CircleGeometry(1400, 32), new THREE.MeshBasicMaterial({ color: 0x555555 })); disc.rotation.x = -Math.PI / 2; disc.position.y = -2; gxEnvScene.add(disc); gxEnvScene.userData.disc = disc; }
  gxQuadCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  gxFinal = new THREE.ShaderMaterial({ vertexShader: "varying vec2 vUv; void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }", fragmentShader: GX_FINAL_FS, depthTest: false, depthWrite: false,
    uniforms: { tScene: { value: null }, tDepth: { value: null }, res: { value: new THREE.Vector2(1, 1) }, exposure: { value: 1 }, contrast: { value: 1 }, saturation: { value: 1 }, vibrance: { value: 0 },
      warmth: { value: 0 }, tint: { value: 0 }, vig: { value: 0 }, grain: { value: 0 }, seed: { value: 0 }, chroma: { value: 0 }, zoom: { value: 0 }, zoomC: { value: new THREE.Vector2(0.5, 0.5) }, distort: { value: 0 },
      sharpen: { value: 0 }, tone: { value: 0 }, alphaOut: { value: 0 }, lift: { value: 0 }, fade: { value: 0 }, grade: { value: new THREE.Vector3(1, 1, 1) },
      dofOn: { value: 0 }, focus: { value: 10 }, dofRange: { value: 0.6 }, dofMax: { value: 10 }, cnear: { value: 0.1 }, cfar: { value: 3000 } } });
  gxQuad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), gxFinal); gxQuad.frustumCulled = false;
  gxQuad.userData.scene = new THREE.Scene(); gxQuad.userData.scene.add(gxQuad);
  return true;
}
function gxSize(w, h) { if (gxGL.width !== w || gxGL.height !== h) gxR.setSize(w, h, false); }
function gxTargets(w, h) { // the HDR scene target (multisampled where the browser can), the depth target and the bloom at this size
  if (gxRT && gxW === w && gxH === h) return;
  if (gxRT) gxRT.dispose(); if (gxDepthRT) gxDepthRT.dispose();
  const o = { type: THREE.HalfFloatType, format: THREE.RGBAFormat, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, depthBuffer: true };
  if (gxR.capabilities.isWebGL2 && THREE.WebGLMultisampleRenderTarget && w * h <= 2600000) { gxRT = new THREE.WebGLMultisampleRenderTarget(w, h, o); gxRT.samples = 4; }
  else gxRT = new THREE.WebGLRenderTarget(w, h, o);
  gxDepthRT = new THREE.WebGLRenderTarget(Math.max(1, Math.round(w / 2)), Math.max(1, Math.round(h / 2)), { minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter });
  if (THREE.UnrealBloomPass) { if (!gxBloom) { gxBloom = new THREE.UnrealBloomPass(new THREE.Vector2(w, h), 0.8, 0.5, 0.9);
      const m = gxBloom.materialCopy; if (m) { m.blending = THREE.CustomBlending; m.blendEquation = THREE.AddEquation; m.blendSrc = THREE.OneFactor; m.blendDst = THREE.OneFactor; m.blendSrcAlpha = THREE.ZeroFactor; m.blendDstAlpha = THREE.OneFactor; } } // (glow adds light, never opacity: a cut-out stays see-through)
    gxBloom.setSize(w, h); }
  gxW = w; gxH = h;
}
// ---- applying the project's world, light and look to the scene
const GX_SKIES = { // the time-of-day looks (a light preset sets these with the sun)
  day: { top: "#3f86e0", horizon: "#bfe0ff", bottom: "#7d8a96", sun: "#fff3dc", cloud: "#ffffff" },
  golden: { top: "#4e6fb8", horizon: "#ffc78a", bottom: "#6d5a52", sun: "#ffb96b", cloud: "#ffe6cc" },
  sunset: { top: "#2b2f6e", horizon: "#ff7a4a", bottom: "#4a3040", sun: "#ff8a4a", cloud: "#ffb08a" },
  night: { top: "#050914", horizon: "#1b2a4a", bottom: "#0a0e18", sun: "#a8c4ff", cloud: "#3a4a6a" },
  studio: { top: "#2a2e38", horizon: "#3a3f4c", bottom: "#202329", sun: "#ffffff", cloud: "#ffffff" },
  purple: { top: "#1a0b3a", horizon: "#7a3cff", bottom: "#140a26", sun: "#ff9af0", cloud: "#b88cff" },
  overcast: { top: "#8e9aa8", horizon: "#d6dde4", bottom: "#7c838a", sun: "#ffffff", cloud: "#eef2f6" },
  toxic: { top: "#0a1a10", horizon: "#4dff8a", bottom: "#0a140c", sun: "#c8ff6a", cloud: "#7aff9a" },
  blood: { top: "#1a0406", horizon: "#ff3a2a", bottom: "#140406", sun: "#ff6a4a", cloud: "#ff8a6a" },
};
const gxV3 = new THREE.Vector3();
function gxSunDir(az, el) { const a = az * DEG, e = el * DEG; return new THREE.Vector3(Math.cos(e) * Math.sin(a), Math.sin(e), -Math.cos(e) * Math.cos(a)); }
function gxApplyLook(p, o) { // p: the project. o.transparent: no sky or ground (a cut-out)
  o = o || {}; const W = p.world, L = p.light, sky = gxSky.material.uniforms;
  sky.top.value.copy(linCol(W.sky.top)); sky.horizon.value.copy(linCol(W.sky.horizon)); sky.bottom.value.copy(linCol(W.sky.bottom)); sky.cloudColor.value.copy(linCol(W.sky.cloud));
  sky.sunColor.value.copy(linCol(L.sunColor)); sky.clouds.value = W.sky.clouds; sky.stars.value = W.sky.stars; sky.sunSize.value = W.sky.sunSize; sky.sunGlow.value = W.sky.sunSize > 0 ? 1 : 0.3; sky.gain.value = 1; sky.seed.value = W.sky.seed || 0;
  const dir = gxSunDir(L.sunAz, L.sunEl); sky.sunDir.value.copy(dir); sky.sunBoost.value = W.sky.sunSize > 0 ? 1 : 0;
  gxSky.visible = !o.transparent;
  if (W.ground.kind === "studio") { const b = linCol(W.ground.color); sky.top.value.copy(b).multiplyScalar(0.7); sky.horizon.value.copy(b); sky.bottom.value.copy(b).multiplyScalar(0.6); sky.clouds.value = 0; sky.stars.value = 0; sky.sunBoost.value = 0; sky.sunGlow.value = 0; }
  // ground
  const gk = W.ground.kind, gm = gxGround.material, studio = gk === "studio";
  gxGround.visible = !o.transparent && gk !== "none" && !studio; gxCyc.visible = !o.transparent && studio;
  if (gxGround.visible) {
    const s = GX_SURF[gk] || GX_SURF.plain, base = gxSurfTex(gk === "neon" ? "plain" : gk);
    if (gm.map !== base) gm.map = base;
    base.repeat.set(2400 / s[1], 2400 / s[1]); gm.color.copy(linCol(W.ground.color)); gm.roughness = gk === "tiles" || gk === "marble" ? 0.35 : gk === "neon" ? 0.25 : gk === "snow" ? 0.7 : 0.9;
    gm.metalness = gk === "neon" ? 0.4 : 0;
    if (gk === "neon") { const em = gxNeonLines(); em.repeat.set(2400 / 8, 2400 / 8); gm.emissiveMap = em; gm.emissive.copy(linCol(W.ground.color2 || "#ff2bd6")); gm.emissiveIntensity = 7; }
    else { gm.emissiveMap = null; gm.emissive.setRGB(0, 0, 0); gm.emissiveIntensity = 0; }
    const mk = (gm.map ? 1 : 0) + "|" + (gm.emissiveMap ? 1 : 0); if (gm.userData.mk !== mk) { gm.userData.mk = mk; gm.needsUpdate = true; }
  }
  if (studio) gxCyc.material.color.copy(linCol(W.ground.color));
  const fogCol = linCol(studio ? W.ground.color : W.sky.horizon);
  gxScene.fog = W.fog > 0.001 && !o.transparent ? new THREE.Fog(fogCol, 30 + (1 - W.fog) * 380, 120 + (1 - W.fog) * 1400) : null;
  // light
  gxSun.color.copy(linCol(L.sunColor)); gxSun.intensity = L.sun; gxSun.castShadow = L.shadows > 0.01;
  gxSun.shadow.radius = 1 + (1 - L.shadows) * 6;
  gxRim.visible = L.rim.on; gxRim.color.copy(linCol(L.rim.color)); gxRim.intensity = L.rim.on ? L.rim.power : 0;
  gxHemi.color.copy(linCol(W.sky.top)); gxHemi.groundColor.copy(linCol(studio ? W.ground.color : W.ground.color)); gxHemi.intensity = L.fill * 0.6;
  gxEnvDirty = true;
}
let gxEnvDirty = true, gxEnvKey = "";
function gxUpdateEnv(p) { // the sky, as light and reflections (rebuilt when the sky changes)
  const key = JSON.stringify([p.world.sky, p.light.sunColor, p.light.sunAz, p.light.sunEl, p.light.sky, p.world.ground.color, p.world.ground.kind]);
  if (!gxEnvDirty && key === gxEnvKey) return; gxEnvDirty = false; gxEnvKey = key;
  const s = gxEnvScene.userData.sky, u = s.material.uniforms, src = gxSky.material.uniforms;
  for (const k of Object.keys(src)) { const v = src[k].value; if (v && v.copy) u[k].value.copy(v); else u[k].value = v; }
  u.gain.value = p.light.sky; u.sunBoost.value = 0.06; u.clouds.value = 0; u.stars.value = 0;
  if (p.world.ground.kind === "studio") { u.top.value.copy(linCol(p.world.ground.color)).multiplyScalar(1.3); u.horizon.value.copy(linCol(p.world.ground.color)); }
  gxEnvScene.userData.disc.material.color.copy(linCol(p.world.ground.color)).lerp(new THREE.Color(0.2, 0.2, 0.2), 0.85).multiplyScalar(0.55 * p.light.sky); // (greyed: metal shouldn't turn the ground's colour)
  if (gxEnvRT) gxEnvRT.dispose();
  gxEnvRT = gxPM.fromScene(gxEnvScene, 0.04, 0.1, 4000); gxScene.environment = gxEnvRT.texture;
}
function gxFitShadow(p) { // the sun's shadow covers what's in the picture
  const box = new THREE.Box3(); let any = false;
  const aim = new THREE.Vector3(...p.cam.t), reach = Math.max(40, gxCam.position.distanceTo(aim) * 2.2);
  for (const L of gxLive.values()) if (L.root.visible && !L.fxOnly && L.root.position.distanceTo(aim) < reach) { box.expandByObject(L.root); any = true; }
  if (!any) box.set(new THREE.Vector3(-8, 0, -8), new THREE.Vector3(8, 8, 8));
  const c = box.getCenter(new THREE.Vector3()), r = clamp(box.getSize(new THREE.Vector3()).length() * 0.55, 8, 140);
  const dir = gxSunDir(p.light.sunAz, p.light.sunEl);
  gxSun.target.position.copy(c); gxSun.position.copy(c).addScaledVector(dir, r * 2 + 30);
  const sc = gxSun.shadow.camera; sc.left = -r; sc.right = r; sc.top = r; sc.bottom = -r; sc.near = 1; sc.far = r * 4 + 60; sc.updateProjectionMatrix();
  // the rim light shines from behind what the camera looks at, toward the camera, a little from the side and above
  const fwd = new THREE.Vector3(); gxCam.getWorldDirection(fwd); const side = new THREE.Vector3().crossVectors(fwd, new THREE.Vector3(0, 1, 0)).normalize();
  const k = p.light.rim.side; gxRim.target.position.copy(c); gxRim.position.copy(c).addScaledVector(fwd, 30).addScaledVector(side, 22 * k).add(new THREE.Vector3(0, 14, 0));
}
function gxApplyCam(p) {
  const C = p.cam; gxCam.fov = C.fov; gxCam.position.set(...C.p); gxCam.up.set(0, 1, 0); gxCam.lookAt(new THREE.Vector3(...C.t));
  if (C.roll) gxCam.rotateZ(-C.roll * DEG); gxCam.updateProjectionMatrix(); gxCam.updateMatrixWorld();
}
// ---- one render: the scene at w x h into the GL canvas, then copied into ctx
function gxRenderScene(p, w, h, o) {
  o = o || {};
  gxSize(w, h); gxTargets(w, h);
  gxCam.aspect = w / h; gxCam.updateProjectionMatrix(); gxSky.position.copy(gxCam.position);
  gxApplyLook(p, o); gxUpdateEnv(p); gxFitShadow(p);
  for (const L of gxLive.values()) if (L.helper) L.helper.visible = !o.export && !o.clean;
  const shadowSize = o.export ? 4096 : 2048; if (gxSun.shadow.mapSize.x !== shadowSize) { gxSun.shadow.mapSize.set(shadowSize, shadowSize); if (gxSun.shadow.map) { gxSun.shadow.map.dispose(); gxSun.shadow.map = null; } }
  // 1. the scene, HDR
  gxR.setRenderTarget(gxRT); gxR.setClearColor(0x000000, 0); gxR.clear(); gxR.render(gxScene, gxCam);
  // 2. depth, for depth of field
  const P = p.post, dof = P.dof.on && !o.noDof;
  if (dof) {
    const keepFog = gxScene.fog, keepEnv = gxScene.environment; gxScene.fog = null; const hidden = [];
    gxScene.traverse(n => { if ((n.isSprite || (n.material && n.material.userData && n.material.userData.fx) || n === gxSky) && n.visible) { n.visible = false; hidden.push(n); } });
    gxScene.overrideMaterial = gxDepthMat; gxR.setRenderTarget(gxDepthRT); gxR.setClearColor(0x000000, 1); gxR.clear(); gxR.render(gxScene, gxCam);
    gxScene.overrideMaterial = null; gxScene.fog = keepFog; gxScene.environment = keepEnv; for (const n of hidden) n.visible = true;
  }
  // 3. bloom (added on top of the scene target)
  if (gxBloom && P.bloom.on && P.bloom.power > 0.001) {
    gxBloom.strength = P.bloom.power; gxBloom.radius = P.bloom.size; gxBloom.threshold = P.bloom.threshold;
    gxBloom.render(gxR, null, gxRT, 0, false);
  }
  // 4. the camera and the grade, into the canvas
  const U = gxFinal.uniforms, focusObj = dof ? gxFocusPoint(p) : null;
  U.tScene.value = gxRT.texture; U.tDepth.value = gxDepthRT.texture; U.res.value.set(w, h);
  U.exposure.value = P.exposure; U.contrast.value = P.contrast; U.saturation.value = P.saturation; U.vibrance.value = P.vibrance; U.warmth.value = P.warmth; U.tint.value = P.tint;
  U.vig.value = P.vignette; U.grain.value = P.grain; U.seed.value = 1.234; U.chroma.value = P.chroma; U.zoom.value = P.zoom.power; U.zoomC.value.set(P.zoom.x, 1 - P.zoom.y);
  U.distort.value = P.distort; U.sharpen.value = P.sharpen; U.tone.value = { filmic: 0, vivid: 1, flat: 2 }[P.tone] || 0; U.alphaOut.value = o.transparent ? 1 : 0; U.lift.value = P.lift; U.fade.value = P.fade;
  const gr = linCol(P.gradeColor || "#ffffff"); U.grade.value.set(gr.r, gr.g, gr.b);
  U.dofOn.value = dof ? 1 : 0;
  if (dof) { U.focus.value = focusObj; U.dofRange.value = 1.15 - P.dof.blur * 0.85; U.dofMax.value = (4 + P.dof.blur * 18) * h / 1080; U.cnear.value = gxCam.near; U.cfar.value = gxCam.far; }
  gxR.setRenderTarget(null); gxR.setClearColor(0x000000, 0); gxR.clear(); gxR.render(gxQuad.userData.scene, gxQuadCam);
}
function gxFocusPoint(p) { // how far away the sharp plane is: the focused object, or what the camera looks at
  const id = p.post.dof.target; const L = id && gxLive.get(id);
  let pt = new THREE.Vector3(...p.cam.t);
  if (L) { const b = new THREE.Box3().setFromObject(L.root); if (!b.isEmpty()) { b.getCenter(pt); if (L.kind === "char") pt.y = b.max.y - 1.2 * (L.root.scale.y || 1); } }
  return Math.max(0.5, pt.applyMatrix4(gxCam.matrixWorldInverse).z * -1);
}
function gxMaskOf(L, w, h) { // a white silhouette of one object as the camera sees it (other things in front hide it) -> a 2D canvas
  const swaps = [];
  gxScene.traverse(n => {
    if (!n.isMesh && !n.isSprite) return;
    let mine = false; for (let q = n; q; q = q.parent) if (q === L.root) { mine = true; break; }
    const fx = n.material && n.material.userData && n.material.userData.fx;
    swaps.push([n, n.material, n.visible]);
    if (n === gxSky || n.isSprite || (fx && !mine) || (mine && n.userData.helperOnly)) { n.visible = false; return; }
    n.material = mine ? gxMaskMat : gxHideMat;
  });
  const keepFog = gxScene.fog, keepEnv = gxScene.environment; gxScene.fog = null; gxScene.environment = null;
  const keepShadow = gxR.shadowMap.enabled; gxR.shadowMap.enabled = false; gxR.shadowMap.autoUpdate = false;
  gxR.setRenderTarget(null); gxR.setClearColor(0x000000, 0); gxR.clear(); gxR.render(gxScene, gxCam);
  gxR.shadowMap.enabled = keepShadow; gxR.shadowMap.autoUpdate = true;
  for (const [n, m, v] of swaps) { n.material = m; n.visible = v; } gxScene.fog = keepFog; gxScene.environment = keepEnv;
  const cv = document.createElement("canvas"); cv.width = w; cv.height = h; cv.getContext("2d").drawImage(gxGL, 0, 0); return cv;
}
function gxStrokeMask(mask, color, width, glow) { // a ring of colour around a silhouette (outline), or a soft halo (glow)
  const w = mask.width, h = mask.height, cv = document.createElement("canvas"); cv.width = w; cv.height = h; const c = cv.getContext("2d");
  if (glow) { c.filter = `blur(${Math.max(1, width)}px)`; c.drawImage(mask, 0, 0); c.drawImage(mask, 0, 0); c.filter = "none"; }
  else { const n = width > 10 ? 32 : width > 4 ? 20 : 12; for (const k of width > 6 ? [1, 0.6, 0.3] : [1, 0.5]) for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; c.drawImage(mask, Math.cos(a) * width * k, Math.sin(a) * width * k); } c.drawImage(mask, 0, 0); }
  c.globalCompositeOperation = "source-in"; c.fillStyle = color; c.fillRect(0, 0, w, h);
  c.globalCompositeOperation = "destination-out"; c.drawImage(mask, 0, 0);
  return cv;
}
// ---- the whole picture: the scene, outlines and glows, then the design layers
function gxCompose(p, ctx, w, h, o) {
  o = o || {};
  if (o.transparent) { // a cut-out: only the characters and effects (the place, its props and parts stay out)
    const hid = []; for (const x of p.objs) { const L = gxLive.get(x.id); if (L && L.root.visible && x.type !== "char" && x.type !== "fx") { L.root.visible = false; hid.push(L); } }
    try { return gxCompose(p, ctx, w, h, Object.assign({}, o, { transparent: false, cutout: true })); } finally { for (const L of hid) L.root.visible = true; }
  }
  if (o.cutout) o.transparent = true;
  const fxObjs = p.objs.filter(x => x.type === "char" && !x.hide && x.fx && (x.fx.outline.on || x.fx.glow.on) && gxLive.get(x.id));
  const masks = [];
  if (fxObjs.length && !o.noFx) { gxSize(w, h); gxSky.position.copy(gxCam.position); gxCam.aspect = w / h; gxCam.updateProjectionMatrix(); gxApplyLook(p, o); for (const x of fxObjs) masks.push([x, gxMaskOf(gxLive.get(x.id), w, h)]); }
  gxRenderScene(p, w, h, o);
  ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalCompositeOperation = "source-over"; ctx.globalAlpha = 1; ctx.clearRect(0, 0, w, h);
  ctx.drawImage(gxGL, 0, 0, w, h);
  for (const [x, m] of masks) {
    const k = h / 1080;
    if (x.fx.glow.on) { const g = gxStrokeMask(m, x.fx.glow.color, x.fx.glow.size * k, true); ctx.globalCompositeOperation = "lighter"; ctx.globalAlpha = clamp(x.fx.glow.power, 0, 1);
      ctx.drawImage(g, 0, 0); if (x.fx.glow.power > 1) { ctx.globalAlpha = clamp(x.fx.glow.power - 1, 0, 1); ctx.drawImage(g, 0, 0); } ctx.globalAlpha = 1; ctx.globalCompositeOperation = "source-over"; }
    if (x.fx.outline.on) ctx.drawImage(gxStrokeMask(m, x.fx.outline.color, Math.max(1, x.fx.outline.width * k), false), 0, 0);
  }
  ctx.restore();
  if (o.layers !== false) gxDrawLayers(ctx, p, w, h, o);
}
// ---- building each object's drawing
function gxSig(o) {
  if (o.type === "char") return "c" + JSON.stringify(o.look) + (o.look.acc || []).map(a => a.kind === "import" ? (gxImports.has(a.model) ? 1 : 0) : a.kind === "model" ? (models.get(a.model) || {}).updatedAt : "").join() +
    (o.look.items || []).map(a => a.kind === "model" ? (models.get(a.model) || {}).updatedAt : a.kind === "import" ? (gxImports.has(a.model) ? 1 : 0) : "").join() + [o.look.faceImg, o.look.shirt.img, o.look.pants.img, o.look.tshirt].map(a => a ? ((gxImgCache.get(a) || {}).ok ? 1 : 0) : "").join();
  if (o.type === "part") return "p" + [o.shape, o.mat, o.color, o.mat in GX_MAT_SURF ? o.s.map(v => Math.round(v)).join() : ""].join("|");
  if (o.type === "prop") return "r" + o.kind + o.color;
  if (o.type === "fx") return "f" + [o.kind, o.c1, o.c2, o.power].join("|");
  if (o.type === "model") return "m" + o.model + ((models.get(o.model) || {}).updatedAt || "");
  if (o.type === "import") return "i" + o.asset + (gxImports.has(o.asset) ? 1 : 0);
  return "?";
}
function gxBuildObj(o) {
  const root = new THREE.Group(), L = { root, kind: o.type, lights: [] };
  if (o.type === "char") { const ch = gxBuildChar(o.look); ch.root.position.y = 3; root.add(ch.root); L.ch = ch;
    const imgs = [o.look.faceImg, o.look.shirt.img, o.look.pants.img, o.look.tshirt].filter(Boolean); if (imgs.length) gxWhenImages(imgs, () => { if (gxFaceCache.has("u:" + o.look.faceImg)) gxFaceCache.delete("u:" + o.look.faceImg); gxSyncSoon(); }); }
  else if (o.type === "part") { const rep = o.mat in GX_MAT_SURF ? [Math.max(1, Math.round(Math.max(o.s[0], o.s[2]) / 6)), Math.max(1, Math.round(o.s[1] / 6))] : [1, 1];
    const m = new THREE.Mesh(gxShapeGeo(o.shape), gxPartMat(o.mat, o.color, rep)); m.castShadow = !(m.material.userData.fx); m.receiveShadow = true; root.add(m); L.mesh = m; }
  else if (o.type === "prop") root.add(gxProp(o.kind, o.color, L.lights));
  else if (o.type === "fx") { root.add(gxFxMesh(o.kind, o.c1, o.c2, o.power, L.lights)); L.fxOnly = true; L.helper = root.children[0].children.find(n => n.userData.helperOnly) || null; }
  else if (o.type === "model") { const m = models.get(o.model); if (m) root.add(gxModelGroup(m)); }
  else if (o.type === "import") { const im = gxImports.get(o.asset); if (im) root.add(im.clone(true)); else gxLoadImport(o.asset, o.fmt); }
  root.traverse(n => { n.userData.objId = o.id; });
  return L;
}
function gxPlace(L, o) {
  L.root.visible = !o.hide;
  L.root.position.set(o.p[0], o.p[1], o.p[2]);
  if (o.type === "char") { L.root.rotation.set(0, (o.yaw || 0) * DEG, 0); L.root.scale.setScalar(o.s || 1); gxPoseChar(L.ch, o.pose, o.tp); }
  else { L.root.rotation.set(o.r[0] * DEG, o.r[1] * DEG, o.r[2] * DEG, "YXZ"); const s = Array.isArray(o.s) ? o.s : [o.s, o.s, o.s]; L.root.scale.set(s[0], s[1], s[2]); }
}
const _ge = new THREE.Euler();
function gxPoseChar(ch, pose, tp) {
  for (const j of J) { const g = ch.joints[j], d = (pose && pose[j]) || [0, 0, 0], piv = R.PIVOT[j]; g.quaternion.setFromEuler(_ge.set(d[0] * DEG, d[1] * DEG, d[2] * DEG, "XYZ"));
    const off = j === "Torso" && tp ? tp : [0, 0, 0]; g.position.set(piv[0] + off[0], piv[1] + off[1], piv[2] + off[2]); }
}
function gxDrop(L) { gxWorld.remove(L.root); if (L.ch) gxDisposeChar(L.ch); else gxDisposeTree(L.root); }
let gxSyncTimer = 0;
function gxSyncSoon() { clearTimeout(gxSyncTimer); gxSyncTimer = setTimeout(() => { if (G.p) { gxSync(); gxDirty = true; } }, 30); }
function gxSync() { // the scene's drawings follow the project's objects
  if (!gxR) return;
  const seen = new Set();
  for (const o of G.p.objs) { seen.add(o.id); let L = gxLive.get(o.id); const sig = gxSig(o);
    if (!L || L.sig !== sig) { if (L) gxDrop(L); L = gxBuildObj(o); L.sig = sig; gxLive.set(o.id, L); gxWorld.add(L.root); }
    gxPlace(L, o); }
  for (const [id, L] of [...gxLive]) if (!seen.has(id)) { gxDrop(L); gxLive.delete(id); }
}
// ---- imported 3D models (GLB / glTF / OBJ)
const gxImportWait = new Set();
async function gxLoadImport(asset, fmt) {
  if (gxImports.has(asset) || gxImportWait.has(asset)) return; gxImportWait.add(asset);
  try {
    const r = await fetch(blobUrl(asset)); if (!r.ok) throw new Error("not found");
    const g = await gxParseModel(await r.arrayBuffer(), fmt);
    gxImports.set(asset, g); gxSyncSoon();
  } catch (e) { console.warn("import", e); }
  gxImportWait.delete(asset);
}
async function gxParseModel(buf, fmt) { // -> a group scaled to about 4 studs tall, standing on its origin
  let g;
  if (fmt === "obj") { if (!THREE.OBJLoader) throw new Error("no OBJ loader"); g = new THREE.OBJLoader().parse(new TextDecoder().decode(buf));
    g.traverse(n => { if (n.isMesh) { const old = n.material; n.material = new THREE.MeshStandardMaterial({ color: (old && old.color) ? old.color.clone() : new THREE.Color(0.75, 0.75, 0.78), roughness: 0.6 }); if (!n.geometry.attributes.normal) n.geometry.computeVertexNormals(); } }); }
  else { if (!THREE.GLTFLoader) throw new Error("no glTF loader"); g = await new Promise((ok, bad) => new THREE.GLTFLoader().parse(buf, "", r => ok(r.scene), bad)); }
  const holder = new THREE.Group(); holder.add(g);
  const b = new THREE.Box3().setFromObject(g), size = b.getSize(new THREE.Vector3()), k = size.y > 0 ? 4 / Math.max(size.x, size.y, size.z) : 1;
  g.scale.multiplyScalar(k); const b2 = new THREE.Box3().setFromObject(g), c = b2.getCenter(new THREE.Vector3()); g.position.x -= c.x; g.position.z -= c.z; g.position.y -= b2.min.y;
  holder.traverse(n => { if (n.isMesh) { n.castShadow = n.receiveShadow = true; if (n.geometry) n.geometry.userData.shared = true; for (const m of [].concat(n.material)) if (m) { m.userData.shared = true; if (m.map) m.map.encoding = THREE.sRGBEncoding; } } });
  return holder;
}
