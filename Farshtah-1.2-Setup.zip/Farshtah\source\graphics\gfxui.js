// ======================================================================= Farshtah Graphics: the project
// A thumbnail project: the 3D scene (characters, parts, props, effects, models), its world (ground, sky), light, camera
// and finish (tone, grade, bloom, lens), and the design layers on top. Stored in the "graphics" collection.
const GX_FORMAT = "farshtah-gfx/1";
const G = { p: null, docId: null, sel: null, joint: "Right Arm", mode: "move", lib: "chars", tab: "look", docs: new Map(), col: null, local: false, saving: false, again: false,
  lastSaved: null, undo: [], redo: [], lockCam: false, guides: false, addN: 0, recent: [] };
let gxDirty = true, gxStarted = false, gxOrbit = null, gxTc = null, gxOut = null, gxOctx = null, gxPR = 1, gxSaveTimer = 0, gxLastPush = { key: "", t: 0 };
function gxDirtyAll() { gxDirty = true; }
const GX_BLENDS = [["source-over", "Normal"], ["screen", "Screen"], ["lighter", "Add"], ["multiply", "Multiply"], ["overlay", "Overlay"], ["soft-light", "Soft light"], ["color-dodge", "Dodge"], ["hard-light", "Hard light"]];
const gxAsset = v => (typeof v === "string" && /^[A-Za-z0-9_\-.~@+:]{1,140}$/.test(v) ? v : "");
const gxKeys = list => list.map(x => x[0]);
// ---- checking a stored project (anything missing or wrong falls back to a default)
function gxCleanLook(r) {
  r = r && typeof r === "object" ? r : {}; const d = gxLook(), out = gxLook();
  for (const k of Object.keys(d.colors)) out.colors[k] = vxHex(r.colors && r.colors[k], d.colors[k]);
  const cloth = (c, list, dd) => ({ kind: VXP(c && c.kind, gxKeys(list), "none"), c1: vxHex(c && c.c1, dd.c1), c2: vxHex(c && c.c2, dd.c2), img: gxAsset(c && c.img) });
  out.shirt = cloth(r.shirt, GX_SHIRTS, d.shirt); out.pants = cloth(r.pants, GX_PANTS, d.pants);
  out.face = VXP(r.face, gxKeys(GX_FACES), "smile"); out.faceImg = gxAsset(r.faceImg); out.tshirt = gxAsset(r.tshirt);
  out.bevel = r.bevel !== false; out.plastic = VXN(r.plastic, 0.55, 0.05, 1);
  const opt3 = (v, lo, hi) => (Array.isArray(v) && v.length === 3 && v.every(x => typeof x === "number" && isFinite(x)) ? v.map(x => clamp(x, lo, hi)) : undefined);
  out.acc = (Array.isArray(r.acc) ? r.acc : []).filter(a => a && typeof a === "object").slice(0, 12).map(a => {
    const x = { kind: VXP(a.kind, gxKeys(GX_ACC).concat(["model", "import"]), "spiky"), color: vxHex(a.color, "#2b2b30") };
    if (x.kind === "model" || x.kind === "import") x.model = gxAsset(a.model);
    const p = opt3(a.p, -20, 20), rr = opt3(a.r, -720, 720), s = opt3(a.s, 0.05, 20); if (p) x.p = p; if (rr) x.r = rr; if (s) x.s = s;
    if (["Head", "Torso", "Right Arm", "Left Arm", "Right Leg", "Left Leg"].includes(a.joint)) x.joint = a.joint; return x; });
  out.items = (Array.isArray(r.items) ? r.items : []).filter(a => a && typeof a === "object").slice(0, 3).map(a => {
    const x = { kind: VXP(a.kind, gxKeys(GX_ITEMS).concat(["model", "import"]), "sword"), joint: VXP(a.joint, ["Right Arm", "Left Arm", "Torso"], "Right Arm"), color: a.color ? vxHex(a.color, "") : "" };
    if (x.kind === "model" || x.kind === "import") x.model = gxAsset(a.model);
    const p = opt3(a.p, -20, 20), rr = opt3(a.r, -720, 720), s = opt3(a.s, 0.05, 20); if (p) x.p = p; if (rr) x.r = rr; if (s) x.s = s; return x; });
  return out;
}
function gxCleanPose(r) { const out = {}; for (const j of J) out[j] = VXV(r && r[j], [0, 0, 0], -720, 720); return out; }
const GX_FXDEF = { outline: { on: false, color: "#ffffff", width: 6 }, glow: { on: false, color: "#4aa3ff", size: 22, power: 0.9 } };
function gxCleanObj(r) {
  if (!r || typeof r !== "object") return null;
  const id = typeof r.id === "string" && /^[a-z0-9]{1,16}$/i.test(r.id) ? r.id : vxId();
  const o = { id, type: r.type, name: String(r.name || "").slice(0, 40), hide: !!r.hide, env: !!r.env, p: VXV(r.p, [0, 0, 0], -3000, 3000) };
  const rot = () => VXV(r.r, [0, 0, 0], -3600, 3600);
  switch (r.type) {
    case "char": { const f = r.fx || {};
      return Object.assign(o, { name: o.name || "Character", look: gxCleanLook(r.look), pose: gxCleanPose(r.pose), tp: VXV(r.tp, [0, 0, 0], -20, 20), yaw: VXN(r.yaw, 0, -3600, 3600), s: VXN(r.s, 1, 0.05, 50),
        fx: { outline: { on: !!(f.outline && f.outline.on), color: vxHex(f.outline && f.outline.color, GX_FXDEF.outline.color), width: VXN(f.outline && f.outline.width, 6, 0.5, 40) },
          glow: { on: !!(f.glow && f.glow.on), color: vxHex(f.glow && f.glow.color, GX_FXDEF.glow.color), size: VXN(f.glow && f.glow.size, 22, 1, 160), power: VXN(f.glow && f.glow.power, 0.9, 0, 2) } } }); }
    case "part": return Object.assign(o, { name: o.name || "Part", shape: VXP(r.shape, ["block", "ball", "cylinder", "wedge", "cone", "ring"], "block"), mat: VXP(r.mat, gxKeys(GX_MATS), "plastic"), color: vxHex(r.color, "#a3a2a5"), r: rot(), s: VXV(r.s, [4, 1, 2], 0.05, 3000) });
    case "prop": { const kind = VXP(r.kind, gxKeys(GX_PROPS), "barrel"); return Object.assign(o, { name: o.name || GX_PROPS.find(x => x[0] === kind)[1], kind, color: vxHex(r.color, GX_PROP_COLOR[kind]), r: rot(), s: VXN(r.s, 1, 0.05, 100) }); }
    case "fx": { const kind = VXP(r.kind, gxKeys(GX_FX), "slash"); return Object.assign(o, { name: o.name || GX_FX.find(x => x[0] === kind)[1], kind, c1: vxHex(r.c1, "#4aa3ff"), c2: vxHex(r.c2, "#ffffff"), power: VXN(r.power, 1, 0, 4), r: rot(), s: VXN(r.s, 1, 0.05, 100) }); }
    case "model": return Object.assign(o, { name: o.name || "Model", model: gxAsset(r.model), r: rot(), s: VXN(r.s, 1, 0.05, 100) });
    case "import": return Object.assign(o, { name: o.name || "Model", asset: gxAsset(r.asset), fmt: VXP(r.fmt, ["glb", "obj"], "glb"), r: rot(), s: VXN(r.s, 1, 0.05, 200) });
  }
  return null;
}
const gxPair = (v, d, n0, n1) => [VXN(Array.isArray(v) ? v[0] : undefined, d[0], n0, n1), vxHex(Array.isArray(v) ? v[1] : undefined, d[1])];
function gxCleanLayer(r) {
  if (!r || typeof r !== "object") return null;
  const id = typeof r.id === "string" && /^[a-z0-9]{1,16}$/i.test(r.id) ? r.id : vxId();
  const o = { id, type: r.type, name: String(r.name || "").slice(0, 40), hide: !!r.hide, lock: !!r.lock, x: VXN(r.x, 0.5, -1, 2), y: VXN(r.y, 0.5, -1, 2), rot: VXN(r.rot, 0, -360, 360),
    opacity: VXN(r.opacity, 1, 0, 1), blend: VXP(r.blend, gxKeys(GX_BLENDS), "source-over") };
  const sh = r.shadow, shadow = [VXN(sh && sh[0], 0, 0, 4), vxHex(sh && sh[1], "#000000"), VXN(sh && sh[2], 0, 0, 8), VXN(sh && sh[3], 60, -360, 360), VXN(sh && sh[4], 0.7, 0, 1)];
  const glow = gxPair(r.glow, [0, "#ffffff"], 0, 4);
  switch (r.type) {
    case "text": { const f = r.fill || {};
      return Object.assign(o, { name: o.name || "Text", text: String(r.text == null ? "TEXT" : r.text).slice(0, 300), font: VXP(r.font, GX_FONTS.map(x => x[0]), "Luckiest Guy"), size: VXN(r.size, 0.14, 0.01, 1.5),
        spacing: VXN(r.spacing, 0, -0.2, 1), line: VXN(r.line, 1, 0.5, 3), align: VXP(r.align, ["center", "left", "right"], "center"), upper: !!r.upper, italic: !!r.italic, arc: VXN(r.arc, 0, -1, 1),
        fill: { kind: VXP(f.kind, ["solid", "grad"], "solid"), a: vxHex(f.a, "#ffffff"), b: vxHex(f.b, "#ffd23f"), mid: f.mid ? vxHex(f.mid, "") : "", angle: VXN(f.angle, 0, -180, 180), shine: VXN(f.shine, 0, 0, 1) },
        stroke1: gxPair(r.stroke1, [0.06, "#14141a"], 0, 0.5), stroke2: gxPair(r.stroke2, [0, "#000000"], 0, 0.5),
        extrude: [VXN(r.extrude && r.extrude[0], 0, 0, 0.6), vxHex(r.extrude && r.extrude[1], "#14141a"), VXN(r.extrude && r.extrude[2], 90, -360, 360)], shadow, glow }); }
    case "image": return Object.assign(o, { name: o.name || "Image", asset: gxAsset(r.asset), h: VXN(r.h, 0.4, 0.01, 4), flip: !!r.flip, outline: gxPair(r.outline, [0, "#ffffff"], 0, 0.2), shadow, glow });
    case "sticker": { const kind = VXP(r.kind, gxKeys(GX_STICKERS), "arrow");
      return Object.assign(o, { name: o.name || GX_STICKERS.find(x => x[0] === kind)[1], kind, h: VXN(r.h, 0.2, 0.01, 3), flip: !!r.flip, c1: vxHex(r.c1, "#ffd23f"), c2: vxHex(r.c2, "#ff8a00"),
        stroke: gxPair(r.stroke, [0.05, "#14141a"], 0, 0.3), text: String(r.text == null ? (GX_STICKER_TEXT[kind] || "") : r.text).slice(0, 14), textColor: vxHex(r.textColor, "#ffffff"),
        font: VXP(r.font, GX_FONTS.map(x => x[0]), "Luckiest Guy"), shadow, glow }); }
    case "overlay": { const kind = VXP(r.kind, gxKeys(GX_OVERLAYS), "speed");
      return Object.assign(o, { name: o.name || GX_OVERLAYS.find(x => x[0] === kind)[1], kind, c1: vxHex(r.c1, "#ffffff"), c2: vxHex(r.c2, "#ffd23f"), power: VXN(r.power, 0.6, 0, 1), seed: Math.round(VXN(r.seed, 1, 0, 9999)) }); }
  }
  return null;
}
function gxClean(raw) {
  const r = raw && typeof raw === "object" ? raw : {}, w = r.world || {}, gr = w.ground || {}, sk = w.sky || {}, l = r.light || {}, c = r.cam || {}, po = r.post || {};
  const day = GX_SKIES.day;
  return {
    format: GX_FORMAT, name: String(r.name || "Untitled thumbnail").slice(0, 60) || "Untitled thumbnail", size: VXP(r.size, Object.keys(GX_SIZES), "thumb"),
    world: { preset: typeof w.preset === "string" ? w.preset.slice(0, 20) : "", fog: VXN(w.fog, 0.3, 0, 1),
      ground: { kind: VXP(gr.kind, Object.keys(GX_SURF).concat(["none", "studio"]), "grid"), color: vxHex(gr.color, "#a3a2a5"), color2: vxHex(gr.color2, "#ff2bd6") },
      sky: { top: vxHex(sk.top, day.top), horizon: vxHex(sk.horizon, day.horizon), bottom: vxHex(sk.bottom, day.bottom), cloud: vxHex(sk.cloud, day.cloud), clouds: VXN(sk.clouds, 0.4, 0, 1),
        stars: VXN(sk.stars, 0, 0, 1), sunSize: VXN(sk.sunSize, 1, 0, 4), seed: VXN(sk.seed, 0, 0, 100) } },
    light: { preset: typeof l.preset === "string" ? l.preset.slice(0, 20) : "", sunAz: VXN(l.sunAz, 35, -360, 360), sunEl: VXN(l.sunEl, 48, -10, 90), sunColor: vxHex(l.sunColor, day.sun),
      sun: VXN(l.sun, 1.7, 0, 10), sky: VXN(l.sky, 1, 0, 4), fill: VXN(l.fill, 0.25, 0, 3), shadows: VXN(l.shadows, 0.85, 0, 1),
      rim: { on: !!(l.rim && l.rim.on), color: vxHex(l.rim && l.rim.color, "#ffffff"), power: VXN(l.rim && l.rim.power, 2, 0, 10), side: VXN(l.rim && l.rim.side, 0.6, -1, 1) } },
    cam: { p: VXV(c.p, [5.5, 4.4, -15], -5000, 5000), t: VXV(c.t, [0, 3.3, 0], -5000, 5000), fov: VXN(c.fov, 38, 8, 120), roll: VXN(c.roll, 0, -60, 60) },
    post: { look: typeof po.look === "string" ? po.look.slice(0, 20) : "", tone: VXP(po.tone, ["filmic", "vivid", "flat"], "vivid"), exposure: VXN(po.exposure, 1, 0.1, 4), contrast: VXN(po.contrast, 1.06, 0.5, 2),
      saturation: VXN(po.saturation, 1.08, 0, 2), vibrance: VXN(po.vibrance, 0.12, -1, 1), warmth: VXN(po.warmth, 0, -1, 1), tint: VXN(po.tint, 0, -1, 1),
      bloom: { on: !(po.bloom && po.bloom.on === false), power: VXN(po.bloom && po.bloom.power, 0.8, 0, 3), size: VXN(po.bloom && po.bloom.size, 0.55, 0, 1), threshold: VXN(po.bloom && po.bloom.threshold, 3, 0, 8) },
      vignette: VXN(po.vignette, 0.22, 0, 1), grain: VXN(po.grain, 0.03, 0, 1), chroma: VXN(po.chroma, 0, 0, 3), sharpen: VXN(po.sharpen, 0.25, 0, 2), distort: VXN(po.distort, 0, -1, 1),
      zoom: { power: VXN(po.zoom && po.zoom.power, 0, 0, 1), x: VXN(po.zoom && po.zoom.x, 0.5, 0, 1), y: VXN(po.zoom && po.zoom.y, 0.5, 0, 1) },
      dof: { on: !!(po.dof && po.dof.on), blur: VXN(po.dof && po.dof.blur, 0.45, 0, 1), target: typeof (po.dof && po.dof.target) === "string" ? po.dof.target.slice(0, 16) : "" },
      lift: VXN(po.lift, 0, 0, 1), fade: VXN(po.fade, 0, 0, 1), gradeColor: vxHex(po.gradeColor, "#ffffff") },
    objs: (Array.isArray(r.objs) ? r.objs : []).slice(0, 300).map(gxCleanObj).filter(Boolean),
    layers: (Array.isArray(r.layers) ? r.layers : []).slice(0, 120).map(gxCleanLayer).filter(Boolean),
  };
}
// ---- presets: places, light, looks, camera
const P3 = (kind, x, z, yaw, s, color) => ({ type: "prop", kind, p: [x, 0, z], r: [0, yaw || 0, 0], s: s || 1, color, env: true });
const PART = (x, y, z, sx, sy, sz, color, mat, shape) => ({ type: "part", shape: shape || "block", mat: mat || "plastic", color, p: [x, y, z], r: [0, 0, 0], s: [sx, sy, sz], env: true });
const GX_WORLDS = [
  ["baseplate", "Baseplate", "day", { kind: "grid", color: "#a3a2a5" }, 0.25, () => []],
  ["grass", "Grassland", "day", { kind: "grass", color: "#5aa83f" }, 0.35, () => [P3("tree", -15, 20, 20), P3("tree", 17, 24, 70, 1.2), P3("pine", -28, 36), P3("pine", 30, 44, 0, 1.3), P3("bush", -9, 13), P3("bush", 11, 15, 40),
    P3("rock", 7, 10, 30, 0.8), P3("rock", -19, 8, 0, 1.2), P3("tree", 4, 46, 0, 1.4), P3("pine", -45, 60, 0, 1.5), P3("fence", -4, 28), P3("fence", 4, 28)]],
  ["arena", "Arena", "golden", { kind: "stone", color: "#cdb994" }, 0.3, () => { const out = [];
    for (let i = 0; i < 14; i++) { const a = Math.PI * (0.05 + i / 13 * 0.9), r = 34; out.push(P3("wall", Math.cos(a) * r, Math.sin(a) * r - 4, -a * 180 / Math.PI + 90, 1, "#a99f8f")); }
    out.push(P3("barrel", -9, 9, 0), P3("barrel", -11.5, 10.5, 30, 0.9), P3("barrel", 10, 11, 0), P3("crate", 13, 13, 20), P3("crate", -15, 15, 10, 1.1), P3("crate", -13.4, 13, 45, 0.8),
      P3("torch", -6, 20), P3("torch", 6, 20), P3("pillar", -20, 26), P3("pillar", 20, 26)); return out; }],
  ["tiles", "Purple tiles", "neon", { kind: "tiles", color: "#7b49e8" }, 0.45, () => [P3("pillar", -12, 14, 0, 1, "#b48cff"), P3("pillar", 12, 14, 0, 1, "#b48cff"), P3("pillar", -24, 30, 0, 1.3, "#b48cff"),
    P3("pillar", 24, 30, 0, 1.3, "#b48cff"), PART(0, 0.3, 22, 30, 0.6, 2, "#ff4fd8", "neon")]],
  ["obby", "Obby", "day", { kind: "none", color: "#4aa3ff" }, 0.2, () => [PART(0, -1, 0, 18, 2, 14, "#4aa3ff"), PART(-14, 2, 16, 8, 1.2, 8, "#ff4f6a"), PART(10, 5, 22, 7, 1.2, 7, "#ffd23f"), PART(-4, 8, 34, 8, 1.2, 8, "#3bd16f"),
    PART(16, 12, 40, 6, 1.2, 6, "#b07cff"), PART(-18, 14, 46, 7, 1.2, 7, "#ff8a2a"), P3("cloud", -30, 40, 0, 2), P3("cloud", 34, 60, 0, 2.6), P3("cloud", 0, 90, 0, 3), P3("coin", 10, 22, 0, 1), PART(-14, 2.8, 16, 1, 1, 1, "#ff2b2b", "neon", "ball")]],
  ["city", "Night city", "night", { kind: "asphalt", color: "#3b3e46" }, 0.45, () => { const out = []; for (let i = 0; i < 8; i++) { out.push(P3("building", -40 + i * 11.5, 36 + (i % 3) * 6, 0, 1, ["#4a5060", "#3c4250", "#585f70"][i % 3])); }
    out.push(P3("lamp", -9, 10, 180), P3("lamp", 9, 12, 0), P3("building", -26, 18, 0, 0.9, "#454b5a"), P3("building", 28, 20, 0, 0.9, "#505868"), PART(0, 0.05, 14, 80, 0.1, 6, "#2c2e34")); return out; }],
  ["desert", "Desert", "sunset", { kind: "sand", color: "#e3c48c" }, 0.4, () => [P3("cactus", -12, 16), P3("cactus", 14, 22, 50, 1.2), P3("rock", -6, 10, 0, 1.3, "#b8875a"), P3("rock", 9, 12, 70, 0.9, "#b8875a"),
    P3("rock", -24, 30, 0, 3, "#b8875a"), P3("rock", 26, 40, 0, 4, "#b8875a"), P3("cactus", 30, 50, 0, 1.5)]],
  ["snow", "Snow", "overcast", { kind: "snow", color: "#f4f7fb" }, 0.5, () => [P3("pine", -14, 18, 0, 1, "#2f6d4a"), P3("pine", 16, 22, 0, 1.2, "#2f6d4a"), P3("pine", -30, 36, 0, 1.4, "#2f6d4a"), P3("pine", 32, 42, 0, 1.5, "#2f6d4a"),
    P3("rock", -7, 9, 0, 0.9, "#c9d2dc"), P3("rock", 9, 11, 40, 1.1, "#c9d2dc")]],
  ["neon", "Neon grid", "neon", { kind: "neon", color: "#120a24", color2: "#ff2bd6" }, 0.5, () => [PART(0, 6, 40, 60, 0.4, 0.4, "#2bd6ff", "neon"), PART(0, 12, 46, 70, 0.4, 0.4, "#ff2bd6", "neon")]],
  ["studio", "Studio", "studio", { kind: "studio", color: "#3a6fd8" }, 0.1, () => []],
  ["void", "Void", "dramatic", { kind: "none", color: "#101116" }, 0, () => []],
];
const GX_LIGHTS = [ // key, name, { sky look, sun azimuth / height / colour / power, sky light, fill, shadows, rim [on, colour, power], clouds, stars, sun size }
  ["day", "Sunny", { sky: "day", az: 35, el: 50, color: "#fff1dc", sun: 1.7, skyL: 0.9, fill: 0.2, sh: 0.85, rim: [false, "#ffffff", 1.4], clouds: 0.4, stars: 0, sunSize: 1 }],
  ["golden", "Golden hour", { sky: "golden", az: 62, el: 15, color: "#ffb56e", sun: 2.0, skyL: 0.7, fill: 0.18, sh: 0.9, rim: [true, "#ffd2a0", 1.6], clouds: 0.45, stars: 0, sunSize: 1.4 }],
  ["sunset", "Sunset", { sky: "sunset", az: 150, el: 7, color: "#ff8a4a", sun: 1.8, skyL: 0.65, fill: 0.3, sh: 0.8, rim: [true, "#ff9a5a", 2.0], clouds: 0.5, stars: 0, sunSize: 1.8 }],
  ["night", "Night", { sky: "night", az: -40, el: 38, color: "#9fb8ff", sun: 0.8, skyL: 0.6, fill: 0.28, sh: 0.7, rim: [true, "#6a8cff", 2.2], clouds: 0.15, stars: 0.9, sunSize: 0.7 }],
  ["studio", "Studio", { sky: "studio", az: 32, el: 38, color: "#ffffff", sun: 1.8, skyL: 0.85, fill: 0.4, sh: 0.6, rim: [true, "#ffffff", 1.8], clouds: 0, stars: 0, sunSize: 0 }],
  ["dramatic", "Dramatic", { sky: "studio", az: 95, el: 22, color: "#ffffff", sun: 2.2, skyL: 0.2, fill: 0.06, sh: 1, rim: [true, "#ff3b3b", 2.8], clouds: 0, stars: 0, sunSize: 0 }],
  ["neon", "Neon", { sky: "purple", az: -60, el: 32, color: "#ff7ad9", sun: 1.25, skyL: 0.7, fill: 0.26, sh: 0.8, rim: [true, "#2bd6ff", 2.6], clouds: 0.2, stars: 0.5, sunSize: 0.8 }],
  ["toxic", "Toxic", { sky: "toxic", az: 40, el: 30, color: "#c8ff6a", sun: 1.5, skyL: 0.7, fill: 0.22, sh: 0.85, rim: [true, "#7aff9a", 2.2], clouds: 0.35, stars: 0, sunSize: 1 }],
  ["blood", "Blood moon", { sky: "blood", az: -30, el: 25, color: "#ff6a4a", sun: 1.4, skyL: 0.55, fill: 0.22, sh: 0.85, rim: [true, "#ff2a2a", 2.4], clouds: 0.3, stars: 0.4, sunSize: 1.5 }],
  ["overcast", "Cloudy", { sky: "overcast", az: 20, el: 55, color: "#ffffff", sun: 0.9, skyL: 1.2, fill: 0.35, sh: 0.4, rim: [false, "#ffffff", 1.4], clouds: 0.85, stars: 0, sunSize: 0.4 }],
];
const GX_GRADES = [
  ["natural", "Natural", { tone: "filmic", exposure: 1, contrast: 1, saturation: 1, vibrance: 0, warmth: 0, tint: 0, vignette: 0.12, grain: 0.02, sharpen: 0.15, chroma: 0, fade: 0, lift: 0, bloom: [0.7, 0.5, 3] }],
  ["vivid", "Vivid", { tone: "vivid", exposure: 1, contrast: 1.06, saturation: 1.08, vibrance: 0.12, warmth: 0, tint: 0, vignette: 0.22, grain: 0.03, sharpen: 0.25, chroma: 0, fade: 0, lift: 0, bloom: [0.85, 0.55, 3] }],
  ["punchy", "Punchy", { tone: "vivid", exposure: 1.05, contrast: 1.2, saturation: 1.22, vibrance: 0.3, warmth: 0.05, tint: 0, vignette: 0.35, grain: 0.03, sharpen: 0.45, chroma: 0.2, fade: 0, lift: 0, bloom: [1, 0.6, 2.6] }],
  ["warm", "Warm", { tone: "vivid", exposure: 1.02, contrast: 1.08, saturation: 1.12, vibrance: 0.15, warmth: 0.5, tint: 0.05, vignette: 0.25, grain: 0.03, sharpen: 0.25, chroma: 0, fade: 0, lift: 0, bloom: [0.9, 0.6, 2.8] }],
  ["cool", "Cool", { tone: "vivid", exposure: 1, contrast: 1.08, saturation: 1.05, vibrance: 0.15, warmth: -0.5, tint: -0.05, vignette: 0.25, grain: 0.03, sharpen: 0.25, chroma: 0, fade: 0, lift: 0, bloom: [0.9, 0.6, 2.8] }],
  ["teal", "Teal & orange", { tone: "vivid", exposure: 1, contrast: 1.14, saturation: 1.18, vibrance: 0.2, warmth: 0.3, tint: -0.25, vignette: 0.3, grain: 0.04, sharpen: 0.3, chroma: 0.1, fade: 0, lift: 0, bloom: [0.9, 0.6, 2.8] }],
  ["moody", "Moody", { tone: "filmic", exposure: 0.85, contrast: 1.18, saturation: 0.85, vibrance: 0, warmth: -0.1, tint: 0, vignette: 0.6, grain: 0.06, sharpen: 0.3, chroma: 0.15, fade: 0.15, lift: 0, bloom: [0.8, 0.6, 2.8] }],
  ["dreamy", "Dreamy", { tone: "filmic", exposure: 1.08, contrast: 0.94, saturation: 1.1, vibrance: 0.1, warmth: 0.15, tint: 0.1, vignette: 0.15, grain: 0.02, sharpen: 0, chroma: 0, fade: 0.1, lift: 0.25, bloom: [1.4, 0.9, 1.8] }],
  ["noir", "Noir", { tone: "filmic", exposure: 1, contrast: 1.3, saturation: 0, vibrance: 0, warmth: 0, tint: 0, vignette: 0.6, grain: 0.15, sharpen: 0.3, chroma: 0, fade: 0, lift: 0, bloom: [0.6, 0.5, 3] }],
  ["retro", "Retro", { tone: "filmic", exposure: 1, contrast: 1, saturation: 0.85, vibrance: 0, warmth: 0.3, tint: 0.05, vignette: 0.4, grain: 0.25, sharpen: 0, chroma: 0.7, fade: 0.4, lift: 0.1, bloom: [0.8, 0.6, 2.8] }],
];
const GX_CAMS = [["front", "Front"], ["hero", "Hero low"], ["close", "Close-up"], ["wide", "Wide"], ["side", "Side"], ["high", "High"], ["dutch", "Dutch"]];
function gxApplyLight(p, key) {
  const L = (GX_LIGHTS.find(x => x[0] === key) || GX_LIGHTS[0])[2], sky = GX_SKIES[L.sky];
  p.light.preset = key; Object.assign(p.light, { sunAz: L.az, sunEl: L.el, sunColor: L.color, sun: L.sun, sky: L.skyL, fill: L.fill, shadows: L.sh });
  p.light.rim = { on: L.rim[0], color: L.rim[1], power: L.rim[2], side: p.light.rim ? p.light.rim.side : 0.6 };
  Object.assign(p.world.sky, { top: sky.top, horizon: sky.horizon, bottom: sky.bottom, cloud: sky.cloud, clouds: L.clouds, stars: L.stars, sunSize: L.sunSize });
}
function gxApplyGrade(p, key) {
  const g = (GX_GRADES.find(x => x[0] === key) || GX_GRADES[1])[2], P = p.post; P.look = key;
  for (const k of ["tone", "exposure", "contrast", "saturation", "vibrance", "warmth", "tint", "vignette", "grain", "sharpen", "chroma", "fade", "lift"]) P[k] = g[k];
  P.bloom = { on: true, power: g.bloom[0], size: g.bloom[1], threshold: g.bloom[2] };
}
function gxApplyWorld(p, key) { // the ground, fog, props and its light (characters and everything else stay)
  const w = GX_WORLDS.find(x => x[0] === key) || GX_WORLDS[0];
  p.world.preset = key; p.world.ground = Object.assign({ color2: "#ff2bd6" }, w[3]); p.world.fog = w[4];
  p.objs = p.objs.filter(o => !o.env).concat(w[5]().map(gxCleanObj).filter(Boolean).map(o => (o.env = true, o)));
  gxApplyLight(p, w[2]);
}
// ---- starting points
const gxChar = (preset, x, z, yaw, pose, extra) => { const pr = GX_PRESETS.find(q => q[0] === preset) || GX_PRESETS[0];
  return Object.assign({ type: "char", name: pr[1], look: pr[2](), pose: gxPoseDeg(pose), p: [x, 0, z], yaw: yaw || 0, s: 1 }, extra || {}); };
function gxPoseDeg(key) { const d = (GX_POSES.find(x => x[0] === key) || GX_POSES[0])[2], out = {}; for (const j of J) out[j] = (d[j] || [0, 0, 0]).slice(); return out; }
const GX_TEXT_STYLES = [ // name, overrides for a text layer
  ["hype", "Hype", { font: "Luckiest Guy", fill: { kind: "grad", a: "#fff36b", b: "#ff9a1a", angle: 0, shine: 0.6 }, stroke1: [0.07, "#4a1d00"], stroke2: [0.035, "#000000"], extrude: [0.07, "#2a0f00", 90], shadow: [0.6, "#000000", 1.2, 70, 0.6] }],
  ["bubble", "Bubble", { font: "Lilita One", fill: { kind: "solid", a: "#ffffff", b: "#ffffff", angle: 0, shine: 0 }, stroke1: [0.09, "#16161c"], stroke2: [0, "#000000"], extrude: [0.05, "#16161c", 90], shadow: [0.5, "#000000", 0.8, 70, 0.5] }],
  ["fire", "Fire", { font: "Bangers", fill: { kind: "grad", a: "#fff7a8", mid: "#ffb21a", b: "#ff3d00", angle: 0, shine: 0.3 }, stroke1: [0.06, "#3a0a00"], stroke2: [0.03, "#000000"], extrude: [0.05, "#3a0a00", 90], glow: [0.7, "#ff5a00"] }],
  ["ice", "Ice", { font: "Titan One", fill: { kind: "grad", a: "#ffffff", b: "#6fd3ff", angle: 0, shine: 0.5 }, stroke1: [0.06, "#0a2f66"], stroke2: [0.03, "#ffffff"], extrude: [0.05, "#06204a", 90], glow: [0.6, "#4fc3ff"] }],
  ["toxic", "Toxic", { font: "Luckiest Guy", fill: { kind: "grad", a: "#e8ff6a", b: "#2fbf3a", angle: 0, shine: 0.5 }, stroke1: [0.07, "#0b2a0e"], stroke2: [0.03, "#000000"], extrude: [0.06, "#071d09", 90], glow: [0.5, "#7aff4a"] }],
  ["gold", "Gold", { font: "Bowlby One SC", fill: { kind: "grad", a: "#fff6c2", mid: "#ffd04a", b: "#c27a12", angle: 0, shine: 0.7 }, stroke1: [0.05, "#5a3400"], stroke2: [0.03, "#1a0e00"], extrude: [0.06, "#3a2100", 90], shadow: [0.6, "#000000", 1, 70, 0.6] }],
  ["neon", "Neon", { font: "Russo One", fill: { kind: "solid", a: "#ffffff", b: "#ffffff", angle: 0, shine: 0 }, stroke1: [0.025, "#ff2bd6"], stroke2: [0, "#000000"], extrude: [0, "#000000", 90], glow: [1.2, "#ff2bd6"] }],
  ["blood", "Horror", { font: "Creepster", fill: { kind: "grad", a: "#ff4a4a", b: "#7a0000", angle: 0, shine: 0 }, stroke1: [0.05, "#000000"], stroke2: [0, "#000000"], extrude: [0.03, "#2a0000", 90], glow: [0.4, "#ff0000"] }],
  ["comic", "Comic", { font: "Bangers", fill: { kind: "solid", a: "#ffffff", b: "#ffffff", angle: 0, shine: 0 }, stroke1: [0.07, "#000000"], stroke2: [0, "#000000"], extrude: [0.08, "#e0262c", 60], spacing: 0.03 }],
  ["pixel", "Pixel", { font: "Press Start 2P", size: 0.08, fill: { kind: "solid", a: "#ffffff", b: "#ffffff", angle: 0, shine: 0 }, stroke1: [0.12, "#000000"], stroke2: [0, "#000000"], extrude: [0.1, "#000000", 45] }],
  ["clean", "Clean", { font: "Anton", fill: { kind: "solid", a: "#ffffff", b: "#ffffff", angle: 0, shine: 0 }, stroke1: [0, "#000000"], stroke2: [0, "#000000"], extrude: [0, "#000000", 90], shadow: [1.2, "#000000", 0.6, 80, 0.75], upper: true, spacing: 0.02 }],
  ["royal", "Royal", { font: "Fredoka", fill: { kind: "grad", a: "#e7c6ff", b: "#7b2cff", angle: 0, shine: 0.6 }, stroke1: [0.06, "#ffd04a"], stroke2: [0.03, "#2a0a4a"], extrude: [0.05, "#2a0a4a", 90] }],
];
function gxTextLayer(style, over) { const s = (GX_TEXT_STYLES.find(x => x[0] === style) || GX_TEXT_STYLES[0])[2];
  return gxCleanLayer(Object.assign({ type: "text", text: "TEXT", size: 0.15, x: 0.5, y: 0.2 }, JSON.parse(JSON.stringify(s)), over || {})); }
function gxBlank() {
  const p = gxClean({ name: "Untitled thumbnail" }); gxApplyWorld(p, "baseplate"); gxApplyGrade(p, "vivid");
  p.objs.push(gxCleanObj(gxChar("noob", 0, 0, 0, "hero"))); return p;
}
const GX_TEMPLATES = [
  ["duel", "Duel", () => { const p = gxClean({ name: "Duel" }); gxApplyWorld(p, "arena"); gxApplyGrade(p, "punchy");
    const hero = gxChar("hero", -2.6, 0, 28, "slash"); hero.look.items = [{ kind: "greatsword", joint: "Right Arm" }]; hero.fx = { glow: { on: true, color: "#4aa3ff", size: 26, power: 0.9 }, outline: { on: true, color: "#ffffff", width: 5 } };
    const foe = gxChar("dummy", 3.6, 0, -34, "hit", { tp: [0, 0.2, 0] }); foe.name = "Enemy"; foe.fx = { glow: { on: true, color: "#ff3b3b", size: 22, power: 0.8 }, outline: { on: false, color: "#ffffff", width: 5 } };
    p.objs.push(hero, foe, { type: "fx", kind: "slash", c1: "#4aa3ff", c2: "#ffffff", p: [0.4, 3.2, -0.6], r: [-15, 10, 55], s: 0.75 }, { type: "fx", kind: "burst", c1: "#ffb347", c2: "#ffffff", p: [1.6, 4.4, -0.4], r: [0, 0, 0], s: 0.45 });
    p.objs = p.objs.map(gxCleanObj).filter(Boolean);
    p.cam = { p: [1.8, 3.2, -12.5], t: [0.6, 3.6, 0], fov: 42, roll: -4 };
    p.layers.push(gxCleanLayer({ type: "overlay", kind: "speed", c1: "#ffffff", power: 0.35, opacity: 0.35, x: 0.56, y: 0.5, blend: "screen" }), gxTextLayer("hype", { text: "DUEL!", size: 0.22, y: 0.17, rot: -4 }));
    return p; }],
  ["hero", "Hero shot", () => { const p = gxClean({ name: "Hero shot" }); gxApplyWorld(p, "grass"); gxApplyLight(p, "sunset"); gxApplyGrade(p, "warm"); p.light.sunAz = 35; p.light.sunEl = 18; p.light.sun = 1.6;
    const c = gxChar("fighter", 0, 0, -10, "raise"); c.look.items = [{ kind: "sword", joint: "Right Arm", color: "#e0b33a" }]; c.fx = { outline: { on: true, color: "#ffffff", width: 6 }, glow: { on: true, color: "#ffb347", size: 30, power: 0.8 } };
    p.objs.push(gxCleanObj(c), gxCleanObj({ type: "fx", kind: "sparkles", c1: "#ffd27a", c2: "#ffffff", p: [0, 2, 0], r: [0, 0, 0], s: 1 }));
    p.cam = { p: [2.6, 2.6, -12], t: [0, 3.6, 0], fov: 44, roll: 0 };
    p.layers.push(gxCleanLayer({ type: "overlay", kind: "rays", c1: "#ffd6a0", c2: "#fff3dd", power: 0.55, x: 0.62, y: 0.25, opacity: 0.7, blend: "screen" }), gxTextLayer("gold", { text: "NEW UPDATE", size: 0.13, y: 0.86 }));
    return p; }],
  ["icon", "Game icon", () => { const p = gxClean({ name: "Game icon", size: "icon" }); gxApplyWorld(p, "studio"); gxApplyGrade(p, "punchy"); p.world.ground.color = "#2f7bff";
    const c = gxChar("king", 0, 0, -18, "ready"); c.look.items = [{ kind: "sword", joint: "Right Arm", color: "#e0b33a" }]; c.fx = { outline: { on: true, color: "#14141a", width: 9 }, glow: { on: true, color: "#9fd0ff", size: 26, power: 0.55 } };
    p.objs.push(gxCleanObj(c)); p.cam = { p: [2.2, 5.4, -10.5], t: [0.3, 3.9, 0], fov: 40, roll: 0 };
    p.layers.push(gxCleanLayer({ type: "overlay", kind: "sparkle", c1: "#ffffff", c2: "#ffe27a", power: 0.25, blend: "screen" }));
    return p; }],
  ["night", "Night battle", () => { const p = gxClean({ name: "Night battle" }); gxApplyWorld(p, "city"); gxApplyGrade(p, "teal");
    const a = gxChar("ninja", -2.4, 0, 30, "slash"); a.look.items = [{ kind: "katana", joint: "Right Arm" }]; a.fx = { glow: { on: true, color: "#2bd6ff", size: 24, power: 0.9 }, outline: { on: false, color: "#ffffff", width: 5 } };
    const b = gxChar("shadow", 3, 0, -30, "guard"); b.look.items = [{ kind: "sword", joint: "Right Arm", color: "#7d4cff" }];
    p.objs.push(gxCleanObj(a), gxCleanObj(b), gxCleanObj({ type: "fx", kind: "lightning", c1: "#7d4cff", c2: "#ffffff", p: [0.6, 0, 1.5], r: [0, 0, 0], s: 0.8 }));
    p.cam = { p: [0.5, 3, -11.5], t: [0.3, 3.6, 0], fov: 44, roll: 3 };
    p.layers.push(gxTextLayer("neon", { text: "1 V 1", size: 0.18, y: 0.16 }));
    return p; }],
];
// ---- saving
function gxSetSave(s, t) { const el = $("gxSave"); if (el) { el.dataset.s = s; el.textContent = t; } }
const GX_LOCAL = "farshtah.gfx.local";
function gxLocalAll() { try { return JSON.parse(store.get(GX_LOCAL) || "{}") || {}; } catch (e) { return {}; } }
function gxSaveSoon() { gxSetSave("pending", "Unsaved"); clearTimeout(gxSaveTimer); gxSaveTimer = setTimeout(gxSaveNow, 1000); }
async function gxThumb() { // a small picture of the project for the list
  if (!gxR || !gxOut || gxOut.width < 2) return "";
  try { const w = gxOut.width, h = gxOut.height, cv = document.createElement("canvas"); cv.width = w; cv.height = h; gxCompose(G.p, cv.getContext("2d"), w, h, { clean: true });
    const s = document.createElement("canvas"), k = Math.min(1, 320 / Math.max(w, h)); s.width = Math.round(w * k); s.height = Math.round(h * k); const c = s.getContext("2d"); c.imageSmoothingQuality = "high"; c.drawImage(cv, 0, 0, s.width, s.height);
    gxDirty = true; return s.toDataURL("image/jpeg", 0.78); } catch (e) { return ""; }
}
async function gxSaveNow() {
  clearTimeout(gxSaveTimer);
  if (G.saving) { G.again = true; return; }
  if (!G.local && !G.col) { gxSetSave("pending", "Unsaved"); return; }
  G.saving = true; gxSetSave("saving", "Saving…");
  try {
    const body = JSON.parse(JSON.stringify(G.p)); body.updatedAt = new Date().toISOString(); body.thumb = await gxThumb();
    if (JSON.stringify(body).length > MAX_DOC) { body.thumb = ""; if (JSON.stringify(body).length > MAX_DOC) throw { code: "too_big" }; }
    if (G.local) { if (!G.docId) G.docId = "local-" + Date.now().toString(36); const all = gxLocalAll(); all[G.docId] = body; store.set(GX_LOCAL, JSON.stringify(all)); G.docs.set(G.docId, body); gxSetSave("local", "Saved in this browser"); }
    else { if (!G.docId) G.docId = G.col.doc().id; await G.col.doc(G.docId).set(body); G.docs.set(G.docId, body); gxSetSave("saved", "Saved"); }
    G.lastSaved = body.updatedAt; store.set("farshtah.gfx.last", G.docId);
  } catch (e) { gxSetSave("error", e && e.code === "too_big" ? "Too big to save" : "Not saved"); }
  G.saving = false; if (G.again) { G.again = false; gxSaveSoon(); }
}
async function gxInitStore() {
  for (let i = 0; i < 160 && !db && !local; i++) await new Promise(r => setTimeout(r, 50));
  if (!db) { G.local = true; for (const [id, d] of Object.entries(gxLocalAll())) G.docs.set(id, d); gxFirstOpen(); return; }
  G.col = db.collection("graphics"); let first = true;
  G.col.onSnapshot(snap => { G.docs.clear(); for (const d of snap.docs) G.docs.set(d.id, d.data()); if (first) { first = false; gxFirstOpen(); } if (!$("gxProjBack").hidden) gxRenderProjects(); }, () => { if (first) { first = false; gxFirstOpen(); } gxSetSave("error", "Storage unavailable"); });
}
function gxFirstOpen() {
  const want = LINK.get("gp"); if (want && want.startsWith("t:")) { const t = GX_TEMPLATES.find(x => x[0] === want.slice(2)); if (t) { gxLoad(t[2](), null); return gxApplyLink(); } }
  if (want && G.docs.has(want)) { gxOpenDoc(want); return gxApplyLink(); }
  const last = store.get("farshtah.gfx.last");
  if (last && G.docs.has(last)) gxOpenDoc(last);
  else { const recent = [...G.docs.entries()].sort((a, b) => String(b[1].updatedAt || "").localeCompare(String(a[1].updatedAt || "")))[0];
    if (recent) gxOpenDoc(recent[0]); else gxLoad(GX_TEMPLATES[0][2](), null); }
  gxApplyLink();
}
function gxApplyLink() {
  const sel = LINK.get("gsel"); if (sel) { const o = G.p.objs.find(x => x.id === sel || x.name === sel), l = G.p.layers.find(x => x.id === sel || x.name === sel); if (o) gxSelect("o", o.id); else if (l) gxSelect("l", l.id); }
  const lib = LINK.get("glib"); if (lib) gxSetLib(lib);
  const tab = LINK.get("gtab"); if (tab) { G.tab = tab; renderGxInsp(); }
  if (LINK.has("gexport")) gxOpenExport();
  if (LINK.has("gproj")) gxOpenProjects();
}
function gxLoad(p, docId) {
  G.p = gxClean(p); G.docId = docId; G.sel = null; G.undo.length = 0; G.redo.length = 0;
  $("gxName").value = G.p.name; gxProjectToCam(); gxSync(); gxLayout(); renderGxAll(); gxDirty = true;
  gxSetSave(docId ? "saved" : "pending", docId ? (G.local ? "Saved in this browser" : "Saved") : "Not saved");
  if (!docId) gxSaveSoon(); else store.set("farshtah.gfx.last", docId);
  for (const L of G.p.layers) if (L.font) gxEnsureFont(L.font);
}
function gxOpenDoc(id) { const d = G.docs.get(id); if (!d) return; gxLoad(d, id); G.lastSaved = d.updatedAt || null; }
function gxNew(tplKey) { if ($("gxSave").dataset.s === "pending") gxSaveNow(); const t = GX_TEMPLATES.find(x => x[0] === tplKey); gxLoad(t ? t[2]() : gxBlank(), null); }
// ---- changes and undo
function gxPushUndo(key) { const now = performance.now(); if (key && gxLastPush.key === key && now - gxLastPush.t < 900) { gxLastPush.t = now; return; }
  G.undo.push(JSON.stringify(G.p)); if (G.undo.length > 120) G.undo.shift(); G.redo.length = 0; gxLastPush = { key: key || "", t: now }; }
function gxChange(fn, o) { // every edit: undo point, the change, then what has to follow it
  o = o || {}; gxPushUndo(o.merge); fn(); gxAfter(o);
}
function gxAfter(o) {
  o = o || {}; if (o.scene !== false) gxSync(); if (o.cam) gxProjectToCam(); if (o.size) gxLayout();
  if (o.insp) renderGxInsp(); if (o.layers !== false) renderGxLayers(); if (o.lib) renderGxLib(); if (o.mode !== false) gxAttach();
  gxDirty = true; gxSaveSoon();
}
function gxUndo() { if (!G.undo.length) return toast("Nothing to undo"); G.redo.push(JSON.stringify(G.p)); G.p = gxClean(JSON.parse(G.undo.pop())); gxLastPush = { key: "", t: 0 }; gxRestored(); }
function gxRedo() { if (!G.redo.length) return toast("Nothing to redo"); G.undo.push(JSON.stringify(G.p)); G.p = gxClean(JSON.parse(G.redo.pop())); gxRestored(); }
function gxRestored() { if (G.sel && !gxSelObj() && !gxSelLayer()) G.sel = null; $("gxName").value = G.p.name; gxProjectToCam(); gxAfter({ insp: true, size: true }); }
// ---- selection
const gxSelObj = () => G.sel && G.sel.k === "o" ? G.p.objs.find(o => o.id === G.sel.id) || null : null;
const gxSelLayer = () => G.sel && G.sel.k === "l" ? G.p.layers.find(o => o.id === G.sel.id) || null : null;
function gxSelect(k, id, o) {
  G.sel = k ? { k, id } : null; o = o || {};
  const ob = gxSelObj(); if (!ob || ob.type !== "char") { if (G.mode === "pose") G.mode = "move"; } else if (o.joint) { G.joint = o.joint; G.mode = "pose"; }
  gxAttach(); renderGxInsp(); renderGxLayers(); renderGxTools(); gxDirty = true;
}
// ---- the stage: the frame keeps the export's shape and fits the space
function gxLayout() {
  const st = $("gxStage"); if (!st || !G.p) return; const [W, H] = GX_SIZES[G.p.size];
  const aw = Math.max(50, st.clientWidth - 40), ah = Math.max(50, st.clientHeight - 104), k = Math.min(aw / W, ah / H);
  const dw = Math.floor(W * k), dh = Math.floor(H * k), fr = $("gxFrame"); fr.style.width = dw + "px"; fr.style.height = dh + "px";
  gxPR = Math.min(devicePixelRatio || 1, 2); const pw = Math.round(dw * gxPR), ph = Math.round(dh * gxPR);
  if (gxOut.width !== pw || gxOut.height !== ph) { gxOut.width = pw; gxOut.height = ph; }
  if (gxCam) { gxCam.aspect = W / H; gxCam.updateProjectionMatrix(); }
  gxDirty = true;
}
function gxProjectToCam() { if (!gxCam || !gxOrbit) return; gxCam.position.set(...G.p.cam.p); gxOrbit.target.set(...G.p.cam.t); gxOrbit.update(); gxDirty = true; }
function gxCamToProject() { G.p.cam.p = gxCam.position.toArray().map(v => R.round(v, 3)); G.p.cam.t = gxOrbit.target.toArray().map(v => R.round(v, 3)); }
function gxCamPose() { gxCam.fov = G.p.cam.fov; gxCam.updateProjectionMatrix(); gxCam.up.set(0, 1, 0); gxCam.lookAt(gxOrbit.target); if (G.p.cam.roll) gxCam.rotateZ(-G.p.cam.roll * DEG); gxCam.updateMatrixWorld(); }
function gxRenderPreview() {
  const w = gxOut.width, h = gxOut.height; if (w < 2 || h < 2 || !G.p) return;
  gxCamPose();
  gxCompose(G.p, gxOctx, w, h, { preview: true });
  const c = gxOctx, accent = css("--accent") || "#7aa0ff";
  if (G.guides) { c.save(); c.strokeStyle = "rgba(255,255,255,.45)"; c.lineWidth = gxPR; c.setLineDash([6 * gxPR, 6 * gxPR]);
    for (const k of [1 / 3, 2 / 3]) { c.beginPath(); c.moveTo(w * k, 0); c.lineTo(w * k, h); c.moveTo(0, h * k); c.lineTo(w, h * k); c.stroke(); }
    c.strokeStyle = "rgba(255,210,63,.5)"; c.setLineDash([]); c.strokeRect(w * 0.05, h * 0.05, w * 0.9, h * 0.9); c.restore(); }
  const ob = gxSelObj(), L = ob && gxLive.get(ob.id);
  if (L && L.root.visible && G.mode !== "pose") { try { const m = gxMaskOf(L, w, h); c.drawImage(gxStrokeMask(m, accent, 2 * gxPR, false), 0, 0); } catch (e) {} }
  if (gxSnapGuide) { c.save(); c.strokeStyle = "#ff4fd8"; c.lineWidth = gxPR; if (gxSnapGuide.x) { c.beginPath(); c.moveTo(w / 2, 0); c.lineTo(w / 2, h); c.stroke(); } if (gxSnapGuide.y) { c.beginPath(); c.moveTo(0, h / 2); c.lineTo(w, h / 2); c.stroke(); } c.restore(); }
  const sl = gxSelLayer(); if (sl) gxDrawHandles(c, gxBoxes.get(sl.id), gxPR, accent);
  if (gxTc && gxTc.object && gxTc.visible) { gxR.setRenderTarget(null); gxR.setClearColor(0x000000, 0); gxR.clear(); gxR.render(gxHelpers, gxCam); c.drawImage(gxGL, 0, 0, w, h); }
}
appHooks.graphicsStep = now => {
  if (!gxR || !G.p) return;
  if (gxOrbit && gxOrbit.update()) gxDirty = true;
  if (gxDirty) { gxDirty = false; try { gxRenderPreview(); } catch (e) { console.error(e); } }
};
// ---- the 3D gizmo
function gxAttach() {
  if (!gxTc) return; const ob = gxSelObj(), L = ob && gxLive.get(ob.id);
  if (!ob || !L || ob.hide) { gxTc.detach(); gxTc.visible = false; return; }
  gxTc.visible = true; gxTc.showX = gxTc.showY = gxTc.showZ = true; gxTc.setSpace("world"); gxTc.size = 0.9;
  if (G.mode === "pose" && ob.type === "char") { const j = L.ch.joints[G.joint]; gxTc.setMode("rotate"); gxTc.setSpace("local"); gxTc.size = 0.7; gxTc.attach(j); }
  else if (G.mode === "turn") { gxTc.setMode("rotate"); if (ob.type === "char") { gxTc.showX = gxTc.showZ = false; } else gxTc.setSpace("local"); gxTc.attach(L.root); }
  else if (G.mode === "scale") { gxTc.setMode("scale"); gxTc.setSpace("local"); gxTc.attach(L.root); }
  else { gxTc.setMode("translate"); gxTc.attach(L.root); }
  gxDirty = true;
}
const _gq = new THREE.Euler();
function gxReadGizmo() { // what the gizmo moved -> the project
  const ob = gxSelObj(), L = ob && gxLive.get(ob.id); if (!ob || !L) return;
  if (G.mode === "pose" && ob.type === "char") { const g = L.ch.joints[G.joint]; _gq.setFromQuaternion(g.quaternion, "XYZ"); ob.pose[G.joint] = [_gq.x, _gq.y, _gq.z].map(v => R.round(v / DEG, 2));
    if (G.joint === "Torso") { const piv = R.PIVOT.Torso; ob.tp = [g.position.x - piv[0], g.position.y - piv[1], g.position.z - piv[2]].map(v => R.round(v, 3)); } return; }
  ob.p = L.root.position.toArray().map(v => R.round(v, 3));
  if (ob.type === "char") { ob.yaw = R.round(L.root.rotation.y / DEG, 2); if (G.mode === "scale") { const s = (L.root.scale.x + L.root.scale.y + L.root.scale.z) / 3; ob.s = R.round(clamp(s, 0.05, 50), 3); L.root.scale.setScalar(ob.s); } }
  else { const e = new THREE.Euler().setFromQuaternion(L.root.quaternion, "YXZ"); ob.r = [e.x, e.y, e.z].map(v => R.round(v / DEG, 2));
    if (ob.type === "part") ob.s = L.root.scale.toArray().map(v => R.round(clamp(Math.abs(v), 0.05, 3000), 3));
    else { const s = (L.root.scale.x + L.root.scale.y + L.root.scale.z) / 3; ob.s = R.round(clamp(s, 0.05, 200), 3); if (G.mode === "scale") L.root.scale.setScalar(ob.s); } }
}
// ---- adding things
function gxDropPoint() { // where something new goes: on the ground under the middle of the frame, a little apart from the last
  const ray = new THREE.Raycaster(); ray.setFromCamera(new THREE.Vector2(0, -0.1), gxCam); const pl = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0), at = new THREE.Vector3();
  if (!ray.ray.intersectPlane(pl, at) || at.distanceTo(gxCam.position) > 80) at.set(gxOrbit.target.x, 0, gxOrbit.target.z);
  const k = G.addN++ % 6, off = [0, 3, -3, 6, -6, 1.5][k]; const side = new THREE.Vector3(); gxCam.getWorldDirection(side); side.cross(new THREE.Vector3(0, 1, 0)).normalize();
  return at.addScaledVector(side, off);
}
function gxFacingYaw(x, z) { return R.round(Math.atan2(-(gxCam.position.x - x), -(gxCam.position.z - z)) / DEG, 1); }
function gxAddObj(o, keepPlace) {
  const at = keepPlace ? null : gxDropPoint(); const ob = gxCleanObj(o); if (!ob) return;
  if (at) { ob.p = [R.round(at.x, 2), ob.type === "fx" || ob.type === "part" ? (o.p ? o.p[1] : 0) : 0, R.round(at.z, 2)]; if (ob.type === "char") ob.yaw = gxFacingYaw(ob.p[0], ob.p[2]); }
  gxChange(() => { G.p.objs.push(ob); }); gxSelect("o", ob.id);
}
function gxAddLayer(L) { const x = gxCleanLayer(L); if (!x) return; gxChange(() => { G.p.layers.push(x); }); gxSelect("l", x.id); }
function gxDeleteSel() {
  const o = gxSelObj(), l = gxSelLayer(); if (!o && !l) return;
  gxChange(() => { if (o) G.p.objs = G.p.objs.filter(x => x !== o); else G.p.layers = G.p.layers.filter(x => x !== l); });
  G.sel = null; gxAfter({ insp: true }); toast("Deleted (Ctrl Z brings it back)");
}
function gxDuplicateSel() {
  const o = gxSelObj(), l = gxSelLayer();
  if (o) { const c = gxCleanObj(Object.assign(JSON.parse(JSON.stringify(o)), { id: vxId(), env: false })); c.p = [o.p[0] + 2.5, o.p[1], o.p[2]]; gxChange(() => G.p.objs.push(c)); gxSelect("o", c.id); }
  else if (l) { const c = gxCleanLayer(Object.assign(JSON.parse(JSON.stringify(l)), { id: vxId() })); c.x += 0.03; c.y += 0.03; gxChange(() => G.p.layers.push(c)); gxSelect("l", c.id); }
}
function gxMoveLayer(d) { const l = gxSelLayer(); if (!l) return; const i = G.p.layers.indexOf(l), j = clamp(i + d, 0, G.p.layers.length - 1); if (i === j) return;
  gxChange(() => { G.p.layers.splice(i, 1); G.p.layers.splice(j, 0, l); }, { insp: true }); }
function gxFocusSel() { // the camera turns to the selection
  const o = gxSelObj(), L = o && gxLive.get(o.id); if (!L) return; const b = new THREE.Box3().setFromObject(L.root); if (b.isEmpty()) return;
  const c = b.getCenter(new THREE.Vector3()), r = Math.max(2, b.getSize(new THREE.Vector3()).length() * 0.6), dir = gxCam.position.clone().sub(gxOrbit.target).normalize();
  gxPushUndo(); gxOrbit.target.copy(c); gxCam.position.copy(c).addScaledVector(dir, r / Math.tan(G.p.cam.fov * DEG / 2) * 0.9); gxOrbit.update(); gxCamToProject(); gxAfter({ scene: false });
}
function gxCamPreset(key) {
  const sel = gxSelObj(), ch = sel && sel.type === "char" ? sel : G.p.objs.find(o => o.type === "char" && !o.hide);
  const c = ch ? new THREE.Vector3(ch.p[0], ch.p[1], ch.p[2]) : new THREE.Vector3(0, 0, 0), s = ch ? ch.s : 1, yaw = (ch ? ch.yaw : 0) * DEG;
  const fwd = new THREE.Vector3(-Math.sin(yaw), 0, -Math.cos(yaw)), side = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
  const at = (f, sd, up, ty, fov, roll) => { G.p.cam.p = c.clone().addScaledVector(fwd, f * s).addScaledVector(side, sd * s).add(new THREE.Vector3(0, up * s, 0)).toArray().map(v => R.round(v, 3));
    G.p.cam.t = c.clone().add(new THREE.Vector3(0, ty * s, 0)).toArray().map(v => R.round(v, 3)); G.p.cam.fov = fov; G.p.cam.roll = roll || 0; };
  const k = { front: [15, 4, 4.2, 3.3, 38], hero: [9.5, 3, 1.4, 3.9, 50], close: [5.2, 1.2, 4.9, 4.3, 36], wide: [24, 10, 8, 3, 42], side: [2, 14, 3.6, 3.3, 38], high: [9, 3, 13, 2.5, 42], dutch: [10, -3.2, 2.6, 3.6, 46, 10] }[key];
  if (!k) return; gxChange(() => at(...k), { cam: true, insp: true });
}
// ---- picking with the mouse: design layers first (they're on top), then the 3D scene; dragging empty space orbits
let gxDrag = null, gxSnapGuide = null, gxDown = null;
function gxFramePt(e) { const r = gxOut.getBoundingClientRect(); return { x: (e.clientX - r.left) * gxOut.width / r.width, y: (e.clientY - r.top) * gxOut.height / r.height, nx: (e.clientX - r.left) / r.width * 2 - 1, ny: -((e.clientY - r.top) / r.height * 2 - 1) }; }
function gxPick3D(nx, ny) {
  const ray = new THREE.Raycaster(); ray.setFromCamera(new THREE.Vector2(nx, ny), gxCam); ray.camera = gxCam;
  const hits = ray.intersectObjects(gxWorld.children, true);
  for (const h of hits) { let vis = true; for (let q = h.object; q; q = q.parent) if (!q.visible) { vis = false; break; } if (!vis) continue;
    const id = h.object.userData.objId; if (!id) continue; return { id, joint: h.object.userData.joint || null }; }
  return null;
}
function gxBindStage() {
  const fr = $("gxFrame");
  fr.addEventListener("pointerdown", e => {
    if (e.button !== 0) return; const pt = gxFramePt(e); gxDown = { x: e.clientX, y: e.clientY, axis: gxTc && gxTc.axis };
    if (gxTc && gxTc.axis && gxTc.object) return; // the gizmo's own drag
    const sl = gxSelLayer(), hb = sl && !sl.lock ? gxHandleAt(gxBoxes.get(sl.id), pt.x, pt.y, gxPR) : null;
    const hit = hb ? sl : gxHitLayer(G.p, pt.x, pt.y);
    if (!hit) return; // the 3D scene (orbit, gizmo, click to pick)
    e.preventDefault(); e.stopImmediatePropagation(); fr.setPointerCapture(e.pointerId);
    if (!sl || sl.id !== hit.id) gxSelect("l", hit.id);
    const b = gxBoxes.get(hit.id), W = gxOut.width, H = gxOut.height;
    gxDrag = { L: hit, mode: hb || "move", x0: pt.x, y0: pt.y, lx: hit.x, ly: hit.y, rot0: hit.rot, size0: hit.type === "text" ? hit.size : hit.h, d0: b ? Math.hypot(pt.x - b.cx, pt.y - b.cy) : 1, a0: b ? Math.atan2(pt.y - b.cy, pt.x - b.cx) : 0, cx: b ? b.cx : hit.x * W, cy: b ? b.cy : hit.y * H, pushed: false };
  }, true);
  fr.addEventListener("pointermove", e => {
    if (!gxDrag) return; const d = gxDrag, L = d.L, pt = gxFramePt(e), W = gxOut.width, H = gxOut.height;
    if (!d.pushed) { if (Math.hypot(pt.x - d.x0, pt.y - d.y0) < 2) return; gxPushUndo(); d.pushed = true; }
    gxSnapGuide = null;
    if (d.mode === "move") { let x = d.lx + (pt.x - d.x0) / W, y = d.ly + (pt.y - d.y0) / H;
      if (!e.altKey && L.type !== "overlay") { const sx = Math.abs(x - 0.5) * W < 8 * gxPR, sy = Math.abs(y - 0.5) * H < 8 * gxPR; if (sx) x = 0.5; if (sy) y = 0.5; if (sx || sy) gxSnapGuide = { x: sx, y: sy }; }
      L.x = R.round(x, 4); L.y = R.round(y, 4); }
    else if (d.mode === "scale") { const k = Math.max(0.05, Math.hypot(pt.x - d.cx, pt.y - d.cy) / Math.max(1, d.d0)); const v = R.round(clamp(d.size0 * k, 0.01, 4), 4); if (L.type === "text") L.size = v; else L.h = v; }
    else if (d.mode === "rot") { let a = d.rot0 + (Math.atan2(pt.y - d.cy, pt.x - d.cx) - Math.atan2(d.y0 - d.cy, d.x0 - d.cx)) / DEG; if (e.shiftKey) a = Math.round(a / 15) * 15; else if (Math.abs(a) < 2.5) a = 0; L.rot = R.round(((a + 540) % 360) - 180, 2); }
    gxDirty = true;
  });
  const end = e => { if (!gxDrag) return; const moved = gxDrag.pushed; gxDrag = null; gxSnapGuide = null; try { fr.releasePointerCapture(e.pointerId); } catch (x) {} if (moved) gxAfter({ insp: true, scene: false }); else gxDirty = true; };
  fr.addEventListener("pointerup", end); fr.addEventListener("pointercancel", end);
  // a click (no drag) on the 3D view picks what's under it; a click on the selected character picks the part (to pose it)
  gxOut.addEventListener("pointerup", e => {
    if (!gxDown || e.button !== 0) return; const moved = Math.hypot(e.clientX - gxDown.x, e.clientY - gxDown.y) > 4, axis = gxDown.axis; gxDown = null;
    if (moved || axis || gxTcDragged) { gxTcDragged = false; return; }
    const pt = gxFramePt(e), hit = gxPick3D(pt.nx, pt.ny);
    if (!hit) { if (G.sel) gxSelect(null); return; }
    const cur = gxSelObj(), ob = G.p.objs.find(o => o.id === hit.id);
    if (cur && cur.id === hit.id && ob && ob.type === "char" && hit.joint) { gxSelect("o", hit.id, { joint: hit.joint }); return; }
    gxSelect("o", hit.id);
  });
  fr.addEventListener("dblclick", e => { const sl = gxSelLayer(); if (sl && sl.type === "text") { const t = $("gxTextIn"); if (t) { t.focus(); t.select(); } } });
  // dropping files: images become layers, 3D models go in the scene
  const st = $("gxStage");
  st.addEventListener("dragover", e => { if (e.dataTransfer && [...e.dataTransfer.types].includes("Files")) { e.preventDefault(); st.classList.add("drop"); } });
  st.addEventListener("dragleave", e => { if (e.target === st) st.classList.remove("drop"); });
  st.addEventListener("drop", e => { e.preventDefault(); st.classList.remove("drop"); for (const f of e.dataTransfer.files) gxImportAny(f); });
}
let gxTcDragged = false;
function gxStartControls() {
  gxOrbit = new THREE.OrbitControls(gxCam, gxOut); gxOrbit.enableDamping = !reduceMotion; gxOrbit.dampingFactor = 0.14; gxOrbit.minDistance = 1; gxOrbit.maxDistance = 600; gxOrbit.screenSpacePanning = true;
  gxOrbit.addEventListener("start", () => gxPushUndo("cam"));
  gxOrbit.addEventListener("end", () => { gxCamToProject(); gxSaveSoon(); });
  gxOrbit.addEventListener("change", () => { gxDirty = true; });
  gxTc = new THREE.TransformControls(gxCam, gxOut); gxHelpers.add(gxTc);
  gxTc.addEventListener("dragging-changed", e => {
    gxOrbit.enabled = !e.value && !G.lockCam;
    if (e.value) { gxPushUndo(); gxTcDragged = true; } else { gxReadGizmo(); gxAfter({ insp: true, mode: false }); }
  });
  gxTc.addEventListener("objectChange", () => { gxReadGizmo(); gxDirty = true; gxUpdateNumbers(); });
  gxTc.addEventListener("change", () => { gxDirty = true; });
}
// ---- importing files
const gxIsModel = f => /\.(glb|gltf|obj)$/i.test(f.name || "");
async function gxUploadImage(f) { // -> an asset id (images are stored with the page / in the Farshtah folder)
  if (!assets) throw new Error("no storage");
  const type = f.type || mimeOf(f.name || "") || "image/png"; if (!/^image\/(png|jpeg|webp|gif)$/.test(type)) throw new Error("type");
  const up = await assets.upload(f, { type }); G.recent = [up.id].concat(G.recent.filter(x => x !== up.id)).slice(0, 24); return up.id;
}
async function gxImportAny(f) {
  if (gxIsModel(f)) return gxImportModel(f);
  if (!/^image\//.test(f.type || mimeOf(f.name || ""))) return toast("Use a PNG, JPEG, GLB or OBJ");
  try { const id = await gxUploadImage(f); const e = gxImage(id); await new Promise(r => { if (e.ok || e.failed) r(); else e.waiters.push(r); });
    const asp = e.ok ? e.img.naturalWidth / Math.max(1, e.img.naturalHeight) : 1, [W, H] = GX_SIZES[G.p.size];
    gxAddLayer({ type: "image", asset: id, name: String(f.name || "Image").replace(/\.[a-z0-9]+$/i, "").slice(0, 40), h: clamp(0.5 / Math.max(1, asp * H / W), 0.05, 0.8), x: 0.5, y: 0.5 });
  } catch (e) { toast("Couldn't import that image"); }
}
async function gxImportModel(f) {
  const fmt = /\.obj$/i.test(f.name) ? "obj" : "glb", buf = await f.arrayBuffer();
  let g; try { g = await gxParseModel(buf, fmt); } catch (e) { return toast(/\.gltf$/i.test(f.name) ? "Use a .glb (a .gltf with separate files can't load)" : "Couldn't read that model"); }
  let id = null;
  if (assets) { try { const up = await assets.upload(new Blob([buf], { type: "application/octet-stream" }), { type: "application/octet-stream" }); id = up.id; } catch (e) { id = null; } }
  if (!id) { id = "tmp:" + vxId(); toast("Model added for this visit only"); }
  gxImports.set(id, g); gxAddObj({ type: "import", asset: id, fmt, name: String(f.name || "Model").replace(/\.[a-z0-9]+$/i, "").slice(0, 40), p: [0, 0, 0], r: [0, 0, 0], s: 1 });
}
function gxPickFile(accept, then) { const inp = make("input", { type: "file", accept }); inp.onchange = () => { if (inp.files && inp.files[0]) then(inp.files[0]); }; inp.click(); }
// ---- export
async function gxRenderImage(o) { // -> a canvas of the finished picture at its export size
  const [W, H] = o.dims, maxS = Math.min(gxR.capabilities.maxTextureSize || 8192, 8192), ss = clamp(Math.floor(Math.min(o.ss || 2, maxS / Math.max(W, H))), 1, 3);
  const w = W * ss, h = H * ss, big = document.createElement("canvas"); big.width = w; big.height = h;
  const keep = gxTc ? gxTc.visible : false; if (gxTc) gxTc.visible = false;
  gxCamPose(); gxCam.aspect = W / H; gxCam.updateProjectionMatrix();
  gxCompose(G.p, big.getContext("2d"), w, h, { export: true, transparent: o.transparent, noText: o.noText });
  if (gxTc) gxTc.visible = keep;
  let out = big; if (ss > 1) { out = document.createElement("canvas"); out.width = W; out.height = H; const c = out.getContext("2d"); c.imageSmoothingEnabled = true; c.imageSmoothingQuality = "high"; c.drawImage(big, 0, 0, W, H); }
  gxDirty = true; return out;
}
const gxFileName = ext => (G.p.name || "thumbnail").replace(/[\\/:*?"<>|]+/g, " ").trim().slice(0, 80) + "." + ext;
async function gxSaveImage(blob, name) {
  if (HOST.saveRender) { try { const r = await HOST.saveRender(blob, name); toast("Saved: Farshtah\\renders\\" + (r && r.file || name)); return; } catch (e) { toast("Couldn't save it"); return; } }
  try { const dl = window.claude && window.claude.use ? await window.claude.use("downloads") : null; if (dl) { await dl.save({ filename: name, data: blob }); return; } } catch (e) {}
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}
async function gxCopyImage(o) {
  try { const cv = await gxRenderImage(o), blob = await new Promise(r => cv.toBlob(r, "image/png"));
    await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]); toast("Copied: paste it into Photoshop or ChatGPT"); }
  catch (e) { toast("Couldn't copy the picture here. Use Export instead."); }
}
