// ======================================================================= Visuals+: the texture presets and the sample effects
// Each preset is drawn here in white on transparent, so an effect's Color tints it the way Roblox tints a particle. A
// flipbook (fire, lightning) is a grid of frames, as Roblox's FlipbookLayout reads it.
function vxRand(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
function vxNoise(seed, cells) { // smooth value noise on a wrapping grid: n(x, y) with x, y in 0..1
  const r = vxRand(seed), g = Array.from({ length: cells * cells }, r);
  const at = (i, j) => g[((j % cells + cells) % cells) * cells + ((i % cells + cells) % cells)];
  const sm = t => t * t * (3 - 2 * t);
  return (x, y) => { const fx = x * cells, fy = y * cells, i = Math.floor(fx), j = Math.floor(fy), u = sm(fx - i), v = sm(fy - j);
    return (at(i, j) * (1 - u) + at(i + 1, j) * u) * (1 - v) + (at(i, j + 1) * (1 - u) + at(i + 1, j + 1) * u) * v; };
}
function vxFbm(seed) { const o = [vxNoise(seed, 4), vxNoise(seed + 1, 8), vxNoise(seed + 2, 16), vxNoise(seed + 3, 32)];
  return (x, y) => (o[0](x, y) * 0.5 + o[1](x, y) * 0.27 + o[2](x, y) * 0.15 + o[3](x, y) * 0.08); }
function vxPixels(c, S, f) { // f(u, v) -> alpha 0..1 (white), u, v in -1..1
  const img = c.createImageData(S, S), d = img.data;
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
    const a = clamp(f((x + 0.5) / S * 2 - 1, (y + 0.5) / S * 2 - 1), 0, 1), i = (y * S + x) * 4;
    d[i] = d[i + 1] = d[i + 2] = 255; d[i + 3] = Math.round(a * 255);
  }
  c.putImageData(img, 0, 0);
}
const sstep = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
function vxBolt(c, x0, y0, x1, y1, w, rnd, depth) { // a jagged lightning line with a soft glow, then a branch or two
  const pts = [[x0, y0]], n = 14;
  for (let i = 1; i < n; i++) { const t = i / n; pts.push([x0 + (x1 - x0) * t + (rnd() - 0.5) * w * 9 * (1 - Math.abs(t - 0.5)), y0 + (y1 - y0) * t + (rnd() - 0.5) * w * 2]); }
  pts.push([x1, y1]);
  const stroke = (lw, a) => { c.strokeStyle = `rgba(255,255,255,${a})`; c.lineWidth = lw; c.lineJoin = "round"; c.lineCap = "round"; c.beginPath(); pts.forEach((p, i) => (i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]))); c.stroke(); };
  stroke(w * 5, 0.12); stroke(w * 2.6, 0.3); stroke(w, 1);
  if (depth > 0) for (let b = 0; b < 2; b++) {
    const k = 3 + Math.floor(rnd() * (n - 6)), p = pts[k], ang = Math.atan2(y1 - y0, x1 - x0) + (rnd() < 0.5 ? -1 : 1) * (0.5 + rnd() * 0.6), L = Math.hypot(x1 - x0, y1 - y0) * (0.18 + rnd() * 0.2);
    vxBolt(c, p[0], p[1], p[0] + Math.cos(ang) * L, p[1] + Math.sin(ang) * L, w * 0.55, rnd, depth - 1);
  }
}
const VX_TEX = [ // key, name, flipbook layout, size, draw(ctx, size)
  ["glow", "Soft glow", "None", 256, (c, S) => vxPixels(c, S, (u, v) => { const r = Math.hypot(u, v); return Math.pow(Math.max(0, 1 - r), 2.2); })],
  ["dot", "Dot", "None", 256, (c, S) => vxPixels(c, S, (u, v) => { const r = Math.hypot(u, v); return Math.max(1 - sstep(0.16, 0.24, r), Math.pow(Math.max(0, 1 - r), 3) * 0.75); })],
  ["spark", "Spark", "None", 256, (c, S) => vxPixels(c, S, (u, v) => { const ay = Math.abs(v), w = 0.07 * (1 - ay * 0.75); return (1 - sstep(w * 0.4, w, Math.abs(u))) * Math.pow(1 - ay, 1.4) + Math.pow(Math.max(0, 1 - Math.hypot(u * 3.2, v * 1.2)), 3) * 0.35; })],
  ["star", "Star", "None", 256, (c, S) => vxPixels(c, S, (u, v) => { const r = Math.hypot(u, v), a = Math.abs(u), b = Math.abs(v);
    const ray = (x, y) => Math.max(0, 1 - y) * Math.exp(-Math.pow(x / (0.035 + 0.06 * (1 - y)), 2));
    return Math.min(1, ray(a, b) + ray(b, a) + 0.45 * (ray(Math.abs(u + v) * 0.7071, Math.abs(u - v) * 0.7071 * 1.6) + ray(Math.abs(u - v) * 0.7071, Math.abs(u + v) * 0.7071 * 1.6)) + Math.pow(Math.max(0, 1 - r * 2.2), 2)); })],
  ["flare", "Flare", "None", 256, (c, S) => vxPixels(c, S, (u, v) => { const r = Math.hypot(u, v), th = Math.atan2(v, u), rays = Math.pow(Math.abs(Math.cos(th * 3)), 40) * Math.max(0, 1 - r) * 0.9;
    return Math.min(1, Math.pow(Math.max(0, 1 - r * 1.8), 2) + rays + Math.pow(Math.max(0, 1 - r), 3) * 0.4); })],
  ["ring", "Ring", "None", 256, (c, S) => vxPixels(c, S, (u, v) => { const r = Math.hypot(u, v); return Math.exp(-Math.pow((r - 0.78) / 0.06, 2)) + Math.exp(-Math.pow((r - 0.78) / 0.16, 2)) * 0.3; })],
  ["shock", "Shockwave", "None", 256, (c, S) => vxPixels(c, S, (u, v) => { const r = Math.hypot(u, v); return r > 0.95 ? Math.max(0, 1 - (r - 0.95) / 0.04) : Math.pow(sstep(0.35, 0.95, r), 2.4); })],
  ["slash", "Slash", "None", 256, (c, S) => { const f = vxFbm(7); vxPixels(c, S, (u, v) => {
    const r = Math.hypot(u, v * 1.02 + 0.08), th = Math.atan2(-v, u), k = clamp((th + 0.25) / 2.9, 0, 1); // the arc runs from the right, over the top
    if (th < -0.35 || th > 2.75) return 0;
    const w = 0.02 + 0.17 * Math.sin(k * Math.PI) * (0.4 + 0.6 * k), edge = 0.82, d = edge - r;
    return d < -0.02 || d > w ? 0 : (d < 0 ? 1 + d / 0.02 : Math.pow(1 - d / w, 1.6)) * (0.75 + 0.5 * f(u * 0.5 + 0.5, v * 0.5 + 0.5)) * Math.min(1, k * 4); }); }],
  ["smoke", "Smoke", "None", 256, (c, S) => { const f = vxFbm(21); vxPixels(c, S, (u, v) => { const r = Math.hypot(u, v), n = f(u * 0.5 + 0.5, v * 0.5 + 0.5);
    return Math.pow(Math.max(0, 1 - r), 1.2) * sstep(0.32, 0.72, n + (1 - r) * 0.35) * 0.95; }); }],
  ["dust", "Dust", "None", 256, (c, S) => { const f = vxFbm(33); vxPixels(c, S, (u, v) => { const r = Math.hypot(u, v * 1.15), n = f(u * 0.5 + 0.5, v * 0.5 + 0.5);
    return Math.pow(Math.max(0, 1 - r), 1.6) * (0.35 + n * 0.9); }); }],
  ["fire", "Fire", "Grid4x4", 512, (c, S) => { // 16 frames of a rising flame
    const cell = S / 4, img = c.createImageData(S, S), d = img.data, f = vxFbm(51);
    for (let k = 0; k < 16; k++) { const ox = (k % 4) * cell, oy = Math.floor(k / 4) * cell, t = k / 16;
      for (let y = 0; y < cell; y++) for (let x = 0; x < cell; x++) {
        const u = (x + 0.5) / cell * 2 - 1, v = (y + 0.5) / cell * 2 - 1, h = 1 - (v + 1) / 2; // h: 0 bottom -> 1 top
        const n = f(u * 0.35 + 0.5, (v * 0.5 + 0.5) * 0.7 + t), wob = (n - 0.5) * 0.55 * h;
        const width = 0.62 * Math.pow(1 - h, 0.55) * (1 - h * 0.15), core = Math.abs(u + wob) / Math.max(width, 0.001);
        let a = (1 - sstep(0.55, 1, core)) * sstep(0, 0.12, h + 0.05) * (1 - sstep(0.55 + n * 0.35, 1, h));
        a *= 0.65 + 0.6 * n;
        const i = ((oy + y) * S + ox + x) * 4; d[i] = d[i + 1] = d[i + 2] = 255; d[i + 3] = Math.round(clamp(a, 0, 1) * 255);
      } }
    c.putImageData(img, 0, 0); }],
  ["lightning", "Lightning", "Grid2x2", 512, (c, S) => { const cell = S / 2, rnd = vxRand(77);
    for (let k = 0; k < 4; k++) { const ox = (k % 2) * cell, oy = Math.floor(k / 2) * cell; c.save(); c.beginPath(); c.rect(ox, oy, cell, cell); c.clip();
      vxBolt(c, ox + cell * (0.42 + rnd() * 0.16), oy + cell * 0.02, ox + cell * (0.4 + rnd() * 0.2), oy + cell * 0.98, cell * 0.012, rnd, 2); c.restore(); } }],
  ["wind", "Wind", "None", 256, (c, S) => vxPixels(c, S, (u, v) => { const ay = (v + 1) / 2, x = u - 0.25 * Math.sin(ay * Math.PI) ; const w = 0.035 + 0.05 * Math.sin(ay * Math.PI);
    return (1 - sstep(w * 0.3, w, Math.abs(x))) * Math.pow(Math.sin(ay * Math.PI), 0.8); })],
  ["petal", "Petal", "None", 256, (c, S) => vxPixels(c, S, (u, v) => { const x = u / (0.55 * Math.sqrt(Math.max(0, 1 - v * v)) + 1e-3); const a = 1 - sstep(0.85, 1, Math.abs(x));
    return a * (1 - sstep(0.88, 1, Math.abs(v))) * (0.75 + 0.25 * (1 - Math.abs(x))); })],
  ["plus", "Plus", "None", 256, (c, S) => vxPixels(c, S, (u, v) => { const a = Math.abs(u), b = Math.abs(v); const bar = (x, y) => (1 - sstep(0.2, 0.26, x)) * (1 - sstep(0.62, 0.7, y));
    return Math.max(bar(a, b), bar(b, a)) + Math.pow(Math.max(0, 1 - Math.hypot(u, v)), 2) * 0.3; })],
  ["square", "Square", "None", 256, (c, S) => vxPixels(c, S, (u, v) => (1 - sstep(0.6, 0.72, Math.max(Math.abs(u), Math.abs(v)))))],
  ["circle", "Circle", "None", 256, (c, S) => vxPixels(c, S, (u, v) => 1 - sstep(0.9, 0.97, Math.hypot(u, v)))],
  ["shard", "Shard", "None", 256, (c, S) => vxPixels(c, S, (u, v) => { const d = Math.abs(u) / 0.3 + Math.abs(v) / 0.95; return (1 - sstep(0.88, 1, d)) * (0.7 + 0.3 * (1 - Math.abs(u) / 0.3)); })],
  ["beam", "Energy beam", "None", 256, (c, S) => { const f = vxFbm(91); vxPixels(c, S, (u, v) => { const n = f(u * 0.5 + 0.5, v * 0.15 + 0.5); const w = 0.22 + 0.2 * n;
    return Math.min(1, Math.exp(-Math.pow(v / w, 2)) * (0.6 + 0.6 * n) + Math.exp(-Math.pow(v / 0.06, 2))); }); }],
  ["bolt", "Electric beam", "None", 256, (c, S) => { const rnd = vxRand(5); for (let i = 0; i < 2; i++) vxBolt(c, 0, S * (0.5 + (rnd() - 0.5) * 0.2), S, S * (0.5 + (rnd() - 0.5) * 0.2), S * 0.014, rnd, 0);
  }],
];
const VX_TEX_MAP = new Map(VX_TEX.map(t => [t[0], { key: t[0], name: t[1], grid: t[2], size: t[3], draw: t[4] }]));
// beams read a texture along their length (left -> right), so the ones made for beams lie sideways
const VX_BEAM_TEX = ["beam", "bolt", "glow", "spark", "wind"];

// ---- samples: a starting point for every common kind of effect (each opens as a copy you can change)
function vxSamples() {
  const P = o => vxLayer("particles", o), M = o => vxLayer("mesh", o), B = o => vxLayer("beam", o);
  const C = (...cs) => cs.map((c, i) => [cs.length > 1 ? i / (cs.length - 1) : 0, c]).concat(cs.length === 1 ? [[1, cs[0]]] : []);
  const fade = [[0, 0, 0], [1, 1, 0]], shrink = v => [[0, v, 0], [1, 0, 0]];
  return [
    { key: "impact", name: "Impact", tint: "#ffb347", where: "chest", effect: { name: "Impact", bloom: { on: true, intensity: 1, size: 24, threshold: 2 },
      cam: { shake: [0.6, 0.25, 0], fov: [3, 0.25, 0], flash: [0.25, 0.14, 0], flashColor: "#fff3d6", hitstop: [0.06, 0] }, layers: [
      P({ name: "Flash", tex: "glow", count: 1, rate: 0, life: [0.16, 0.16], speed: [0, 0], size: [[0, 1.5, 0], [0.3, 4.5, 0], [1, 5, 0]], transp: [[0, 0.15, 0], [1, 1, 0]], color: C("#ffffff", "#ffd38a"), light: 1, bright: 1.6, z: 1 }),
      P({ name: "Sparks", tex: "spark", count: 26, life: [0.25, 0.45], speed: [35, 60], spread: [180, 180], drag: 6, orient: "VelocityParallel", size: shrink(0.6),
        squash: [[0, 1.6, 0], [1, 1.6, 0]], color: C("#ffffff", "#ffb347", "#ff5a1f"), light: 1, bright: 2, accel: [0, -30, 0] }),
      M({ name: "Ring", shape: "Ring", color: "#ffbf5e", r: [90, 0, 0], start: { size: [1, 0.12, 1], p: [0, 0, 0], r: [0, 0, 0] }, end: { size: [8, 0.04, 8], p: [0, 0, 0], r: [0, 0, 0] },
        morph: 0.3, life: 0.3, ease: ["Quart", "Out"], tease: ["Quad", "In"] }),
      P({ name: "Shards", tex: "shard", count: 8, speed: [18, 30], spread: [180, 180], life: [0.3, 0.5], drag: 3, orient: "VelocityParallel", size: shrink(0.7), color: C("#ffffff", "#ffd38a"), light: 0.6 }),
      P({ name: "Smoke", tex: "smoke", count: 6, life: [0.6, 0.9], speed: [3, 6], spread: [180, 180], drag: 2, size: [[0, 1.5, 0.3], [1, 4, 0.5]], transp: [[0, 0.5, 0], [1, 1, 0]],
        color: C("#bbbbbb", "#555555"), light: 0, rot: [0, 360], rotSpeed: [-60, 60] })] } },
    { key: "slash", name: "Slash", tint: "#7fd8ff", where: "chest", effect: { name: "Slash", bloom: { on: true, intensity: 1, size: 24, threshold: 2 }, cam: { shake: [0.25, 0.15, 0.03] }, layers: [
      P({ name: "Arc", tex: "slash", count: 1, life: [0.28, 0.28], speed: [0, 0], size: [[0, 4, 0], [0.3, 8, 0], [1, 9, 0]], transp: [[0, 0, 0], [0.5, 0.2, 0], [1, 1, 0]],
        color: C("#ffffff", "#7fd8ff", "#2f7bff"), light: 1, bright: 2.5, rot: [-35, -35], z: 1 }),
      P({ name: "Glint", tex: "star", count: 1, delay: 0.05, life: [0.2, 0.2], speed: [0, 0], p: [2.6, 1.6, 0], size: [[0, 0, 0], [0.3, 3, 0], [1, 0, 0]], transp: [[0, 0, 0], [1, 0.2, 0]], light: 1, bright: 3, z: 1.5 }),
      P({ name: "Sparks", tex: "spark", count: 12, dir: "Right", speed: [20, 35], spread: [40, 40], orient: "VelocityParallel", drag: 5, size: shrink(0.4), color: C("#ffffff", "#7fd8ff"), light: 1, bright: 2, life: [0.2, 0.4] })] } },
    { key: "shockwave", name: "Ground slam", tint: "#9ad7ff", where: "ground", effect: { name: "Ground slam", bloom: { on: true, intensity: 1, size: 24, threshold: 2 },
      cam: { shake: [1, 0.4, 0], fov: [4, 0.3, 0] }, layers: [
      M({ name: "Ring", shape: "Ring", color: "#9ad7ff", start: { size: [2, 0.3, 2], p: [0, 0.1, 0], r: [0, 0, 0] }, end: { size: [26, 0.1, 26], p: [0, 0.1, 0], r: [0, 0, 0] }, morph: 0.5, life: 0.5, ease: ["Quart", "Out"], tease: ["Quad", "In"] }),
      M({ name: "Inner ring", shape: "Ring", color: "#ffffff", delay: 0.08, start: { size: [1, 0.3, 1], p: [0, 0.1, 0], r: [0, 0, 0] }, end: { size: [16, 0.1, 16], p: [0, 0.1, 0], r: [0, 0, 0] }, morph: 0.4, life: 0.4, ease: ["Quart", "Out"], tease: ["Quad", "In"] }),
      P({ name: "Dust", tex: "dust", shape: "Disc", shapeSize: [6, 0.2, 6], count: 24, speed: [10, 16], drag: 3, accel: [0, 4, 0], life: [0.6, 1], size: [[0, 1.5, 0.4], [1, 4, 0.6]],
        transp: [[0, 0.4, 0], [1, 1, 0]], color: C("#d9c7a8", "#8a7a66"), light: 0, rot: [0, 360], rotSpeed: [-40, 40] }),
      P({ name: "Debris", tex: "shard", count: 14, speed: [16, 24], spread: [35, 35], accel: [0, -60, 0], life: [0.6, 0.9], rot: [0, 360], rotSpeed: [-360, 360], size: [[0, 0.5, 0], [1, 0.4, 0]],
        transp: [[0, 0, 0], [0.8, 0, 0], [1, 1, 0]], color: C("#6b5b4a"), light: 0 })] } },
    { key: "aura", name: "Aura", tint: "#9b5cff", where: "ground", effect: { name: "Aura", bloom: { on: true, intensity: 1, size: 24, threshold: 2 }, layers: [
      P({ name: "Flames", tex: "fire", flip: { layout: "Grid4x4", mode: "OneShot", fps: [30, 30], startRandom: false }, shape: "Box", shapeSize: [3, 0.4, 3],
        rate: 40, count: 0, duration: 2, speed: [4, 7], spread: [5, 5], life: [0.5, 0.8], size: [[0, 1.2, 0.3], [1, 2, 0.4]], transp: [[0, 1, 0], [0.15, 0.35, 0], [1, 1, 0]],
        color: C("#e7d6ff", "#a26bff", "#4a1fa8"), light: 1, bright: 1 }),
      P({ name: "Embers", tex: "dot", shape: "Box", shapeSize: [4, 4, 4], rate: 25, count: 0, duration: 2, speed: [2, 4], life: [0.8, 1.4], accel: [0, 3, 0], size: shrink(0.25), color: C("#e0c8ff"), light: 1, bright: 2 }),
      P({ name: "Glow", tex: "glow", p: [0, 3, 0], rate: 4, count: 1, duration: 2, speed: [0, 0], life: [0.6, 0.6], size: [[0, 6, 0], [1, 7, 0]], transp: [[0, 1, 0], [0.5, 0.75, 0], [1, 1, 0]], color: C("#9b5cff"), light: 1 }),
      M({ name: "Floor ring", shape: "Ring", color: "#b48cff", rate: 2, count: 1, duration: 2, start: { size: [4, 0.1, 4], p: [0, 0.05, 0], r: [0, 0, 0] }, end: { size: [6.5, 0.1, 6.5], p: [0, 0.05, 0], r: [0, 0, 0] },
        morph: 0.9, life: 0.9, t0: 0.3, t1: 1, spin: [120, 120], ease: ["Sine", "Out"], tease: ["Linear", "In"] })] } },
    { key: "lightning", name: "Lightning", tint: "#9fd8ff", where: "front", effect: { name: "Lightning", bloom: { on: true, intensity: 1, size: 24, threshold: 2 },
      cam: { shake: [0.8, 0.3, 0], flash: [0.5, 0.12, 0], flashColor: "#dff2ff" }, layers: [
      P({ name: "Bolt", tex: "lightning", flip: { layout: "Grid2x2", mode: "Random", fps: [24, 24], startRandom: true }, orient: "FacingCameraWorldUp", count: 1, life: [0.3, 0.3], speed: [0, 0],
        p: [0, 7, 0], size: [[0, 14, 0], [1, 14, 0]], transp: [[0, 0, 0], [0.7, 0, 0], [1, 1, 0]], color: C("#ffffff", "#9fd8ff"), light: 1, bright: 1.8 }),
      P({ name: "Bolt 2", tex: "lightning", flip: { layout: "Grid2x2", mode: "Random", fps: [24, 24], startRandom: true }, orient: "FacingCameraWorldUp", count: 1, delay: 0.08, life: [0.22, 0.22], speed: [0, 0],
        p: [0.6, 7, 0.4], size: [[0, 13, 0], [1, 13, 0]], transp: [[0, 0.2, 0], [1, 1, 0]], color: C("#cfeaff"), light: 1, bright: 2 }),
      P({ name: "Flash", tex: "glow", count: 1, p: [0, 0.5, 0], life: [0.25, 0.25], speed: [0, 0], size: [[0, 4, 0], [0.3, 10, 0], [1, 12, 0]], transp: fade, color: C("#cfe9ff"), light: 1, bright: 3 }),
      M({ name: "Ring", shape: "Ring", color: "#bfe6ff", start: { size: [1, 0.2, 1], p: [0, 0.1, 0], r: [0, 0, 0] }, end: { size: [14, 0.05, 14], p: [0, 0.1, 0], r: [0, 0, 0] }, morph: 0.35, life: 0.35, ease: ["Quart", "Out"], tease: ["Quad", "In"] }),
      P({ name: "Sparks", tex: "spark", count: 30, speed: [25, 45], spread: [70, 70], drag: 4, accel: [0, -40, 0], orient: "VelocityParallel", size: shrink(0.5), color: C("#ffffff", "#7fc8ff"), light: 1, bright: 2, life: [0.3, 0.6] })] } },
    { key: "heal", name: "Heal", tint: "#5dff8a", where: "ground", effect: { name: "Heal", bloom: { on: true, intensity: 0.8, size: 24, threshold: 2 }, layers: [
      P({ name: "Sparkles", tex: "star", shape: "Box", shapeSize: [3, 0.2, 3], rate: 20, count: 0, duration: 1.4, speed: [3, 5], spread: [10, 10], life: [0.8, 1.2],
        size: [[0, 0, 0], [0.3, 0.7, 0], [1, 0, 0]], transp: [[0, 0, 0], [1, 0, 0]], color: C("#e9ffe9", "#5dff8a"), light: 1, bright: 1.5, rotSpeed: [-90, 90] }),
      P({ name: "Plus", tex: "plus", shape: "Box", shapeSize: [3, 3, 3], rate: 4, count: 1, duration: 1.4, speed: [2, 3], life: [1, 1.2], size: [[0, 0, 0], [0.2, 0.7, 0], [1, 0.5, 0]],
        transp: [[0, 0, 0], [0.7, 0, 0], [1, 1, 0]], color: C("#7dffa0"), light: 0.8 }),
      M({ name: "Ring", shape: "Ring", color: "#6dff9a", rate: 1.2, count: 1, duration: 1.4, start: { size: [6, 0.1, 6], p: [0, 0.05, 0], r: [0, 0, 0] }, end: { size: [2.5, 0.1, 2.5], p: [0, 0.05, 0], r: [0, 0, 0] },
        morph: 0.8, life: 0.8, t0: 0.2, t1: 1, ease: ["Sine", "InOut"], tease: ["Quad", "In"] }),
      P({ name: "Glow", tex: "glow", p: [0, 2.5, 0], count: 1, rate: 1.5, duration: 1.4, speed: [0, 0], life: [0.9, 0.9], size: [[0, 5, 0], [1, 6, 0]], transp: [[0, 1, 0], [0.5, 0.8, 0], [1, 1, 0]], color: C("#5dff8a"), light: 1 })] } },
    { key: "explosion", name: "Explosion", tint: "#ff7a2f", where: "front", effect: { name: "Explosion", bloom: { on: true, intensity: 1, size: 24, threshold: 2 },
      cam: { shake: [1.2, 0.5, 0], fov: [6, 0.35, 0], flash: [0.35, 0.15, 0], flashColor: "#ffe2b8" }, layers: [
      M({ name: "Core", shape: "Sphere", color: "#ffb54d", t0: 0.15, start: { size: [1, 1, 1], p: [0, 2, 0], r: [0, 0, 0] }, end: { size: [7, 7, 7], p: [0, 2, 0], r: [0, 0, 0] }, morph: 0.25, life: 0.25, ease: ["Quad", "Out"], tease: ["Quad", "Out"] }),
      P({ name: "Fireball", tex: "fire", flip: { layout: "Grid4x4", mode: "OneShot", fps: [30, 30], startRandom: false }, p: [0, 2, 0], shape: "Sphere", shapeSize: [3, 3, 3], count: 14,
        speed: [4, 10], spread: [180, 180], drag: 2, life: [0.5, 0.8], size: [[0, 2, 0.5], [1, 5, 1]], transp: [[0, 0, 0], [0.6, 0.2, 0], [1, 1, 0]],
        color: C("#ffffff", "#ffb23d", "#ff3d1f", "#3a1a12"), light: 0.8, bright: 1.5, rot: [0, 360] }),
      P({ name: "Smoke", tex: "smoke", p: [0, 2, 0], count: 16, delay: 0.1, shape: "Sphere", shapeSize: [4, 4, 4], speed: [3, 7], spread: [180, 180], accel: [0, 5, 0], drag: 1, life: [1.2, 1.8],
        size: [[0, 3, 1], [1, 7, 1]], transp: [[0, 0.3, 0], [1, 1, 0]], color: C("#5a4a42", "#2a2522"), light: 0, rot: [0, 360], rotSpeed: [-30, 30] }),
      P({ name: "Sparks", tex: "spark", p: [0, 2, 0], count: 40, speed: [40, 70], spread: [180, 180], drag: 4, accel: [0, -50, 0], orient: "VelocityParallel", life: [0.4, 0.8], size: shrink(0.6), color: C("#ffffff", "#ffb347"), light: 1, bright: 2 }),
      M({ name: "Shock", shape: "Ring", color: "#ffd9a0", start: { size: [2, 0.3, 2], p: [0, 0.2, 0], r: [0, 0, 0] }, end: { size: [30, 0.1, 30], p: [0, 0.2, 0], r: [0, 0, 0] }, morph: 0.45, life: 0.45, ease: ["Quart", "Out"], tease: ["Quad", "In"] })] } },
    { key: "dash", name: "Dash", tint: "#dfe7f2", where: "torso", effect: { name: "Dash", bloom: { on: false, intensity: 1, size: 24, threshold: 2 }, layers: [
      P({ name: "Wind", tex: "wind", orient: "VelocityParallel", dir: "Back", shape: "Box", shapeSize: [3, 4, 1], count: 10, rate: 40, duration: 0.25, speed: [30, 45], spread: [3, 3], life: [0.15, 0.25],
        size: [[0, 0.5, 0], [1, 0.3, 0]], squash: [[0, 2, 0], [1, 2, 0]], transp: [[0, 0.3, 0], [1, 1, 0]], color: C("#ffffff"), light: 0.6 }),
      P({ name: "Dust", tex: "dust", dir: "Back", p: [0, -2.8, 0], count: 10, speed: [6, 10], spread: [30, 20], life: [0.4, 0.7], drag: 3, size: [[0, 1, 0], [1, 2.5, 0]],
        transp: [[0, 0.5, 0], [1, 1, 0]], color: C("#c9b79a"), light: 0, rot: [0, 360] })] } },
    { key: "charge", name: "Charge", tint: "#6fd3ff", where: "rhand", effect: { name: "Charge", bloom: { on: true, intensity: 1, size: 24, threshold: 2 },
      cam: { shake: [0.7, 0.25, 1.2], flash: [0.3, 0.12, 1.2], flashColor: "#dff5ff" }, layers: [
      P({ name: "Gather", tex: "spark", orient: "VelocityParallel", shape: "Sphere", shapeSize: [8, 8, 8], shapeStyle: "Surface", shapeInOut: "Inward", rate: 50, count: 0, duration: 1.2,
        speed: [8, 8], life: [0.5, 0.5], size: [[0, 0.15, 0], [1, 0.45, 0]], squash: [[0, 1.5, 0], [1, 1.5, 0]], color: C("#ffffff", "#6fd3ff"), light: 1, bright: 2 }),
      P({ name: "Orb", tex: "glow", count: 1, life: [1.25, 1.25], speed: [0, 0], size: [[0, 0.5, 0], [1, 4, 0]], transp: [[0, 0.3, 0], [1, 0, 0]], color: C("#bfeaff", "#3aa0ff"), light: 1, bright: 2 }),
      M({ name: "Rings", shape: "Ring", color: "#7fd8ff", r: [90, 0, 0], rate: 3, count: 1, duration: 1.1, start: { size: [6, 0.1, 6], p: [0, 0, 0], r: [0, 0, 0] }, end: { size: [1, 0.1, 1], p: [0, 0, 0], r: [0, 0, 0] },
        morph: 0.4, life: 0.4, t0: 0.5, t1: 0.2, ease: ["Quad", "In"], tease: ["Linear", "In"] }),
      M({ name: "Release", shape: "Sphere", material: "Neon", color: "#bfeaff", delay: 1.2, start: { size: [1, 1, 1], p: [0, 0, 0], r: [0, 0, 0] }, end: { size: [8, 8, 8], p: [0, 0, 0], r: [0, 0, 0] }, morph: 0.3, life: 0.3, ease: ["Quad", "Out"], tease: ["Quad", "In"] })] } },
    { key: "beam", name: "Energy beam", tint: "#ff5ad1", where: "rhand", effect: { name: "Energy beam", bloom: { on: true, intensity: 1, size: 24, threshold: 2 }, layers: [
      B({ name: "Beam", tex: "beam", a: [0, 0, 0], b: [0, 0, -18], width: [1.6, 2.4], texSpeed: 3, texLen: 6, texMode: "Wrap", color: C("#ffffff", "#ff5ad1"), light: 1, bright: 2, delay: 0, duration: 0.8 }),
      B({ name: "Core", tex: "bolt", a: [0, 0, 0], b: [0, 0, -18], width: [0.8, 1.2], texSpeed: 6, texLen: 4, texMode: "Wrap", color: C("#ffffff"), light: 1, bright: 3, delay: 0, duration: 0.8 }),
      P({ name: "Muzzle", tex: "glow", count: 1, rate: 10, duration: 0.8, life: [0.15, 0.15], speed: [0, 0], size: [[0, 3, 0], [1, 2, 0]], transp: fade, color: C("#ff9be6"), light: 1, bright: 2 }),
      P({ name: "Hit", tex: "spark", p: [0, 0, -18], rate: 60, count: 0, duration: 0.8, speed: [15, 25], spread: [70, 70], dir: "Back", orient: "VelocityParallel", drag: 4, life: [0.2, 0.35], size: shrink(0.4), color: C("#ffffff", "#ff5ad1"), light: 1, bright: 2 })] } },
  ];
}
