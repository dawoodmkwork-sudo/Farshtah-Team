# install.ps1 - installs Farshtah (the R6 animator) for this Windows user: no admin rights, nothing downloaded.
# Node.js runs the app's helper (server.js), which keeps your animations, references, backgrounds, models, settings and
# clips as files; Microsoft Edge shows the app in its own window. The Node.js used is the copy in node\ beside this
# script when there is one (the shareable package has it), otherwise the one already on the PC.
#   powershell -NoProfile -ExecutionPolicy Bypass -File install.ps1 [-AppDir <dir>] [-DataDir <dir>] [-NoShortcuts] [-Launch]
#   (-StateDir and -Port are for a side-by-side test install.)
# Running it again updates the app; your animations are never overwritten.
# It also replaces the earlier "R6 Animator" install, moving its data folder (Documents\R6 Animator) to Documents\Farshtah.
param(
  [string]$AppDir = (Join-Path $env:LOCALAPPDATA "Programs\Farshtah"),
  [string]$DataDir = (Join-Path ([Environment]::GetFolderPath("MyDocuments")) "Farshtah"),
  [string]$StateDir = (Join-Path $env:LOCALAPPDATA "Farshtah"),
  [int]$Port = 51735,
  [switch]$NoShortcuts,
  [switch]$Launch
)
$ErrorActionPreference = "Stop"
$src = Split-Path -Parent $MyInvocation.MyCommand.Path
$profileDir = Join-Path $StateDir "browser"

# ---- Node.js and Edge
$bundled = Join-Path $src "node\node.exe"
$node = $null
if (-not (Test-Path $bundled)) {
  $cmd = Get-Command node.exe -ErrorAction SilentlyContinue
  if ($cmd) { $node = $cmd.Source }
  if (-not $node) { foreach ($p in @("$env:ProgramFiles\nodejs\node.exe", "${env:ProgramFiles(x86)}\nodejs\node.exe")) { if (Test-Path $p) { $node = $p; break } } }
  if (-not $node) { throw "Node.js wasn't found. Install it from nodejs.org, then run this again." }
}
$edge = $null
foreach ($p in @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe")) { if (Test-Path $p) { $edge = $p; break } }
if (-not $edge) { Write-Warning "Microsoft Edge wasn't found: the app will open in your default browser instead." }

# ---- close a running copy: its windows first (politely, so a last change still saves), then its helper
function Stop-Copy([string]$state, [string]$prof) {
  $wins = @(Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -and $_.CommandLine.Contains($prof) })
  if ($wins.Count) {
    foreach ($w in $wins) { $p = Get-Process -Id $w.ProcessId -ErrorAction SilentlyContinue; if ($p -and $p.MainWindowHandle -ne 0) { [void]$p.CloseMainWindow() } }
    for ($i = 0; $i -lt 30; $i++) { Start-Sleep -Milliseconds 200; if (-not @($wins | Where-Object { Get-Process -Id $_.ProcessId -ErrorAction SilentlyContinue }).Count) { break } }
    $wins | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    "closed the app's window"
  }
  if (Test-Path $state) {
    try {
      $s = Get-Content $state -Raw | ConvertFrom-Json
      $p = Get-Process -Id $s.pid -ErrorAction SilentlyContinue
      if ($p -and $p.ProcessName -eq "node") { Stop-Process -Id $s.pid -Force; $p.WaitForExit(5000) | Out-Null }
    } catch {}
  }
}
Stop-Copy (Join-Path $StateDir "server.json") $profileDir

# ---- the earlier "R6 Animator" install: closed, its data folder moved here, the rest removed
$oldState = Join-Path $env:LOCALAPPDATA "R6 Animator"
$oldApp = Join-Path $env:LOCALAPPDATA "Programs\R6 Animator"
$oldData = Join-Path ([Environment]::GetFolderPath("MyDocuments")) "R6 Animator"
if ((Test-Path $oldApp) -or (Test-Path $oldState)) {
  Stop-Copy (Join-Path $oldState "server.json") (Join-Path $oldState "browser")
  try { $oc = Get-Content (Join-Path $oldApp "config.json") -Raw | ConvertFrom-Json; if ($oc.dataDir) { $oldData = $oc.dataDir } } catch {}
}
if ((Test-Path $oldData) -and -not (Test-Path $DataDir)) {
  Move-Item -LiteralPath $oldData -Destination $DataDir
  "moved your animations: $oldData -> $DataDir"
} elseif ((Test-Path $oldData) -and ($oldData -ne $DataDir)) {
  Write-Warning "Both $oldData and $DataDir exist: the old folder was left as it is."
}
if (Test-Path $oldApp) { Remove-Item $oldApp -Recurse -Force -ErrorAction SilentlyContinue; "removed the old R6 Animator app" }
Remove-Item $oldState -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path ([Environment]::GetFolderPath("Desktop")) "R6 Animator.lnk") -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path ([Environment]::GetFolderPath("Programs")) "R6 Animator") -Recurse -Force -ErrorAction SilentlyContinue

# ---- the app
New-Item -ItemType Directory -Force -Path $AppDir, (Join-Path $AppDir "app") | Out-Null
Copy-Item (Join-Path $src "server.js"), (Join-Path $src "icon.png"), (Join-Path $src "icon.ico"), (Join-Path $src "uninstall.ps1") $AppDir -Force
Copy-Item (Join-Path $src "app\index.html") (Join-Path $AppDir "app") -Force
if (Test-Path $bundled) { # the package's own Node.js goes with the app, so the unzipped folder can be deleted
  New-Item -ItemType Directory -Force -Path (Join-Path $AppDir "node") | Out-Null
  $target = Join-Path $AppDir "node\node.exe"
  for ($i = 0; ; $i++) { try { Copy-Item $bundled $target -Force; break } catch { if ($i -ge 10) { throw }; Start-Sleep -Milliseconds 500 } }
  $lic = Join-Path $src "node\LICENSE.txt"; if (Test-Path $lic) { Copy-Item $lic (Join-Path $AppDir "node") -Force }
  $node = $target
}
$utf8 = New-Object System.Text.UTF8Encoding $false
$cfg = [ordered]@{ dataDir = $DataDir; edge = $edge; port = $Port; profileDir = $profileDir }
[IO.File]::WriteAllText((Join-Path $AppDir "config.json"), ($cfg | ConvertTo-Json), $utf8)
$vbs = (Get-Content (Join-Path $src "launcher.vbs") -Raw).Replace("__NODE__", $node)
[IO.File]::WriteAllText((Join-Path $AppDir "launcher.vbs"), $vbs, [Text.Encoding]::Unicode)
# files that came from a downloaded zip carry Windows' "from the internet" mark; clear it on the app's own files so
# Windows doesn't ask again every time Farshtah starts
Get-ChildItem $AppDir -Recurse -File | Unblock-File -ErrorAction SilentlyContinue

# ---- your data folder, with the starting animations on a first install only (an update never brings back ones you deleted)
$firstTime = -not (Get-ChildItem (Join-Path $DataDir "animations") -Filter *.json -ErrorAction SilentlyContinue | Select-Object -First 1)
foreach ($d in "animations", "refs", "backgrounds", "settings", "models", "effects", "textures", "graphics", "faces", "media", "clips", "renders") { New-Item -ItemType Directory -Force -Path (Join-Path $DataDir $d) | Out-Null }
$seed = Join-Path $src "seed\animations"
if ($firstTime -and (Test-Path $seed)) {
  Get-ChildItem $seed -Filter *.json | ForEach-Object {
    $dest = Join-Path $DataDir ("animations\" + $_.Name)
    if (-not (Test-Path $dest)) { Copy-Item $_.FullName $dest; "added animation: $($_.BaseName)" }
  }
}

# ---- shortcuts: Desktop, and a Start menu folder with the app and its uninstaller
$wscript = Join-Path $env:WINDIR "System32\wscript.exe"
$launchArg = '"' + (Join-Path $AppDir "launcher.vbs") + '"'
if (-not $NoShortcuts) {
  $wsh = New-Object -ComObject WScript.Shell
  function New-Link([string]$path, [string]$target, [string]$arguments, [string]$workDir, [string]$desc) {
    $l = $wsh.CreateShortcut($path)
    $l.TargetPath = $target; $l.Arguments = $arguments; $l.WorkingDirectory = $workDir
    $l.IconLocation = (Join-Path $AppDir "icon.ico") + ",0"; $l.Description = $desc
    $l.Save()
  }
  $menu = Join-Path ([Environment]::GetFolderPath("Programs")) "Farshtah"
  New-Item -ItemType Directory -Force -Path $menu | Out-Null
  New-Link (Join-Path ([Environment]::GetFolderPath("Desktop")) "Farshtah.lnk") $wscript $launchArg $AppDir "Farshtah: animate R6 rigs"
  New-Link (Join-Path $menu "Farshtah.lnk") $wscript $launchArg $AppDir "Farshtah: animate R6 rigs"
  $ps = Join-Path $PSHOME "powershell.exe"
  New-Link (Join-Path $menu "Uninstall Farshtah.lnk") $ps ('-NoProfile -ExecutionPolicy Bypass -File "' + (Join-Path $AppDir "uninstall.ps1") + '"') $env:LOCALAPPDATA "Remove Farshtah (your animations stay)"
}
"installed to $AppDir"
"data folder: $DataDir"
"node: $node"
"edge: $edge"
if ($Launch) { Start-Process -FilePath $wscript -ArgumentList $launchArg }
