// Farshtah (desktop) - serves the app to its own Edge window and keeps everything as plain files:
//   <data>/animations/<id>.json   one animation each (the r6-animator/1 format, see ../README.md)
//   <data>/refs/<id>.json         a reference's settings (name, frame rate, offset, mirror)
//   <data>/backgrounds/<id>.json  a 3D-view background (image, GIF or video) in the Settings library
//   <data>/settings/app.json      the Settings (theme, background, layout, clips, rig look)
//   <data>/models/<id>.json       a model built in the Model tab
//   <data>/effects/<id>.json      an effect made in Farshtah Visuals+ (the farshtah-vfx/1 format)
//   <data>/textures/<id>.json     a texture imported into Visuals+ (its image is in media)
//   <data>/graphics/<id>.json     a thumbnail project made in Farshtah Graphics
//   <data>/faces/<id>.json        a face uploaded to Graphics' face gallery (its image is in media)
//   <data>/renders/               thumbnails rendered with Export (PNG)
//   <data>/media/<id>             the reference, background and texture files themselves
//                                 (served at /assets/<id> without the key, so Studio's image uploader can fetch them)
//   <data>/clips/                 clips recorded with Rec
// Only this PC can reach it (127.0.0.1, Host header checked), and every API call must carry the random key written into
// the app's own page, so other websites open in a browser can't read or change the files.
// Each open window holds one long-lived connection (/api/alive); ~30 s after the last one closes, the server exits.
//   node server.js [--port 51735] [--data <dir>] [--no-window] [--exit-idle]
"use strict";
const http = require("http"), fs = require("fs"), fsp = fs.promises, path = require("path"), os = require("os"), crypto = require("crypto");
const { spawn } = require("child_process");
const args = process.argv.slice(2);
const arg = (k, d) => { const i = args.indexOf("--" + k); return i >= 0 && args[i + 1] ? args[i + 1] : d; };
const HERE = __dirname;
let cfg = {};
try { cfg = JSON.parse(fs.readFileSync(path.join(HERE, "config.json"), "utf8").replace(/^\uFEFF/, "")); } catch (e) {}
const BASE_PORT = +arg("port", cfg.port || 51735);
const DATA = path.resolve(arg("data", cfg.dataDir || path.join(os.homedir(), "Documents", "Farshtah")));
const NO_WINDOW = args.includes("--no-window"), EXIT_IDLE = !NO_WINDOW || args.includes("--exit-idle");
const EDGE = cfg.edge || "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe";
const PROFILE = cfg.profileDir || path.join(process.env.LOCALAPPDATA || HERE, "Farshtah", "browser");
const COLS = new Set(["animations", "refs", "backgrounds", "settings", "models", "effects", "textures", "graphics", "faces"]);
const TOKEN = crypto.randomBytes(18).toString("hex");
const MAX_MEDIA = 1024 * 1024 * 1024, MAX_DOC = 8 * 1024 * 1024;
// .mov is served as video/mp4: the same container family, and Edge plays it far more willingly under that name
const TYPES = { ".gif": "image/gif", ".mp4": "video/mp4", ".webm": "video/webm", ".mov": "video/mp4", ".m4v": "video/mp4",
  ".png": "image/png", ".jpg": "image/jpeg", ".webp": "image/webp", ".bin": "application/octet-stream" };
const EXT = { "image/gif": ".gif", "video/mp4": ".mp4", "video/webm": ".webm", "video/quicktime": ".mov", "video/x-m4v": ".m4v",
  "image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp" };
for (const d of ["animations", "refs", "backgrounds", "settings", "models", "effects", "textures", "graphics", "faces", "media", "clips", "renders"]) fs.mkdirSync(path.join(DATA, d), { recursive: true });
const safeId = s => typeof s === "string" && /^[A-Za-z0-9_\-.~@+]{1,120}$/.test(s) && !/^\.+$/.test(s) && !/\.tmp-/.test(s);
const log = (...a) => { try { fs.appendFileSync(path.join(DATA, "app.log"), new Date().toISOString() + " " + a.join(" ") + "\n"); } catch (e) {} };
const sleep = ms => new Promise(r => setTimeout(r, ms));
// OneDrive (Documents usually lives there) can hold a file for a moment while it syncs: retry briefly
async function retry(fn) {
  for (let i = 0; ; i++) {
    try { return await fn(); } catch (e) { if (i >= 9 || !/EPERM|EBUSY|EACCES/.test(e.code || "")) throw e; await sleep(60 + i * 60); }
  }
}

let port = BASE_PORT, url = `http://127.0.0.1:${port}/`;
function openWindow() {
  if (NO_WINDOW) return;
  try {
    if (fs.existsSync(EDGE)) {
      spawn(EDGE, [`--app=${url}`, `--user-data-dir=${PROFILE}`, "--no-first-run", "--no-default-browser-check", "--start-maximized"],
        { detached: true, stdio: "ignore" }).unref();
      return;
    }
  } catch (e) { log("edge", e.message); }
  spawn("cmd", ["/c", "start", "", url], { detached: true, stdio: "ignore", windowsHide: true }).unref();
}

// ---- open windows
const alive = new Set(); let everAlive = false, emptySince = Date.now();
setInterval(() => { for (const r of alive) { try { r.write(": ping\n\n"); } catch (e) {} } }, 15000);
setInterval(() => {
  if (!EXIT_IDLE || alive.size) return;
  if (Date.now() - emptySince > (everAlive ? 30000 : 120000)) { log("exit: no window open"); process.exit(0); }
}, 2000);

function send(res, code, body, type) {
  const b = typeof body === "string" || Buffer.isBuffer(body) ? body : JSON.stringify(body);
  res.writeHead(code, { "Content-Type": type || "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" });
  res.end(b);
}
function readBody(req, limit) {
  return new Promise((ok, bad) => {
    const parts = []; let n = 0, over = false;
    req.on("data", c => { if (over) return; n += c.length; if (n > limit) { over = true; bad(Object.assign(new Error("too large"), { status: 413 })); } else parts.push(c); });
    req.on("end", () => { if (!over) ok(Buffer.concat(parts)); }); req.on("error", bad);
  });
}
async function writeAtomic(file, text) {
  const tmp = file + ".tmp-" + process.pid + "-" + crypto.randomBytes(3).toString("hex");
  await fsp.writeFile(tmp, text);
  try { await retry(() => fsp.rename(tmp, file)); } catch (e) { fsp.unlink(tmp).catch(() => {}); throw e; }
}
async function listCol(col) {
  const dir = path.join(DATA, col), docs = [], h = crypto.createHash("sha1");
  for (const f of (await fsp.readdir(dir)).sort()) {
    if (!f.endsWith(".json") || !safeId(f.slice(0, -5))) continue;
    const file = path.join(dir, f);
    try {
      const s = await fsp.stat(file); h.update(f + ":" + s.mtimeMs + ":" + s.size + ";");
      docs.push({ id: f.slice(0, -5), data: JSON.parse((await fsp.readFile(file, "utf8")).replace(/^\uFEFF/, "")) });
    } catch (e) { log("unreadable", col, f, e.message); }
  }
  return { rev: h.digest("hex"), docs };
}
async function revCol(col) { // changes whenever a file in the collection changes, edits made outside the app included
  const dir = path.join(DATA, col), h = crypto.createHash("sha1");
  for (const f of (await fsp.readdir(dir)).sort()) {
    if (!f.endsWith(".json") || !safeId(f.slice(0, -5))) continue;
    try { const s = await fsp.stat(path.join(dir, f)); h.update(f + ":" + s.mtimeMs + ":" + s.size + ";"); } catch (e) {}
  }
  return h.digest("hex");
}
function serveFile(req, res, file, type) {
  const stat = fs.statSync(file), range = req.headers.range;
  if (range) {
    const m = /bytes=(\d*)-(\d*)/.exec(range);
    let s, e;
    if (m && m[1] === "" && m[2] !== "") { s = Math.max(0, stat.size - +m[2]); e = stat.size - 1; } // suffix range
    else { s = m && m[1] ? +m[1] : 0; e = m && m[2] ? Math.min(+m[2], stat.size - 1) : stat.size - 1; }
    if (!m || s >= stat.size || s > e) { res.writeHead(416, { "Content-Range": `bytes */${stat.size}` }); return res.end(); }
    res.writeHead(206, { "Content-Type": type, "Content-Range": `bytes ${s}-${e}/${stat.size}`, "Accept-Ranges": "bytes", "Content-Length": e - s + 1, "Cache-Control": "no-store" });
    return fs.createReadStream(file, { start: s, end: e }).pipe(res);
  }
  res.writeHead(200, { "Content-Type": type, "Content-Length": stat.size, "Accept-Ranges": "bytes", "Cache-Control": "no-store" });
  fs.createReadStream(file).pipe(res);
}
function saveUpload(req, file) { // streams to disk, so a big video never sits in memory
  return new Promise((ok, bad) => {
    const tmp = file + ".tmp-" + process.pid, out = fs.createWriteStream(tmp); let n = 0, failed = false;
    const fail = e => { if (failed) return; failed = true; out.destroy(); fs.unlink(tmp, () => {}); bad(e); };
    req.on("data", c => { n += c.length; if (n > MAX_MEDIA) { fail(Object.assign(new Error("too large"), { status: 413 })); req.unpipe(out); } });
    req.on("error", fail); req.on("aborted", () => fail(new Error("aborted"))); out.on("error", fail);
    out.on("finish", () => { if (failed) return; if (!n) { fs.unlink(tmp, () => {}); return bad(Object.assign(new Error("empty"), { status: 400 })); } fs.rename(tmp, file, e => e ? fail(e) : ok(n)); });
    req.pipe(out);
  });
}

async function handle(req, res) {
  const host = String(req.headers.host || "");
  if (host !== `localhost:${port}` && host !== `127.0.0.1:${port}`) return send(res, 403, { error: "wrong host" });
  const u = new URL(req.url, url), m = req.method;
  let p; try { p = decodeURIComponent(u.pathname); } catch (e) { return send(res, 400, {}); }
  if (m === "GET" && (p === "/" || p === "/index.html")) {
    const html = fs.readFileSync(path.join(HERE, "app", "index.html"), "utf8").replace("__R6_TOKEN__", TOKEN);
    return send(res, 200, html, "text/html; charset=utf-8");
  }
  if (m === "GET" && (p === "/icon.png" || p === "/favicon.ico")) {
    const f = path.join(HERE, "icon.png"); return fs.existsSync(f) ? serveFile(req, res, f, "image/png") : send(res, 404, {});
  }
  if (m === "GET" && p.startsWith("/assets/")) {
    const id = p.slice(8); if (!safeId(id)) return send(res, 400, {});
    const f = path.join(DATA, "media", id); if (!fs.existsSync(f)) return send(res, 404, {});
    return serveFile(req, res, f, TYPES[path.extname(id).toLowerCase()] || "application/octet-stream");
  }
  if (p === "/api/ping") return send(res, 200, { app: "farshtah" });
  if (!p.startsWith("/api/")) return send(res, 404, {});
  const seg = p.split("/").filter(Boolean); // "api", ...
  if (seg[1] === "alive" && m === "GET") { // EventSource can't send headers, so this one takes the key in the query
    if (u.searchParams.get("k") !== TOKEN) return send(res, 403, { error: "missing key" });
    res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-store", "Connection": "keep-alive" });
    res.write("retry: 2000\n\n");
    alive.add(res); everAlive = true;
    req.on("close", () => { alive.delete(res); if (!alive.size) emptySince = Date.now(); });
    return;
  }
  if (req.headers["x-r6-token"] !== TOKEN) return send(res, 403, { error: "missing key" });
  try {
    if (seg[1] === "open-folder" && m === "POST") {
      const dir = seg[2] === "clips" || seg[2] === "renders" ? path.join(DATA, seg[2]) : DATA; fs.mkdirSync(dir, { recursive: true });
      spawn("explorer.exe", [dir], { detached: true, stdio: "ignore" }).unref(); return send(res, 200, { ok: true });
    }
    if (seg[1] === "clips" && m === "POST" && !seg[2]) { // a recorded clip: <data>/clips/<its name>, never overwriting one
      const type = String(req.headers["content-type"] || "").split(";")[0].trim().toLowerCase(), ext = type === "video/mp4" ? ".mp4" : ".webm";
      let name = ""; try { name = decodeURIComponent(String(req.headers["x-clip-name"] || "")); } catch (e) {}
      name = name.replace(/\.(mp4|webm)$/i, "").replace(/[\u0000-\u001f\\/:*?"<>|]+/g, " ").replace(/\s+/g, " ").trim().replace(/^\.+/, "").slice(0, 100) || "clip";
      const dir = path.join(DATA, "clips"); fs.mkdirSync(dir, { recursive: true });
      let file = path.join(dir, name + ext); for (let i = 2; fs.existsSync(file); i++) file = path.join(dir, `${name} (${i})${ext}`);
      const n = await saveUpload(req, file);
      return send(res, 200, { file: path.basename(file), sizeBytes: n });
    }
    if (seg[1] === "renders" && m === "POST" && !seg[2]) { // a rendered thumbnail: <data>/renders/<its name>.png, never overwriting one
      let name = ""; try { name = decodeURIComponent(String(req.headers["x-file-name"] || "")); } catch (e) {}
      name = name.replace(/\.png$/i, "").replace(/[\u0000-\u001f\\/:*?"<>|]+/g, " ").replace(/\s+/g, " ").trim().replace(/^\.+/, "").slice(0, 100) || "thumbnail";
      const dir = path.join(DATA, "renders"); fs.mkdirSync(dir, { recursive: true });
      let file = path.join(dir, name + ".png"); for (let i = 2; fs.existsSync(file); i++) file = path.join(dir, `${name} (${i}).png`);
      const n = await saveUpload(req, file);
      return send(res, 200, { file: path.basename(file), sizeBytes: n });
    }
    if (seg[1] === "rev" && COLS.has(seg[2]) && m === "GET") return send(res, 200, { rev: await revCol(seg[2]) });
    if (seg[1] === "col" && COLS.has(seg[2])) {
      const col = seg[2], id = seg[3];
      if (!id && m === "GET") return send(res, 200, await listCol(col));
      if (!safeId(id)) return send(res, 400, { error: "bad id" });
      const file = path.join(DATA, col, id + ".json");
      if (m === "PUT" || m === "PATCH") {
        const body = JSON.parse((await readBody(req, MAX_DOC)).toString("utf8"));
        if (!body || typeof body !== "object" || Array.isArray(body)) return send(res, 400, { error: "not an object" });
        let doc = body;
        if (m === "PATCH") {
          let old; try { old = JSON.parse((await fsp.readFile(file, "utf8")).replace(/^\uFEFF/, "")); } catch (e) { return send(res, 404, { error: "no such document" }); }
          doc = Object.assign(old, body);
        }
        await writeAtomic(file, JSON.stringify(doc, null, 1));
        return send(res, 200, { ok: true });
      }
      if (m === "DELETE") { await retry(() => fsp.unlink(file)).catch(e => { if (e.code !== "ENOENT") throw e; }); return send(res, 200, { ok: true }); }
    }
    if (seg[1] === "assets") {
      if (m === "POST" && !seg[2]) {
        const type = String(req.headers["content-type"] || "").split(";")[0].trim().toLowerCase();
        const id = crypto.randomBytes(12).toString("hex") + (EXT[type] || ".bin");
        const n = await saveUpload(req, path.join(DATA, "media", id));
        return send(res, 200, { id, url: "/assets/" + id, sizeBytes: n, contentType: TYPES[path.extname(id)] || type });
      }
      if (m === "DELETE" && safeId(seg[2])) {
        let had = true; await retry(() => fsp.unlink(path.join(DATA, "media", seg[2]))).catch(e => { if (e.code === "ENOENT") had = false; else throw e; });
        return send(res, 200, { deleted: had });
      }
    }
    return send(res, 404, { error: "unknown" });
  } catch (e) {
    log("error", m, p, e.message);
    if (!res.headersSent) send(res, e.status || (e instanceof SyntaxError ? 400 : 500), { error: e.message });
    if (e.status === 413) req.destroy();
  }
}

function ping(prt) {
  return new Promise(ok => {
    const r = http.get({ host: "127.0.0.1", port: prt, path: "/api/ping", headers: { Host: `localhost:${prt}` }, timeout: 800 }, res => {
      let b = ""; res.on("data", c => b += c); res.on("end", () => { try { ok(JSON.parse(b).app === "farshtah"); } catch (e) { ok(false); } });
    });
    r.on("error", () => ok(false)); r.on("timeout", () => { r.destroy(); ok(false); });
  });
}
(async function start() {
  for (let i = 0; i < 12; i++) {
    port = BASE_PORT + i; url = `http://127.0.0.1:${port}/`;
    if (await ping(port)) { openWindow(); setTimeout(() => process.exit(0), 300); return; } // already running: just open a window
    const ok = await new Promise(res => {
      const srv = http.createServer((q, r) => { handle(q, r).catch(e => { log("crash", e.message); try { if (!r.headersSent) send(r, 500, { error: e.message }); } catch (x) {} }); });
      srv.requestTimeout = 0; // a big reference upload may take a while
      srv.once("error", () => res(false));
      srv.listen(port, "127.0.0.1", () => res(true));
    });
    if (ok) {
      log("listening", url, "data", DATA); console.log("Farshtah on " + url + " (data: " + DATA + ")");
      if (!NO_WINDOW) { // lets the uninstaller stop a running copy
        const state = path.join(path.dirname(PROFILE), "server.json");
        try { fs.mkdirSync(path.dirname(state), { recursive: true }); fs.writeFileSync(state, JSON.stringify({ pid: process.pid, port, data: DATA })); } catch (e) {}
        process.on("exit", () => { try { if (JSON.parse(fs.readFileSync(state, "utf8")).pid === process.pid) fs.unlinkSync(state); } catch (e) {} });
        for (const sig of ["SIGINT", "SIGTERM", "SIGBREAK"]) process.on(sig, () => process.exit(0));
      }
      openWindow(); return;
    }
  }
  log("no free port"); process.exit(1);
})();
