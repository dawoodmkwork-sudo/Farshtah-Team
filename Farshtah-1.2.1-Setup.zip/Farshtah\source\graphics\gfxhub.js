// ======================================================================= the start screen's cards, drawn live in 3D
// One small renderer draws all three: Motion's rig swinging a katana (with onion-skin ghosts of its last frames),
// Visuals+' burst of sparks and rings, and Graphics' little thumbnail with its title. They only run while the start
// screen shows.
const HUB = { on: false, cards: [], W: 0, H: 0, accent: "#7aa0ff", key: "#f2b234" };
const HUB_SWING = [ // seconds into the loop, pose (degrees per joint)
  [0, { Torso: [-6, -15, 0], Head: [0, 15, 0], "Right Arm": [40, 0, 10], "Left Arm": [20, 0, -10], "Right Leg": [-12, 0, 6], "Left Leg": [14, 0, -6] }],
  [0.55, { Torso: [6, -38, 0], Head: [0, 30, 0], "Right Arm": [165, 0, 28], "Left Arm": [45, 0, -22], "Right Leg": [-14, 0, 6], "Left Leg": [16, 0, -6] }],
  [0.78, { Torso: [-12, 36, 0], Head: [0, -20, 0], "Right Arm": [72, 0, -52], "Left Arm": [-30, 0, -25], "Right Leg": [25, 0, 8], "Left Leg": [-25, 0, -8] }],
  [1.05, { Torso: [-10, 42, 0], Head: [0, -24, 0], "Right Arm": [38, 0, -72], "Left Arm": [-34, 0, -30], "Right Leg": [25, 0, 8], "Left Leg": [-25, 0, -8] }],
  [1.6, null], // (back to the first)
];
const HUB_LOOP = 1.6;
function hubPoseAt(t) { // the swing at time t (eased between its keys; the strike itself snaps)
  t = ((t % HUB_LOOP) + HUB_LOOP) % HUB_LOOP; let i = 0; while (i < HUB_SWING.length - 2 && t >= HUB_SWING[i + 1][0]) i++;
  const a = HUB_SWING[i], b = HUB_SWING[i + 1], A = a[1], B = b[1] || HUB_SWING[0][1]; let k = (t - a[0]) / (b[0] - a[0]);
  k = i === 1 ? k * k * k : k * k * (3 - 2 * k);
  const out = {}; for (const j of J) { const qa = new THREE.Quaternion().setFromEuler(new THREE.Euler(...(A[j] || [0, 0, 0]).map(v => v * DEG), "XYZ")), qb = new THREE.Quaternion().setFromEuler(new THREE.Euler(...(B[j] || [0, 0, 0]).map(v => v * DEG), "XYZ"));
    out[j] = qa.slerp(qb, k); } return out;
}
function hubApply(ch, pose) { for (const j of J) { ch.joints[j].quaternion.copy(pose[j]); } }
function hubGlowTex() { return gxCanvasTex("hub:shadow", 128, (c, S) => { const g = c.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2); g.addColorStop(0, "rgba(0,0,0,.55)"); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.fillRect(0, 0, S, S); }); }
function hubArtStart() {
  const r = gxIconRenderer(); if (!r) return false; HUB.on = true;
  HUB.accent = css("--accent") || "#7aa0ff"; HUB.key = css("--key") || "#f2b234";
  const lights = (sc, rimHex) => { sc.add(new THREE.HemisphereLight(0xe6eeff, 0x40382f, 0.85)); const k = new THREE.DirectionalLight(0xffffff, 2.3); k.position.set(5, 9, -7); sc.add(k);
    const rim = new THREE.DirectionalLight(linCol(rimHex).getHex(), 3.2); rim.position.set(-7, 6, 9); sc.add(rim); return rim; };
  // Motion
  { const sc = new THREE.Scene(), rim = lights(sc, HUB.accent), look = GX_PRESETS.find(p => p[0] === "fighter")[2](); look.items = [{ kind: "katana", joint: "Right Arm" }];
    const ch = gxBuildChar(look); ch.root.position.y = 3; const rig = new THREE.Group(); rig.add(ch.root); sc.add(rig); rig.rotation.y = 0.35;
    const ghosts = [0, 1].map(i => { const gch = gxBuildChar(gxLook({ colors: allSkin("#ffffff") })); gch.root.position.y = 3; const m = new THREE.MeshBasicMaterial({ color: linCol(HUB.accent), transparent: true, opacity: 0.16 - i * 0.06, depthWrite: false });
      gch.root.traverse(n => { if (n.isMesh) n.material = m; }); const g = new THREE.Group(); g.add(gch.root); g.rotation.y = 0.35; sc.add(g); return { ch: gch, g, m }; });
    const sh = new THREE.Mesh(new THREE.PlaneGeometry(7, 7), new THREE.MeshBasicMaterial({ map: hubGlowTex(), transparent: true, depthWrite: false })); sh.rotation.x = -Math.PI / 2; sh.position.y = 0.01; sc.add(sh);
    const arc = new THREE.Mesh(gxArcGeo(3.4, 5, -0.3, 2.6, 64), gxAdd(gxArcTex(), HUB.accent, 3)); arc.position.set(0.2, 3.4, -0.6); arc.rotation.set(-0.35, 0.2, 0.95); sc.add(arc);
    const cam = new THREE.PerspectiveCamera(30, 1.6, 0.1, 100); cam.position.set(4.6, 4.2, -10.4); cam.lookAt(0, 2.8, 0);
    HUB.cards.push({ el: $("hubArtMotion"), sc, cam, draw: t => { hubApply(ch, hubPoseAt(t));
      ghosts.forEach((g, i) => { hubApply(g.ch, hubPoseAt(t - 0.045 * (i + 1))); const fast = t % HUB_LOOP > 0.55 && t % HUB_LOOP < 1.0; g.g.visible = fast; });
      const s = t % HUB_LOOP, a = s < 0.62 ? 0 : s < 0.8 ? (s - 0.62) / 0.18 : Math.max(0, 1 - (s - 0.8) / 0.35); arc.material.color.copy(linCol(HUB.accent)).multiplyScalar(3 * a); arc.visible = a > 0.01; void rim; } }); }
  // Visuals+: an energy core that never stops (rings pulse out of it, sparks stream away, embers rise), so any moment looks alive
  { const sc = new THREE.Scene(), grp = new THREE.Group(); sc.add(grp); grp.rotation.x = 0.18;
    const spr = (key, hex, size) => { const s = gxSprite(key, hex, 1, size); grp.add(s); return s; };
    const halo = spr("glow", HUB.accent, 9), core = spr("glow", "#ffffff", 2.6), flare = spr("flare", HUB.accent, 7), star = spr("star", "#ffffff", 5);
    const rings = [0, 1, 2].map(i => { const m = new THREE.Mesh(new THREE.RingGeometry(0.1, 4, 64), gxAdd(gxFxTex(i === 1 ? "ring" : "shock"), i === 1 ? HUB.key : HUB.accent, 1)); m.rotation.x = -0.42; grp.add(m); return m; });
    const rnd = vxRand(11), sparks = [];
    for (let i = 0; i < 46; i++) { const a = rnd() * Math.PI * 2, el = (rnd() - 0.4) * 1.3, v = new THREE.Vector3(Math.cos(a) * Math.cos(el), Math.sin(el), Math.sin(a) * Math.cos(el)).multiplyScalar(4 + rnd() * 5);
      sparks.push({ s: spr(rnd() < 0.72 ? "spark" : "dot", rnd() < 0.5 ? HUB.key : HUB.accent, 0.5 + rnd() * 0.6), v, ph: rnd(), sp: 0.7 + rnd() * 0.6, c: null }); }
    const embers = []; for (let i = 0; i < 26; i++) embers.push({ s: spr("dot", rnd() < 0.5 ? HUB.key : "#ffffff", 0.12 + rnd() * 0.16), x: (rnd() - 0.5) * 12, z: (rnd() - 0.5) * 4, ph: rnd(), sp: 0.15 + rnd() * 0.2 });
    const cam = new THREE.PerspectiveCamera(36, 1.6, 0.1, 100); cam.position.set(0, 1.2, -12.5); cam.lookAt(0, 0.3, 0);
    const hexA = linCol(HUB.accent), hexK = linCol(HUB.key);
    HUB.cards.push({ el: $("hubArtVisuals"), sc, cam, draw: t => { const pulse = 0.5 + 0.5 * Math.sin(t * 3.1);
      halo.material.color.copy(hexA).multiplyScalar(0.55 + 0.25 * pulse); core.material.color.setScalar(2.4 + pulse * 0.8); core.scale.setScalar(2.2 + pulse * 0.5);
      flare.material.color.copy(hexA).multiplyScalar(1.1 + pulse * 0.5); flare.material.rotation = -t * 0.2; star.material.color.setScalar(1.4 + pulse); star.material.rotation = t * 0.35; star.scale.setScalar(4 + pulse * 1.5);
      rings.forEach((m, i) => { const k = ((t * 0.55 + i / 3) % 1), e = 1 - Math.pow(1 - k, 2.4); m.scale.setScalar(0.15 + e * 1.5); m.material.color.copy(i === 1 ? hexK : hexA).multiplyScalar(2.2 * (1 - k) * (1 - k)); });
      for (const p of sparks) { const k = (t * 0.5 * p.sp + p.ph) % 1, d = 1 - Math.exp(-k * 3); p.s.position.copy(p.v).multiplyScalar(d); p.s.position.y -= k * k * 1.5;
        if (!p.c) { p.c = p.s.material.color.clone(); p.sz = p.s.scale.x; } p.s.material.color.copy(p.c).multiplyScalar(2.4 * (1 - k)); const z = p.sz * (1 - k * 0.5); p.s.scale.set(z, z, 1);
        p.s.material.rotation = Math.atan2(p.v.y, -p.v.x) - Math.PI / 2; }
      for (const m of embers) { const k = (t * m.sp + m.ph) % 1; m.s.position.set(m.x + Math.sin(t + m.ph * 9) * 0.3, -2.5 + k * 6, m.z); m.s.material.color.setScalar(1.6 * Math.sin(k * Math.PI)); }
      grp.rotation.y = t * 0.12; } }); }
  // Graphics: a small thumbnail with a title
  { const sc = new THREE.Scene();
    const sky = new THREE.Mesh(new THREE.SphereGeometry(80, 32, 16), new THREE.ShaderMaterial({ vertexShader: GX_SKY_VS, fragmentShader: GX_SKY_FS, side: THREE.BackSide, depthWrite: false,
      uniforms: { top: { value: linCol("#3a2f7a") }, horizon: { value: linCol("#ff8a5a") }, bottom: { value: linCol("#2a2238") }, sunDir: { value: new THREE.Vector3(-0.3, 0.12, 1).normalize() }, sunColor: { value: linCol("#ffb46b") },
        cloudColor: { value: linCol("#ffc6a8") }, sunSize: { value: 2 }, sunGlow: { value: 1 }, clouds: { value: 0.55 }, stars: { value: 0 }, gain: { value: 1 }, sunBoost: { value: 0.2 }, seed: { value: 3 } } }));
    sc.add(sky);
    const gt = gxSurfTex("grass").clone(); gt.needsUpdate = true; gt.repeat.set(12, 12);
    const ground = new THREE.Mesh(new THREE.CircleGeometry(60, 48), new THREE.MeshStandardMaterial({ color: linCol("#4f9a3c"), map: gt, roughness: 0.95 })); ground.rotation.x = -Math.PI / 2; sc.add(ground);
    sc.add(new THREE.HemisphereLight(0xffd6c0, 0x2a3a20, 0.9)); const k = new THREE.DirectionalLight(0xffc89a, 2.6); k.position.set(-6, 5, 10); sc.add(k); const f = new THREE.DirectionalLight(0xbcd0ff, 1.1); f.position.set(6, 6, -8); sc.add(f);
    const look = GX_PRESETS.find(p => p[0] === "hero")[2](); look.items = [{ kind: "greatsword", joint: "Right Arm" }];
    const ch = gxBuildChar(look); ch.root.position.y = 3; gxPoseChar(ch, gxPoseDeg("raise")); const rig = new THREE.Group(); rig.add(ch.root); rig.rotation.y = -0.25; sc.add(rig);
    const glow = gxSprite("glow", "#ffcf7a", 0.9, 10, [0, 4.5, 1.5]); sc.add(glow);
    for (const [x, z, s] of [[-9, 14, 1.2], [10, 18, 1.4], [-16, 26, 1.6]]) { const t = gxProp("tree", "#4caf3e"); t.position.set(x, 0, z); t.scale.setScalar(s); sc.add(t); }
    const cam = new THREE.PerspectiveCamera(40, 1.6, 0.1, 200);
    const title = gxTextLayer("hype", { text: "PEAK", size: 0.26, x: 0.5, y: 0.19, rot: -4 }); gxEnsureFont(title.font);
    HUB.cards.push({ el: $("hubArtGraphics"), sc, cam, opaque: true, draw: t => { const a = Math.sin(t * 0.35) * 0.32; cam.position.set(Math.sin(a) * 11 + 1.2, 2.4, -Math.cos(a) * 11); cam.lookAt(0, 4.4, 0); glow.material.rotation = t * 0.1; },
      over: (c, w, h) => { gxDrawLayers(c, { layers: [title] }, w, h); } }); }
  return true;
}
function hubArtFrame(now) {
  if (!HUB.on && !hubArtStart()) return;
  const r = gxIconR, pr = Math.min(devicePixelRatio || 1, 2), t = reduceMotion ? 0.9 : now / 1000;
  const sizes = HUB.cards.map(c => { const b = c.el.getBoundingClientRect(); return [Math.max(2, Math.round(b.width * pr)), Math.max(2, Math.round(b.height * pr))]; });
  const W = Math.max(...sizes.map(s => s[0])), H = Math.max(...sizes.map(s => s[1]));
  HUB.W = W; HUB.H = H * 3; if (r.domElement.width !== W || r.domElement.height !== H * 3) r.setSize(W, H * 3, false);
  r.setScissorTest(true);
  HUB.cards.forEach((c, i) => { const [w, h] = sizes[i]; if (c.el.width !== w || c.el.height !== h) { c.el.width = w; c.el.height = h; }
    c.cam.aspect = w / h; c.cam.updateProjectionMatrix(); c.draw(t);
    r.setViewport(0, i * H, w, h); r.setScissor(0, i * H, w, h); r.setClearColor(0x000000, 0); r.clear(); r.render(c.sc, c.cam);
    const ctx = c.el.getContext("2d"); ctx.clearRect(0, 0, w, h); ctx.drawImage(r.domElement, 0, HUB.H - i * H - h, w, h, 0, 0, w, h); if (c.over) c.over(ctx, w, h); });
  r.setScissorTest(false); r.setViewport(0, 0, HUB.W, HUB.H);
}
appHooks.hubStep = now => { if (reduceMotion && HUB.drawn) return; try { hubArtFrame(now); HUB.drawn = true; } catch (e) { console.error(e); appHooks.hubStep = null; } };

// ======================================================================= which app opens first
{
  const want = LINK.get("app"), motionLink = ["anim", "tab", "test", "settings"].some(k => LINK.has(k));
  if (want === "visuals") setApp("visuals");
  else if (want === "graphics") setApp("graphics");
  else if (want === "motion" || (motionLink && want !== "hub")) setApp("motion");
  else openHub();
}
window.__vx = { VX, SIM, vxSeek, vxSamples, vxLoadSample, vxStudioScript, vxHandoff, vxTexUrls, VX_PLAYER_LUA, vxClean, setApp, openHub, enterApp, greetLine,
  vxAddLayer, vxUndo, vxRedo, vxImportFile, vxCustom, vxExport, vxOpenExport, vxSetLib, vxUseTexture, openCurve, openGrad, renderVxInsp, renderVxTimeline, vxFitCurve, vxStats: () => vxStats, vxChange };
window.__gx = { G, gxClean, gxLoad, gxCompose, gxRenderImage, gxSelect, gxAddObj, gxAddLayer, gxApplyWorld, gxApplyLight, gxApplyGrade, GX_TEMPLATES, gxCamPreset, gxUndo, gxRedo, gxSync, gxLive,
  gxDirtyAll, gxOpenExport, gxSetLib, gxChange, gxTextLayer, gxBlank, HUB, gxIconCache, gxSaveNow, GX_PRESETS, GX_POSES, gxPoseDeg, gxCleanLook, gxCleanObj, gxCleanLayer, GX_WORLDS, GX_LIGHTS, gxAttach, gxReadGizmo, gxDrawFace, GX_FACES, gxUploadFace, gxWearFace, gxSetPart, gxTc: () => gxTc };
