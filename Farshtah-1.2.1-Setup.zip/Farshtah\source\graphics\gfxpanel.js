// ======================================================================= Farshtah Graphics: the panels
// The library (what to add, down the left), the inspector (the selection's settings, or the scene's), the layers list
// and the frame's toolbars. Library pictures are rendered once, by a small renderer of their own.
let gxIconR = null, gxIconScene = null, gxIconCam = null, gxIconBusy = false;
const gxIconCache = new Map(), gxIconQueue = [];
function gxIconRenderer() { // a small renderer for library pictures and the start screen (normal tone mapping, no post)
  if (gxIconR) return gxIconR;
  const cv = document.createElement("canvas"); cv.width = cv.height = 160;
  try { gxIconR = new THREE.WebGLRenderer({ canvas: cv, antialias: true, alpha: true, preserveDrawingBuffer: true }); } catch (e) { gxIconR = null; return null; }
  gxIconR.outputEncoding = THREE.sRGBEncoding; gxIconR.toneMapping = THREE.ACESFilmicToneMapping; gxIconR.toneMappingExposure = 1.15;
  gxIconScene = new THREE.Scene();
  gxIconScene.add(new THREE.HemisphereLight(0xdfeaff, 0x4a4038, 0.9));
  const key = new THREE.DirectionalLight(0xffffff, 2.2); key.position.set(4, 8, -6); gxIconScene.add(key);
  const rim = new THREE.DirectionalLight(0x9cc4ff, 1.6); rim.position.set(-6, 5, 8); gxIconScene.add(rim);
  { const pm = new THREE.PMREMGenerator(gxIconR), es = new THREE.Scene(), m = new THREE.ShaderMaterial({ vertexShader: GX_SKY_VS, fragmentShader: GX_SKY_FS, side: THREE.BackSide, depthWrite: false,
      uniforms: { top: { value: linCol("#5a8fd8") }, horizon: { value: linCol("#e8f0ff") }, bottom: { value: linCol("#5a5048") }, sunDir: { value: new THREE.Vector3(0.4, 0.7, -0.5) }, sunColor: { value: new THREE.Color(1, 1, 1) },
        cloudColor: { value: new THREE.Color(1, 1, 1) }, sunSize: { value: 1 }, sunGlow: { value: 1 }, clouds: { value: 0 }, stars: { value: 0 }, gain: { value: 1 }, sunBoost: { value: 0.05 }, seed: { value: 0 } } });
    es.add(new THREE.Mesh(new THREE.SphereGeometry(50, 32, 16), m)); gxIconScene.environment = pm.fromScene(es, 0.04, 0.1, 200).texture; }
  gxIconCam = new THREE.PerspectiveCamera(28, 1, 0.05, 400);
  return gxIconR;
}
function gxIconShot(obj, o) { // render one object, framed to fit -> a data URL
  o = o || {}; const r = gxIconRenderer(); if (!r) return "";
  const w = o.w || 160, h = o.h || 160; r.setSize(w, h, false); gxIconCam.aspect = w / h; gxIconCam.fov = o.fov || 28; gxIconCam.updateProjectionMatrix();
  gxIconScene.add(obj); obj.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(obj), c = box.getCenter(new THREE.Vector3()), size = box.getSize(new THREE.Vector3());
  if (o.aim) c.y = box.min.y + size.y * o.aim;
  const rad = Math.max(size.x, size.y / Math.max(0.6, w / h * 0.9), size.z) * 0.5 * (o.pad || 1.18), dist = rad / Math.tan(gxIconCam.fov * DEG / 2);
  const dir = new THREE.Vector3(...(o.dir || [0.42, 0.22, -1])).normalize();
  gxIconCam.position.copy(c).addScaledVector(dir, dist + size.z * 0.5); gxIconCam.lookAt(c);
  r.setClearColor(0x000000, 0); r.clear(); r.render(gxIconScene, gxIconCam);
  gxIconScene.remove(obj); const url = r.domElement.toDataURL("image/png"); gxDisposeTree(obj); return url;
}
function gxIcon(key, make, o, img) { // fills img now (cached) or soon (queued: a few per frame, so the panel opens at once)
  const have = gxIconCache.get(key); if (have) { img.src = have; return; }
  img.dataset.icon = key; gxIconQueue.push({ key, make, o }); if (!gxIconBusy) { gxIconBusy = true; requestAnimationFrame(gxIconPump); }
}
function gxIconPump() {
  const t0 = performance.now();
  while (gxIconQueue.length && performance.now() - t0 < 24) { const q = gxIconQueue.shift(); if (gxIconCache.has(q.key)) { gxIconFill(q.key); continue; }
    try { gxIconCache.set(q.key, gxIconShot(q.make(), q.o)); } catch (e) { gxIconCache.set(q.key, ""); console.warn(e); } gxIconFill(q.key); }
  if (gxIconQueue.length) requestAnimationFrame(gxIconPump); else gxIconBusy = false;
}
function gxIconFill(key) { const url = gxIconCache.get(key); for (const im of document.querySelectorAll(`img[data-icon="${CSS.escape(key)}"]`)) if (url) im.src = url; }
function gxCharThumb(look, pose) { const ch = gxBuildChar(look); ch.root.position.y = 3; gxPoseChar(ch, gxPoseDeg(pose || "hero")); const g = new THREE.Group(); g.add(ch.root); return g; }
function gxHeadThumb(kind, color) { const g = new THREE.Group(), look = gxLook({ colors: allSkin(GX_SKIN.yellow), acc: [{ kind, color }] }), ch = gxBuildChar(look);
  const head = ch.holds.Head; head.parent.remove(head); head.position.set(0, 0, 0); g.add(head); if (GX_ACC_JOINT[kind]) { const t = ch.holds.Torso; ch.root.remove(t); g.add(t); t.position.y = -1.6; } return g; }
function gxItemThumb(kind) { const g = new THREE.Group(), it = gxItem(kind, null); it.rotation.z = -0.7; g.add(it); return g; }
// ---- small builders for panels
const gxImgEl = (cls) => make("img", { class: cls || "", alt: "", draggable: "false" });
function gxTile(name, pic, onclick, o) { o = o || {}; const b = make("button", { type: "button", class: "gtile" + (o.cls ? " " + o.cls : ""), title: o.title || name, onclick }, pic, o.noLabel ? null : make("span", { class: "gl", text: name }));
  if (o.pressed != null) b.setAttribute("aria-pressed", String(!!o.pressed)); return b; }
function gxCanvasPic(w, h, draw) { const cv = make("canvas", { class: "gpic" }); cv.width = w; cv.height = h; draw(cv.getContext("2d"), w, h); return cv; }
function gxSwatch(cols) { return make("span", { class: "gsw", style: `background:${cols}` }); }
const GX_TABS = [["chars", "Characters", '<circle cx="12" cy="5.5" r="3"/><path d="M7 21v-6H5l1-6h12l1 6h-2v6"/>'], ["world", "World", '<path d="M3 20h18M5 20l5-9 3 5 2-3 4 7"/><circle cx="17" cy="6" r="2"/>'],
  ["fx", "Effects", '<path d="M12 2l2 6 6 .5-4.6 4 1.4 6-4.8-3.2L7.2 18.5l1.4-6L4 8.5 10 8z"/>'], ["text", "Text", '<path d="M5 6V4h14v2M12 4v16M9 20h6"/>'],
  ["images", "Images", '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-9 9"/>'], ["overlays", "Overlays", '<path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/>'],
  ["look", "Look", '<circle cx="12" cy="12" r="4"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>']];
function gxSetLib(id) { if (!GX_TABS.some(t => t[0] === id)) return; G.lib = id; store.set("farshtah.gfx.lib", id); renderGxLib(); }
function renderGxLib() {
  const tabs = $("gxTabs"); if (!tabs.childElementCount) for (const [id, name, svg] of GX_TABS) { const b = make("button", { type: "button", role: "tab", id: "gxt-" + id, title: name }); b.innerHTML = `<svg viewBox="0 0 24 24">${svg}</svg>`; b.append(make("span", { text: name })); b.onclick = () => gxSetLib(id); tabs.append(b); }
  for (const [id] of GX_TABS) $("gxt-" + id).setAttribute("aria-selected", String(G.lib === id));
  const body = $("gxLibBody"); body.innerHTML = ""; const top = body.scrollTop;
  const sec = (title, ...kids) => body.append(make("h4", { text: title }), ...kids);
  const grid = (cls, ...kids) => make("div", { class: "gtiles " + (cls || "") }, ...kids);
  if (!G.p) return;
  if (G.lib === "chars") {
    sec("Characters", grid("", ...GX_PRESETS.map(([k, name, mk]) => { const im = gxImgEl(); gxIcon("char:" + k, () => gxCharThumb(mk()), { dir: [0.35, 0.12, -1], pad: 1.08, w: 150, h: 180 }, im);
      return gxTile(name, im, () => gxAddObj({ type: "char", name, look: mk(), pose: gxPoseDeg("hero"), p: [0, 0, 0], s: 1 }), { cls: "tall" }); })));
    { const sel = gxSelObj(), ch = sel && sel.type === "char" ? sel : null; // faces for the selected character
      body.append(make("h4", { text: "Faces" }), gxFaceGallery(ch ? ch.look.colors.head : GX_SKIN.yellow, ch ? ch.look.face : "", ch ? ch.look.faceImg : "", (kind, img) => gxWearFace(kind, img)),
        make("button", { type: "button", class: "btn gwide", text: "Upload a face", onclick: () => gxPickFile("image/png,image/jpeg,image/webp", f => gxUploadFace(f, ch)) })); }
  } else if (G.lib === "world") {
    sec("Places", grid("wide", ...GX_WORLDS.map(([k, name, light, ground]) => { const sky = GX_SKIES[(GX_LIGHTS.find(x => x[0] === light) || GX_LIGHTS[0])[2].sky];
      const gcol = ground.kind === "none" ? sky.bottom : ground.color;
      return gxTile(name, gxSwatch(`linear-gradient(${sky.top}, ${sky.horizon} 62%, ${gcol} 62%, ${gxShade(gcol, -0.25)})`), () => gxChange(() => gxApplyWorld(G.p, k), { insp: true, lib: true }), { pressed: G.p.world.preset === k }); })));
    sec("Build", grid("", ...GX_PROPS.map(([k, name]) => { const im = gxImgEl(); gxIcon("prop:" + k, () => gxProp(k, GX_PROP_COLOR[k]), { dir: [0.5, 0.45, -1] }, im);
      return gxTile(name, im, () => gxAddObj({ type: "prop", kind: k, p: [0, 0, 0], r: [0, 0, 0], s: 1 })); })));
    sec("Parts", grid("", ...SHAPES.concat([]).filter(s => s[0] !== "ring").concat([["ring", "Ring"]]).map(([k, name]) => { const ic = make("span", { class: "gshape" }); ic.append(shapeIcon(k));
      const shape = k === "block" ? "block" : k; return gxTile(name, ic, () => gxAddObj({ type: "part", shape, mat: "plastic", color: "#a3a2a5", p: [0, shape === "block" ? 0.5 : 1, 0], r: [0, 0, 0], s: shape === "block" ? [4, 1, 2] : [2, 2, 2] })); })));
    if (models.size) sec("Your models", grid("", ...[...models.entries()].map(([id, m]) => { const im = gxImgEl(); gxIcon("model:" + id + (m.updatedAt || ""), () => gxModelGroup(m), { dir: [0.5, 0.3, -1] }, im);
      return gxTile(m.name, im, () => gxAddObj({ type: "model", model: id, name: m.name, p: [0, 0, 0], r: [0, 0, 0], s: 1 })); })));
    body.append(make("button", { type: "button", class: "btn gwide", text: "Import 3D model", title: "GLB or OBJ", onclick: () => gxPickFile(".glb,.gltf,.obj", gxImportModel) }));
  } else if (G.lib === "fx") {
    sec("Effects", grid("", ...GX_FX.map(([k, name]) => { const im = gxImgEl("dark"); const col = { slash: "#4aa3ff", slash2: "#7fd8ff", burst: "#ffb347", ring: "#9ad7ff", aura: "#ffcf3a", orb: "#b07cff", sparkles: "#ffd27a", lightning: "#8a6bff", fire: "#ff7a1a", smoke: "#9aa0a8", beam: "#ff4fd8", wind: "#ffffff", light: "#ffd27a" }[k];
      gxIcon("fx:" + k, () => gxFxMesh(k, col, "#ffffff", 1), { dir: k === "ring" || k === "slash" || k === "slash2" ? [0.2, 1.2, -1] : [0.2, 0.25, -1], pad: 1.05 }, im);
      return gxTile(name, im, () => gxAddObj({ type: "fx", kind: k, c1: col, c2: "#ffffff", p: [0, k === "ring" || k === "aura" || k === "fire" || k === "smoke" ? 0.1 : 3, 0], r: [0, 0, 0], s: 1 })); })));
  } else if (G.lib === "text") {
    body.append(make("button", { type: "button", class: "btn primary gwide", text: "Add text", onclick: () => gxAddLayer(gxTextLayer("hype")) }));
    sec("Styles", grid("wide", ...GX_TEXT_STYLES.map(([k, name]) => gxTile(name, gxTextPic(k), () => gxAddLayer(gxTextLayer(k)), { cls: "txt" }))));
  } else if (G.lib === "images") {
    body.append(make("button", { type: "button", class: "btn primary gwide", text: "Import image", onclick: () => gxPickFile("image/png,image/jpeg,image/webp,image/gif", gxImportAny) }));
    const used = new Set(G.recent); for (const d of [G.p].concat([...G.docs.values()])) for (const L of (d.layers || [])) if (L && L.type === "image" && gxAsset(L.asset)) used.add(L.asset);
    if (used.size) sec("Recent", grid("", ...[...used].slice(0, 18).map(id => { const im = make("img", { class: "gimg", alt: "" }); im.src = blobUrl(id);
      return gxTile("", im, () => gxAddLayer({ type: "image", asset: id, h: 0.4, x: 0.5, y: 0.5 }), { noLabel: true, title: "Add" }); })));
    sec("Stickers", grid("", ...GX_STICKERS.map(([k, name]) => gxTile(name, gxCanvasPic(96, 96, (c, w, h) => { const L = gxCleanLayer({ type: "sticker", kind: k, h: 0.8 }), d = gxDrawSticker(L, 96 * 0.95);
      c.drawImage(d.cv, (w - d.cv.width) / 2, (h - d.cv.height) / 2); }), () => gxAddLayer({ type: "sticker", kind: k, x: 0.5, y: 0.5, h: 0.22 })))));
  } else if (G.lib === "overlays") {
    sec("Overlays", grid("wide", ...GX_OVERLAYS.map(([k, name]) => gxTile(name, gxCanvasPic(160, 90, (c, w, h) => { const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, "#28304a"); g.addColorStop(1, "#0e1220"); c.fillStyle = g; c.fillRect(0, 0, w, h);
      gxDrawOverlay(c, gxCleanLayer({ type: "overlay", kind: k, c1: k === "vignette" ? "#ff2a2a" : k === "halftone" ? "#000000" : "#ffffff", c2: "#ffd23f", power: 0.7, x: 0.5, y: 0.45 }), w, h); }),
      () => gxAddLayer({ type: "overlay", kind: k, c1: k === "vignette" ? "#ff2a2a" : k === "halftone" ? "#000000" : k === "gradient" ? "#000000" : "#ffffff", c2: k === "gradient" ? "#000000" : "#ffd23f", power: 0.6, opacity: k === "speed" ? 0.6 : 1, blend: k === "rays" || k === "flare" || k === "sparkle" || k === "embers" ? "screen" : "source-over" })))));
  } else if (G.lib === "look") {
    sec("Light", grid("wide", ...GX_LIGHTS.map(([k, name, L]) => { const s = GX_SKIES[L.sky];
      return gxTile(name, gxSwatch(`radial-gradient(circle at ${50 + Math.sin(L.az * DEG) * 30}% ${70 - L.el * 0.6}%, ${L.color} 0 7%, transparent 18%), linear-gradient(${s.top}, ${s.horizon})`), () => gxChange(() => gxApplyLight(G.p, k), { insp: true, lib: true }), { pressed: G.p.light.preset === k }); })));
    sec("Finish", make("div", { class: "presets" }, ...GX_GRADES.map(([k, name]) => make("button", { type: "button", "aria-pressed": String(G.p.post.look === k), text: name, onclick: () => gxChange(() => gxApplyGrade(G.p, k), { insp: true, lib: true, scene: false }) }))));
    sec("Camera", make("div", { class: "presets" }, ...GX_CAMS.map(([k, name]) => make("button", { type: "button", text: name, onclick: () => gxCamPreset(k) }))));
  }
  body.scrollTop = top;
}
const gxFaceArtCache = new Map();
function gxFaceArt(kind) { let c = gxFaceArtCache.get(kind); if (!c) { c = document.createElement("canvas"); c.width = 590; c.height = 440; gxDrawFace(c.getContext("2d"), kind, 590, 440); gxFaceArtCache.set(kind, c); } return c; }
function gxFaceGallery(head, face, faceImg, pick) { // built-in faces, then uploaded ones (with a remove button), on the character's head colour
  const wrap = make("div", { class: "gfacewrap" }), grid = make("div", { class: "gfaces" });
  for (const [k, name] of GX_FACES) grid.append(make("button", { type: "button", class: "gface", title: name, "aria-pressed": String(!faceImg && face === k), onclick: () => pick(k, "") },
    gxCanvasPic(64, 48, c => { c.fillStyle = head; c.fillRect(0, 0, 64, 48); c.drawImage(gxFaceArt(k), 0, 0, 64, 48); })));
  wrap.append(grid);
  const mine = gxFaceList();
  if (mine.length) { const g2 = make("div", { class: "gfaces" });
    for (const f of mine) { const im = make("img", { alt: "", draggable: "false" }); im.src = blobUrl(f.asset);
      const del = make("span", { class: "x", role: "button", tabindex: "0", title: "Remove from the gallery", text: "×" });
      del.onclick = ev => { ev.stopPropagation(); if (confirmDelete(del)) gxDeleteFace(f.id); };
      g2.append(make("button", { type: "button", class: "gface mine", title: f.name, style: "background:" + head, "aria-pressed": String(faceImg === f.asset), onclick: () => pick(null, f.asset) }, im, del)); }
    wrap.append(make("span", { class: "gfacehd", text: "Yours" }), g2); }
  else if (faceImg) { const im = make("img", { alt: "", draggable: "false" }); im.src = blobUrl(faceImg); const g2 = make("div", { class: "gfaces" }); g2.append(make("button", { type: "button", class: "gface mine", style: "background:" + head, "aria-pressed": "true" }, im)); wrap.append(make("span", { class: "gfacehd", text: "Yours" }), g2); }
  return wrap;
}
function gxTextPic(style) {
  const L = gxTextLayer(style, { text: "Peak", size: 0.5 }); gxEnsureFont(L.font);
  const cv = gxCanvasPic(180, 80, () => {}); cv.dataset.style = style; gxPaintTextPic(cv, L); return cv;
}
function gxPaintTextPic(cv, L) { const c = cv.getContext("2d"); c.clearRect(0, 0, cv.width, cv.height); const d = gxDrawTextLayer(L, 96), k = Math.min(1, (cv.width - 8) / d.w, (cv.height - 4) / d.h);
  c.save(); c.translate(cv.width / 2, cv.height / 2); c.scale(k, k); if (L.glow[0] > 0) { c.shadowColor = L.glow[1]; c.shadowBlur = 14; } c.drawImage(d.cv, -d.ox, -d.oy); c.restore(); }
function gxRefreshTextTiles() { for (const cv of document.querySelectorAll("canvas[data-style]")) gxPaintTextPic(cv, gxTextLayer(cv.dataset.style, { text: "Peak", size: 0.5 })); }
// ---- inspector fields (every change is one undo step; dragging a slider is one step)
const GF = {
  live: [],
  num(get, set, o) { o = o || {}; const inp = make("input", { class: "num", type: "number", step: o.step || 0.1, "aria-label": o.label || "" }); const show = () => { inp.value = +(+get()).toFixed(o.dp == null ? 2 : o.dp); }; show();
    inp.oninput = () => { const v = parseFloat(inp.value); if (isFinite(v)) gxChange(() => set(clamp(v, o.min != null ? o.min : -1e9, o.max != null ? o.max : 1e9)), { merge: "n" + (o.label || ""), scene: o.scene !== false }); };
    inp.onchange = show; inp._drag = { get, set: v => gxChange(() => set(v), { merge: "n" + (o.label || ""), scene: o.scene !== false }), o, inp }; GF.live.push({ inp, show }); return inp; },
  row(label, ...kids) { const fl = make("span", { class: "fl", text: label }); const r = make("div", { class: "frow" }, fl, make("div", { class: "fv" }, ...kids));
    const first = kids.find(k => k && k._drag); if (first) gxDragLabel(fl, first._drag); else fl.classList.add("plain"); return r; },
  vec(label, get, o) { return GF.row(label, ...[0, 1, 2].map(i => GF.num(() => get()[i], v => { get()[i] = v; }, Object.assign({ label: label + " " + "XYZ"[i] }, o)))); },
  slider(label, get, set, min, max, step, fmt, o) { o = o || {}; const inp = make("input", { type: "range", min, max, step, "aria-label": label }); inp.value = get(); const out = make("span", { class: "unit", text: fmt(get()) });
    inp.oninput = () => { gxChange(() => set(+inp.value), { merge: "s" + label, scene: o.scene !== false, mode: false }); out.textContent = fmt(+inp.value); };
    inp.onchange = () => { if (o.after) o.after(); }; GF.live.push({ inp, show: () => { if (document.activeElement !== inp) { inp.value = get(); out.textContent = fmt(get()); } } }); return GF.row(label, inp, out); },
  color(label, get, set, o) { o = o || {}; const inp = make("input", { type: "color", "aria-label": label }); inp.value = get();
    inp.oninput = () => gxChange(() => set(inp.value), { merge: "c" + label, scene: o.scene !== false, mode: false }); inp.onchange = () => { if (o.after) o.after(); }; return o.bare ? inp : GF.row(label, inp); },
  segs(label, opts, get, set, o) { o = o || {}; const box = make("div", { class: "segs" });
    for (const [v, t] of opts) box.append(make("button", { type: "button", class: "chip", "aria-pressed": String(get() === v), text: t, onclick: () => gxChange(() => set(v), { insp: true, scene: o.scene !== false, size: o.size, lib: o.lib }) }));
    return label ? GF.row(label, box) : box; },
  select(label, opts, get, set, o) { o = o || {}; const s = make("select", { "aria-label": label }); for (const [v, t] of opts) { const op = make("option", { value: v, text: t }); if (get() === v) op.selected = true; s.append(op); }
    s.onchange = () => gxChange(() => set(s.value), { insp: true, scene: o.scene !== false }); return GF.row(label, s); },
  check(label, get, set, o) { o = o || {}; const inp = make("input", { type: "checkbox" }); inp.checked = !!get(); inp.onchange = () => gxChange(() => set(inp.checked), { insp: true, scene: o.scene !== false }); return make("label", { class: "check" }, inp, label); },
  sec(title, ...kids) { const key = "farshtah.gfx.sec." + title, open = store.get(key) !== "0"; const d = make("details", { class: "isec gsec" }); if (open) d.open = true;
    d.append(make("summary", { text: title }), ...kids.filter(Boolean)); d.addEventListener("toggle", () => store.set(key, d.open ? "1" : "0")); return d; },
  btn(text, onclick, cls) { return make("button", { type: "button", class: "btn" + (cls ? " " + cls : ""), text, onclick }); },
};
function gxDragLabel(fl, d) { // drag a field's label sideways to change it
  fl.addEventListener("pointerdown", e => { if (e.button !== 0) return; e.preventDefault(); fl.setPointerCapture(e.pointerId);
    const x0 = e.clientX, v0 = +d.get(), st = +(d.o.step || 0.1);
    const move = ev => { const v = clamp(v0 + Math.round((ev.clientX - x0) / 3) * st * (ev.shiftKey ? 10 : 1), d.o.min != null ? d.o.min : -1e9, d.o.max != null ? d.o.max : 1e9); d.set(+v.toFixed(4)); d.inp.value = +(+d.get()).toFixed(d.o.dp == null ? 2 : d.o.dp); };
    const up = () => { fl.removeEventListener("pointermove", move); fl.removeEventListener("pointerup", up); fl.removeEventListener("pointercancel", up); };
    fl.addEventListener("pointermove", move); fl.addEventListener("pointerup", up); fl.addEventListener("pointercancel", up); });
}
function gxUpdateNumbers() { for (const f of GF.live) if (document.activeElement !== f.inp) f.show(); }
const pct = v => Math.round(v * 100) + "%", deg = v => Math.round(v) + "°", x2 = v => (+v).toFixed(2);
const GX_ICON = { char: '<circle cx="12" cy="6" r="3"/><path d="M7 21v-6H5l1-5h12l1 5h-2v6"/>', part: '<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><path d="M4 7.5l8 4.5 8-4.5M12 12v9"/>',
  prop: '<path d="M6 21V9l6-5 6 5v12z"/><path d="M10 21v-6h4v6"/>', fx: '<path d="M12 2l2 6 6 .5-4.6 4 1.4 6-4.8-3.2L7.2 18.5l1.4-6L4 8.5 10 8z"/>', model: '<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/>', import: '<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>',
  text: '<path d="M5 6V4h14v2M12 4v16M9 20h6"/>', image: '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-9 9"/>', sticker: '<path d="M12 3a9 9 0 1 0 9 9l-9-9z"/>', overlay: '<circle cx="12" cy="12" r="8"/><path d="M12 4v16M4 12h16"/>',
  scene: '<path d="M3 20h18M5 20l5-9 3 5 2-3 4 7"/>' };
const gxSvg = k => { const s = make("span", { class: "gic" }); s.innerHTML = `<svg viewBox="0 0 24 24">${GX_ICON[k] || GX_ICON.part}</svg>`; return s; };
function renderGxAll() { renderGxLib(); renderGxInsp(); renderGxLayers(); renderGxTools(); }
function renderGxInsp() {
  const el = $("gxInsp"); if (!el || !G.p) return; const top = el.querySelector(".ibody") ? el.querySelector(".ibody").scrollTop : 0; el.innerHTML = ""; GF.live = [];
  const o = gxSelObj(), l = gxSelLayer(), body = make("div", { class: "ibody" });
  const head = (icon, get, set, ...acts) => { const inp = make("input", { type: "text", maxlength: 40, "aria-label": "Name", spellcheck: "false" }); inp.value = get();
    inp.onchange = () => gxChange(() => set(inp.value.slice(0, 40) || get()), { scene: false }); return make("div", { class: "ihead" }, make("span", { class: "ic", style: "background:var(--accent)" }, gxSvg(icon)), inp, ...acts); };
  const acts = () => [make("button", { type: "button", class: "rbtn", title: "Duplicate (Ctrl D)", onclick: gxDuplicateSel }, svgEl('<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M4 16V6a2 2 0 0 1 2-2h10"/>')),
    make("button", { type: "button", class: "rbtn", title: "Delete (Del)", onclick: gxDeleteSel }, svgEl('<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>'))];
  if (o) { el.append(head(o.type, () => o.name, v => { o.name = v; }, ...acts()), body); gxObjFields(o, body); }
  else if (l) { el.append(head(l.type, () => l.name, v => { l.name = v; }, ...acts()), body); gxLayerFields(l, body); }
  else { el.append(make("div", { class: "ihead" }, make("span", { class: "ic", style: "background:var(--panel-2);color:var(--ink-2)" }, gxSvg("scene")), make("b", { class: "gtitle", text: "Scene" })), body); gxSceneFields(body); }
  body.scrollTop = top;
}
function svgEl(paths) { const s = document.createElementNS("http://www.w3.org/2000/svg", "svg"); s.setAttribute("viewBox", "0 0 24 24"); s.innerHTML = paths; return s; }
// ---- the selected 3D object
function gxObjFields(o, body) {
  const place = (withSize) => GF.sec("Place", GF.vec("Position", () => o.p, { step: 0.1 }),
    o.type === "char" ? GF.slider("Turn", () => o.yaw, v => { o.yaw = v; }, -180, 180, 1, deg) : GF.vec("Rotation", () => o.r, { step: 1, dp: 1 }),
    withSize === "vec" ? GF.vec("Size", () => o.s, { step: 0.1, min: 0.05 }) : GF.slider("Size", () => o.s, v => { o.s = v; }, 0.1, o.type === "char" ? 6 : 10, 0.01, x2),
    make("div", { class: "rowbtns" }, o.type === "char" ? GF.btn("Face camera", () => gxChange(() => { o.yaw = gxFacingYaw(o.p[0], o.p[2]); }, { insp: true })) : null,
      GF.btn("On the ground", () => gxChange(() => { o.p[1] = 0; }, { insp: true })), GF.btn("Focus", gxFocusSel)));
  if (o.type === "char") {
    const tabs = make("div", { class: "imode g4" }); for (const [k, t] of [["look", "Look"], ["pose", "Pose"], ["glow", "Glow"], ["place", "Place"]]) tabs.append(make("button", { type: "button", "aria-pressed": String(G.tab === k), text: t, onclick: () => { G.tab = k; renderGxInsp(); } }));
    body.before(tabs);
    if (G.tab === "pose") gxPoseFields(o, body);
    else if (G.tab === "glow") body.append(GF.sec("Outline", GF.check("Outline", () => o.fx.outline.on, v => { o.fx.outline.on = v; }, { scene: false }), GF.color("Colour", () => o.fx.outline.color, v => { o.fx.outline.color = v; }, { scene: false }),
        GF.slider("Width", () => o.fx.outline.width, v => { o.fx.outline.width = v; o.fx.outline.on = true; }, 0.5, 30, 0.5, v => v + " px", { scene: false })),
      GF.sec("Glow", GF.check("Glow", () => o.fx.glow.on, v => { o.fx.glow.on = v; }, { scene: false }), GF.color("Colour", () => o.fx.glow.color, v => { o.fx.glow.color = v; }, { scene: false }),
        GF.slider("Size", () => o.fx.glow.size, v => { o.fx.glow.size = v; o.fx.glow.on = true; }, 2, 120, 1, v => v + " px", { scene: false }), GF.slider("Strength", () => o.fx.glow.power, v => { o.fx.glow.power = v; }, 0, 2, 0.01, pct, { scene: false })),
      GF.sec("Depth of field", GF.btn(G.p.post.dof.on && G.p.post.dof.target === o.id ? "Focused on this" : "Focus the camera here", () => gxChange(() => { G.p.post.dof.on = true; G.p.post.dof.target = o.id; }, { insp: true, scene: false }))));
    else if (G.tab === "place") body.append(place());
    else gxLookFields(o, body);
    return;
  }
  if (o.type === "part") body.append(GF.sec("Part", GF.segs("Shape", [["block", "Block"], ["ball", "Ball"], ["cylinder", "Cylinder"], ["wedge", "Wedge"], ["cone", "Cone"], ["ring", "Ring"]], () => o.shape, v => { o.shape = v; }),
    GF.select("Material", GX_MATS, () => o.mat, v => { o.mat = v; }), GF.color("Colour", () => o.color, v => { o.color = v; }), swatchRow(v => gxChange(() => { o.color = v; }, { insp: true }))), place("vec"));
  else if (o.type === "prop") body.append(GF.sec("Prop", GF.color("Colour", () => o.color, v => { o.color = v; }), swatchRow(v => gxChange(() => { o.color = v; }, { insp: true }))), place());
  else if (o.type === "fx") body.append(GF.sec("Effect", GF.select("Kind", GX_FX, () => o.kind, v => { o.kind = v; }), GF.color("Colour", () => o.c1, v => { o.c1 = v; }), GF.color("Core", () => o.c2, v => { o.c2 = v; }),
    GF.slider("Brightness", () => o.power, v => { o.power = v; }, 0, 4, 0.01, pct)), place());
  else body.append(place());
}
const GX_SWATCHES = ["#ffffff", "#a3a2a5", "#1b1c22", "#e8473f", "#ff8a2a", "#ffd23f", "#5aa83f", "#3bd1a4", "#4aa3ff", "#2f5fd6", "#8a4dff", "#ff4fd8", "#8a5a32", "#f5cd30", "#d7a37a"];
function swatchRow(pick, list) { return make("div", { class: "swrow" }, ...(list || GX_SWATCHES).map(c => make("button", { type: "button", style: "background:" + c, title: c, onclick: () => pick(c) }))); }
function gxLookFields(o, body) {
  const L = o.look;
  body.append(GF.sec("Character", make("div", { class: "gtiles mini" }, ...GX_PRESETS.map(([k, name, mk]) => { const im = gxImgEl(); gxIcon("char:" + k, () => gxCharThumb(mk()), { dir: [0.35, 0.12, -1], pad: 1.08, w: 150, h: 180 }, im);
    return gxTile(name, im, () => gxChange(() => { const n = mk(); n.items = L.items; o.look = gxCleanLook(n); if (o.name === "Character" || GX_PRESETS.some(p => p[1] === o.name)) o.name = name; }, { insp: true }), { cls: "tall", noLabel: true }); }))));
  const parts = make("div", { class: "gcols" });
  for (const [k, t] of [["head", "Head"], ["torso", "Torso"], ["rarm", "Right arm"], ["larm", "Left arm"], ["rleg", "Right leg"], ["lleg", "Left leg"]]) parts.append(make("label", { class: "gcol" }, GF.color(t, () => L.colors[k], v => { L.colors[k] = v; }, { bare: true }), make("span", { text: t })));
  body.append(GF.sec("Body colours", swatchRow(v => gxChange(() => { for (const k of ["head", "rarm", "larm"]) L.colors[k] = v; if (L.shirt.kind === "none" && !L.shirt.img) L.colors.torso = v; if (L.pants.kind === "none" && !L.pants.img) { L.colors.rleg = v; L.colors.lleg = v; } }, { insp: true }), Object.values(GX_SKIN)), parts));
  // face: the gallery, then your uploads
  body.append(GF.sec("Face", gxFaceGallery(L.colors.head, L.face, L.faceImg, (kind, img) => gxWearFace(kind, img, o)),
    make("div", { class: "rowbtns" }, GF.btn("Upload a face", () => gxPickFile("image/png,image/jpeg,image/webp", f => gxUploadFace(f, o)), "primary"))));
  // clothing: built-in styles or a Roblox template (585 x 559)
  const cloth = (title, key, list) => { const c = L[key];
    const tpl = make("div", { class: "rowbtns" }, GF.btn(c.img ? "Change template" : "Template", () => gxPickFile("image/png,image/jpeg", async f => { try { const id = await gxUploadImage(f); const e = gxImage(id);
        await new Promise(r => { if (e.ok || e.failed) r(); else e.waiters.push(r); }); if (e.ok && (e.img.naturalWidth !== 585 || e.img.naturalHeight !== 559)) toast("Not 585 × 559: stretched to fit"); gxChange(() => { c.img = id; }, { insp: true }); } catch (x) { toast("Couldn't import that template"); } })),
      c.img ? GF.btn("Remove", () => gxChange(() => { c.img = ""; }, { insp: true })) : null);
    return GF.sec(title, c.img ? null : GF.select("Style", list, () => c.kind, v => { c.kind = v; }), c.img ? null : make("div", { class: "gpair" }, GF.color("Main", () => c.c1, v => { c.c1 = v; }), GF.color("Trim", () => c.c2, v => { c.c2 = v; })), tpl); };
  body.append(cloth("Shirt", "shirt", GX_SHIRTS), cloth("Pants", "pants", GX_PANTS),
    GF.sec("T-shirt", make("div", { class: "rowbtns" }, GF.btn(L.tshirt ? "Change" : "Add image", () => gxPickFile("image/png,image/jpeg", async f => { try { const id = await gxUploadImage(f); gxChange(() => { L.tshirt = id; }, { insp: true }); } catch (e) { toast("Couldn't import that image"); } })),
      L.tshirt ? GF.btn("Remove", () => gxChange(() => { L.tshirt = ""; }, { insp: true })) : null)));
  // accessories: tap to add or take off
  const on = new Set(L.acc.map(a => a.kind)), accs = make("div", { class: "gtiles mini" });
  for (const [k, name] of GX_ACC) { const im = gxImgEl(); gxIcon("acc:" + k, () => gxHeadThumb(k, { halo: "#ffd84a", crown: "#f2c230", wings: "#ffffff", horns: "#7d4cff", helmet: "#9aa3b2", bandana: "#c9372c", cap: "#e8473f", beanie: "#2f5fd6", tophat: "#1b1c22", headphones: "#1b1c22", cape: "#c9372c", shades: "#111216" }[k] || "#6a3d1e"), { dir: [0.5, 0.25, -1], pad: 1.05 }, im);
    accs.append(gxTile(name, im, () => gxChange(() => { if (on.has(k)) L.acc = L.acc.filter(a => a.kind !== k); else L.acc.push({ kind: k, color: { halo: "#ffd84a", crown: "#f2c230", wings: "#ffffff", cape: "#c9372c", helmet: "#9aa3b2" }[k] || "#2b2b30" }); }, { insp: true }), { pressed: on.has(k), noLabel: true })); }
  const accCols = L.acc.filter(a => a.kind !== "model" && a.kind !== "import").map(a => GF.color((GX_ACC.find(x => x[0] === a.kind) || [0, "Item"])[1], () => a.color, v => { a.color = v; }));
  const modelAcc = models.size ? GF.select("Add model", [["", "Model on head…"]].concat([...models.entries()].map(([id, m]) => [id, m.name])), () => "", v => { if (v) L.acc.push({ kind: "model", model: v, color: "#ffffff" }); }) : null;
  body.append(GF.sec("Accessories", accs, ...accCols, modelAcc));
  // held items
  const itemOpts = [["", "Nothing"]].concat(GX_ITEMS).concat([...models.entries()].map(([id, m]) => ["m:" + id, m.name]));
  const slot = (joint, label) => { const it = L.items.find(x => x.joint === joint);
    const get = () => it ? (it.kind === "model" ? "m:" + it.model : it.kind) : "";
    const set = v => { L.items = L.items.filter(x => x.joint !== joint); if (v) L.items.push(v.startsWith("m:") ? { kind: "model", model: v.slice(2), joint } : { kind: v, joint, color: "" }); };
    const rows = [GF.select(label, itemOpts, get, set)];
    if (it && it.kind !== "model" && it.kind !== "import") rows.push(make("div", { class: "frow" }, make("span", { class: "fl plain", text: "" }), make("div", { class: "fv" }, GF.color("Colour", () => it.color || "#c8ccd4", v => { it.color = v; }, { bare: true }),
      it.color ? GF.btn("Default", () => gxChange(() => { it.color = ""; }, { insp: true })) : null)));
    if (it) { const fit = gxItemFit(it.kind, joint); rows.push(GF.vec("Offset", () => (it.p || (it.p = fit.p.slice())), { step: 0.05 }), GF.vec("Angle", () => (it.r || (it.r = fit.r.slice())), { step: 1, dp: 1 }),
      GF.slider("Size", () => (it.s ? it.s[0] : 1), v => { it.s = [v, v, v]; }, 0.2, 4, 0.01, x2),
      make("div", { class: "rowbtns" }, GF.btn("Turn 90°", () => gxChange(() => { const r = it.r || (it.r = fit.r.slice()); r[1] = ((r[1] + 90 + 180) % 360) - 180; }, { insp: true })), GF.btn("Reset grip", () => gxChange(() => { delete it.p; delete it.r; delete it.s; }, { insp: true })))); }
    return rows; };
  body.append(GF.sec("Holding", ...slot("Right Arm", "Right hand"), ...slot("Left Arm", "Left hand"), ...slot("Torso", "On the back")));
  body.append(GF.sec("Plastic", GF.slider("Shine", () => 1 - L.plastic, v => { L.plastic = R.round(1 - v, 3); }, 0, 0.95, 0.01, pct), GF.check("Rounded edges", () => L.bevel, v => { L.bevel = v; })));
}
const GX_PARTS = [[null, "Whole"], ["Head", "Head"], ["Torso", "Torso"], ["Right Arm", "R arm"], ["Left Arm", "L arm"], ["Right Leg", "R leg"], ["Left Leg", "L leg"]];
const GX_PART_NAME = { Head: "Head", Torso: "Torso", "Right Arm": "Right arm", "Left Arm": "Left arm", "Right Leg": "Right leg", "Left Leg": "Left leg" };
function gxSetPart(j) { G.part = j; gxAttach(); renderGxTools(); renderGxInsp(); gxDirty = true; }
function gxPoseFields(o, body) {
  const poses = make("div", { class: "presets" }, ...GX_POSES.map(([k, name]) => make("button", { type: "button", text: name, onclick: () => gxChange(() => { o.pose = gxPoseDeg(k); o.off.Torso = [0, 0, 0]; }, { insp: true }) })));
  const parts = make("div", { class: "segs" }); for (const [j, t] of GX_PARTS) parts.append(make("button", { type: "button", class: "chip", "aria-pressed": String(G.part === j), text: t, onclick: () => gxSetPart(j) }));
  const mirror = () => gxChange(() => { const sw = (m, a, b, f) => { const x = m[a]; m[a] = f(m[b]); m[b] = f(x); }, rot = v => [v[0], -v[1], -v[2]], pos = v => [-v[0], v[1], v[2]], same = v => v.slice();
    sw(o.pose, "Right Arm", "Left Arm", rot); sw(o.pose, "Right Leg", "Left Leg", rot); for (const j of ["Head", "Torso"]) o.pose[j] = rot(o.pose[j]);
    sw(o.off, "Right Arm", "Left Arm", pos); sw(o.off, "Right Leg", "Left Leg", pos); for (const j of ["Head", "Torso"]) o.off[j] = pos(o.off[j]);
    sw(o.scl, "Right Arm", "Left Arm", same); sw(o.scl, "Right Leg", "Left Leg", same); }, { insp: true });
  const resetAll = () => gxChange(() => { for (const j of J) { o.off[j] = [0, 0, 0]; o.scl[j] = [1, 1, 1]; } }, { insp: true });
  body.append(GF.sec("Body part", parts));
  if (G.part) { const j = G.part, D = () => o.pose[j];
    const sz = () => o.scl[j], uni = GF.slider("Size", () => (sz()[0] + sz()[1] + sz()[2]) / 3, v => { o.scl[j] = [v, v, v]; }, 0.1, 5, 0.01, x2);
    body.append(GF.sec(GX_PART_NAME[j], GF.slider("Bend", () => D()[0], v => { D()[0] = v; }, -180, 180, 1, deg), GF.slider("Twist", () => D()[1], v => { D()[1] = v; }, -180, 180, 1, deg), GF.slider("Side", () => D()[2], v => { D()[2] = v; }, -180, 180, 1, deg),
      GF.vec("Move", () => o.off[j], { step: 0.05 }), uni, GF.vec("Stretch", () => o.scl[j], { step: 0.05, min: 0.05, max: 20 }),
      make("div", { class: "rowbtns" }, GF.btn("Reset turn", () => gxChange(() => { o.pose[j] = [0, 0, 0]; }, { insp: true })), GF.btn("Reset move", () => gxChange(() => { o.off[j] = [0, 0, 0]; }, { insp: true })),
        GF.btn("Reset size", () => gxChange(() => { o.scl[j] = [1, 1, 1]; }, { insp: true })))));
  }
  body.append(GF.sec("Poses", poses, make("div", { class: "rowbtns" }, GF.btn("Mirror", mirror), GF.btn("Reset parts", resetAll))));
  // a pose from one of the Motion animations, at a moment of it
  const anims = [...docs.entries()].filter(([, v]) => v && v.tracks).sort((a, b) => String(a[1].name || "").localeCompare(String(b[1].name || "")));
  if (anims.length) {
    let pickId = store.get("farshtah.gfx.anim"); if (!anims.some(a => a[0] === pickId)) pickId = anims[0][0];
    let t = parseFloat(store.get("farshtah.gfx.animt") || "0.3") || 0;
    const apply = () => { const raw = docs.get(pickId); if (!raw) return; const a = R.sanitize(raw), len = a.length || 1, pose = R.evaluate(a, clamp(t, 0, 1) * len, R.prepAnim(a));
      gxChange(() => { for (const j of J) { _gq.setFromQuaternion(new THREE.Quaternion(...pose[j].q), "XYZ"); o.pose[j] = [_gq.x, _gq.y, _gq.z].map(v => R.round(v / DEG, 2)); } o.off.Torso = pose.Torso.p.map(v => R.round(v, 3)); }, { merge: "anim", insp: false }); gxUpdateNumbers(); };
    const sel = make("select", { "aria-label": "Animation" }); for (const [id, v] of anims) { const op = make("option", { value: id, text: String(v.name || "Untitled").slice(0, 40) }); if (id === pickId) op.selected = true; sel.append(op); }
    sel.onchange = () => { pickId = sel.value; store.set("farshtah.gfx.anim", pickId); apply(); };
    const rng = make("input", { type: "range", min: 0, max: 1, step: 0.005, "aria-label": "Moment" }); rng.value = t; const out = make("span", { class: "unit", text: pct(t) });
    rng.oninput = () => { t = +rng.value; out.textContent = pct(t); store.set("farshtah.gfx.animt", String(t)); apply(); };
    body.append(GF.sec("From an animation", GF.row("Animation", sel), GF.row("Moment", rng, out), GF.btn("Use this moment", apply, "primary")));
  }
}
// ---- the selected design layer
function gxLayerFields(l, body) {
  const o = { scene: false };
  const order = make("div", { class: "rowbtns" }, GF.btn("Forward", () => gxMoveLayer(1)), GF.btn("Back", () => gxMoveLayer(-1)), GF.btn("Centre", () => gxChange(() => { l.x = 0.5; l.y = 0.5; }, { insp: true, scene: false })));
  const common = () => GF.sec("Layer", GF.slider("Opacity", () => l.opacity, v => { l.opacity = v; }, 0, 1, 0.01, pct, o), GF.select("Blend", GX_BLENDS, () => l.blend, v => { l.blend = v; }, o),
    l.type !== "overlay" ? GF.slider("Tilt", () => l.rot, v => { l.rot = v; }, -180, 180, 1, deg, o) : null, order);
  const shadowSec = () => GF.sec("Shadow & glow", GF.slider("Shadow", () => l.shadow[0], v => { l.shadow[0] = v; }, 0, 4, 0.01, x2, o), GF.slider("Distance", () => l.shadow[2], v => { l.shadow[2] = v; }, 0, 8, 0.05, x2, o),
    GF.slider("Angle", () => l.shadow[3], v => { l.shadow[3] = v; }, -180, 180, 1, deg, o), GF.slider("Darkness", () => l.shadow[4], v => { l.shadow[4] = v; }, 0, 1, 0.01, pct, o), GF.color("Shadow colour", () => l.shadow[1], v => { l.shadow[1] = v; }, o),
    GF.slider("Glow", () => l.glow[0], v => { l.glow[0] = v; }, 0, 4, 0.01, x2, o), GF.color("Glow colour", () => l.glow[1], v => { l.glow[1] = v; }, o));
  if (l.type === "text") {
    const ta = make("textarea", { id: "gxTextIn", rows: 2, maxlength: 300, spellcheck: "false", "aria-label": "Text" }); ta.value = l.text;
    ta.oninput = () => gxChange(() => { l.text = ta.value; }, { merge: "text", scene: false });
    const styles = make("div", { class: "gtiles mini wide" }, ...GX_TEXT_STYLES.map(([k, name]) => gxTile(name, gxTextPic(k), () => gxChange(() => { const keep = { id: l.id, text: l.text, x: l.x, y: l.y, rot: l.rot, size: l.size, name: l.name };
      Object.assign(l, gxTextLayer(k, keep)); }, { insp: true, scene: false }), { cls: "txt", noLabel: true })));
    const fonts = make("select", { "aria-label": "Font" }); for (const [f] of GX_FONTS) { const op = make("option", { value: f, text: f }); op.style.fontFamily = `"${f}"`; if (l.font === f) op.selected = true; fonts.append(op); }
    fonts.onchange = () => { gxEnsureFont(fonts.value); gxChange(() => { l.font = fonts.value; }, { scene: false }); };
    body.append(GF.sec("Text", ta, styles, GF.row("Font", fonts), GF.slider("Size", () => l.size, v => { l.size = v; }, 0.02, 0.6, 0.001, v => Math.round(v * 1080) + " px", o),
      make("div", { class: "segs" }, GF.check("Caps", () => l.upper, v => { l.upper = v; }, o), GF.check("Italic", () => l.italic, v => { l.italic = v; }, o)),
      GF.segs("Align", [["left", "Left"], ["center", "Centre"], ["right", "Right"]], () => l.align, v => { l.align = v; }, o),
      GF.slider("Spacing", () => l.spacing, v => { l.spacing = v; }, -0.1, 0.5, 0.005, x2, o), GF.slider("Lines", () => l.line, v => { l.line = v; }, 0.6, 2, 0.01, x2, o), GF.slider("Arc", () => l.arc, v => { l.arc = v; }, -1, 1, 0.01, x2, o)),
      GF.sec("Fill", GF.segs("", [["solid", "Colour"], ["grad", "Gradient"]], () => l.fill.kind, v => { l.fill.kind = v; }, o), make("div", { class: "gpair" }, GF.color(l.fill.kind === "grad" ? "Top" : "Colour", () => l.fill.a, v => { l.fill.a = v; }, o),
        l.fill.kind === "grad" ? GF.color("Bottom", () => l.fill.b, v => { l.fill.b = v; }, o) : null), l.fill.kind === "grad" ? GF.slider("Angle", () => l.fill.angle, v => { l.fill.angle = v; }, -180, 180, 1, deg, o) : null,
        GF.slider("Shine", () => l.fill.shine, v => { l.fill.shine = v; }, 0, 1, 0.01, pct, o)),
      GF.sec("Outline", GF.slider("Width", () => l.stroke1[0], v => { l.stroke1[0] = v; }, 0, 0.3, 0.002, x2, o), GF.color("Colour", () => l.stroke1[1], v => { l.stroke1[1] = v; }, o),
        GF.slider("Outer", () => l.stroke2[0], v => { l.stroke2[0] = v; }, 0, 0.3, 0.002, x2, o), GF.color("Outer colour", () => l.stroke2[1], v => { l.stroke2[1] = v; }, o)),
      GF.sec("3D depth", GF.slider("Depth", () => l.extrude[0], v => { l.extrude[0] = v; }, 0, 0.4, 0.002, x2, o), GF.slider("Direction", () => l.extrude[2], v => { l.extrude[2] = v; }, -180, 180, 1, deg, o), GF.color("Colour", () => l.extrude[1], v => { l.extrude[1] = v; }, o)),
      shadowSec(), common());
  } else if (l.type === "image") {
    body.append(GF.sec("Image", GF.slider("Size", () => l.h, v => { l.h = v; }, 0.02, 2, 0.001, pct, o), GF.check("Flip", () => l.flip, v => { l.flip = v; }, o),
      GF.slider("Cut-out outline", () => l.outline[0], v => { l.outline[0] = v; }, 0, 0.1, 0.001, x2, o), GF.color("Outline colour", () => l.outline[1], v => { l.outline[1] = v; }, o),
      GF.btn("Replace image", () => gxPickFile("image/png,image/jpeg,image/webp,image/gif", async f => { try { const id = await gxUploadImage(f); gxChange(() => { l.asset = id; }, { insp: true, scene: false }); } catch (e) { toast("Couldn't import that image"); } }))), shadowSec(), common());
  } else if (l.type === "sticker") {
    const kinds = make("div", { class: "gtiles mini" }, ...GX_STICKERS.map(([k, name]) => gxTile(name, gxCanvasPic(60, 60, (c, w, h) => { const d = gxDrawSticker(gxCleanLayer({ type: "sticker", kind: k, h: 0.8 }), 58); c.drawImage(d.cv, (w - d.cv.width) / 2, (h - d.cv.height) / 2); }),
      () => gxChange(() => { l.kind = k; if (k in GX_STICKER_TEXT && !l.text) l.text = GX_STICKER_TEXT[k]; }, { insp: true, scene: false }), { noLabel: true, pressed: l.kind === k })));
    const hasText = l.kind in GX_STICKER_TEXT;
    const ti = make("input", { type: "text", class: "txt", maxlength: 14, "aria-label": "Sticker text" }); ti.value = l.text; ti.oninput = () => gxChange(() => { l.text = ti.value; }, { merge: "stext", scene: false });
    body.append(GF.sec("Sticker", kinds, make("div", { class: "gpair" }, GF.color("Colour", () => l.c1, v => { l.c1 = v; }, o), GF.color("Second", () => l.c2, v => { l.c2 = v; }, o)), swatchRow(v => gxChange(() => { l.c1 = v; l.c2 = gxShade(v, -0.25); }, { insp: true, scene: false })),
      hasText ? GF.row("Text", ti) : null, hasText ? GF.color("Text colour", () => l.textColor, v => { l.textColor = v; }, o) : null,
      GF.slider("Size", () => l.h, v => { l.h = v; }, 0.03, 1.5, 0.001, pct, o), GF.check("Flip", () => l.flip, v => { l.flip = v; }, o),
      GF.slider("Outline", () => l.stroke[0], v => { l.stroke[0] = v; }, 0, 0.2, 0.002, x2, o), GF.color("Outline colour", () => l.stroke[1], v => { l.stroke[1] = v; }, o)), shadowSec(), common());
  } else if (l.type === "overlay") {
    body.append(GF.sec("Overlay", GF.select("Kind", GX_OVERLAYS, () => l.kind, v => { l.kind = v; }, o), make("div", { class: "gpair" }, GF.color("Colour", () => l.c1, v => { l.c1 = v; }, o), GF.color("Second", () => l.c2, v => { l.c2 = v; }, o)),
      GF.slider("Amount", () => l.power, v => { l.power = v; }, 0, 1, 0.01, pct, o), GF.slider("Centre X", () => l.x, v => { l.x = v; }, 0, 1, 0.005, pct, o), GF.slider("Centre Y", () => l.y, v => { l.y = v; }, 0, 1, 0.005, pct, o),
      GF.btn("Shuffle", () => gxChange(() => { l.seed = Math.floor(Math.random() * 9999); }, { scene: false }))), common());
  }
}
// ---- nothing selected: the scene's world, light, camera and finish
function gxSceneFields(body) {
  const p = G.p, W = p.world, L = p.light, C = p.cam, P = p.post, o = { scene: false };
  const sizes = Object.entries(GX_SIZES).map(([k, v]) => [k, v[2]]);
  body.append(GF.sec("Frame", GF.segs("", sizes, () => p.size, v => { p.size = v; }, { size: true, scene: false }), make("p", { class: "ihint", text: GX_SIZES[p.size][0] + " × " + GX_SIZES[p.size][1] })));
  const grounds = Object.entries(GX_SURF).map(([k, v]) => [k, v[0]]).concat([["studio", "Studio backdrop"], ["none", "None"]]);
  body.append(GF.sec("Ground", GF.select("Ground", grounds, () => W.ground.kind, v => { W.ground.kind = v; }, o), GF.color("Colour", () => W.ground.color, v => { W.ground.color = v; }, o),
    W.ground.kind === "neon" ? GF.color("Lines", () => W.ground.color2, v => { W.ground.color2 = v; }, o) : null, GF.slider("Haze", () => W.fog, v => { W.fog = v; }, 0, 1, 0.01, pct, o)));
  body.append(GF.sec("Sky", make("div", { class: "gpair three" }, GF.color("Top", () => W.sky.top, v => { W.sky.top = v; }, o), GF.color("Horizon", () => W.sky.horizon, v => { W.sky.horizon = v; }, o), GF.color("Below", () => W.sky.bottom, v => { W.sky.bottom = v; }, o)),
    GF.slider("Clouds", () => W.sky.clouds, v => { W.sky.clouds = v; }, 0, 1, 0.01, pct, o), GF.color("Cloud colour", () => W.sky.cloud, v => { W.sky.cloud = v; }, o), GF.slider("Stars", () => W.sky.stars, v => { W.sky.stars = v; }, 0, 1, 0.01, pct, o),
    GF.slider("Sun size", () => W.sky.sunSize, v => { W.sky.sunSize = v; }, 0, 4, 0.01, x2, o), GF.btn("New clouds", () => gxChange(() => { W.sky.seed = Math.round(Math.random() * 1000) / 10; }, { scene: false }))));
  body.append(GF.sec("Light", GF.slider("Sun around", () => L.sunAz, v => { L.sunAz = v; }, -180, 180, 1, deg, o), GF.slider("Sun height", () => L.sunEl, v => { L.sunEl = v; }, -5, 90, 1, deg, o),
    GF.color("Sun colour", () => L.sunColor, v => { L.sunColor = v; }, o), GF.slider("Sun", () => L.sun, v => { L.sun = v; }, 0, 6, 0.01, x2, o), GF.slider("Sky light", () => L.sky, v => { L.sky = v; }, 0, 3, 0.01, x2, o),
    GF.slider("Fill", () => L.fill, v => { L.fill = v; }, 0, 2, 0.01, x2, o), GF.slider("Shadows", () => L.shadows, v => { L.shadows = v; }, 0, 1, 0.01, pct, o),
    GF.check("Rim light", () => L.rim.on, v => { L.rim.on = v; }, o), L.rim.on ? GF.color("Rim colour", () => L.rim.color, v => { L.rim.color = v; }, o) : null, L.rim.on ? GF.slider("Rim", () => L.rim.power, v => { L.rim.power = v; }, 0, 8, 0.01, x2, o) : null,
    L.rim.on ? GF.slider("Rim side", () => L.rim.side, v => { L.rim.side = v; }, -1, 1, 0.01, x2, o) : null));
  const focusOpts = [["", "Where the camera looks"]].concat(p.objs.filter(x => x.type === "char").map(x => [x.id, x.name]));
  body.append(GF.sec("Camera", GF.slider("Zoom (FOV)", () => C.fov, v => { C.fov = v; }, 10, 100, 0.5, deg, o), GF.slider("Roll", () => C.roll, v => { C.roll = v; }, -45, 45, 0.5, deg, o),
    make("div", { class: "presets" }, ...GX_CAMS.map(([k, name]) => make("button", { type: "button", text: name, onclick: () => gxCamPreset(k) }))),
    GF.check("Depth of field", () => P.dof.on, v => { P.dof.on = v; }, o), P.dof.on ? GF.slider("Blur", () => P.dof.blur, v => { P.dof.blur = v; }, 0, 1, 0.01, pct, o) : null,
    P.dof.on ? GF.select("Focus on", focusOpts, () => P.dof.target, v => { P.dof.target = v; }, o) : null));
  body.append(GF.sec("Finish", make("div", { class: "presets" }, ...GX_GRADES.map(([k, name]) => make("button", { type: "button", "aria-pressed": String(P.look === k), text: name, onclick: () => gxChange(() => gxApplyGrade(p, k), { insp: true, scene: false }) }))),
    GF.segs("Tone", [["vivid", "Vivid"], ["filmic", "Filmic"], ["flat", "Flat"]], () => P.tone, v => { P.tone = v; }, o),
    GF.slider("Exposure", () => P.exposure, v => { P.exposure = v; }, 0.2, 3, 0.01, x2, o), GF.slider("Contrast", () => P.contrast, v => { P.contrast = v; }, 0.5, 2, 0.01, x2, o),
    GF.slider("Saturation", () => P.saturation, v => { P.saturation = v; }, 0, 2, 0.01, x2, o), GF.slider("Vibrance", () => P.vibrance, v => { P.vibrance = v; }, -1, 1, 0.01, x2, o),
    GF.slider("Warmth", () => P.warmth, v => { P.warmth = v; }, -1, 1, 0.01, x2, o), GF.slider("Tint", () => P.tint, v => { P.tint = v; }, -1, 1, 0.01, x2, o), GF.color("Colour wash", () => P.gradeColor, v => { P.gradeColor = v; }, o),
    GF.slider("Lift", () => P.lift, v => { P.lift = v; }, 0, 1, 0.01, pct, o), GF.slider("Fade", () => P.fade, v => { P.fade = v; }, 0, 1, 0.01, pct, o)));
  body.append(GF.sec("Glow & lens", GF.check("Bloom", () => P.bloom.on, v => { P.bloom.on = v; }, o), GF.slider("Bloom", () => P.bloom.power, v => { P.bloom.power = v; P.bloom.on = true; }, 0, 3, 0.01, x2, o),
    GF.slider("Bloom size", () => P.bloom.size, v => { P.bloom.size = v; }, 0, 1, 0.01, pct, o), GF.slider("Glows above", () => P.bloom.threshold, v => { P.bloom.threshold = v; }, 0, 6, 0.01, x2, o),
    GF.slider("Sharpen", () => P.sharpen, v => { P.sharpen = v; }, 0, 2, 0.01, x2, o), GF.slider("Vignette", () => P.vignette, v => { P.vignette = v; }, 0, 1, 0.01, pct, o), GF.slider("Grain", () => P.grain, v => { P.grain = v; }, 0, 1, 0.01, pct, o),
    GF.slider("Colour split", () => P.chroma, v => { P.chroma = v; }, 0, 3, 0.01, x2, o), GF.slider("Lens", () => P.distort, v => { P.distort = v; }, -1, 1, 0.01, x2, o),
    GF.slider("Zoom blur", () => P.zoom.power, v => { P.zoom.power = v; }, 0, 1, 0.01, pct, o), P.zoom.power > 0 ? GF.slider("Blur centre X", () => P.zoom.x, v => { P.zoom.x = v; }, 0, 1, 0.005, pct, o) : null,
    P.zoom.power > 0 ? GF.slider("Blur centre Y", () => P.zoom.y, v => { P.zoom.y = v; }, 0, 1, 0.005, pct, o) : null));
}
// ---- the layers list
function renderGxLayers() {
  const el = $("gxLayers"); if (!el || !G.p) return; const keep = el.querySelector(".glist") ? el.querySelector(".glist").scrollTop : 0; el.innerHTML = "";
  const list = make("div", { class: "glist" });
  const row = (k, x, icon, extra) => { const sel = G.sel && G.sel.k === k && G.sel.id === x.id;
    const eye = make("button", { type: "button", class: "eye", title: x.hide ? "Show" : "Hide", onclick: ev => { ev.stopPropagation(); gxChange(() => { x.hide = !x.hide; }, { scene: k === "o" }); } }, svgEl(x.hide ? '<path d="M3 3l18 18M10.6 6.1A9.8 9.8 0 0 1 12 6c5 0 9 6 9 6a15 15 0 0 1-3 3.4M6.6 7.7C4.4 9.2 3 12 3 12s4 6 9 6c1.4 0 2.7-.4 3.8-1"/>' : '<path d="M3 12s4-6 9-6 9 6 9 6-4 6-9 6-9-6-9-6z"/><circle cx="12" cy="12" r="2.5"/>'));
    const r = make("div", { class: "lrow" + (sel ? " sel" : "") + (x.hide ? " off" : ""), onclick: () => gxSelect(k, x.id) }, gxSvg(icon), make("span", { class: "nm", text: x.name || icon }), extra, eye);
    return r; };
  if (G.p.layers.length) { list.append(make("div", { class: "lgrp", text: "Design" }));
    for (const L of G.p.layers.slice().reverse()) list.append(row("l", L, L.type, make("button", { type: "button", class: "eye", title: L.lock ? "Unlock" : "Lock", onclick: ev => { ev.stopPropagation(); gxChange(() => { L.lock = !L.lock; }, { scene: false }); } },
      svgEl(L.lock ? '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>' : '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 7.5-2"/>')))); }
  list.append(make("div", { class: "lgrp", text: "Scene" }));
  const env = G.p.objs.filter(o => o.env), mine = G.p.objs.filter(o => !o.env);
  for (const o of mine) list.append(row("o", o, o.type));
  if (env.length) { const open = store.get("farshtah.gfx.envopen") === "1";
    list.append(make("div", { class: "lrow lsub", onclick: () => { store.set("farshtah.gfx.envopen", open ? "0" : "1"); renderGxLayers(); } }, gxSvg("prop"), make("span", { class: "nm", text: `Place (${env.length})` }), make("span", { class: "chev", text: open ? "▾" : "▸" })));
    if (open) for (const o of env) list.append(row("o", o, o.type)); }
  const sceneRow = make("div", { class: "lrow" + (G.sel ? "" : " sel"), onclick: () => gxSelect(null) }, gxSvg("scene"), make("span", { class: "nm", text: "World, light & finish" }));
  list.append(sceneRow);
  el.append(make("div", { class: "tlh" }, make("span", { text: "Layers" }), make("span", { class: "muted", text: String(G.p.layers.length + G.p.objs.length) })), list);
  list.scrollTop = keep;
}
// ---- the frame's toolbars
function renderGxTools() {
  if (!G.p) return; const top = $("gxToolsTop"), bot = $("gxToolsBot"); top.innerHTML = ""; bot.innerHTML = "";
  const chip = (text, pressed, onclick, title) => make("button", { type: "button", class: "chip", "aria-pressed": String(!!pressed), text, title: title || text, onclick });
  for (const [k, v] of Object.entries(GX_SIZES)) top.append(chip(v[2], G.p.size === k, () => gxChange(() => { G.p.size = k; }, { size: true, scene: false, insp: true }), v[0] + " × " + v[1]));
  top.append(make("span", { class: "sep" }), chip("Guides", G.guides, () => { G.guides = !G.guides; renderGxTools(); gxDirty = true; }),
    chip("Lock camera", G.lockCam, () => { G.lockCam = !G.lockCam; gxOrbit.enabled = !G.lockCam; renderGxTools(); }));
  const o = gxSelObj();
  if (o) {
    if (o.type === "char") { for (const [j, t] of GX_PARTS) bot.append(chip(t, G.part === j, () => gxSetPart(j), j ? GX_PART_NAME[j] : "The whole character (Esc)")); bot.append(make("span", { class: "sep" })); }
    for (const [k, t, key] of [["move", "Move", "W"], ["turn", "Turn", "E"], ["scale", "Size", "R"]]) bot.append(chip(t, G.mode === k, () => { G.mode = k; gxAttach(); renderGxTools(); }, t + " (" + key + ")"));
    bot.append(make("span", { class: "sep" }), chip("Focus", false, gxFocusSel, "Focus (F)")); bot.hidden = false; }
  else bot.hidden = true;
}
// ---- projects and export dialogs
function gxOpenProjects() { $("gxProjBack").hidden = false; gxRenderProjects(); $("gxProjClose").focus(); }
function gxCloseProjects() { $("gxProjBack").hidden = true; }
function gxRenderProjects() {
  const tpl = $("gxTpl"); tpl.innerHTML = "";
  tpl.append(make("button", { type: "button", class: "gtpl", onclick: () => { gxNew(""); gxCloseProjects(); } }, make("span", { class: "tp blank", text: "+" }), make("span", { text: "Blank" })));
  for (const [k, name] of GX_TEMPLATES) tpl.append(make("button", { type: "button", class: "gtpl", onclick: () => { gxNew(k); gxCloseProjects(); } }, make("span", { class: "tp t-" + k }), make("span", { text: name })));
  const list = $("gxProjList"); list.innerHTML = "";
  const all = [...G.docs.entries()].sort((a, b) => String(b[1].updatedAt || "").localeCompare(String(a[1].updatedAt || "")));
  if (!all.length) list.append(make("p", { class: "muted", text: "No projects yet" }));
  for (const [id, d] of all) {
    const pic = d.thumb ? make("img", { alt: "", src: d.thumb }) : make("span", { class: "nothumb" });
    const when = d.updatedAt ? new Date(d.updatedAt).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) : "";
    const del = make("button", { type: "button", class: "x", title: "Delete", text: "×", onclick: async ev => { ev.stopPropagation(); if (!confirmDelete(del)) return;
      try { if (G.local) { const a = gxLocalAll(); delete a[id]; store.set(GX_LOCAL, JSON.stringify(a)); G.docs.delete(id); } else await G.col.doc(id).delete(); if (G.docId === id) { G.docId = null; gxSaveSoon(); } gxRenderProjects(); toast("Deleted"); } catch (e) { toast("Couldn't delete it"); } } });
    list.append(make("div", { class: "gproj" + (id === G.docId ? " cur" : ""), role: "button", tabindex: "0", onclick: () => { if ($("gxSave").dataset.s === "pending") gxSaveNow(); gxOpenDoc(id); gxCloseProjects(); } },
      pic, make("span", { class: "pn", text: d.name || "Untitled" }), make("span", { class: "pd", text: when }), del));
  }
}
function confirmDelete(btn) { if (btn.dataset.sure === "1") return true; btn.dataset.sure = "1"; btn.textContent = "Delete?"; btn.classList.add("sure"); setTimeout(() => { btn.dataset.sure = ""; btn.textContent = "×"; btn.classList.remove("sure"); }, 2500); return false; }
const GX_EXP = { res: null, ss: 2, transparent: false, noText: false, fmt: "png" };
function gxExpSizes() { const [W, H] = GX_SIZES[G.p.size], a = W / H; const list = a > 1.2 ? [[1280, 720], [1920, 1080], [2560, 1440], [3840, 2160]] : a < 0.8 ? [[720, 1280], [1080, 1920]] : [[512, 512], [1024, 1024], [2048, 2048]];
  return list.map(([w, h]) => [w + "x" + h, w + " × " + h]); }
function gxOpenExport() { if (!G.p) return; $("gxExpBack").hidden = false; const sizes = gxExpSizes(); if (!GX_EXP.res || !sizes.some(s => s[0] === GX_EXP.res)) GX_EXP.res = GX_SIZES[G.p.size][0] + "x" + GX_SIZES[G.p.size][1];
  if (!sizes.some(s => s[0] === GX_EXP.res)) GX_EXP.res = sizes[Math.min(1, sizes.length - 1)][0]; gxRenderExport(); $("gxExpSave").focus(); }
function gxRenderExport() {
  const el = $("gxExpOpts"); el.innerHTML = "";
  const seg = (label, opts, get, set) => { const box = make("div", { class: "segs" }); for (const [v, t] of opts) box.append(make("button", { type: "button", class: "chip", "aria-pressed": String(get() === v), text: t, onclick: () => { set(v); gxRenderExport(); } }));
    return make("div", { class: "frow" }, make("span", { class: "fl plain", text: label }), make("div", { class: "fv" }, box)); };
  const chk = (label, get, set) => { const i = make("input", { type: "checkbox" }); i.checked = get(); i.onchange = () => set(i.checked); return make("label", { class: "check" }, i, label); };
  el.append(seg("Size", gxExpSizes(), () => GX_EXP.res, v => { GX_EXP.res = v; }), seg("Quality", [[1, "Fast"], [2, "Best"]], () => GX_EXP.ss, v => { GX_EXP.ss = v; }),
    seg("Format", [["png", "PNG"], ["jpg", "JPEG"]], () => GX_EXP.fmt, v => { GX_EXP.fmt = v; }),
    chk("Transparent background (characters only)", () => GX_EXP.transparent, v => { GX_EXP.transparent = v; if (v) GX_EXP.fmt = "png"; gxRenderExport(); }), chk("Text and stickers", () => !GX_EXP.noText, v => { GX_EXP.noText = !v; }),
    make("p", { class: "muted", text: "Saves to " + (HOST.saveRender ? "Farshtah\\renders" : "a download") }));
}
function gxExpOpts() { const [w, h] = GX_EXP.res.split("x").map(Number); return { dims: [w, h], ss: GX_EXP.ss, transparent: GX_EXP.transparent, noText: GX_EXP.noText }; }
async function gxDoExport() {
  const btn = $("gxExpSave"); btn.disabled = true; btn.textContent = "Rendering…";
  try { await new Promise(r => setTimeout(r, 30)); const o = gxExpOpts(), cv = await gxRenderImage(o), jpg = GX_EXP.fmt === "jpg" && !o.transparent;
    const blob = await new Promise(r => cv.toBlob(r, jpg ? "image/jpeg" : "image/png", 0.93)); await gxSaveImage(blob, gxFileName(jpg ? "jpg" : "png")); }
  catch (e) { console.error(e); toast("Couldn't render it"); }
  btn.disabled = false; btn.textContent = "Save";
}
// ---- keys
document.addEventListener("keydown", e => {
  if (APP !== "graphics") return;
  const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement && document.activeElement.tagName) || (document.activeElement && document.activeElement.isContentEditable);
  if (e.key === "Escape") { if (!$("gxExpBack").hidden) { $("gxExpBack").hidden = true; return; } if (!$("gxProjBack").hidden) { gxCloseProjects(); return; } if (!$("settings").hidden) { closeSettings(); return; } if (!typing && G.part) { gxSetPart(null); return; } if (!typing && G.sel) { gxSelect(null); return; } }
  const mod = e.ctrlKey || e.metaKey;
  if (mod && (e.key === "z" || e.key === "Z") && !typing) { e.preventDefault(); if (e.shiftKey) gxRedo(); else gxUndo(); return; }
  if (mod && (e.key === "y" || e.key === "Y") && !typing) { e.preventDefault(); gxRedo(); return; }
  if (mod && (e.key === "s" || e.key === "S")) { e.preventDefault(); gxSaveNow(); return; }
  if (mod && (e.key === "e" || e.key === "E")) { e.preventDefault(); gxOpenExport(); return; }
  if (typing || !G.p) return;
  if (mod && (e.key === "d" || e.key === "D")) { e.preventDefault(); gxDuplicateSel(); return; }
  if (mod && e.key === "]") { e.preventDefault(); gxMoveLayer(1); return; } if (mod && e.key === "[") { e.preventDefault(); gxMoveLayer(-1); return; }
  if (e.key === "Delete" || e.key === "Backspace") { e.preventDefault(); gxDeleteSel(); return; }
  const o = gxSelObj(), l = gxSelLayer();
  if (!mod && o) { const m = { w: "move", e: "turn", r: "scale" }[e.key.toLowerCase()]; if (m) { G.mode = m; gxAttach(); renderGxTools(); return; } }
  if (!mod && (e.key === "f" || e.key === "F")) { gxFocusSel(); return; }
  if (e.key.startsWith("Arrow") && (o || l)) { e.preventDefault(); const st = e.shiftKey ? 10 : 1, dx = e.key === "ArrowLeft" ? -1 : e.key === "ArrowRight" ? 1 : 0, dy = e.key === "ArrowUp" ? -1 : e.key === "ArrowDown" ? 1 : 0;
    if (l) gxChange(() => { l.x = R.round(l.x + dx * st / gxOut.width * gxPR, 4); l.y = R.round(l.y + dy * st / gxOut.height * gxPR, 4); }, { merge: "nudge", scene: false });
    else { const side = new THREE.Vector3(), fwd = new THREE.Vector3(); gxCam.getWorldDirection(fwd); fwd.y = 0; fwd.normalize(); side.crossVectors(fwd, new THREE.Vector3(0, 1, 0));
      gxChange(() => { o.p[0] = R.round(o.p[0] + (side.x * dx - fwd.x * dy) * 0.25 * st, 3); o.p[2] = R.round(o.p[2] + (side.z * dx - fwd.z * dy) * 0.25 * st, 3); }, { merge: "nudge" }); } }
});
// ---- starting Graphics (the first time it shows)
function gxBindUi() {
  $("gxHome").onclick = () => openHub();
  $("gxName").addEventListener("input", () => { if (!G.p) return; G.p.name = $("gxName").value.slice(0, 60) || "Untitled thumbnail"; gxSaveSoon(); });
  $("gxOpen").onclick = gxOpenProjects; $("gxNew").onclick = gxOpenProjects; $("gxProjClose").onclick = gxCloseProjects;
  $("gxProjBack").addEventListener("pointerdown", e => { if (e.target === $("gxProjBack")) gxCloseProjects(); });
  $("gxExport").onclick = gxOpenExport; $("gxExpClose").onclick = () => { $("gxExpBack").hidden = true; };
  $("gxExpBack").addEventListener("pointerdown", e => { if (e.target === $("gxExpBack")) $("gxExpBack").hidden = true; });
  $("gxExpSave").onclick = gxDoExport; $("gxExpCopy").onclick = () => gxCopyImage(gxExpOpts());
  $("gxCopy").onclick = () => gxCopyImage({ dims: GX_SIZES[G.p.size].slice(0, 2), ss: 2 });
  $("gxUndo").onclick = gxUndo; $("gxRedo").onclick = gxRedo; $("gxSettings").onclick = () => openSettings();
  addEventListener("pagehide", () => { if ($("gxSave").dataset.s === "pending") gxSaveNow(); });
}
function gxStart() {
  gxStarted = true; gxLinkFonts();
  gxOut = $("gxOut"); gxOctx = gxOut.getContext("2d");
  G.lib = store.get("farshtah.gfx.lib") || "chars"; if (!GX_TABS.some(t => t[0] === G.lib)) G.lib = "chars";
  if (!gxStartScene()) $("gxStage").insertAdjacentHTML("beforeend", '<div class="nogl">Graphics needs WebGL, which this browser has turned off.</div>');
  else gxStartControls();
  gxBindStage(); gxBindUi();
  new ResizeObserver(() => gxLayout()).observe($("gxStage"));
  gxInitStore().catch(e => { console.error(e); G.local = true; gxFirstOpen(); });
}
function gxOnShow() { if (!gxStarted) gxStart(); if (G.p) gxLayout(); gxDirty = true; }
