// ======================================================================= Farshtah Graphics: the R6 character
// Roblox's R6 proportions (a 2x2x1 torso, 1x2x1 limbs, the rounded classic head) with smooth-plastic shading. Classic
// clothing goes on with Roblox's own 585x559 template layout, so any shirt or pants template from the catalog fits:
// the torso and the right and left arms (on pants: legs) each have front, back, right, left, up and down panels.
const CLOTH_W = 585, CLOTH_H = 559, CLOTH_SCALE = 2; // (procedural clothing is drawn at twice the template's size)
const CLOTH_MAP = {
  T: { front: [231, 74, 128, 128], back: [427, 74, 128, 128], right: [165, 74, 64, 128], left: [361, 74, 64, 128], top: [231, 8, 128, 64], bottom: [231, 204, 128, 64] },
  R: { front: [217, 355, 64, 128], back: [85, 355, 64, 128], right: [151, 355, 64, 128], left: [19, 355, 64, 128], top: [217, 289, 64, 64], bottom: [217, 485, 64, 64] },
  L: { front: [308, 355, 64, 128], back: [440, 355, 64, 128], right: [506, 355, 64, 128], left: [374, 355, 64, 128], top: [308, 289, 64, 64], bottom: [308, 485, 64, 64] },
};
// three.js box faces in order: +X (the part's right side), -X (left), +Y (up), -Y (down), +Z (back), -Z (front)
const BOX_FACES = ["right", "left", "top", "bottom", "back", "front"];
const GX_PART_REGION = { Torso: "T", "Right Arm": "R", "Left Arm": "L", "Right Leg": "R", "Left Leg": "L" };
const GX_COLOR_KEY = { Head: "head", Torso: "torso", "Right Arm": "rarm", "Left Arm": "larm", "Right Leg": "rleg", "Left Leg": "lleg" };
const linCol = hex => new THREE.Color(hex).convertSRGBToLinear();
// ---- geometry
function gxPartGeo(w, h, d, region, bevel) { // a softly bevelled box whose faces read their panel of the clothing atlas
  const g = bevel ? roundedBox(w, h, d, Math.min(w, h, d) * 0.07) : new THREE.BoxGeometry(w, h, d, 2, 2, 2);
  const uv = g.attributes.uv, groups = g.groups;
  groups.forEach((gr, fi) => {
    const r = CLOTH_MAP[region][BOX_FACES[fi]], flip = BOX_FACES[fi] === "top" || BOX_FACES[fi] === "bottom"; // (up / down panels are turned half round)
    const seen = new Set();
    for (let k = gr.start; k < gr.start + gr.count; k++) {
      const i = g.index.getX(k); if (seen.has(i)) continue; seen.add(i);
      let u = uv.getX(i), v = uv.getY(i); if (flip) { u = 1 - u; v = 1 - v; }
      const inset = 0.6; // (half a texel in, so a panel never samples its neighbour)
      uv.setXY(i, (r[0] + inset + u * (r[2] - 2 * inset)) / CLOTH_W, 1 - (r[1] + inset + (1 - v) * (r[3] - 2 * inset)) / CLOTH_H);
    }
  });
  uv.needsUpdate = true; g.clearGroups(); return g;
}
const GX_HEAD = { r: 0.62, h: 0.6, c: 0.27 };
function gxHeadGeo() { // the classic head: a cylinder with well-rounded top and bottom edges
  const { r, h, c } = GX_HEAD, pts = [new THREE.Vector2(0, -h)];
  for (let i = 0; i <= 10; i++) { const a = -Math.PI / 2 + (i / 10) * (Math.PI / 2); pts.push(new THREE.Vector2(r - c + Math.cos(a) * c, -h + c + Math.sin(a) * c)); }
  for (let i = 0; i <= 10; i++) { const a = (i / 10) * (Math.PI / 2); pts.push(new THREE.Vector2(r - c + Math.cos(a) * c, h - c + Math.sin(a) * c)); }
  pts.push(new THREE.Vector2(0, h));
  return new THREE.LatheGeometry(pts, 56);
}
function gxFaceGeo() { // the face's decal: a curved strip just in front of the head
  const { r, h, c } = GX_HEAD, L = 2.15;
  return new THREE.CylinderGeometry(r + 0.004, r + 0.004, (h - c) * 2 + 0.34, 40, 1, true, Math.PI - L / 2, L);
}
// ---- faces (drawn here: black features on transparent, the head's colour shows through)
const GX_FACES = [["smile", "Smile"], ["grin", "Grin"], ["happy", "Happy"], ["laugh", "Laughing"], ["blush", "Blushing"], ["chill", "Chill"], ["smug", "Smug"], ["wink", "Wink"],
  ["tongue", "Silly"], ["uwu", "Cute"], ["hearts", "Heart eyes"], ["stars", "Star eyes"], ["money", "Money eyes"], ["kiss", "Kiss"], ["cool", "Cool shades"], ["determined", "Determined"],
  ["angry", "Angry"], ["rage", "Rage"], ["evil", "Evil grin"], ["skeptic", "Skeptical"], ["bored", "Bored"], ["sleepy", "Sleepy"], ["sad", "Sad"], ["cry", "Crying"],
  ["nervous", "Nervous"], ["shocked", "Shocked"], ["scream", "Screaming"], ["dead", "Knocked out"], ["zombie", "Zombie"], ["robot", "Robot"], ["ninja", "Ninja mask"], ["beard", "Beard"], ["none", "No face"]];
function gxDrawFace(c, kind, W, H) {
  const cx = W / 2, ink = "#1a1a1d"; c.clearRect(0, 0, W, H); c.fillStyle = ink; c.strokeStyle = ink; c.lineCap = "round"; c.lineJoin = "round";
  const eye = (x, y, w, h) => { c.beginPath(); c.ellipse(x, y, w, h, 0, 0, Math.PI * 2); c.fill(); };
  const shine = (x, y, s) => { c.save(); c.fillStyle = "#ffffff"; c.beginPath(); c.ellipse(x, y, s, s * 1.15, 0, 0, Math.PI * 2); c.fill(); c.restore(); };
  const brow = (x1, y1, x2, y2, w) => { c.lineWidth = w; c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.stroke(); };
  const ex = W * 0.13, ey = H * 0.4;
  const fillIn = (col, fn) => { c.save(); c.fillStyle = col; fn(); c.restore(); };
  const blush = a => fillIn(`rgba(255,110,140,${a || 0.55})`, () => { for (const s of [-1, 1]) { c.beginPath(); c.ellipse(cx + s * W * 0.25, H * 0.6, 34, 18, 0, 0, Math.PI * 2); c.fill(); } });
  const heart = (x, y, s, col) => fillIn(col, () => { c.beginPath(); c.moveTo(x, y + s * 0.9); c.bezierCurveTo(x - s * 1.6, y - s * 0.1, x - s * 0.8, y - s * 1.3, x, y - s * 0.45); c.bezierCurveTo(x + s * 0.8, y - s * 1.3, x + s * 1.6, y - s * 0.1, x, y + s * 0.9); c.fill(); });
  const star = (x, y, r, col) => { c.save(); c.beginPath(); for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? r * 0.45 : r; c.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); } c.closePath();
    c.fillStyle = col; c.fill(); c.lineWidth = 7; c.strokeStyle = "#1a1a1d"; c.stroke(); c.restore(); };
  const arc = (x, y, r, a0, a1, w) => { c.lineWidth = w || 12; c.beginPath(); c.arc(x, y, r, a0, a1); c.stroke(); };
  const grinMouth = (y0, y1, wd) => { c.beginPath(); c.moveTo(cx - W * wd, H * y0); c.quadraticCurveTo(cx, H * (y0 + 0.03), cx + W * wd, H * y0); c.quadraticCurveTo(cx + W * wd * 0.8, H * y1, cx, H * y1); c.quadraticCurveTo(cx - W * wd * 0.8, H * y1, cx - W * wd, H * y0); c.fill(); };
  switch (kind) {
    case "none": return;
    case "smile": eye(cx - ex, ey, 17, 33); eye(cx + ex, ey, 17, 33); c.lineWidth = 13; c.beginPath(); c.arc(cx, H * 0.36, W * 0.22, 0.2 * Math.PI, 0.8 * Math.PI); c.stroke(); break;
    case "grin": {
      eye(cx - ex, ey, 18, 34); eye(cx + ex, ey, 18, 34); shine(cx - ex - 5, ey - 12, 6); shine(cx + ex - 5, ey - 12, 6);
      c.beginPath(); c.moveTo(cx - W * 0.2, H * 0.58); c.quadraticCurveTo(cx, H * 0.6, cx + W * 0.2, H * 0.58); c.quadraticCurveTo(cx + W * 0.16, H * 0.86, cx, H * 0.86); c.quadraticCurveTo(cx - W * 0.16, H * 0.86, cx - W * 0.2, H * 0.58); c.fill();
      c.fillStyle = "#ffffff"; c.beginPath(); c.moveTo(cx - W * 0.17, H * 0.6); c.quadraticCurveTo(cx, H * 0.62, cx + W * 0.17, H * 0.6); c.lineTo(cx + W * 0.15, H * 0.67); c.quadraticCurveTo(cx, H * 0.69, cx - W * 0.15, H * 0.67); c.fill(); break;
    }
    case "happy": c.lineWidth = 14; for (const s of [-1, 1]) { c.beginPath(); c.arc(cx + s * ex, ey + 12, 26, 1.1 * Math.PI, 1.9 * Math.PI); c.stroke(); }
      c.beginPath(); c.moveTo(cx - W * 0.17, H * 0.6); c.quadraticCurveTo(cx, H * 0.95, cx + W * 0.17, H * 0.6); c.closePath(); c.fill(); break;
    case "smug": // half-closed eyes, raised brow, a sideways smirk
      eye(cx - ex, ey + 6, 18, 22); eye(cx + ex, ey + 6, 18, 22); c.save(); c.globalCompositeOperation = "destination-out"; c.fillRect(0, ey - 30, W, 22); c.restore();
      brow(cx - ex - 30, ey - 34, cx - ex + 26, ey - 26, 11); brow(cx + ex - 26, ey - 40, cx + ex + 30, ey - 52, 11);
      c.lineWidth = 12; c.beginPath(); c.moveTo(cx - W * 0.16, H * 0.66); c.quadraticCurveTo(cx + W * 0.04, H * 0.74, cx + W * 0.2, H * 0.58); c.stroke(); break;
    case "angry": eye(cx - ex, ey + 8, 16, 26); eye(cx + ex, ey + 8, 16, 26);
      brow(cx - ex - 34, ey - 34, cx - ex + 22, ey - 12, 15); brow(cx + ex + 34, ey - 34, cx + ex - 22, ey - 12, 15);
      c.lineWidth = 13; c.beginPath(); c.arc(cx, H * 0.84, W * 0.13, 1.15 * Math.PI, 1.85 * Math.PI); c.stroke(); break;
    case "shocked": eye(cx - ex, ey - 4, 22, 38); eye(cx + ex, ey - 4, 22, 38); shine(cx - ex - 6, ey - 18, 7); shine(cx + ex - 6, ey - 18, 7);
      brow(cx - ex - 24, ey - 60, cx - ex + 18, ey - 66, 10); brow(cx + ex - 18, ey - 66, cx + ex + 24, ey - 60, 10);
      c.beginPath(); c.ellipse(cx, H * 0.72, W * 0.06, H * 0.12, 0, 0, Math.PI * 2); c.fill(); break;
    case "evil": eye(cx - ex, ey, 18, 30); eye(cx + ex, ey, 18, 30); brow(cx - ex - 30, ey - 44, cx - ex + 24, ey - 22, 12); brow(cx + ex + 30, ey - 44, cx + ex - 24, ey - 22, 12);
      c.beginPath(); c.moveTo(cx - W * 0.23, H * 0.55); c.quadraticCurveTo(cx, H * 0.95, cx + W * 0.23, H * 0.55); c.quadraticCurveTo(cx, H * 0.7, cx - W * 0.23, H * 0.55); c.fill();
      c.fillStyle = "#ffffff"; for (let i = -3; i <= 3; i++) { const x = cx + i * W * 0.05; c.beginPath(); c.moveTo(x - 9, H * 0.63); c.lineTo(x + 9, H * 0.63); c.lineTo(x, H * 0.7); c.fill(); } break;
    case "sad": eye(cx - ex, ey + 4, 16, 30); eye(cx + ex, ey + 4, 16, 30); brow(cx - ex - 26, ey - 30, cx - ex + 20, ey - 44, 10); brow(cx + ex + 26, ey - 30, cx + ex - 20, ey - 44, 10);
      c.lineWidth = 12; c.beginPath(); c.arc(cx, H * 0.88, W * 0.14, 1.2 * Math.PI, 1.8 * Math.PI); c.stroke(); break;
    case "wink": eye(cx + ex, ey, 17, 33); c.lineWidth = 12; c.beginPath(); c.moveTo(cx - ex - 24, ey + 4); c.quadraticCurveTo(cx - ex, ey - 14, cx - ex + 24, ey + 4); c.stroke();
      c.beginPath(); c.arc(cx, H * 0.38, W * 0.2, 0.22 * Math.PI, 0.78 * Math.PI); c.stroke(); break;
    case "cool": c.beginPath(); c.moveTo(cx - W * 0.33, ey - 30); c.lineTo(cx + W * 0.33, ey - 30); c.lineTo(cx + W * 0.3, ey + 2); c.quadraticCurveTo(cx + W * 0.2, ey + 34, cx + 30, ey + 6); c.lineTo(cx - 30, ey + 6);
      c.quadraticCurveTo(cx - W * 0.2, ey + 34, cx - W * 0.3, ey + 2); c.closePath(); c.fill(); c.save(); c.fillStyle = "rgba(255,255,255,.35)"; c.fillRect(cx - W * 0.27, ey - 24, W * 0.1, 8); c.fillRect(cx + W * 0.08, ey - 24, W * 0.1, 8); c.restore();
      c.lineWidth = 12; c.beginPath(); c.moveTo(cx - W * 0.12, H * 0.68); c.quadraticCurveTo(cx + W * 0.04, H * 0.76, cx + W * 0.16, H * 0.64); c.stroke(); break;
    case "dead": c.lineWidth = 13; for (const s of [-1, 1]) { const x = cx + s * ex; brow(x - 20, ey - 20, x + 20, ey + 20, 13); brow(x + 20, ey - 20, x - 20, ey + 20, 13); }
      c.beginPath(); c.moveTo(cx - W * 0.12, H * 0.72); c.lineTo(cx + W * 0.12, H * 0.72); c.stroke(); c.save(); c.fillStyle = "#ff6b8a"; c.beginPath(); c.ellipse(cx + W * 0.05, H * 0.77, 16, 20, 0, 0, Math.PI); c.fill(); c.restore(); break;
    case "determined": eye(cx - ex, ey + 6, 16, 24); eye(cx + ex, ey + 6, 16, 24); brow(cx - ex - 30, ey - 26, cx - ex + 24, ey - 14, 14); brow(cx + ex + 30, ey - 26, cx + ex - 24, ey - 14, 14);
      c.lineWidth = 12; c.beginPath(); c.moveTo(cx - W * 0.12, H * 0.72); c.quadraticCurveTo(cx, H * 0.68, cx + W * 0.12, H * 0.72); c.stroke(); break;
    case "laugh": for (const s of [-1, 1]) { c.lineWidth = 13; c.beginPath(); c.moveTo(cx + s * ex - 26, ey + 12); c.lineTo(cx + s * ex, ey - 12); c.lineTo(cx + s * ex + 26, ey + 12); c.stroke(); }
      grinMouth(0.56, 0.95, 0.2); fillIn("#e8576b", () => { c.beginPath(); c.ellipse(cx, H * 0.86, W * 0.08, H * 0.055, 0, 0, Math.PI * 2); c.fill(); }); break;
    case "blush": eye(cx - ex, ey, 19, 34); eye(cx + ex, ey, 19, 34); for (const s of [-1, 1]) { shine(cx + s * ex - 6, ey - 13, 7); shine(cx + s * ex + 6, ey + 10, 3.5); }
      arc(cx, H * 0.4, W * 0.17, 0.25 * Math.PI, 0.75 * Math.PI); blush(0.6); break;
    case "chill": for (const s of [-1, 1]) arc(cx + s * ex, ey - 6, 24, 0.15 * Math.PI, 0.85 * Math.PI, 12);
      c.lineWidth = 12; c.beginPath(); c.moveTo(cx - W * 0.13, H * 0.68); c.quadraticCurveTo(cx + W * 0.02, H * 0.78, cx + W * 0.16, H * 0.64); c.stroke(); break;
    case "tongue": eye(cx + ex, ey, 17, 33); c.lineWidth = 12; c.beginPath(); c.moveTo(cx - ex - 24, ey + 4); c.quadraticCurveTo(cx - ex, ey - 14, cx - ex + 24, ey + 4); c.stroke();
      fillIn("#e8576b", () => { c.beginPath(); c.moveTo(cx - W * 0.02, H * 0.7); c.lineTo(cx + W * 0.1, H * 0.7); c.quadraticCurveTo(cx + W * 0.11, H * 0.9, cx + W * 0.04, H * 0.9); c.quadraticCurveTo(cx - W * 0.03, H * 0.9, cx - W * 0.02, H * 0.7); c.fill(); });
      arc(cx, H * 0.42, W * 0.18, 0.22 * Math.PI, 0.78 * Math.PI); break;
    case "uwu": for (const s of [-1, 1]) arc(cx + s * ex, ey - 4, 22, 0.1 * Math.PI, 0.9 * Math.PI, 12);
      c.lineWidth = 11; c.beginPath(); c.moveTo(cx - 34, H * 0.66); c.quadraticCurveTo(cx - 17, H * 0.76, cx, H * 0.66); c.quadraticCurveTo(cx + 17, H * 0.76, cx + 34, H * 0.66); c.stroke(); blush(0.6); break;
    case "hearts": heart(cx - ex, ey, 30, "#ff3b5c"); heart(cx + ex, ey, 30, "#ff3b5c"); grinMouth(0.6, 0.85, 0.15); break;
    case "stars": star(cx - ex, ey, 36, "#ffd23f"); star(cx + ex, ey, 36, "#ffd23f"); grinMouth(0.6, 0.88, 0.17); break;
    case "money": c.save(); c.fillStyle = "#2fbf3a"; c.strokeStyle = "#1a1a1d"; c.lineWidth = 6; c.font = "900 92px Arial, sans-serif"; c.textAlign = "center"; c.textBaseline = "middle";
      for (const s of [-1, 1]) { c.strokeText("$", cx + s * ex, ey + 4); c.fillText("$", cx + s * ex, ey + 4); } c.restore(); grinMouth(0.6, 0.86, 0.17); break;
    case "kiss": for (const s of [-1, 1]) arc(cx + s * ex, ey + 4, 22, 1.1 * Math.PI, 1.9 * Math.PI, 12);
      c.lineWidth = 11; c.beginPath(); c.arc(cx, H * 0.72, 18, 0, Math.PI * 2); c.stroke(); heart(cx + W * 0.2, H * 0.62, 16, "#ff3b5c"); blush(0.4); break;
    case "rage": eye(cx - ex, ey + 12, 13, 18); eye(cx + ex, ey + 12, 13, 18); brow(cx - ex - 40, ey - 40, cx - ex + 26, ey - 6, 20); brow(cx + ex + 40, ey - 40, cx + ex - 26, ey - 6, 20);
      fillIn("#ffffff", () => { c.beginPath(); c.roundRect ? c.roundRect(cx - W * 0.17, H * 0.62, W * 0.34, H * 0.16, 12) : c.rect(cx - W * 0.17, H * 0.62, W * 0.34, H * 0.16); c.fill(); });
      c.lineWidth = 7; c.beginPath(); c.roundRect ? c.roundRect(cx - W * 0.17, H * 0.62, W * 0.34, H * 0.16, 12) : c.rect(cx - W * 0.17, H * 0.62, W * 0.34, H * 0.16); c.stroke();
      c.lineWidth = 5; c.beginPath(); c.moveTo(cx - W * 0.17, H * 0.7); c.lineTo(cx + W * 0.17, H * 0.7); for (let i = -2; i <= 2; i++) { c.moveTo(cx + i * W * 0.06, H * 0.62); c.lineTo(cx + i * W * 0.06, H * 0.78); } c.stroke(); break;
    case "skeptic": eye(cx - ex, ey + 6, 16, 26); eye(cx + ex, ey + 2, 17, 30); brow(cx - ex - 28, ey - 24, cx - ex + 24, ey - 24, 11); brow(cx + ex - 26, ey - 52, cx + ex + 28, ey - 44, 11);
      c.lineWidth = 12; c.beginPath(); c.moveTo(cx - W * 0.12, H * 0.74); c.lineTo(cx + W * 0.12, H * 0.69); c.stroke(); break;
    case "bored": for (const s of [-1, 1]) { eye(cx + s * ex, ey + 8, 17, 22); c.save(); c.globalCompositeOperation = "destination-out"; c.fillRect(cx + s * ex - 24, ey - 24, 48, 26); c.restore(); c.lineWidth = 9; c.beginPath(); c.moveTo(cx + s * ex - 24, ey + 2); c.lineTo(cx + s * ex + 24, ey + 2); c.stroke(); }
      c.lineWidth = 12; c.beginPath(); c.moveTo(cx - W * 0.1, H * 0.72); c.lineTo(cx + W * 0.1, H * 0.72); c.stroke(); break;
    case "sleepy": for (const s of [-1, 1]) arc(cx + s * ex, ey - 10, 22, 0.15 * Math.PI, 0.85 * Math.PI, 11);
      c.lineWidth = 10; c.beginPath(); c.ellipse(cx, H * 0.72, 16, 20, 0, 0, Math.PI * 2); c.stroke();
      c.save(); c.font = "900 54px Arial, sans-serif"; c.fillText("z", cx + W * 0.27, H * 0.22); c.font = "900 38px Arial, sans-serif"; c.fillText("z", cx + W * 0.36, H * 0.12); c.restore(); break;
    case "cry": eye(cx - ex, ey + 4, 16, 30); eye(cx + ex, ey + 4, 16, 30); brow(cx - ex - 26, ey - 30, cx - ex + 20, ey - 44, 10); brow(cx + ex + 26, ey - 30, cx + ex - 20, ey - 44, 10);
      fillIn("rgba(90,180,255,.85)", () => { for (const s of [-1, 1]) { c.beginPath(); c.roundRect ? c.roundRect(cx + s * ex - 10, ey + 26, 20, H * 0.5, 10) : c.rect(cx + s * ex - 10, ey + 26, 20, H * 0.5); c.fill(); } });
      c.lineWidth = 11; c.beginPath(); c.moveTo(cx - W * 0.12, H * 0.8); c.quadraticCurveTo(cx - W * 0.06, H * 0.7, cx, H * 0.78); c.quadraticCurveTo(cx + W * 0.06, H * 0.7, cx + W * 0.12, H * 0.8); c.stroke(); break;
    case "nervous": eye(cx - ex, ey, 16, 30); eye(cx + ex, ey, 16, 30); brow(cx - ex - 24, ey - 36, cx - ex + 20, ey - 46, 9); brow(cx + ex + 24, ey - 36, cx + ex - 20, ey - 46, 9);
      c.lineWidth = 10; c.beginPath(); for (let i = 0; i <= 8; i++) { const x = cx - W * 0.14 + i * W * 0.035; const y = H * 0.73 + (i % 2 ? -10 : 10); if (i) c.lineTo(x, y); else c.moveTo(x, y); } c.stroke();
      fillIn("rgba(110,190,255,.95)", () => { const x = cx + W * 0.3, y = H * 0.22; c.beginPath(); c.moveTo(x, y - 30); c.quadraticCurveTo(x + 22, y + 4, x, y + 14); c.quadraticCurveTo(x - 22, y + 4, x, y - 30); c.fill(); }); break;
    case "scream": for (const s of [-1, 1]) { fillIn("#ffffff", () => { c.beginPath(); c.ellipse(cx + s * ex, ey - 4, 28, 38, 0, 0, Math.PI * 2); c.fill(); }); c.lineWidth = 7; c.beginPath(); c.ellipse(cx + s * ex, ey - 4, 28, 38, 0, 0, Math.PI * 2); c.stroke(); eye(cx + s * ex, ey - 2, 7, 8); }
      c.beginPath(); c.ellipse(cx, H * 0.75, W * 0.09, H * 0.15, 0, 0, Math.PI * 2); c.fill(); break;
    case "zombie": c.lineWidth = 12; brow(cx - ex - 20, ey - 20, cx - ex + 20, ey + 20, 12); brow(cx - ex + 20, ey - 20, cx - ex - 20, ey + 20, 12);
      fillIn("#ffffff", () => { c.beginPath(); c.arc(cx + ex, ey, 26, 0, Math.PI * 2); c.fill(); }); c.lineWidth = 7; c.beginPath(); c.arc(cx + ex, ey, 26, 0, Math.PI * 2); c.stroke(); eye(cx + ex + 4, ey + 4, 7, 7);
      c.lineWidth = 8; c.beginPath(); c.moveTo(cx - W * 0.15, H * 0.74); c.lineTo(cx + W * 0.15, H * 0.72); for (let i = -2; i <= 2; i++) { const x = cx + i * W * 0.06; c.moveTo(x, H * 0.68); c.lineTo(x, H * 0.79); } c.stroke(); break;
    case "robot": c.save(); c.shadowColor = "#3df2ff"; c.shadowBlur = 24; c.fillStyle = "#7ff7ff";
      for (const s of [-1, 1]) { c.beginPath(); c.roundRect ? c.roundRect(cx + s * ex - 34, ey - 18, 68, 36, 10) : c.rect(cx + s * ex - 34, ey - 18, 68, 36); c.fill(); } c.restore();
      c.lineWidth = 7; c.beginPath(); c.roundRect ? c.roundRect(cx - W * 0.15, H * 0.64, W * 0.3, H * 0.13, 8) : c.rect(cx - W * 0.15, H * 0.64, W * 0.3, H * 0.13); c.stroke();
      c.lineWidth = 5; c.beginPath(); for (let i = -3; i <= 3; i++) { c.moveTo(cx + i * W * 0.035, H * 0.65); c.lineTo(cx + i * W * 0.035, H * 0.76); } c.stroke(); break;
    case "ninja": c.fillRect(0, ey - 46, W, 92); fillIn("#ffffff", () => { for (const s of [-1, 1]) { c.beginPath(); c.moveTo(cx + s * (ex - 34), ey - (s > 0 ? 4 : 4)); c.lineTo(cx + s * (ex + 34), ey - 16); c.lineTo(cx + s * (ex + 28), ey + 12); c.lineTo(cx + s * (ex - 30), ey + 10); c.closePath(); c.fill(); } });
      eye(cx - ex - 6, ey, 9, 11); eye(cx + ex + 6, ey, 9, 11); break;
    case "beard": eye(cx - ex, ey - 8, 16, 28); eye(cx + ex, ey - 8, 16, 28); brow(cx - ex - 26, ey - 48, cx - ex + 22, ey - 46, 11); brow(cx + ex - 22, ey - 46, cx + ex + 26, ey - 48, 11);
      fillIn("#5a3a22", () => { c.beginPath(); c.moveTo(cx - W * 0.33, H * 0.5); c.quadraticCurveTo(cx - W * 0.3, H * 1.02, cx, H * 1.0); c.quadraticCurveTo(cx + W * 0.3, H * 1.02, cx + W * 0.33, H * 0.5); c.lineTo(cx + W * 0.25, H * 0.55);
        c.quadraticCurveTo(cx, H * 0.6, cx - W * 0.25, H * 0.55); c.closePath(); c.fill(); c.beginPath(); c.moveTo(cx - W * 0.16, H * 0.62); c.quadraticCurveTo(cx, H * 0.54, cx + W * 0.16, H * 0.62); c.quadraticCurveTo(cx, H * 0.64, cx - W * 0.16, H * 0.62); c.fill(); });
      fillIn("#1a1a1d", () => { c.beginPath(); c.ellipse(cx, H * 0.72, W * 0.07, H * 0.04, 0, 0, Math.PI); c.fill(); }); break;
    default: eye(cx - ex, ey, 17, 33); eye(cx + ex, ey, 17, 33);
  }
}
// ---- clothing: the built-in styles, drawn panel by panel onto a template-sized canvas
const GX_SHIRTS = [["none", "None"], ["tee", "T-shirt"], ["hoodie", "Hoodie"], ["suit", "Suit"], ["jacket", "Open jacket"], ["jersey", "Jersey"], ["ninja", "Ninja"],
  ["knight", "Knight armor"], ["police", "Police"], ["stripes", "Stripes"], ["camo", "Camo"], ["tank", "Tank top"]];
const GX_PANTS = [["none", "None"], ["jeans", "Jeans"], ["pants", "Pants"], ["shorts", "Shorts"], ["sweats", "Sweatpants"], ["camo", "Camo"], ["armor", "Armor"]];
function gxShade(hex, k) { const c = new THREE.Color(hex); if (k < 0) c.lerp(new THREE.Color(0, 0, 0), -k); else c.lerp(new THREE.Color(1, 1, 1), k); return "#" + c.getHexString(); }
function gxPanels(regions) { const out = []; for (const rg of regions) for (const f of BOX_FACES) out.push([rg, f, CLOTH_MAP[rg][f]]); return out; }
function gxDrawShirt(c, kind, c1, c2) { // c: a 2d context already scaled to template pixels
  if (kind === "none") return;
  const dark = gxShade(c1, -0.35), light = gxShade(c1, 0.18), all = gxPanels(["T", "R", "L"]);
  const fill = (r, col, y0, y1) => { c.fillStyle = col; c.fillRect(r[0], r[1] + r[3] * (y0 || 0), r[2], r[3] * ((y1 == null ? 1 : y1) - (y0 || 0))); };
  const seamTop = r => { c.fillStyle = "rgba(0,0,0,.12)"; c.fillRect(r[0], r[1], r[2], 3); };
  if (kind === "tee" || kind === "tank") {
    for (const [rg, f, r] of all) { if (rg === "T") fill(r, c1); else if (kind === "tee" && f !== "bottom") fill(r, c1, 0, f === "top" ? 1 : 0.42); }
    const fr = CLOTH_MAP.T.front; c.fillStyle = dark; c.beginPath(); c.ellipse(fr[0] + 64, fr[1], 26, 16, 0, 0, Math.PI); c.fill();
    if (kind === "tee") for (const rg of ["R", "L"]) for (const f of ["front", "back", "left", "right"]) { const r = CLOTH_MAP[rg][f]; c.fillStyle = dark; c.fillRect(r[0], r[1] + r[3] * 0.42 - 4, r[2], 4); }
    else for (const rg of ["R", "L"]) { const r = CLOTH_MAP.T[rg === "R" ? "right" : "left"]; c.fillStyle = gxShade(c1, -0.15); c.fillRect(r[0], r[1], r[2], 10); }
    return;
  }
  if (kind === "stripes" || kind === "camo") {
    for (const [, , r] of all) { fill(r, c1);
      if (kind === "stripes") { c.fillStyle = c2; for (let y = r[1] + 8; y < r[1] + r[3]; y += 22) c.fillRect(r[0], y, r[2], 10); }
      else { const rnd = vxRand(r[0] * 31 + r[1]); for (let i = 0; i < r[2] * r[3] / 220; i++) { c.fillStyle = [c2, dark, light][i % 3]; c.beginPath(); c.ellipse(r[0] + rnd() * r[2], r[1] + rnd() * r[3], 6 + rnd() * 10, 4 + rnd() * 7, rnd() * 3, 0, Math.PI * 2); c.fill(); } }
    } return;
  }
  for (const [rg, f, r] of all) fill(r, c1);
  const F = CLOTH_MAP.T.front, B = CLOTH_MAP.T.back;
  if (kind === "hoodie") {
    c.fillStyle = dark; c.beginPath(); c.roundRect ? c.roundRect(F[0] + 24, F[1] + 78, 80, 36, 10) : c.rect(F[0] + 24, F[1] + 78, 80, 36); c.fill();
    c.strokeStyle = light; c.lineWidth = 3; for (const x of [F[0] + 52, F[0] + 76]) { c.beginPath(); c.moveTo(x, F[1] + 6); c.lineTo(x - 2, F[1] + 44); c.stroke(); c.fillStyle = light; c.beginPath(); c.arc(x - 2, F[1] + 46, 3.5, 0, 7); c.fill(); }
    c.fillStyle = dark; c.beginPath(); c.ellipse(F[0] + 64, F[1], 34, 16, 0, 0, Math.PI); c.fill();
    c.fillStyle = gxShade(c1, -0.15); c.beginPath(); c.moveTo(B[0] + 20, B[1]); c.quadraticCurveTo(B[0] + 64, B[1] + 70, B[0] + 108, B[1]); c.fill(); // the hood on the back
    for (const rg of ["R", "L"]) for (const f of ["front", "back", "left", "right"]) { const r = CLOTH_MAP[rg][f]; c.fillStyle = dark; c.fillRect(r[0], r[1] + r[3] - 14, r[2], 14); }
    for (const f of ["front", "back", "left", "right"]) { const r = CLOTH_MAP.T[f]; c.fillStyle = dark; c.fillRect(r[0], r[1] + r[3] - 12, r[2], 12); }
  } else if (kind === "suit") {
    c.fillStyle = "#f4f4f6"; c.beginPath(); c.moveTo(F[0] + 40, F[1]); c.lineTo(F[0] + 88, F[1]); c.lineTo(F[0] + 64, F[1] + 66); c.closePath(); c.fill();
    c.fillStyle = c2; c.beginPath(); c.moveTo(F[0] + 58, F[1] + 4); c.lineTo(F[0] + 70, F[1] + 4); c.lineTo(F[0] + 72, F[1] + 50); c.lineTo(F[0] + 64, F[1] + 60); c.lineTo(F[0] + 56, F[1] + 50); c.closePath(); c.fill();
    c.strokeStyle = gxShade(c1, -0.5); c.lineWidth = 3; c.beginPath(); c.moveTo(F[0] + 36, F[1]); c.lineTo(F[0] + 62, F[1] + 70); c.lineTo(F[0] + 62, F[1] + 128); c.moveTo(F[0] + 92, F[1]); c.lineTo(F[0] + 66, F[1] + 70); c.stroke();
    c.fillStyle = light; for (const y of [F[1] + 84, F[1] + 104]) { c.beginPath(); c.arc(F[0] + 72, y, 3.5, 0, 7); c.fill(); }
    for (const rg of ["R", "L"]) for (const f of ["front", "back", "left", "right"]) { const r = CLOTH_MAP[rg][f]; c.fillStyle = "#f4f4f6"; c.fillRect(r[0], r[1] + r[3] - 8, r[2], 8); }
  } else if (kind === "jacket") {
    c.fillStyle = c2; c.fillRect(F[0] + 44, F[1], 40, 128);
    c.fillStyle = dark; c.fillRect(F[0] + 41, F[1], 4, 128); c.fillRect(F[0] + 83, F[1], 4, 128);
    c.fillStyle = gxShade(c1, -0.2); c.beginPath(); c.moveTo(F[0] + 30, F[1]); c.lineTo(F[0] + 45, F[1] + 36); c.lineTo(F[0] + 45, F[1]); c.fill(); c.beginPath(); c.moveTo(F[0] + 98, F[1]); c.lineTo(F[0] + 83, F[1] + 36); c.lineTo(F[0] + 83, F[1]); c.fill();
    for (const rg of ["R", "L"]) for (const f of ["front", "back", "left", "right"]) { const r = CLOTH_MAP[rg][f]; c.fillStyle = dark; c.fillRect(r[0], r[1] + r[3] - 10, r[2], 10); }
  } else if (kind === "jersey") {
    for (const rg of ["R", "L"]) for (const f of ["front", "back", "left", "right"]) { const r = CLOTH_MAP[rg][f]; c.fillStyle = c2; c.fillRect(r[0], r[1] + 30, r[2], 10); c.fillRect(r[0], r[1] + 46, r[2], 5); }
    for (const f of ["right", "left"]) { const r = CLOTH_MAP.T[f]; c.fillStyle = c2; c.fillRect(r[0] + 26, r[1], 12, r[3]); }
    c.font = "bold 76px Impact, 'Arial Black', sans-serif"; c.textAlign = "center"; c.textBaseline = "middle"; c.lineWidth = 6; c.strokeStyle = dark; c.fillStyle = c2;
    for (const [r, n] of [[F, "1"], [B, "1"]]) { c.strokeText(n, r[0] + 64, r[1] + 70); c.fillText(n, r[0] + 64, r[1] + 70); }
    c.fillStyle = c2; c.beginPath(); c.moveTo(F[0] + 44, F[1]); c.lineTo(F[0] + 64, F[1] + 18); c.lineTo(F[0] + 84, F[1]); c.fill();
  } else if (kind === "ninja") {
    c.fillStyle = c2; c.save(); c.translate(F[0] + 64, F[1] + 64); c.rotate(-0.5); c.fillRect(-110, -9, 220, 18); c.restore();
    c.fillStyle = c2; for (const f of ["front", "back", "left", "right"]) { const r = CLOTH_MAP.T[f]; c.fillRect(r[0], r[1] + 92, r[2], 14); }
    c.strokeStyle = light; c.lineWidth = 2; for (const rg of ["R", "L"]) for (const f of ["front", "back", "left", "right"]) { const r = CLOTH_MAP[rg][f]; for (let y = r[1] + 70; y < r[1] + r[3] - 4; y += 9) { c.beginPath(); c.moveTo(r[0], y); c.lineTo(r[0] + r[2], y + 5); c.stroke(); } }
  } else if (kind === "knight") {
    for (const [rg, f, r] of all) { const g = c.createLinearGradient(r[0], r[1], r[0] + r[2], r[1] + r[3]); g.addColorStop(0, light); g.addColorStop(0.5, c1); g.addColorStop(1, dark); c.fillStyle = g; c.fillRect(r[0], r[1], r[2], r[3]);
      c.strokeStyle = dark; c.lineWidth = 2; for (let y = r[1] + 30; y < r[1] + r[3]; y += 30) { c.beginPath(); c.moveTo(r[0], y); c.lineTo(r[0] + r[2], y); c.stroke(); }
      c.fillStyle = light; for (let y = r[1] + 10; y < r[1] + r[3]; y += 30) { c.beginPath(); c.arc(r[0] + 8, y, 2.5, 0, 7); c.arc(r[0] + r[2] - 8, y, 2.5, 0, 7); c.fill(); } }
    c.fillStyle = c2; c.fillRect(F[0] + 56, F[1] + 18, 16, 92); c.fillRect(F[0] + 30, F[1] + 44, 68, 16);
  } else if (kind === "police") {
    for (const f of ["front", "back"]) { const r = CLOTH_MAP.T[f]; c.fillStyle = dark; c.fillRect(r[0], r[1] + 104, r[2], 12); c.fillStyle = "#d9b84a"; c.fillRect(r[0] + 56, r[1] + 104, 16, 12); }
    c.fillStyle = dark; c.fillRect(F[0] + 14, F[1] + 34, 34, 22); c.fillRect(F[0] + 80, F[1] + 34, 34, 22);
    c.fillStyle = "#e8c14a"; c.beginPath(); for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? 6 : 13; c.lineTo(F[0] + 31 + Math.cos(a) * rr, F[1] + 20 + Math.sin(a) * rr); } c.fill();
    c.fillStyle = dark; c.beginPath(); c.moveTo(F[0] + 44, F[1]); c.lineTo(F[0] + 64, F[1] + 26); c.lineTo(F[0] + 84, F[1]); c.fill();
  }
  for (const [, , r] of all) seamTop(r);
}
function gxDrawPants(c, kind, c1, c2) {
  if (kind === "none") return;
  const dark = gxShade(c1, -0.35), light = gxShade(c1, 0.15), legs = gxPanels(["R", "L"]);
  const torso = ["front", "back", "left", "right"].map(f => CLOTH_MAP.T[f]), bottom = CLOTH_MAP.T.bottom;
  const paint = (r, y0, y1, col) => { c.fillStyle = col; c.fillRect(r[0], r[1] + r[3] * y0, r[2], r[3] * (y1 - y0)); };
  for (const r of torso) paint(r, 0.78, 1, c1); c.fillStyle = c1; c.fillRect(bottom[0], bottom[1], bottom[2], bottom[3]);
  for (const [, f, r] of legs) { if (kind === "shorts" && f !== "top") paint(r, 0, 0.42, c1); else if (f === "bottom") { if (kind !== "shorts") paint(r, 0, 1, dark); } else paint(r, 0, 1, c1); }
  for (const r of torso) { c.fillStyle = kind === "armor" ? gxShade(c1, -0.5) : "#2a2420"; c.fillRect(r[0], r[1] + r[3] * 0.8, r[2], 9); }
  const fr = CLOTH_MAP.T.front; c.fillStyle = "#c9a227"; c.fillRect(fr[0] + 56, fr[1] + 102, 16, 10);
  if (kind === "jeans") {
    for (const [, f, r] of legs) if (f !== "top" && f !== "bottom") { c.strokeStyle = gxShade(c1, 0.3); c.setLineDash([4, 3]); c.lineWidth = 1.5; c.beginPath(); c.moveTo(r[0] + 6, r[1]); c.lineTo(r[0] + 6, r[1] + r[3]); c.moveTo(r[0] + r[2] - 6, r[1]); c.lineTo(r[0] + r[2] - 6, r[1] + r[3]); c.stroke(); c.setLineDash([]);
      const g = c.createLinearGradient(0, r[1], 0, r[1] + r[3]); g.addColorStop(0, "rgba(255,255,255,.08)"); g.addColorStop(0.5, "rgba(255,255,255,0)"); g.addColorStop(1, "rgba(0,0,0,.18)"); c.fillStyle = g; c.fillRect(r[0], r[1], r[2], r[3]); }
  } else if (kind === "sweats") {
    for (const rg of ["R", "L"]) { const r = CLOTH_MAP[rg][rg === "R" ? "right" : "left"]; c.fillStyle = c2; c.fillRect(r[0] + 26, r[1], 12, r[3]); }
    for (const [, f, r] of legs) if (f !== "top" && f !== "bottom") paint(r, 0.9, 1, dark);
  } else if (kind === "camo") {
    for (const [, , r] of legs) { const rnd = vxRand(r[0] * 7 + r[1]); for (let i = 0; i < r[2] * r[3] / 200; i++) { c.fillStyle = [c2, dark, light][i % 3]; c.beginPath(); c.ellipse(r[0] + rnd() * r[2], r[1] + rnd() * r[3], 6 + rnd() * 9, 4 + rnd() * 6, rnd() * 3, 0, Math.PI * 2); c.fill(); } }
  } else if (kind === "armor") {
    for (const [, f, r] of legs) { const g = c.createLinearGradient(r[0], 0, r[0] + r[2], 0); g.addColorStop(0, light); g.addColorStop(1, dark); c.fillStyle = g; c.fillRect(r[0], r[1], r[2], r[3]);
      c.strokeStyle = dark; c.lineWidth = 2; for (let y = r[1] + 32; y < r[1] + r[3]; y += 32) { c.beginPath(); c.moveTo(r[0], y); c.lineTo(r[0] + r[2], y); c.stroke(); } }
  }
}
// ---- characters: looks, presets
const GX_SKIN = { yellow: "#f5cd30", tan: "#d7a37a", light: "#f3c9a6", brown: "#8a5a3b", dark: "#5a3a26", white: "#f2f2f2", gray: "#a3a2a5", red: "#e0463c", blue: "#3a7bd5" };
function gxLook(o) { return Object.assign({ colors: { head: GX_SKIN.yellow, torso: "#0d69ac", rarm: GX_SKIN.yellow, larm: GX_SKIN.yellow, rleg: "#287f47", lleg: "#287f47" },
  face: "smile", faceImg: "", shirt: { kind: "none", c1: "#2f6fd6", c2: "#ffffff", img: "" }, pants: { kind: "none", c1: "#2a3f6e", c2: "#ffffff", img: "" }, tshirt: "", bevel: true, plastic: 0.55, acc: [], items: [] }, o || {}); }
const allSkin = c => ({ head: c, torso: c, rarm: c, larm: c, rleg: c, lleg: c });
const GX_PRESETS = [
  ["noob", "Noob", () => gxLook()],
  ["hero", "Blue hero", () => gxLook({ colors: allSkin("#4aa3ff"), face: "determined", acc: [{ kind: "spiky", color: "#1f5fb8" }] })],
  ["dummy", "Red dummy", () => gxLook({ colors: allSkin("#e8473f"), face: "none" })],
  ["fighter", "Fighter", () => gxLook({ colors: allSkin(GX_SKIN.light), face: "grin", shirt: { kind: "hoodie", c1: "#1f2128", c2: "#ffffff", img: "" }, pants: { kind: "jeans", c1: "#2c4c80", c2: "#ffffff", img: "" }, acc: [{ kind: "swoop", color: "#6a3d1e" }] })],
  ["classic", "Classic", () => gxLook({ colors: allSkin(GX_SKIN.tan), face: "smug", shirt: { kind: "tee", c1: "#6b4b33", c2: "#ffffff", img: "" }, pants: { kind: "pants", c1: "#2b2b2f", c2: "#ffffff", img: "" } })],
  ["knight", "Knight", () => gxLook({ colors: allSkin(GX_SKIN.light), face: "determined", shirt: { kind: "knight", c1: "#9aa3b2", c2: "#c9372c", img: "" }, pants: { kind: "armor", c1: "#8a93a2", c2: "#ffffff", img: "" }, acc: [{ kind: "helmet", color: "#9aa3b2" }] })],
  ["ninja", "Ninja", () => gxLook({ colors: allSkin(GX_SKIN.light), face: "angry", shirt: { kind: "ninja", c1: "#1c1d22", c2: "#c9372c", img: "" }, pants: { kind: "pants", c1: "#1c1d22", c2: "#ffffff", img: "" }, acc: [{ kind: "bandana", color: "#c9372c" }] })],
  ["agent", "Agent", () => gxLook({ colors: allSkin(GX_SKIN.light), face: "cool", shirt: { kind: "suit", c1: "#1d1f26", c2: "#b3262c", img: "" }, pants: { kind: "pants", c1: "#1d1f26", c2: "#ffffff", img: "" }, acc: [{ kind: "short", color: "#2a1d14" }] })],
  ["king", "King", () => gxLook({ colors: allSkin(GX_SKIN.light), face: "smug", shirt: { kind: "jacket", c1: "#7a1f2b", c2: "#e8c14a", img: "" }, pants: { kind: "pants", c1: "#3a1d24", c2: "#ffffff", img: "" }, acc: [{ kind: "crown", color: "#f2c230" }] })],
  ["shadow", "Shadow", () => gxLook({ colors: allSkin("#24262c"), face: "evil", shirt: { kind: "hoodie", c1: "#111216", c2: "#7d4cff", img: "" }, pants: { kind: "pants", c1: "#111216", c2: "#ffffff", img: "" }, acc: [{ kind: "horns", color: "#7d4cff" }] })],
  ["angel", "Angel", () => gxLook({ colors: allSkin(GX_SKIN.light), face: "happy", shirt: { kind: "tee", c1: "#f6f7fb", c2: "#ffffff", img: "" }, pants: { kind: "pants", c1: "#e9eaf2", c2: "#ffffff", img: "" }, acc: [{ kind: "halo", color: "#ffd84a" }, { kind: "wings", color: "#ffffff" }] })],
  ["athlete", "Athlete", () => gxLook({ colors: allSkin(GX_SKIN.brown), face: "grin", shirt: { kind: "jersey", c1: "#e8473f", c2: "#ffffff", img: "" }, pants: { kind: "shorts", c1: "#e8473f", c2: "#ffffff", img: "" }, acc: [{ kind: "cap", color: "#e8473f" }] })],
];
// ---- accessories and held items (built here from simple shapes, in a head / hand space)
const GX_ACC = [["spiky", "Spiky hair"], ["swoop", "Swoop hair"], ["short", "Short hair"], ["long", "Long hair"], ["cap", "Cap"], ["beanie", "Beanie"], ["crown", "Crown"], ["tophat", "Top hat"],
  ["headphones", "Headphones"], ["horns", "Horns"], ["halo", "Halo"], ["shades", "Shades"], ["helmet", "Knight helmet"], ["bandana", "Bandana"], ["wings", "Wings"], ["cape", "Cape"]];
const GX_ACC_JOINT = { wings: "Torso", cape: "Torso" };
const GX_ITEMS = [["sword", "Sword"], ["greatsword", "Greatsword"], ["katana", "Katana"], ["scythe", "Scythe"], ["axe", "Axe"], ["hammer", "Hammer"], ["knife", "Knife"],
  ["pistol", "Pistol"], ["sniper", "Sniper"], ["bat", "Bat"], ["shield", "Shield"]];
function gxMat(hex, o) { o = o || {}; return new THREE.MeshStandardMaterial({ color: linCol(hex), roughness: o.rough != null ? o.rough : 0.55, metalness: o.metal || 0, emissive: o.glow ? linCol(hex) : 0x000000, emissiveIntensity: o.glow ? 1.6 : 0, side: o.side || THREE.FrontSide }); }
function gxMesh(geo, mat, p, r, s) { const m = new THREE.Mesh(geo, mat); if (p) m.position.set(...p); if (r) m.rotation.set(r[0], r[1], r[2]); if (s) m.scale.set(...s); m.castShadow = true; m.receiveShadow = true; return m; }
function gxAccessory(kind, color) { // positioned on a head whose centre is at 0 (the head is ~1.24 across and 1.2 high)
  const g = new THREE.Group(), M = gxMat(color, { rough: 0.6, side: THREE.DoubleSide }), metal = gxMat(color, { rough: 0.3, metal: 0.7 }), H = GX_HEAD;
  const cap = (cut, t) => { // a shell over the top of the head, from the hairline (cut) up, following the head's rounded edge
    const R = H.r + t, C = H.c + t, top = H.h - H.c, pts = []; if (cut < top) pts.push(new THREE.Vector2(R, cut));
    const a0 = cut < top ? 0 : Math.asin(clamp((cut - top) / C, 0, 1));
    for (let i = 0; i <= 14; i++) { const a = a0 + (i / 14) * (Math.PI / 2 - a0); pts.push(new THREE.Vector2(H.r - H.c + Math.cos(a) * C, top + Math.sin(a) * C)); }
    pts.push(new THREE.Vector2(0, H.h + t)); return gxMesh(new THREE.LatheGeometry(pts, 56), M); };
  const back = t => gxMesh(new THREE.SphereGeometry(H.r + t, 40, 20, 0, Math.PI * 2, 0, Math.PI * 0.62), M, [0, 0.1, 0.1], [Math.PI / 2 + 0.25, 0, 0], [1, 1, 0.9]); // (the back and sides, under the shell)
  switch (kind) {
    case "spiky": g.add(cap(0.22, 0.05)); g.add(back(0.04)); for (let i = 0; i < 9; i++) { const a = i / 9 * Math.PI * 2, t = i % 2 ? 0.5 : 0.7;
      g.add(gxMesh(new THREE.ConeGeometry(0.2, t, 12), M, [Math.sin(a) * 0.4, 0.62 + (i % 2) * 0.05, Math.cos(a) * 0.4 + 0.05], [Math.cos(a) * 0.65, 0, -Math.sin(a) * 0.65])); }
      g.add(gxMesh(new THREE.ConeGeometry(0.22, 0.8, 12), M, [0, 0.86, 0.05])); for (let i = -2; i <= 2; i++) g.add(gxMesh(new THREE.ConeGeometry(0.11, 0.42, 10), M, [i * 0.18, 0.42, -0.6], [-2.2, 0, i * 0.15])); break;
    case "swoop": g.add(cap(0.26, 0.05)); g.add(back(0.05));
      g.add(gxMesh(new THREE.SphereGeometry(0.5, 32, 16), M, [0.1, 0.5, -0.44], [0.25, 0, -0.38], [1.05, 0.36, 0.55])); g.add(gxMesh(new THREE.SphereGeometry(0.4, 28, 14), M, [-0.36, 0.55, -0.36], [0.2, 0, 0.3], [0.7, 0.34, 0.5])); break;
    case "short": g.add(cap(0.27, 0.045)); g.add(back(0.03)); break;
    case "long": g.add(cap(0.24, 0.05)); g.add(back(0.05)); g.add(gxMesh(new THREE.CylinderGeometry(0.67, 0.62, 1.5, 32, 1, true, Math.PI * 0.3, Math.PI * 1.4), M, [0, -0.3, 0.04])); break;
    case "cap": g.add(cap(0.22, 0.07)); g.add(gxMesh(new THREE.CylinderGeometry(0.58, 0.58, 0.05, 32, 1, false, Math.PI * 0.62, Math.PI * 0.76), M, [0, 0.27, -0.25], null, [1, 1, 1.4]));
      g.add(gxMesh(new THREE.SphereGeometry(0.06, 12, 8), M, [0, 0.66, 0])); break;
    case "beanie": g.add(cap(0.14, 0.09)); g.add(gxMesh(new THREE.TorusGeometry(H.r + 0.06, 0.1, 12, 40), gxMat(gxShade(color, -0.2)), [0, 0.14, 0], [Math.PI / 2, 0, 0]));
      g.add(gxMesh(new THREE.SphereGeometry(0.16, 16, 10), gxMat("#ffffff"), [0, 0.86, 0])); break;
    case "crown": { const cr = new THREE.CylinderGeometry(0.5, 0.46, 0.32, 40, 1, true); g.add(gxMesh(cr, gxMat(color, { rough: 0.25, metal: 0.9, side: THREE.DoubleSide }), [0, 0.74, 0]));
      for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; g.add(gxMesh(new THREE.ConeGeometry(0.1, 0.32, 8), metal, [Math.sin(a) * 0.48, 1.04, Math.cos(a) * 0.48])); g.add(gxMesh(new THREE.SphereGeometry(0.055, 12, 8), gxMat(i % 2 ? "#e0263c" : "#2f7bff", { rough: 0.15 }), [Math.sin(a) * 0.5, 0.74, Math.cos(a) * 0.5])); } break; }
    case "tophat": g.add(gxMesh(new THREE.CylinderGeometry(0.46, 0.46, 0.7, 40), M, [0, 1, 0])); g.add(gxMesh(new THREE.CylinderGeometry(0.72, 0.72, 0.05, 40), M, [0, 0.66, 0]));
      g.add(gxMesh(new THREE.CylinderGeometry(0.465, 0.465, 0.12, 40), gxMat("#c9372c"), [0, 0.74, 0])); break;
    case "headphones": g.add(gxMesh(new THREE.TorusGeometry(0.7, 0.06, 12, 40, Math.PI), M, [0, 0.05, 0], [0, 0, 0])); for (const s of [-1, 1]) g.add(gxMesh(new THREE.CylinderGeometry(0.24, 0.24, 0.16, 24), gxMat(gxShade(color, -0.3)), [s * 0.68, 0, 0], [0, 0, Math.PI / 2])); break;
    case "horns": for (const s of [-1, 1]) { const curve = new THREE.QuadraticBezierCurve3(new THREE.Vector3(s * 0.35, 0.45, 0), new THREE.Vector3(s * 0.75, 0.7, 0), new THREE.Vector3(s * 0.6, 1.15, -0.1));
      g.add(gxMesh(new THREE.TubeGeometry(curve, 20, 0.09, 10), gxMat(color, { rough: 0.35 }))); g.add(gxMesh(new THREE.ConeGeometry(0.09, 0.2, 10), gxMat(color, { rough: 0.35 }), [s * 0.6, 1.2, -0.1])); } break;
    case "halo": { const m = new THREE.MeshBasicMaterial({ color: linCol(color).multiplyScalar(5) }); m.userData.glow = true; g.add(gxMesh(new THREE.TorusGeometry(0.55, 0.07, 16, 48), m, [0, 1.05, 0], [Math.PI / 2 - 0.15, 0, 0])); break; }
    case "shades": g.add(gxMesh(new THREE.BoxGeometry(1.1, 0.24, 0.06), gxMat("#111216", { rough: 0.15, metal: 0.3 }), [0, 0.08, -0.63])); g.add(gxMesh(new THREE.BoxGeometry(0.05, 0.05, 0.6), gxMat("#111216"), [0.55, 0.1, -0.33])); g.add(gxMesh(new THREE.BoxGeometry(0.05, 0.05, 0.6), gxMat("#111216"), [-0.55, 0.1, -0.33])); break;
    case "helmet": { g.add(gxMesh(new THREE.SphereGeometry(H.r + 0.1, 40, 24, 0, Math.PI * 2, 0, Math.PI * 0.62), metal, [0, 0.05, 0], null, [1, 1.12, 1]));
      g.add(gxMesh(new THREE.BoxGeometry(0.9, 0.08, 0.1), gxMat("#111216"), [0, 0.12, -0.7])); g.add(gxMesh(new THREE.BoxGeometry(0.12, 0.5, 0.08), metal, [0, -0.1, -0.72])); g.add(gxMesh(new THREE.ConeGeometry(0.08, 0.5, 8), gxMat("#c9372c"), [0, 0.95, 0.1], [0.3, 0, 0])); break; }
    case "bandana": g.add(gxMesh(new THREE.CylinderGeometry(H.r + 0.05, H.r + 0.05, 0.22, 40, 1, true), gxMat(color, { side: THREE.DoubleSide }), [0, 0.3, 0]));
      for (const s of [-1, 1]) g.add(gxMesh(new THREE.BoxGeometry(0.12, 0.5, 0.04), M, [s * 0.12, 0.05, 0.68], [0.35, 0, s * 0.35])); break;
    case "wings": for (const s of [-1, 1]) { const sh = new THREE.Shape(); sh.moveTo(0, 0); sh.quadraticCurveTo(1.2, 1.4, 2.4, 1.6); sh.quadraticCurveTo(2.0, 0.8, 2.2, 0.4); sh.quadraticCurveTo(1.6, 0.2, 1.8, -0.4); sh.quadraticCurveTo(1.0, -0.4, 0, 0);
      const w = gxMesh(new THREE.ExtrudeGeometry(sh, { depth: 0.08, bevelEnabled: true, bevelSize: 0.04, bevelThickness: 0.04, bevelSegments: 2 }), gxMat(color, { rough: 0.5 }), [s * 0.3, 0.3, 0.6], [0, s > 0 ? -0.5 : Math.PI + 0.5, 0]); g.add(w); } break;
    case "cape": { const cg = new THREE.PlaneGeometry(2.1, 3.6, 8, 12), pos = cg.attributes.position; for (let i = 0; i < pos.count; i++) { const y = pos.getY(i), x = pos.getX(i); pos.setZ(i, Math.sin((x + 1) * 2.4) * 0.06 + (1.8 - y) * 0.12); pos.setX(i, x * (1 + (1.8 - y) * 0.08)); }
      cg.computeVertexNormals(); g.add(gxMesh(cg, gxMat(color, { side: THREE.DoubleSide, rough: 0.7 }), [0, -0.75, 0.56])); break; }
  }
  return g;
}
function gxItem(kind, color) { // held along +Y from the grip (Motion's held models use the same space)
  const g = new THREE.Group(), steel = gxMat("#eef1f6", { rough: 0.28, metal: 0.55 }), dark = gxMat("#2a2228", { rough: 0.7 }), gold = gxMat("#d8a933", { rough: 0.3, metal: 0.9 }), C = color ? gxMat(color, { rough: 0.4, metal: 0.2 }) : null;
  const ext = (shape, depth, mat, p, r) => gxMesh(new THREE.ExtrudeGeometry(shape, { depth, bevelEnabled: true, bevelSize: 0.03, bevelThickness: 0.03, bevelSegments: 2 }), mat, p, r);
  const blade = (w, len, tip) => { const s = new THREE.Shape(); s.moveTo(-w, 0); s.lineTo(w, 0); s.lineTo(w, len - tip); s.lineTo(0, len); s.lineTo(-w, len - tip); s.closePath(); return s; };
  switch (kind) {
    case "sword": g.add(gxMesh(new THREE.CylinderGeometry(0.08, 0.08, 0.7, 12), dark, [0, 0, 0])); g.add(gxMesh(new THREE.BoxGeometry(0.75, 0.1, 0.16), C || gold, [0, 0.38, 0])); g.add(gxMesh(new THREE.SphereGeometry(0.11, 12, 8), C || gold, [0, -0.38, 0]));
      g.add(ext(blade(0.14, 2.9, 0.4), 0.03, steel, [0, 0.43, -0.015])); break;
    case "greatsword": g.add(gxMesh(new THREE.CylinderGeometry(0.11, 0.11, 1.0, 12), dark)); g.add(gxMesh(new THREE.BoxGeometry(1.3, 0.2, 0.26), C || gold, [0, 0.55, 0])); g.add(gxMesh(new THREE.BoxGeometry(0.24, 0.16, 0.24), C || gold, [0, -0.56, 0]));
      g.add(ext(blade(0.42, 4.2, 0.6), 0.1, steel, [0, 0.65, -0.05])); break;
    case "katana": { g.add(gxMesh(new THREE.CylinderGeometry(0.07, 0.07, 0.9, 12), dark)); g.add(gxMesh(new THREE.CylinderGeometry(0.2, 0.2, 0.05, 20), C || gold, [0, 0.47, 0]));
      const s = new THREE.Shape(); s.moveTo(-0.08, 0); s.lineTo(0.08, 0); s.quadraticCurveTo(0.2, 1.6, 0.05, 3.3); s.lineTo(-0.06, 3.1); s.quadraticCurveTo(0.06, 1.6, -0.08, 0); g.add(ext(s, 0.02, steel, [0, 0.5, -0.01])); break; }
    case "scythe": { g.add(gxMesh(new THREE.CylinderGeometry(0.07, 0.07, 4.6, 12), C || gxMat("#2a3a8c", { rough: 0.4 }), [0, 1.3, 0])); g.add(gxMesh(new THREE.TorusGeometry(0.1, 0.04, 8, 16), gold, [0, 3.62, 0], [Math.PI / 2, 0, 0]));
      const s = new THREE.Shape(); s.moveTo(0, 0); s.quadraticCurveTo(1.6, 0.9, 2.6, -0.4); s.quadraticCurveTo(1.6, 0.3, 0, -0.3); s.closePath(); g.add(ext(s, 0.04, steel, [0, 3.6, -0.02], [0, 0, 0])); break; }
    case "axe": { g.add(gxMesh(new THREE.CylinderGeometry(0.08, 0.09, 2.4, 12), gxMat("#6b4426", { rough: 0.8 }), [0, 0.7, 0]));
      const s = new THREE.Shape(); s.moveTo(0, -0.3); s.quadraticCurveTo(0.6, -0.5, 1.0, -0.8); s.quadraticCurveTo(1.2, 0, 1.0, 0.8); s.quadraticCurveTo(0.6, 0.5, 0, 0.3); s.closePath(); g.add(ext(s, 0.08, steel, [0.05, 1.6, -0.04])); break; }
    case "hammer": g.add(gxMesh(new THREE.CylinderGeometry(0.08, 0.09, 2.2, 12), gxMat("#6b4426", { rough: 0.8 }), [0, 0.6, 0])); g.add(gxMesh(new THREE.BoxGeometry(0.6, 0.6, 1.1), C || gxMat("#7a8494", { rough: 0.35, metal: 0.8 }), [0, 1.85, 0])); break;
    case "knife": g.add(gxMesh(new THREE.CylinderGeometry(0.07, 0.07, 0.5, 12), dark)); g.add(gxMesh(new THREE.BoxGeometry(0.3, 0.06, 0.12), C || dark, [0, 0.27, 0])); g.add(ext(blade(0.1, 0.9, 0.25), 0.02, steel, [0, 0.3, -0.01])); break;
    case "pistol": g.add(gxMesh(new THREE.BoxGeometry(0.16, 0.5, 0.24), dark, [0, 0, 0], [0.25, 0, 0])); g.add(gxMesh(new THREE.BoxGeometry(0.17, 0.26, 0.85), C || gxMat("#3a3d45", { rough: 0.35, metal: 0.7 }), [0, 0.3, -0.25])); break;
    case "sniper": { const body = C || gxMat("#3b4a2c", { rough: 0.5, metal: 0.3 }); g.add(gxMesh(new THREE.BoxGeometry(0.16, 0.45, 0.22), dark, [0, 0, 0], [0.3, 0, 0])); g.add(gxMesh(new THREE.BoxGeometry(0.2, 0.3, 1.6), body, [0, 0.3, -0.3]));
      g.add(gxMesh(new THREE.CylinderGeometry(0.06, 0.07, 1.8, 12), gxMat("#26282e", { rough: 0.3, metal: 0.8 }), [0, 0.36, -1.9], [Math.PI / 2, 0, 0])); g.add(gxMesh(new THREE.CylinderGeometry(0.11, 0.11, 0.8, 16), gxMat("#26282e", { rough: 0.3, metal: 0.7 }), [0, 0.6, -0.3], [Math.PI / 2, 0, 0]));
      g.add(gxMesh(new THREE.BoxGeometry(0.18, 0.3, 0.6), body, [0, 0.25, 0.75])); break; }
    case "bat": g.add(gxMesh(new THREE.CylinderGeometry(0.2, 0.07, 3.0, 20), C || gxMat("#c48a4a", { rough: 0.6 }), [0, 1.2, 0])); g.add(gxMesh(new THREE.SphereGeometry(0.2, 16, 10), C || gxMat("#c48a4a", { rough: 0.6 }), [0, 2.7, 0])); break;
    case "shield": g.add(gxMesh(new THREE.CylinderGeometry(1.0, 1.0, 0.16, 40), C || gxMat("#8a2a2a", { rough: 0.5 }), [0, 0.6, 0], [Math.PI / 2, 0, 0])); g.add(gxMesh(new THREE.TorusGeometry(1.0, 0.08, 10, 40), gold, [0, 0.6, 0]));
      g.add(gxMesh(new THREE.SphereGeometry(0.22, 16, 10), gold, [0, 0.6, -0.08])); break;
  }
  return g;
}
// ---- poses (degrees about each joint, in the order the core uses: X, then Y, then Z)
const GX_POSES = [
  ["stand", "Stand", {}],
  ["hero", "Hero", { "Right Arm": [0, 0, 18], "Left Arm": [0, 0, -18], Head: [8, 0, 0], "Right Leg": [0, 0, 6], "Left Leg": [0, 0, -6] }],
  ["ready", "Weapon ready", { Torso: [-6, -15, 0], "Right Arm": [40, 0, 10], "Left Arm": [20, 0, -10], "Right Leg": [-12, 0, 6], "Left Leg": [14, 0, -6], Head: [0, 15, 0] }],
  ["slash", "Slash", { Torso: [-10, 30, 0], Head: [0, -20, 0], "Right Arm": [80, 0, -45], "Left Arm": [-30, 0, -25], "Right Leg": [25, 0, 8], "Left Leg": [-25, 0, -8] }],
  ["overhead", "Overhead strike", { Torso: [10, -10, 0], Head: [10, 10, 0], "Right Arm": [165, 0, 10], "Left Arm": [150, 0, -15], "Right Leg": [-15, 0, 8], "Left Leg": [20, 0, -8] }],
  ["raise", "Sword raised", { "Right Arm": [0, 0, 165], "Left Arm": [0, 0, -18], Head: [10, 0, 0], "Right Leg": [0, 0, 8], "Left Leg": [0, 0, -8] }],
  ["point", "Point", { Torso: [0, 12, 0], "Right Arm": [90, 0, 0], "Left Arm": [0, 0, -8], Head: [0, -12, 0] }],
  ["run", "Run", { Torso: [-14, 0, 0], "Right Arm": [-55, 0, 6], "Left Arm": [55, 0, -6], "Right Leg": [45, 0, 0], "Left Leg": [-45, 0, 0], Head: [10, 0, 0] }],
  ["dash", "Dash", { Torso: [-28, 0, 0], "Right Arm": [-70, 0, 10], "Left Arm": [-70, 0, -10], "Right Leg": [35, 0, 0], "Left Leg": [-45, 0, 0], Head: [22, 0, 0] }],
  ["jump", "Jump", { "Right Arm": [10, 0, 150], "Left Arm": [10, 0, -150], "Right Leg": [35, 0, 6], "Left Leg": [-15, 0, -6], Head: [12, 0, 0] }],
  ["hit", "Knocked back", { Torso: [24, 0, -8], Head: [26, 0, 10], "Right Arm": [40, 0, 70], "Left Arm": [55, 0, -60], "Right Leg": [30, 0, 10], "Left Leg": [10, 0, -12] }],
  ["guard", "Guard", { Torso: [-6, 0, 0], "Right Arm": [95, 0, -40], "Left Arm": [95, 0, 40], "Right Leg": [-10, 0, 8], "Left Leg": [12, 0, -8] }],
  ["aim", "Aim", { Torso: [0, 30, 0], Head: [0, -30, 0], "Right Arm": [90, 0, -8], "Left Arm": [85, 0, -45], "Right Leg": [-10, 0, 8], "Left Leg": [10, 0, -6] }],
  ["wave", "Wave", { "Right Arm": [0, 0, 150], "Left Arm": [0, 0, -6], Head: [0, 0, -8] }],
  ["flex", "Flex", { "Right Arm": [20, 0, 100], "Left Arm": [20, 0, -100], Head: [10, 0, 0], "Right Leg": [0, 0, 8], "Left Leg": [0, 0, -8] }],
  ["victory", "Victory", { "Right Arm": [0, 0, 155], "Left Arm": [0, 0, -155], Head: [18, 0, 0], "Right Leg": [0, 0, 10], "Left Leg": [0, 0, -10] }],
  ["scared", "Scared", { Torso: [12, 0, 0], "Right Arm": [150, 0, -25], "Left Arm": [150, 0, 25], Head: [-10, 0, 0], "Right Leg": [-6, 0, 10], "Left Leg": [6, 0, -10] }],
  ["sit", "Sit", { "Right Leg": [90, 0, 0], "Left Leg": [90, 0, 0], "Right Arm": [35, 0, 4], "Left Arm": [35, 0, -4] }],
  ["dab", "Dab", { Torso: [-8, 0, -6], Head: [-35, 0, -30], "Right Arm": [125, 0, 55], "Left Arm": [100, 0, -75] }],
  ["think", "Think", { Head: [8, 0, 12], "Right Arm": [125, 0, -20], "Left Arm": [40, 0, -10] }],
];
function gxPoseFrom(def) { // degrees per joint -> the core's pose ({ joint: { q, p } })
  const pose = {}; for (const j of J) { const d = def[j] || [0, 0, 0]; pose[j] = { q: R.qFromEuler(d[0], d[1], d[2]), p: [0, 0, 0] }; } return pose;
}
// ---- building one character
const gxFaceCache = new Map(), gxImgCache = new Map();
function gxImage(asset) { // an imported image (texture, face, shirt): an <img> that loads once
  if (!asset) return null; let e = gxImgCache.get(asset); if (e) return e;
  const img = new Image(); img.crossOrigin = "anonymous"; e = { img, ok: false, waiters: [] };
  const done = ok => { e.ok = ok; e.failed = !ok; for (const w of e.waiters) w(); e.waiters.length = 0; if (typeof gxDirtyAll === "function") gxDirtyAll(); };
  img.onload = () => done(true); img.onerror = () => done(false); img.src = blobUrl(asset); gxImgCache.set(asset, e); return e;
}
function gxWhenImages(assets, then) { let n = 0; for (const a of assets) { const e = gxImage(a); if (e && !e.ok && !e.failed) { n++; e.waiters.push(() => { if (--n === 0) then(); }); } } return n === 0; }
function gxClothAtlas(look, upper) { // the template-sized canvas a character's torso and arms (upper) or legs read
  const cv = document.createElement("canvas"); cv.width = CLOTH_W * CLOTH_SCALE; cv.height = CLOTH_H * CLOTH_SCALE; const c = cv.getContext("2d"); c.scale(CLOTH_SCALE, CLOTH_SCALE);
  const col = look.colors, paint = (rg, hex) => { c.fillStyle = hex; for (const f of BOX_FACES) { const r = CLOTH_MAP[rg][f]; c.fillRect(r[0] - 1, r[1] - 1, r[2] + 2, r[3] + 2); } };
  if (upper) { paint("T", col.torso); paint("R", col.rarm); paint("L", col.larm); } else { paint("R", col.rleg); paint("L", col.lleg); }
  const clip = regs => { c.save(); c.beginPath(); for (const rg of regs) for (const f of BOX_FACES) { const r = CLOTH_MAP[rg][f]; c.rect(r[0] - 1, r[1] - 1, r[2] + 2, r[3] + 2); } c.clip(); };
  const layer = (spec, draw, regs) => { // a template image, or a built-in style
    clip(regs);
    if (spec.img) { const e = gxImage(spec.img); if (e && e.ok) c.drawImage(e.img, 0, 0, CLOTH_W, CLOTH_H); }
    else draw(c, spec.kind, spec.c1, spec.c2);
    c.restore();
  };
  if (upper) { layer(look.pants, gxDrawPants, ["T"]); layer(look.shirt, gxDrawShirt, ["T", "R", "L"]);
    if (look.tshirt) { const e = gxImage(look.tshirt), r = CLOTH_MAP.T.front; if (e && e.ok) c.drawImage(e.img, r[0] + 4, r[1] + 4, r[2] - 8, r[3] - 8); } }
  else layer(look.pants, gxDrawPants, ["R", "L"]);
  const tex = new THREE.CanvasTexture(cv); tex.encoding = THREE.sRGBEncoding; tex.anisotropy = 8; tex.gxOwn = true; return tex;
}
function gxFaceTex(look) {
  const key = look.faceImg ? "u:" + look.faceImg : look.face; let t = gxFaceCache.get(key); if (t) return t;
  const cv = document.createElement("canvas"); cv.width = 590; cv.height = 440; const c = cv.getContext("2d"); // (the strip's own shape: 1.34 wide for 1 tall)
  if (look.faceImg) { const e = gxImage(look.faceImg); if (e && e.ok) { const s = Math.min(cv.width / e.img.naturalWidth, cv.height / e.img.naturalHeight); c.drawImage(e.img, (cv.width - e.img.naturalWidth * s) / 2, (cv.height - e.img.naturalHeight * s) / 2, e.img.naturalWidth * s, e.img.naturalHeight * s); } }
  else gxDrawFace(c, look.face, cv.width, cv.height);
  t = new THREE.CanvasTexture(cv); t.encoding = THREE.sRGBEncoding; t.anisotropy = 8; t.gxShared = true; gxFaceCache.set(key, t); return t;
}
const gxImports = new Map(); // an imported 3D model (OBJ / GLB) -> its loaded group, shared
function gxBuildChar(look, extra) { // -> { root, joints, holds, meshes } (the same joint tree as Motion's rig, so its poses fit)
  const root = new THREE.Group(), joints = {}, holds = {}, meshes = [];
  const torso = new THREE.Group(); root.add(torso); joints.Torso = torso; const tskin = new THREE.Group(); torso.add(tskin); holds.Torso = tskin; // (the torso's own part and what it wears)
  for (const j of J.slice(1)) { const piv = new THREE.Group(); piv.position.set(...R.PIVOT[j]); torso.add(piv); joints[j] = piv; const h = new THREE.Group(); h.position.set(...R.OFFSET[j]); piv.add(h); holds[j] = h; }
  const upper = gxClothAtlas(look, true), lower = gxClothAtlas(look, false), rough = clamp(look.plastic, 0.05, 1);
  const mats = { upper: new THREE.MeshStandardMaterial({ map: upper, roughness: rough, metalness: 0 }), lower: new THREE.MeshStandardMaterial({ map: lower, roughness: rough, metalness: 0 }) };
  for (const j of ["Torso", "Right Arm", "Left Arm", "Right Leg", "Left Leg"]) {
    const w = j === "Torso" ? 2 : 1, m = new THREE.Mesh(gxPartGeo(w, 2, 1, GX_PART_REGION[j], look.bevel), j.endsWith("Leg") ? mats.lower : mats.upper);
    m.castShadow = m.receiveShadow = true; m.userData.joint = j; holds[j].add(m); meshes.push(m);
  }
  const head = new THREE.Mesh(gxHeadGeo(), new THREE.MeshStandardMaterial({ color: linCol(look.colors.head), roughness: rough, metalness: 0 }));
  head.castShadow = head.receiveShadow = true; head.userData.joint = "Head"; holds.Head.add(head); meshes.push(head);
  const face = new THREE.Mesh(gxFaceGeo(), new THREE.MeshStandardMaterial({ map: gxFaceTex(look), transparent: true, roughness: rough, metalness: 0, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2 }));
  face.userData.joint = "Head"; face.renderOrder = 2; holds.Head.add(face);
  for (const a of look.acc || []) {
    let g = null;
    if (a.kind === "import") { const im = gxImports.get(a.model); if (im) g = im.clone(true); }
    else if (a.kind === "model") { const m = models.get(a.model); if (m) g = gxModelGroup(m); }
    else g = gxAccessory(a.kind, a.color || "#333333");
    if (!g) continue;
    const holder = new THREE.Group(), jn = a.joint || GX_ACC_JOINT[a.kind] || "Head";
    if (a.p) holder.position.set(...a.p); if (a.r) holder.rotation.set(a.r[0] * DEG, a.r[1] * DEG, a.r[2] * DEG); if (a.s) holder.scale.set(...a.s);
    g.traverse(n => { if (n.isMesh) { n.castShadow = n.receiveShadow = true; n.userData.joint = jn; } });
    holder.add(g); (holds[jn] || holds.Head).add(holder);
  }
  for (const it of look.items || []) { // held things: a hand (or the back) and where in it
    let g = null; const jn = holds[it.joint] ? it.joint : "Right Arm";
    if (it.kind === "model") { const m = models.get(it.model); if (m) g = gxModelGroup(m); }
    else if (it.kind === "import") { const im = gxImports.get(it.model); if (im) g = im.clone(true); }
    else g = gxItem(it.kind, it.color || null);
    if (!g) continue;
    const fit = gxItemFit(it.kind, jn), h = new THREE.Group(), p = it.p || fit.p, r = it.r || fit.r, s = it.s || [1, 1, 1];
    h.position.set(...p); h.rotation.set(r[0] * DEG, r[1] * DEG, r[2] * DEG); h.scale.set(...s);
    g.traverse(n => { if (n.isMesh) { n.castShadow = n.receiveShadow = true; n.userData.joint = jn; } }); h.add(g); holds[jn].add(h);
  }
  root.userData.mats = mats;
  return { root, joints, holds, meshes, atlases: [upper, lower] };
}
function gxItemFit(kind, joint) { // where a held thing sits by default (the same grip as Motion's held models)
  if (joint === "Torso") return { p: [0, 0, 0.62], r: [0, 0, kind === "shield" ? 0 : 35] };
  if (kind === "shield") return { p: [joint === "Left Arm" ? -0.62 : 0.62, -0.9, 0], r: [0, 90, 0] };
  return { p: [0, -1.05, 0], r: [-90, 0, 0] }; // (Motion's grip: pointing out of the hand, the flat of a blade toward the camera; "Turn 90°" turns it)
}
function gxModelGroup(model) { // a Farshtah model (Motion's Model tab), in smooth plastic, metal or neon
  const g = new THREE.Group();
  model.parts.forEach(pt => { const m = new THREE.Mesh(shapeGeo(pt.shape), pt.glow ? gxPartMat("neon", pt.color) : gxMat(pt.color, { rough: 0.45 }));
    m.position.set(pt.p[0], pt.p[1], pt.p[2]); m.rotation.set(pt.r[0] * DEG, pt.r[1] * DEG, pt.r[2] * DEG); m.scale.set(pt.s[0], pt.s[1], pt.s[2]); m.castShadow = m.receiveShadow = true; g.add(m); });
  return g;
}
function gxDisposeTree(o) { // geometry, materials and their own textures (shared ones stay)
  o.traverse(n => { if (!n.isMesh && !n.isSprite) return;
    if (n.geometry && !n.geometry.userData.shared) n.geometry.dispose();
    for (const m of [].concat(n.material)) if (m && !m.userData.shared) { for (const k of ["map", "emissiveMap", "alphaMap"]) if (m[k] && m[k].gxOwn) m[k].dispose(); m.dispose(); } });
}
function gxDisposeChar(ch) { if (!ch) return; gxDisposeTree(ch.root); for (const t of ch.atlases || []) t.dispose(); }
